﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/22/2015 1:32 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$array = @()
$events = Get-WinEvent -FilterHashtable @{logname="Security"; id=4625}

foreach ($event in $events)
{
	# get the first event raw XML
	#$event = [xml]$events[0].ToXml()
	$xmlevent = [xml]$event.ToXml()
	# display its content
	#$event.Event.EventData.Data
	$array += $xmlevent.Event.EventData.data
}

$array | Export-Csv c:\temp\eventdata.csv

