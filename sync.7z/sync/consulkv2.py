import argparse
import requests
import logging
import sys
import os
import ast
import base64

logging.basicConfig(level=logging.INFO)

parser = argparse.ArgumentParser(description='Modify Consul CMDB KV Store')
parser.add_argument('--project', required=True, type=str, help='Specify a project name')
parser.add_argument('--department', required=True, type=str, help='Specify a department name')
parser.add_argument('--component', type=str, help='Specify a component name')
parser.add_argument('--artifactorylabel', required=True, type=str, help='Specify an artifactory label')
parser.add_argument('--environment', required=False, type=str, help='Specify an environment', default='dev')
parser.add_argument('--file', type=str, help='Specify a file for configs')
#parser.add_argument('--data', type=dict, help='Specify a file for configs',default={})
#parser.add_argument('--d', type=json.loads)
parser.add_argument('--data', type=str, default="")
parser.add_argument('--force', type=str, default="")

args = parser.parse_args()
#argsdata = parser.parse_args(['d'])


#define variables from arguments
project = args.project
department = args.department
component = args.component
environment = args.environment
artifactorylabel = args.artifactorylabel
force = args.artifactorylabel
file = args.file
#Take the data string (formatted as a dictionary) and turn it into an actual dictionary
if args.data != "":
     data = ast.literal_eval(args.data)
else:
      data = {}

#Write to the consul CMDB KV store with the full artifactory path, the package version key will be tagged with the buildlabel argument
#default value for builds - if environment is null then default to dev
if file:
     basepath = "http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel, filename)
else
     basepath = "http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel)



#If we have a config file create a new directory with the config file name and set all the kvs under it
file_data = {}
if file:
     if os.path.exists(file):
         fp = open(file, "r")
         content = fp.read()
         fp.close()
     for line in content.splitlines():
	     if line.rfind("=") != -1:
	         key = line.split("=")[0]
	         value = line.split("=")[1]
	         #print "the key is %s" % key
	         #print "the value is %s" % value
	         file_data.update({key: value})

final_data = file_data.update(data)
#for item in data
#   item.key
#   item.value#

#for key, value in data.iteritems():
#   print "%s - %s" % (key, value)
#   logging.info("INFO: Writing to CMDB at: http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel, key))
#   r=requests.put("http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/" % (department, project, component, environment, artifactorylabel, key), verify=False, data=value)

r=requests.get("http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/client_facing_tech/aml/client/beta/LATEST-dev/version")
cmbdvalue = base64.b64decode(r.json()[0].get("Value").encode('ascii'))


for key, value in final_data.iteritems():
	update = False
    try:
	      r=requests.get("%s/%s" % (basepath, key))
          cmbdvalue = base64.b64decode(r.json()[0].get(key).encode('ascii'))
          if cmdbvalue == value:
               logging.info("Skipping insert into CMDB value already exists")
               update = False
          else:
               print "%s - %s" % (key, value)
               logging.info("Writing to CMDB at: %s/%s" % (basepath, key))
               update = True
    except requests.exceptions.HTTPError as e:
        logging.info("Tried to look up key and failed")
        update = True
    if update:
        try:
            r=requests.put("%s/%s" % (basepath, key), verify=False, data=value)
        except requests.exceptions.HTTPError as e:
            logging.exception("ERR: Failed to set key value")
            sys.exit(1)

          
     
