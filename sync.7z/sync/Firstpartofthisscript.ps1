﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/15/2016 5:32 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$array = @()
foreach ($i in $linkhashtable.values)
{
	$object = "" | select Namespacetop, NamespaceFolder, FolderTarget
	$namespacetop = $i.linkparent + "\" + $i.linkname
	$object.namespacetop = $namespacetop
	$object.Namespacefolder = $i.linkname
	foreach ($target in ($linktargethashtable.values | where { $_.linktargetparent -eq $i.linkname }))
	{
		$object.Foldertarget = $target.linktargetname
	}
	$array += $object
}

$domain = "pimco.imswest.sscims.com"
$dfsutilnamespace = dfsutil domain $domain
$namespaces = ($dfsutilnamespace | where { $_ -notlike "" -and $_ -notlike "Roots on Domain*" -and $_ -notlike "Done with Roots on Domain*" -and $_ -notlike "Done Processing*"}) | foreach { $_.trimstart("") }

$array = @()
$toplevel = @()
foreach ($name in $namespaces)
{
	dfsutil.exe root export "\\$domain\$name" c:\temp\xmlout.XML
	
	[xml]$a = get-content C:\temp\xmlout.XML
	$object = "" | select Namespace, Targets, TargetStatus
	$object.Namespace = $a.root.name
	$object.Targets = [string]$a.root.target."#text" -replace " ", ", "
	$object.TargetStatus = [string]$a.root.target."state" -replace " ", ", "
	$toplevel += $object
	
	foreach ($link in $a.root.link)
	{
		Write-Host "Getting link information for $($link.name)"
		$linkstats = $a.root.link | where { $_.name -eq $link.name }
		$object = "" | select Namespace, Linkname, FullPath, Targets, TargetStatus
		$object.Namespace = $a.root.name
		$object.Linkname = $linkstats.name
		$object.FullPath = $a.root.name + "\" + $linkstats.name
		$object.Targets = [string]$linkstats.target."#text" -replace " ", ", "
		$object.TargetStatus = [string]$linkstats.target."state" -replace " ", ", "
		$array += $object
		$object
	}
}