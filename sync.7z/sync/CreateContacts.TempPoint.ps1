﻿
add-pssnapin quest.activeroles.admanagement
connect-qadservice pimco.imswest.sscims.com

$objects = import-csv C:\temp\LyncContacts.csv

123
58
55
54
44
foreach ($contact in $objects[44])
{
    #new-qadobject -type contact -ParentContainer "OU=Conference,OU=PIMCO External Contacts,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com" -Name $($contact.name)
    get-qadobject -Type contact -name $($contact.name) | set-qadobject -ObjectAttributes @{"msRTCSIP-PrimaryUserAddress"="sip:$($contact.sip)"}
    get-qadobject -Type contact -name $($contact.name) | set-qadobject -ObjectAttributes @{mail="$($contact.email)"}
}


$objects = import-csv C:\temp\LyncContacts.csv
foreach ($contact in $objects[44])
{
    #Exchange mail enable contact
    Enable-mailcontact -identity $($contact.name) -externalemailaddress $($contact.email)
}

foreach ($contact in $objects)
{
	get-qadobject -Type contact -name $($contact.name) -IncludedProperties msRTCSIP-PrimaryUserAddress, Mail | select Displayname, msRTCSIP-PrimaryUserAddress, Mail, type
}