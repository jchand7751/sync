﻿<#
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/28/2015 1:24 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   	preOSinit.ps1  	
	===========================================================================
	.DESCRIPTION
		OS init update and launch
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer
)


#endregion

#region Base variables and environment information
$logfile = "c:\temp\PreOSinit.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$server = hostname
$whoami = whoami

#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	#Import-module BitsTransfer -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions


function SetupGit
{
	mkdir C:\Users\Administrator\.ssh
	$File = New-Item -Type File -Name "known_hosts" -Path "C:\Users\Administrator\.ssh"
	$File | Set-Content -Value "[pimcocm.pimco.imswest.sscims.com]:29418,[144.77.120.103]:29418 ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAxgxagfLOjW26DNwnOXIY3M73/bHJhf4N/DoBAhmeT0ocV+ionQ4P7moaGyKXCcd3gAOd8sPOf2ZfOOrQOcBl998FznmHNzd3wqw6bTb+ahdl//BqzuNYw1XFYV5dmxHGy77uY9YtjaeBYRcuX/fCYIBR0UebZRMNGNSXL68RF6usbRNC7tRUmYP/63QQshTTry5g9owRQEbzxzniJgGPvitqy/iGLntk98+lDrYLdumXFOX1zFwWOySwQvfqXIS3Kr32ufVCSDFjq41l0yvo+bLeTjB9N8BgA4CPzHUieZBV9t2YEAKRCNYRWUjXmJuNax29AW8thaQUWy3DPT3t1Q=="
	$File = New-Item -Type File -Name "id_rsa.pub" -Path "C:\Users\Administrator\.ssh"
	$File | Set-Content -Value "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDV2sQeHoqi1pIO64Mb0W2smptcvJQbuzn962il1pkRnrHtiQAlFOlbxmxf3Qee/xDMhOYXS/Hbln16o8d50BxzXdhtf6BcYyZhtj+O4y11fq5tNNUlfIvJxCbNlqQASRSVymIKB+8SDhAGHsAIPuG/JRurt1nV8oOhMFUQZOMwVKUDIRDh1Gi18NscFKiTvRvpdykeC5mmcXXw/oC/ZnVDMVKsffk8CTqTIdVDWgiHOBmGZOVONmpS8KnRWjAETVEJ/MCJoDFbItLY+8px9rWY8gl/koI5si8PYsyIMI/+g9WU3yt+POxOIDUtZlNj7VoE3e3Ram/U57ylAK1HHc7t CLV035SW-68A325+Administrator@clv035sw-68a325"
	$File = New-Item -Type File -Name "id_rsa" -Path "C:\Users\Administrator\.ssh"
	$File | Set-Content -value "-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA1drEHh6KotaSDuuDG9FtrJqbXLyUG7s5/etopdaZEZ6x7YkA
JRTpW8ZsX90Hnv8QzITmF0vx25Z9eqPHedAcc13YbX+gXGMmYbY/juMtdX6ubTTV
JXyLycQmzZakAEkUlcpiCgfvEg4QBh7ACD7hvyUbq7dZ1fKDoTBVEGTjMFSlAyEQ
4dRotfDbHBSok70b6XcpHguZpnF18P6Av2Z1QzFSrH35PAk6kyHVQ1oIhzgZhmTl
TjZqUvCp0VowBE1RCfzAiaAxWyLS2PvKcfa1mPIJf5KCObIvD2LMiDCP/oPVlN8r
fjzsTiA1LWZTY+1aBN3t0Wpv1Oe8pQCtRx3O7QIDAQABAoIBAGVOezVhdn9pckuL
GdLlxTTNEOg/lVIFwZUeHbbiECUerl8+VUk7vMhzGQfYpzGU1xproqxKl8pUYiDk
0SxNgAzO2iYVHZxmg9oqAbXovLI6TtsA+jAF7hqox1EBGbPg6tWCyCrEU2aULtcX
XhUJ5Nst8wvHkdEeT2jego1/nXhY4kmyAdSqaeV7GOo9tSZBcblbJmwYI7kGRMHI
tFsmkw27enrf8qcX8lkhvdozHZBe1w82VzHBC4nSbvbtHphjvXVRCKXSwYB1YeqG
h5GEcW3qHdA//hgOVAMRVCurro+WUTRDP4KDKVllJU7D8PgRzutjEJejx9Ry3vyv
QqsQlukCgYEA/vwkqijDUtyTVjhrH7moFqGtwGETO3T9b5yRvnsqNcQtsOdxURMe
BMQYNFYBIwag9T2rntKfHmb1YUgMba5DenxeKfX4XeQ7/kOgOrerAGkPzAFeRx5B
STQaxgdw0+bO6ycEUEyfi+xp41OAh6figwswQfCKqORxo2WuRPf6/8sCgYEA1rS0
5bg5QR/Cj2qbvHAmu5sHiPgWkNAemYiswwa/LHIdAsVPTbYEN1Vk98GWP1Yrp2A2
egS3l9Nkiwk2XIVIxYI0BPcBmH8sVvNjsOiWdOZNPYXfzqhb1mRyqaFSOmy6/qBq
Izs5Tma0f/Zq/BJNxW9QQ0hSvqzSwN9J+BSppScCgYBdrimSUrOgZ+XB0ayZ1U4K
MpBxk7jLKWpLbUymnP2fD1pyGjYpwUpQGfOClu6H/dF5CJVbHqrTMqSIfz4BtfqY
r8SwyevcIxRfkFz39a7f0bm6C+6lVlpKGNiVVPqA/9WZ05XkIqKjd9JXcMBSFr5D
wwKR11w6POP7Uko6kJkpDQKBgEBlInxjrIhjxi7NgrgZywQpkzD5d4snYIYb//Te
aSgjcaALHaXpGYqfChFk9nM4nQ8uRCiEkavvsxAgSzWkpBbY3lE+5DOgsOPDS/sb
R0T4beIt7NpGlITQy7Mkt0zen5cO9cZrVNy24RwgBCZmNv0oTaJgZrDZlLxUPBMz
302xAoGBANJVbMaVBUdQn+9On128kosJd+klMRlUJSinC2qpdP+JgJUBaeXa67fA
ikctXpdx6DhS6BKvBpKYVGYmKkXHN25Stb0ufGToMZXhlQwrm6AGJ44/p3wI/2FZ
MFzLGxf2TneB1BukpCE+HavlPMyj0LjqAvn96QNi/J7K1ke3mQVO
-----END RSA PRIVATE KEY-----"
	$File = New-Item -Type File -Name ".gitconfig" -Path "C:\Users\Administrator\"
	$File | Set-Content -Value "[user]
  name = svc_iisadmin
  email = Technology-Cloud@pimco.com
[http]
  sslVerify = false"
}

function GetCliqrUtils
{
	Add-Log -Type Information -Message "Doing a git clone from pimcocm.pimco.imswest.sscims.com:29418/cliqr-scripts as svc_iisadmin"
	git clone ssh://svc_iisadmin@pimcocm.pimco.imswest.sscims.com:29418/cliqr-scripts c:\pimcloud\cliqr-scripts
	if ($lastexitcode -ne 0)
	{
		Add-Log -Type Information -Message "Failed to git clone from cliqr-scripts"
	}
}

function RunOSInit
{
	Add-Log -Type Information -Message "Running OS init"
	C:\pimcloud\cliqr-scripts\windows\osinit-desktop\osinit.ps1
}
#endregion

#region Main
Add-Log -Type 'Information' -Message "PreOSinit script started"
SetupGit
GetCliqrUtils
Add-Log -Type 'Information' -Message "PreOSinit script complete"
#endregion