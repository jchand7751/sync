﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/26/2013 3:01 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

Add-PSSnapin Quest.ActiveRoles.ADManagement

$importlist = Import-Csv c:\Temp\workinglist.csv

$Changedarray = @()
$postchangearray = @()

foreach ($i in $importlist[0])
	{
	$GetUser = Get-QADUser -SamAccountName $i.samid -IncludedProperties primarySMTPAddress, proxyaddresses
	
	if ($GetUser)
		{
		$tempobject = "" | select Name, SamName, email, mail, SMTP, proxyaddresses
		$tempobject.name = $Getuser.name
		$tempobject.Samname = $Getuser.samaccountname
		$tempobject.email = $Getuser.email
		$tempobject.mail = $Getuser.mail
		$tempobject.SMTP = $Getuser.primarySMTPAddress
		$tempobject.proxyaddresses = [string]$Getuser.proxyaddresses
		
		#$proxycount = ($GetUser.proxyaddreses).count
		
		#$newproxyaddresses = $GetUser.proxyaddresses[1..($proxycount -1)]
		$proxyaddresses = $GetUser.proxyaddresses
		#$proxyaddresses[0] = "SMTP:$($i.newemail)"
		$proxyaddresses += "SMTP:$($i.newemail)"
		
		$proxyaddresses = $proxyaddresses | where {$_ -ne "SMTP:$($Getuser.primarySMTPAddress)"}
		
		
		$proxyaddresses
		#$GetUser | Set-QADUser -Email $i.newemail -objectAttributes @{primarySMTPAddress='$($i.newemail)'} #-WhatIf
		$GetUser | Set-QADUser -Email $i.newemail -objectAttributes @{proxyaddresses=$proxyaddresses} -WhatIf
	
		$GetUserAfter = Get-QADUser -SamAccountName $i.samid -IncludedProperties primarySMTPAddress, proxyaddresses
		$tempobject1 = "" | select Name, SamName, email, mail, SMTP, proxyaddresses
		$tempobject1.name = $GetuserAfter.name
		$tempobject1.Samname = $GetuserAfter.samaccountname
		$tempobject1.email = $GetuserAfter.email
		$tempobject1.mail = $GetuserAfter.mail
		$tempobject1.SMTP = $GetuserAfter.primarySMTPAddress
		$tempobject1.proxyaddresses = [string]$GetuserAfter.proxyaddresses
		
		$PostChangearray += $tempobject1
		$Changedarray += $tempobject		
		}
		else 
			{
			$tempobject = "" | select Name, SamName, email, mail, SMTP
			$tempobject.name = "User not found"
			$tempobject.Samname = $i.samid
			$tempobject.email = "User not found"
			$tempobject.mail = "User not found"
			$tempobject.SMTP = "User not found"
			$Changedarray += $tempobject		
			}
		
	}
$changedarray		
$postchangearray