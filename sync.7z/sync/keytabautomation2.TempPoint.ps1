﻿
#Web keytab
#svc app keytab
Param (
	
	[Parameter(ParameterSetName = 'upnkeytab', Mandatory = $false, Position = 0)]
	[switch]$upnkeytab,
	
	[Parameter(ParameterSetName = 'upnkeytab', Mandatory = $false, Position = 2)]
	[ValidateScript({
		$script:Credential = get-credential $_
		$True
	})]
	[string]$principalname,
	
	[Parameter(ParameterSetName = 'spnkeytab', Mandatory = $false, Position = 0)]
	[switch]$spnkeytab,
	
	#[Parameter(ParameterSetName='SPNs', Mandatory = $false, Position = 0)]
	#[switch]$SPN,
	
	[Parameter(ParameterSetName = 'spnkeytab', Mandatory = $true, Position = 2)]
	[string]$serviceclass,
	
	[Parameter(ParameterSetName = 'spnkeytab', Mandatory = $true, Position = 2)]
	[ValidateScript({
		$script:Credential = get-credential $_
		$True
	})]
	[string]$mappeduser,
	
	[Parameter(ParameterSetName = 'spnkeytab', Mandatory = $true, Position = 2)]
	[string]$port,
	
	[Parameter(ParameterSetName = 'spnkeytab', Mandatory = $true, Position = 2)]
	[string]$hostname
)

$erroractionpreference = "stop"
function createkeytabwithmapuser
{
	try
	{
		write-host "ktpass /princ $principalname /mapuser $mappeduser /pass $($script:credential.GetNetworkCredential().password) /out $filename.keytab /crypto all /ptype KRB5_NT_PRINCIPAL -SetUPN -SetPass > null 2>&1"
		invoke-expression "ktpass /princ $principalname /mapuser $mappeduser /pass $($script:credential.GetNetworkCredential().password) /out $filename.keytab  /crypto all /ptype KRB5_NT_PRINCIPAL -SetUPN -SetPass > null 2>&1" -ea stop
	}
	catch
	{
		if ($lastexitcode -ne 0 -or ([string]($error[0])).contains("NOTE: creating a keytab but not mapping principal to any user.") -eq $true)
		{
			write-warning "Ktpass command failed, exiting"
			exit
		}
	}
}

function createkeytabnomappeduser
{
	try
	{
		invoke-expression "ktpass /princ $principalname /pass $($script:credential.GetNetworkCredential().password) /out $filename.keytab /crypto all /ptype KRB5_NT_PRINCIPAL -SetUPN -SetPass > null 2>&1" -ea stop
	}
	catch
	{
		if ($lastexitcode -ne 0)
		{
			write-warning "Ktpass command failed, exiting"
			exit
		}
	}
}

function addspn
{
	try
	{
		invoke-expression "setspn -a $serviceclass/$hostname $servicename > null 2>&1" -ea stop
	}
	catch
	{
		write-warning "Setspn command failed, exiting."
	}
}

function VerifyKeytab
{
	$pwd = pwd
	try
	{
		Get-Item $pwd\$filename.keytab -ea stop | out-null
	}
	catch
	{
		Write-warning "Keytab not found, exiting"
		exit
	}
	Write-host "Keytab created."
}

function VerifySPN
{
	sleep 10
	$found = $false
	$foundspn = (invoke-expression "setspn -L $servicename")
	foreach ($spn in $foundspn)
	{
		if ($spn.trimstart("") -eq "$serviceclass/$hostname")
		{
			$found = $true
			break
		}
	}
	switch ($found)
	{
		"$true" { }
		"$false" { write-warning "SPN not found!"; exit }
	}
	Write-host "SPN created."
}

function enabledelegation
{
	#if (get-qaduser flagtest -IncludedProperties useraccountcontrol).useraccountcontrol -ne 590336)
	#{
	try
	{
		Set-ADAccountControl -Identity flagtest -TrustedForDelegation $true
	}
	catch
	{
		Write-warning "Attempt to set delegation failed"
	}
	#}
}

function testpassword
{
	try
	{
		Start-Process powershell.exe -ArgumentList noninteractive, noprofile -Credential $script:Credentialcredential
	}
	catch
	{
		Write-Error "User name/Password does not seem to be correct"
		exit
	}
}

#setspn -A HTTP/kerbtest.lab1.com:8088 LAB1\svc_kerbtest
#setspn -A HTTP/kerbtest:8088 LAB1\svc_kerbtest

#ktpass /princ $serviceclass/$hostname /
#ktpass /princ HTTP/kerbtest.lab1.com:8088@LAB1.COM /mapuser lab1\svc_kerbtest /pass Pimco123 /out c:\temp\kerbtest.keytab /crypto RC4-HMAC-NT /ptype KRB5_NT_PRINCIPAL

#setspn -a HTTP/pimcolive lab1\svc_kerbtest
#setspn -a $serviceclass/$hostname $servicename

#### MAIN #############

switch ($upnkeytab)
{
	#"$true" {enabledelegation ; createkeytabnomappeduser ; verifykeytab}
	"true" { testpassword;  createkeytabnomappeduser; verifykeytab }
}

switch ($spnkeytab)
{
	"$true" { $principalname = $serviceclass + "/" + $hostname; $filename = $hostname.split("@")[0]; $filename; $servicename = $mappeduser; testpassword ;enabledelegation; createkeytabwithmapuser; verifykeytab; $SPN = $true }
	#principalname = serviceclass + DNS/hostname
}

switch ($SPN)
{
	"$true" { addspn; verifyspn }
}

if ($keytab -eq $false -and $webkeytab -eq $false)
{
	Write-warning "You must specify to create a keytab or webkeytab"
}