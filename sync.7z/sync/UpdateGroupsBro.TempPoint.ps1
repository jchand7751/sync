﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/5/2017 12:32 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement

#Run from Core
$credential = get-credential
Connect-QADService pimco.imswest.sscims.com -Credential $credential
get-qadgroup pimcloud-* | foreach {
	$groupname = $_.name
	Connect-QADService core.pimcocloud.net
	New-QADGroup -Name $_.name -DisplayName $_.name -GroupName $_.name -GroupType security -GroupScope DomainLocal -parentcontainer "OU=onboarding,OU=sec_groups,OU=itops,DC=core,DC=pimcocloud,DC=net"
}

#Run from Pimco
Connect-QADService pimco.imswest.sscims.com -Credential $credential
$Groups = Get-QADGroup pimcloud-*
foreach ($i in $Groups)
{
	$i | get-qadgroupmember | add-qadgroupmember $i.name -Service core.pimcocloud.net -Credential $credential
}