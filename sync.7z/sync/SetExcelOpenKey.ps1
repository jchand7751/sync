﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/7/2015 4:02 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#"/R \\nasshare\share\test\ExcelServices.xll"
param ($stringvalues)
Import-Module PSRemoteRegistry

$stringarray = ($stringvalues -split ",")
foreach ($value in $stringarray)
{
	if (Get-RegString -Hive CurrentUser -Key Software\Microsoft\Office\14.0\Excel\Options -Value OPEN -ea 'SilentlyContinue')
	{
		for ($x = 1 ; $x -lt 50 ; $x++)
		{
			try
			{
				Get-RegString -Hive CurrentUser -Key Software\Microsoft\Office\14.0\Excel\Options -Value OPEN$x -ea 'Stop'
			}
			catch
			{
				Write-Host "Value OPEN$x is available"
				try
				{
					Set-RegString -Hive CurrentUser -Key Software\Microsoft\Office\14.0\Excel\Options -Value OPEN$x -Data $value -ErrorAction 'Stop' -Confirm:$false
					break
				}
				catch
				{
					Write-Warning "Set Regstring $value failed!"
				}
			}
		}
	}
	else
	{
		Write-Host "Using standard key"
		try
		{
			Set-RegString -Hive CurrentUser -Key Software\Microsoft\Office\14.0\Excel\Options -Value OPEN -Data $value -ErrorAction 'Stop' -Confirm:$false
		}
		catch
		{
			Write-Warning "Set Regstring $value failed!"	
		}
	}
}