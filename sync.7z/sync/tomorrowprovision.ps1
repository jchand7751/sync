﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/18/2017 1:15 PM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#Federate sub domains

Add-PSSnapin Quest.ActiveRoles.ADManagement
$users = get-qaduser -DontUseDefaultIncludedProperties -sizelimit 0 -Service pimco.imswest.sscims.com  -IncludedProperties mail, cloudsync | where { $_.mail -notlike "*@pimco.com" -and $_.mail -notlike "" -and $_.cloudsync -notlike "" } | select mail, cloudsync
foreach ($i in $users)
{
	$i | Set-QADObject -ObjectAttributes @{ cloudsync = '' }
}

#Run ADSYNC from VMA001P145 - Start-ADSyncSyncCycle

$users = get-qaduser -DontUseDefaultIncludedProperties -sizelimit 0 -Service pimco.imswest.sscims.com -IncludedProperties mail, cloudsync | where { $_.mail -notlike "*@pimco.com" -and $_.mail -notlike "" -and $_.cloudsync -notlike "" } | select mail, cloudsync
New-Item -Type File c:\tmp\UndoMsolGroups.txt
foreach ($i in $users)
{
	Add-Content "`$user = Get-QADUser -SamAccountName $($i.samaccountname)" -Path c:\tmp\UndoMSOLGroups.txt
	$user = Get-QADUser -SamAccountName $i.samaccountname
	$o365groups = $user | Get-QADMemberOf -Name o365-*
	foreach ($group in $o365groups)
	{
		Write-Host "Removing user from $($group.name)"
		Add-Content "`$user | Remove-QADMemberOf -Group $($group.name)" -Path c:\tmp\UndoMSOLGroups.txt
		$user | Remove-QADMemberOf -Group $group.name
	}
}
$deletedusers = Get-MsolUser -ReturnDeletedUsers -all
foreach ($i in $users)
{
	$remove = $null
	$remove = ($i.samaccountname -split "@")[0] + "@PIMCO.onmicrosoft.com"
	Write-Host "Removing $remove"
	$deletedusers |  where { $_.userprincipalname -eq $remove } | remove-msoluser -RemoveFromRecycleBin -force
}

#Delete 3 users from yesterday manually

#Run attribue script

#Run ADSYNC from VMA001P145 - Start-ADSyncSyncCycle

#Run license script
