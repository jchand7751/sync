﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/14/2017 2:26 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


Add-PSSnapin VMware.VimAutomation.Core
$vSphereLicInfo = @()
$VCenterservers = "vma035gw080", "vma0h5gw080"
$VcenterCreds = Get-Credential
Disconnect-VIServer * -Confirm:$false -force
Foreach ($vcenter in $VCenterservers)
{
	Connect-VIServer $vcenter -Credential $VcenterCreds
	$ServiceInstance = Get-View ServiceInstance
	Foreach ($LicenseMan in Get-View ($ServiceInstance | Select -First 1).Content.LicenseManager)
	{
		Foreach ($License in ($LicenseMan | Select -ExpandProperty Licenses))
		{
			$Details = "" | Select VC, Name, Key, Total, Used, ExpirationDate, Information
			$Details.VC = ([Uri]$LicenseMan.Client.ServiceUrl).Host
			$Details.Name = $License.Name
			$Details.Key = $License.LicenseKey
			$Details.Total = $License.Total
			$Details.Used = $License.Used
			$Details.Information = $License.Labels | Select -expand Value
			$Details.ExpirationDate = $License.Properties | Where { $_.key -eq "expirationDate" } | Select -ExpandProperty Value
			$vSphereLicInfo += $Details
		}
	}
	Disconnect-VIServer * -Confirm:$false -force
}
$vSphereLicInfo | Format-Table -AutoSize