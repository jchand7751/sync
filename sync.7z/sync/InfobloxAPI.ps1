﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/26/2015 1:21 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$a = curl -k -u admin:infoblox -X GET https://pimcloudinfblx/wapi/v1.0/record:host -d name=vma035gu0100.core.pimcocloud.net
$a = $a -join "`n" | ConvertFrom-Json

$a = curl.exe -k -u admjchandler:Ker988qa -X GET https://pimcloudinfblx/wapi/v1.0/record:host -d name=clv035sw-c5a828.core.pimcocloud.net -s | ConvertFrom-Json

curl -k -u admin:infoblox -H "Content-Type: application/json" -X PUT https://pimcloudinfblx/wapi/v2.0/record:txt/ZG5zLmJpbmRfdHh0JC4xLm5ldC5waW1jb2Nsb3VkLmNvcmUudG9kZHNhd2Vzb21lc2VydmVyLiJpdHMiICJ1cHN0YWlycyI:toddsawesomeserver.core.pimcocloud.net/Internal -d '{""extattrs"": { ""Site"": { ""value"": ""Dogs"" },  } }'
curl -k -u admin:infoblox -H "Content-Type: application/json" -X PUT https://pimcloudinfblx/wapi/v2.0/record:txt/ZG5zLmJpbmRfdHh0JC4xLm5ldC5waW1jb2Nsb3VkLmNvcmUudG9kZHNhd2Vzb21lc2VydmVyLiJpdHMiICJ1cHN0YWlycyI:toddsawesomeserver.core.pimcocloud.net/Internal -d '{ ""extattrs"": { ""Site"": { ""value"": ""Dogs"" }, ""Purpose"": { ""value"": ""cats"" } } }'

#iba_api.delete_host_record(infobloxFQDN.lower())

#curl.exe -k -u admjchandler:Ker988qa -X DELETE https://pimcloudinfblx/wapi/v1.2/record:host/ZG5zLmhvc3QkLjEubmV0LnBpbWNvY2xvdWQuY29yZS5jbHYwMzVzbC0xNDBlYTM -s

#works
$servers = Get-Content c:\tmp\inflist.txt
foreach ($srv in $servers)
{
	$record = [string](curl.exe -k -u admjchandler:Ker988qa -X GET https://pimcloudinfblx/wapi/v1.0/record:host -d name=$srv.core.pimcocloud.net -s) | ConvertFrom-Json
	if ($record.name)
	{
		try
		{
			$deletereq = [string](curl.exe -k -u admjchandler:Ker988qa -X DELETE "https://pimcloudinfblx/wapi/v1.2/$($record._ref)" -s) | ConvertFrom-Json
			if ($deletereq.error)
			{
				throw "Failed!"
			}
			else
			{
				Write-Host "Record for $srv.core.pimcocloud.net deleted successfully"
			}
		}
		catch
		{
			Write-Warning "Record deletion failed for $srv!"
		}
	}
	else
	{
		Write-Warning "Record not found for $srv!"
	}
}

function Get-InfobloxDNSRecord
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $True, Position = 0)]
		$HostName
	)
	#Connection variables
	$infobloxcreds = "admjchandler:Ker988qa"
	$url = "pimcloudinfblx/wapi/v1.0/record:host"
	
	try
	{
		$command = [string](curl.exe -k -u $infobloxcreds -X GET https://$url -d name=$HostName -s) | ConvertFrom-Json
		if ($command.code -eq 400)
		{
			throw "Exception"
		}
	}
	catch
	{
		throw "Exception: Something happened"
	}
	Write-Output $command
}

$a = knife search node fqdn:clv035sl-f5c11f.core.pimcocloud.net -c C:\chef\client.rb -F json

$a = [string](knife search node fqdn:clv035sl-f5c11f.core.pimcocloud.ne -c C:\chef\client.rb -F json) | ConvertFrom-Json
if ($a.results -ne 0)
{
	Write-Warning "Chef Provision failed, node still exists in Chef"
}