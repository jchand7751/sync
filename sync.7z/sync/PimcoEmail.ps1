﻿

$body = 'Hello $($user.firstname),
<br>
<br>
Welcome to the PIMCO Cloud!
<br>
Please review the information below to understand our service model and policies.

<br>
<br>
Cloud Documentation:
<br>
<br>
*  <a href="http://docs.cliqr.com/display/CCD42/Deployment+Lifecycle+Scripts">User Guide</a>
<br>
*  <a href="http://pimcoportal/newport/technology/infrastructure/Documents/Cloud/PIMCO Cloud Expectations Early Access.docx">Cloud Sandbox Expectations</a>
<br>
*  <a href="http://pimcoportal/newport/technology/infrastructure/core/Shared Documents/Cliqr/Cliqr Service Modeling Expectations.docx">Service Managers</a>
<br>
*  <a href="http://pimcoportal/newport/technology/infrastructure/core/Shared Documents/Cliqr/How to Model Services in Cliqr.docx">How to Build a Service</a>
<br>
*  <a href="http://docs.cliqr.com/display/CCD42/Deployment+Lifecycle+Scripts">CliQr Lifecycle Scripts</a>
<br>
<br>
If you have any questions or need help please email: <a href="mailto:Technology-Cloud@pimco.com">Technology-Cloud@pimco.com</a>
<br>
<br>
Thanks
'

Send-MailMessage -BodyAsHtml -To james.chandler@pimco.com -From PimcoCloudOnboarding@pimcocloud.net -SmtpServer vme001py -Body $body -Subject "Cloud Onboarding"