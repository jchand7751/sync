﻿Param ($computer)
$filepath = "c$\program files (x86)\Oracle\SQL Developer\ide\bin\ide.conf"
$filepathbackup = "c$\program files (x86)\Oracle\SQL Developer\ide\bin\ideconf.old"
$object = "" | select Computer, Status
$object.computer = $computer
if (Test-Connection $computer -count 1 -quiet)
{}
else
{
    $object.status = "Failed - Computer is offline"
    $object
    exit
}

##Look for the file
#$a = get-content "Z:\Share\!Bierman\SQLDeveloper\3.1\download\Sql Developer\ide\bin\ide.conf"
$a = Get-Content \\$computer\$Filepath -ea silentlycontinue

if ($a)
{
    if (Test-path \\$computer\$filepathbackup)
    {
        #write-host "File seems to be backed up already, skipping"
    }
    else
    {
        try
        {
        #Backup the file
        copy-item \\$computer\$filepath \\$computer\$filepathbackup -ea stop
        }
        catch
        {
            $object.status = "Failed - Backup failed"
            #write-warning "Backup failed, exiting"
            $object
            exit
        }
    }

    for ($x = 0 ; $x -lt $a.count ; $x++)
    {
        if ($a[$x] -eq "AddVMOption  -Xmx256M")
        {
            #write-host "Config has already been modified!"
            $object.status = "Success - Config seems to be modified already"
            $object
            exit
        }
    }

    for ($x = 0 ; $x -lt $a.count ; $x++)
    {
        if ($a[$x] -eq "AddVMOption  -Xmx640M")
        {
            #write-host "Found a match"
            $script:linenumber = $x
        }
    }

    if ($script:linenumber -eq $null)
    {
        $object.status = "Failed - Didn't find the line"
        #write-warning "Didn't find the line we need"
        $object
        exit
    }

    #Make sure we have the line number
    if ($a[$script:linenumber])
    {
        #Replace the line
        $a[$script:linenumber] = "AddVMOption  -Xmx256M"
        try
        {
            #Set the file
            #$a
            $b = Get-Content \\$computer\$Filepath -ea stop
            $b | Set-Content -value $a -ea stop
            $object.status = "Success"
        }
        catch
        {
            $object.status = "Failed - Set content failed"
            #Write-warning "Set content failed"
            $object
            exit
        }
        $object
    }
    else
    {
        #write-warning "No Matchy"
        $object.status = "Failed - Didn't find the line"
        $object
    }
}
else
{
    #write-warning "File not found"
    $object.status = "Failed - File not found"
    $object
}