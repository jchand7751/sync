﻿
#Web keytab
#svc app keytab
Param (
    
    [Parameter(ParameterSetName='keytab', Mandatory = $false, Position = 0)]
	[switch]$keytab,
    
    [Parameter(ParameterSetName='keytab', Mandatory = $true, Position = 2)]
    [ValidateScript({
            $script:Credential = get-credential $_
            $True
        })]
	[string]$principalname,

    [Parameter(ParameterSetName='webkeytab', Mandatory = $false, Position = 0)]
	[switch]$webkeytab,

    #[Parameter(ParameterSetName='SPNs', Mandatory = $false, Position = 0)]
	#[switch]$SPN,

	[Parameter(ParameterSetName='webkeytab', Mandatory = $true, Position = 2)]
	[string]$serviceclass,

    [Parameter(ParameterSetName='webkeytab', Mandatory = $true, Position = 2)]
    [ValidateScript({
            $script:Credential = get-credential $_
            $True
        })]
	[string]$mappeduser,

    [Parameter(ParameterSetName='webkeytab', Mandatory = $true, Position = 2)]
	[string]$hostname
)

$erroractionpreference = "stop"
function createkeytabwithmapuser
{
    try 
    {
        invoke-expression "ktpass /princ $principalname /mapuser $mappeduser /pass $script:credential.GetNetworkCredential().password /out $principalname.keytab /crypto RC4-HMAC-NT /ptype KRB5_NT_PRINCIPAL > null 2>&1" -ea stop
    }
    catch
    {
        if ($lastexitcode -ne 0 -or ([string]($error[0])).contains("NOTE: creating a keytab but not mapping principal to any user.") -eq $true)
        {
            write-warning "Ktpass command failed, exiting"
            exit
        }
    }
}

function createkeytabnomappeduser
{
    try 
    {
        invoke-expression "ktpass /princ $principalname /pass $script:credential.GetNetworkCredential().password /out $principalname.keytab /crypto RC4-HMAC-NT /ptype KRB5_NT_PRINCIPAL > null 2>&1" -ea stop
    }
    catch
    {
        if ($lastexitcode -ne 0)
        {
            write-warning "Ktpass command failed, exiting"
            exit
        }
    }
}

function addspn
{
    try 
    {
        invoke-expression "setspn -a $serviceclass/$hostname $servicename > null 2>&1" -ea stop
    }
    catch 
    {
        write-warning "Setspn command failed, exiting."
    }
}

function VerifyKeytab
{
    $pwd = pwd
    try
    {
        Get-Item $pwd\$principalname.keytab -ea stop | out-null
    }
    catch
    {
        Write-warning "Keytab not found, exiting"
        exit
    }
    Write-host "Keytab created."
}

function VerifySPN
{
    sleep 10
    $found = $false
    $foundspn = (invoke-expression "setspn -L $servicename") 
    foreach ($spn in $foundspn) 
    {
        if ($spn.trimstart("") -eq "$serviceclass/$hostname") 
        {
            $found = $true
            break
        }
    }
    switch ($found)
    {
        "$true" {}
        "$false" {write-warning "SPN not found!" ; exit}
    }
    Write-host "SPN created."
}

function enabledelegation
{
    #if (get-qaduser flagtest -IncludedProperties useraccountcontrol).useraccountcontrol -ne 590336)
    #{
        try
        {
            Set-ADAccountControl -Identity flagtest -TrustedForDelegation $true
        }
        catch
        {
            Write-warning "Attempt to set delegation failed"
        }
    #}
}
#setspn -A HTTP/kerbtest.lab1.com:8088 LAB1\svc_kerbtest
#setspn -A HTTP/kerbtest:8088 LAB1\svc_kerbtest
#ktpass /princ HTTP/kerbtest.lab1.com:8088@LAB1.COM /mapuser lab1\svc_kerbtest /pass Pimco123 /out c:\temp\kerbtest.keytab /crypto RC4-HMAC-NT /ptype KRB5_NT_PRINCIPAL

switch ($keytab)
{
    "$true" {enabledelegation ; createkeytabnomappeduser ; verifykeytab}
}

switch ($webkeytab)
{
    "$true" {$principalname = $serviceclass + $hostname ; $servicename = $mappeduser ; enabledelegation ; createkeytabwithmapuser ; verifykeytab; $SPN = $true}
    #principalname = serviceclass + DNS/hostname 
}

switch ($SPN)
{
    "$true" {addspn ; verifyspn}
}

if ($keytab -eq $false -and $webkeytab -eq $false)
{
    Write-warning "You must specify to create a keytab or webkeytab"
}