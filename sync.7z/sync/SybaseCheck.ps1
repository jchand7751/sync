﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/4/2016 10:37 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$whoami = ((whoami) -split ("\\"))[1]
$pcname = hostname
$date = (Get-Date).ToString()
$outputfile = New-Item -Type File c:\temp\SybaseCheck-$pcname-$whoami.txt
$file = New-Item -Type File c:\temp\isqlcmd.txt -Force
Add-Content "select @@servername" -Path $file
Add-Content "go" -Path $file
$verifyconnect = isql -SSYBBTAPIM -Usvc_ta_nb -PpimcoDB1 -i $file.fullname
$verifyversion = isql -v
Add-Content $verifyconnect -Path $outputfile
Add-Content "" -Path $outputfile
Add-Content $verifyversion[0] -Path $outputfile
#Sybase CTISQL Utility/15.7/P-EBF20100 ESD #4/PC Intel/BUILD1570-015/OPT/Thu May24 01:13:19 2012
