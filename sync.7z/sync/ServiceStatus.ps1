﻿$comps = get-content c:\temp\bleh.txt
#$comps = "nb-18-1034", "nb-18-1051"
$array = @()
Connect-qadservice vms001p4 | out-null
foreach ($i in $comps)
{
    $object = "" | select Name, Service, Status, Notes
    $object.name = $i
    
    if (Test-connection -ComputerName $i -Quiet -count 1)
    {
        try
        {
            $service = Get-Service -Name "AppSense EmCoreService" -ComputerName $i -ea stop | select displayname, status
            $object.service = $service.DisplayName
            $object.status = $service.status
        }
        catch
        {
            $object.service = "Service not found"
            $object.status = "Service not found"
        }
        #$object
        $array += $object
    }
    else
    {
        $object.notes = "PC Offline"
        #$object
        $array += $object
    }
}
$array
$array | export-csv c:\temp\servicecheckappsense.csv
