﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	09/15/2016 1:24 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   	SQLinit.ps1  	
	===========================================================================
	.DESCRIPTION
		Cliqr SLQ Init Script.
#>
#Import Modules
Import-module BitsTransfer
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

#Environment Setup
$logfile = "C:\temp\CliqrInitLog.txt"
$server = hostname
$key = 203, 117, 112, 91, 119, 165, 146, 173, 140, 253, 20, 134, 174, 241, 213, 16
$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString -Key $key)
$credential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
$cliqrvars = Get-Content C:\temp\userenv.ps1
$clientrb = "C:\chef\client.rb"
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrresumefile = "C:\Program Files\Osmosix\.cliqrRebootResumeInit"
$reposource = "http://10.155.5.63:8080/"
$whoami = whoami
#$deploymentenv = ((($cliqrvars | foreach { $_ } | where { $_ -like '$env:cliqrdepenvname*' }) -split "=")[1] -replace "'", "") -replace ";"
#$runlist = ((($cliqrvars | foreach { $_ } | where { $_ -like '$env:runlist*' }) -split "=")[1] -replace "'", "") -replace ";"

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

function Executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force
	}
}
function SqlInitScript
{
	$logfile = "C:\temp\SQLInitLog.txt"
	$ipv4address = (Get-NetIPAddress -InterfaceAlias Ethernet1 -AddressFamily IPv4).ipaddress
	$ipv6address = (Get-NetIPAddress -InterfaceAlias Ethernet1 -AddressFamily IPv6).ipaddress
	$ipisatap = (Get-NetIPAddress -InterfaceAlias "isatap*").ipaddress
	$server = hostname
	$key = 203, 117, 112, 91, 119, 165, 146, 173, 140, 253, 20, 134, 174, 241, 213, 16
	$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString -Key $key)
	$credential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
	
	CreateLogFile
	Add-Content -Path $logfile "$(executiontime) - Starting SQL init script"
	agentSendLogMessage "$(executiontime) - Starting SQL init script"
	Add-Content -Path $logfile "$(executiontime) - Adding registry values"
	agentSendLogMessage "$(executiontime) - Adding registry values"
	Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQLServer\SuperSocketNetLib\Tcp\IP1" -Name IpAddress -Value $ipv6address
	Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQLServer\SuperSocketNetLib\Tcp\IP2" -Name IpAddress -Value $ipv4address
	Set-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQLServer\SuperSocketNetLib\Tcp\IP5" -Name IpAddress -Value $ipisatap
	
	Add-Content -Path $logfile "$(executiontime) - Setting services starttype"
	agentSendLogMessage "$(executiontime) - Setting services starttype"
	Set-Service -Name MSSQLSERVER -StartupType Automatic
	Set-Service -Name SQLSERVERAGENT -StartupType Automatic
	
	Add-Content -Path $logfile "$(executiontime) - Starting services"
	agentSendLogMessage "$(executiontime) - Starting services"
	Start-Service -Name MSSQLSERVER
	Start-Service -Name SQLSERVERAGENT
	
	Add-Content -Path $logfile "$(executiontime) - Giving svc_adaccess temporary admin access to create SPNs"
	agentSendLogMessage "$(executiontime) - Giving svc_adaccess temporary admin access to create SPNs"
	try
	{
		([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://core.pimcocloud.net/svc_adaccess") | Out-Null
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to add $userlogin to local admins group"
		agentSendLogMessage "$(executiontime) - Failed to add $userlogin to local admins group"
	}
	Add-Content -Path $logfile "$(executiontime) - Creating SPNs"
	agentSendLogMessage "$(executiontime) - Creating SPNs"
	$session = New-PSSession localhost -Credential $credential -Authentication Credssp
	
	$spnarray = @()
	$spnarray += "MSSQLSvc/$server"
	$spnarray += "MSSQLSvc/$server.core.pimcocloud.net"
	$spnarray += "MSSQLSvc/$server`:1433"
	$spnarray += "MSSQLSvc/$server.core.pimcocloud.net:1433"
	
	$user = Invoke-Command -Session $session { [ADSI]"LDAP://CN=svc-sqladmin,OU=svc_accounts,OU=itops,DC=core,DC=pimcocloud,DC=net" }
	
	if ($user.samaccountname)
	{ }
	else
	{
		Add-Content -Path $logfile "$(executiontime) - Couldn't get user account"
		agentSendLogMessage "$(executiontime) - Couldn't get user account"
		exit 1
	}
	
	$currentSPNs = $user.serviceprincipalname
	
	if ($currentSPNs)
	{ }
	else
	{
		Add-Content -Path $logfile "$(executiontime) - Couldn't find SPNs"
		agentSendLogMessage "$(executiontime) - Couldn't find SPNs"
		exit 1
	}
	
	#Set SPN
	foreach ($spn in $spnarray)
	{
		
		#Add-Content -Path $logfile "$(executiontime) - Adding a SPN for $spn"
		#agentSendLogMessage "$(executiontime) - Adding a SPN for $spn"
		#Invoke-Command -Session $session {setspn -s $args CORE\svc-sqladmin} -ArgumentList $spn
		
		if (($currentSPNs -contains $spn) -eq $false)
		{
			$currentSPNs += $spn
		}
		else
		{
			Add-Content -Path $logfile "$(executiontime) - SPN already exists"
			agentSendLogMessage "$(executiontime) - SPN already exists"
		}
	}
	
	Add-Content -Path $logfile "$(executiontime) - Bulk settings SPNs"
	agentSendLogMessage "$(executiontime) - Bulk settings SPNs"
	
	Invoke-Command -Session $session {
		$user = [ADSI]"LDAP://CN=svc-sqladmin,OU=svc_accounts,OU=itops,DC=core,DC=pimcocloud,DC=net"
		$user.put("serviceprincipalname", $args)
		$user.setinfo()
	} -ArgumentList $currentSPNs
	
	
	
	sleep 30
	$foundspn = (Invoke-Command -Session $session { setspn -L core\svc-sqladmin })
	
	#Verify SPN
	
	foreach ($spn in $spnarray)
	{
		$found = $false
		foreach ($fspn in $foundspn)
		{
			if ($fspn.trimstart("") -eq $spn)
			{
				$found = $true
				break
			}
		}
		switch ($found)
		{
			"$true" { }
			"$false" { Add-Content -Path $logfile "$(executiontime) - SPN not found: $spn"; agentSendLogMessage "$(executiontime) - SPN not found: $spn"; $script:spnerror = $true }
		}
		Add-Content -Path $logfile "$(executiontime) - SPN found"
	}
	#>
	#Remove credentials
	try
	{
		([ADSI]"WinNT://localhost/Administrators,group").Remove("WinNT://core.pimcocloud.net/svc_adaccess") | Out-Null
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
		agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	}
	
	#Add the user as a SQL admin
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Adding user to sysadmin"
		agentSendLogMessage "$(executiontime) - Adding user to sysadmin"
		
		[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null
		$srv = New-Object "Microsoft.SqlServer.Management.SMO.Server" "localhost"
		$srv
		$login = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Login -ArgumentList "localhost", "PIMCO\$($env:userExternalId)"
		$login.LoginType = [Microsoft.SqlServer.Management.Smo.LoginType]::WindowsUser
		$login.Create()
		$login.AddToRole("sysadmin")
		$login.Alter()
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to add user to sysadmin"
		agentSendLogMessage "$(executiontime) - Failed to add user to sysadmin"
	}
	
	Add-Content -Path $logfile "$(executiontime) - SQL initialization complete"
	agentSendLogMessage "$(executiontime) - SQL initialization complete"
}