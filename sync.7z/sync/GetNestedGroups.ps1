﻿$script:grouparray = @()
function GetAllNestedGroups
{
    Param($group)
    $toplevel = Get-qadgroup $group | get-qadgroupmember
    foreach ($i in $toplevel)
    {
       if ($i.type -eq "group")
       {
            write-host "Adding $i.name"
           $script:grouparray += $i.name
           GetAllNestedGroups $i.name
       }
    }
}