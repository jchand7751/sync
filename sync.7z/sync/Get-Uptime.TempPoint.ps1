﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/2/2015 10:11 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
function Get-Uptime
{
	param ($computer = "localhost")
	$object = "" | select Computer, Lastboot, Uptime
	if ((Test-Connection -ComputerName $computer -Count 1 -Quiet) -eq $true)
	{
		$object.Computer = $computer
		try
		{
			$wmi = gwmi win32_operatingsystem -Computer $computer -ea 'Stop'
		}
		catch
		{
			#Write-Host "WMI call failed on $computer"
			$object.Lastboot = "WMI call failed on $computer"
			$object.Uptime = "WMI call failed on $computer"
			$object
			return
		}
		$lastboot = $wmi.converttodatetime($wmi.lastbootuptime)
		$localtime = $wmi.converttodatetime($wmi.localdatetime)
		#[string](($localtime - $lastboot).days) + " days " + [string](($localtime - $lastboot).hours) + " hours " + [string](($localtime - $lastboot).seconds) + " seconds"
		$object.Lastboot = $lastboot.tostring()
		$object.Uptime = [string](($localtime - $lastboot).days) + " days " + [string](($localtime - $lastboot).hours) + " hours " + [string](($localtime - $lastboot).seconds) + " seconds"
		$object
	}
	else
	{
		#Write-Host "$computer is offline"
		$object.Computer = $computer
		$object.Lastboot = "Computer offline"
		$object.Uptime = "Computer offline"
		$object
	}
}
Import-Module ActiveDirectory
$array = @()
get-adcomputer -Filter { name -like "nb-18*" -or name -like "nb-19*" -or name -like "nb-20*"  } | foreach { $_.name; $array += Get-Uptime -comp $_.name }
#$processlist = Import-Csv -Path c:\temp\
$array | Export-Csv c:\temp\uptimereport.csv

