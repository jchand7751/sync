﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/27/2016 2:02 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin VMware.VimAutomation.Core
Add-PSSnapin Quest.ActiveRoles.ADManagement
Import-Module Centrify.DirectControl.PowerShell

#Get Chef Nodes
$chefnodes = ([string](knife search node fqdn:clv* -c C:\chef\client.rb -F json -i) | ConvertFrom-Json).rows -replace ".core.pimcocloud.net",""

#Get VMware Nodes
Connect-VIServer vma035gw080.core.pimcocloud.net
Connect-VIServer vma0h5gw080.core.pimcocloud.net
$vmnodes = (get-view -ViewType virtualmachine -Filter @{ Name = "clv" }).name

#Get AD Nodes
Connect-QADService core.pimcocloud.net
$ADnodes = (Get-QADComputer -Name "clv*" -properties Name).Name

#Get Centrify Nodes
$centrifynodes = (Get-CdmManagedComputer | where { $_.name -like "clv*" }).name -replace ".core.pimcocloud.net", ""

#Get Infoblox VMs
$infobloxnodes = curl.exe -k -u admjchandler:Ker988qa -X GET https://pimcloudinfblx/wapi/v1.0/record:host -d name~=clv03.* -s
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
$jsonserial = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
$jsonserial.MaxJsonLength = 500000000
$infobloxnodes = $jsonserial.DeserializeObject($infobloxnodes)
$infobloxnodes = $infobloxnodes.name -replace ".core.pimcocloud.net", ""

#Cliqr VMs
$vmarray = @()
$vmarray1 = @()
$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"

#Get all Cliqr jobs and jsonify them
$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?includeTerminated=true&size=0" -s
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
$jsonserial = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
$jsonserial.MaxJsonLength = 500000000
$jobstatus = $jsonserial.DeserializeObject($jobstatus)

#Non terminated Cliqr VMs
$jobstatus = foreach ($job in $jobstatus.jobs)
{
	$wtf = $job.deploymentInfo.isDeploymentTerminated
	if ($wtf -eq $false)
	{
		$job
	}
}
	
foreach ($i in $jobstatus.id)
{
	#Write-Host "Job $i"
	$query = (curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://10.155.5.112/v1/jobs/$i/nodes" -s | ConvertFrom-Json).nodes.virtualmachines.id
	#Write-Host "VM(s) $Query"
	$vmarray += $query
}

#Get all Cliqr jobs and jsonify them
$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?includeTerminated=true&size=0" -s
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
$jsonserial = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
$jsonserial.MaxJsonLength = 500000000
$jobstatus = $jsonserial.DeserializeObject($jobstatus)

#Terminated Cliqr VMs
$jobstatus = foreach ($job in $jobstatus.jobs)
{
	$wtf = $job.deploymentInfo.isDeploymentTerminated
	if ($wtf -eq $true)
	{
		$job
	}
}

foreach ($i in $jobstatus.id)
{
	#Write-Host "Job $i"
	$query = (curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://10.155.5.112/v1/jobs/$i/nodes" -s | ConvertFrom-Json).nodes.virtualmachines.id
	#Write-Host "VM(s) $Query"
	$vmarray1 += $query
}

$masterlist = @()
foreach ($node in $chefnodes)
{
	$object = "" | select Name
	$object.Name = $node
	$masterlist += $object
}

foreach ($node in $vmnodes)
{
	$object = "" | select Name
	$object.Name = $node
	$masterlist += $object
}

foreach ($node in $ADnodes)
{
	$object = "" | select Name
	$object.Name = $node
	$masterlist += $object
}

foreach ($node in $centrifynodes)
{
	$object = "" | select Name
	$object.Name = $node
	$masterlist += $object
}

foreach ($node in $infobloxnodes)
{
	$object = "" | select Name
	$object.Name = $node
	$masterlist += $object
}

foreach ($node in $vmarray)
{
	$object = "" | select Name
	$object.Name = $node
	$masterlist += $object
}

foreach ($node in $vmarray1)
{
	$object = "" | select Name
	$object.Name = $node
	$masterlist += $object
}

$masterlist = ($masterlist | sort -Unique -Property Name)
foreach ($node in $masterlist)
{
	if (($chefnodes -contains $node.name) -eq $true)
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Chef" -Value "True"
	}
	else
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Chef" -Value "False"
	}
	if (($vmnodes -contains $node.name) -eq $true)
	{
		$node | Add-Member -Type 'NoteProperty' -Name "VMware" -Value "True"
	}
	else
	{
		$node | Add-Member -Type 'NoteProperty' -Name "VMware" -Value "False"
	}
	if (($adnodes -contains $node.name) -eq $true)
	{
		$node | Add-Member -Type 'NoteProperty' -Name "AD" -Value "True"
	}
	else
	{
		$node | Add-Member -Type 'NoteProperty' -Name "AD" -Value "False"
	}
	if (($centrifynodes -contains $node.name) -eq $true)
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Centrify" -Value "True"
	}
	else
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Centrify" -Value "False"
	}
	if (($infobloxnodes -contains $node.name) -eq $true)
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Infoblox" -Value "True"
	}
	else
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Infoblox" -Value "False"
	}
	if (($vmarray -contains $node.name) -eq $true)
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Cliqr Provisioned" -Value "True"
	}
	else
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Cliqr Provisioned" -Value "False"
	}
	if (($vmarray1 -contains $node.name) -eq $true)
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Cliqr Deprovisioned" -Value "True"
	}
	else
	{
		$node | Add-Member -Type 'NoteProperty' -Name "Cliqr Deprovisioned" -Value "False"
	}
}