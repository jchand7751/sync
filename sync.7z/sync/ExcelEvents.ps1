﻿#find excel crash events on a machine
Param ($Computer, $Days)
$days = -30
$today = Get-Date

$cleanstart = $today
$cleanend = ($today.adddays($days))

$datestart = Get-Date $cleanstart -UFormat "%Y-%m-%d"
$dateend = Get-Date $cleanend -UFormat "%Y-%m-%d"

$uglydatestring = "TimeCreated[@SystemTime&gt;='$($dateend)T08:00:01.000Z' and @SystemTime&lt;='$($datestart)T07:59:00.999Z'"

$events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Application'><Select Path='Application'>*[System[Provider[@Name='Application Error' or @Name='Application Hang'] and (EventID=1000) or (EventID=1002)]]</Select></Query></QueryList>" -Computername $Computer

$events = $events | where {$_.timecreated -ge $dateend} | select TimeCreated, MachineName, ProviderName, ID, LevelDisplayName, Message

$user = (gwmi win32_computersystem -comp $computer).username

#Add logged on user to the events
foreach ($evt in $events)
{
    if ($user)
    {
        $evt | Add-Member -MemberType NoteProperty -Name User -Value $User
    }
    else
    {
        $evt | Add-Member -MemberType NoteProperty -Name User -Value "User not found"
    }
}
$events | where {$_.message.contains("EXCEL.EXE,") -or $_.message.contains("EXCEL.EXE") -eq $true} | select TimeCreated, User, MachineName, ProviderName, ID, LevelDisplayName, Message
