﻿[void][reflection.assembly]::LoadWithPartialName("System.Windows.Forms")

#Get Image details
$imagepath = "\\nasshare\share\PimcoIIS_InstallPackage\GPOTest\WeArePimco\WeArePimco.JPG"
$imageobject = [system.drawing.image]::fromfile($imagepath)

#Define the form
$form = new-object Windows.Forms.Form
$form.Text = "We Are Pimco"
#not sure why this isnt displaying correctly
$form.width = $imageobject.width + 8
$form.height = $imageobject.height + 25
$form.startposition = "centerscreen"

#Define the picturebox
$picturebox1 = new-object Windows.Forms.PictureBox
$picturebox1.Width = $imageobject.width
$picturebox1.Height = $imageobject.height
$picturebox1.image = $imageobject

#Add controls
$form.controls.add($picturebox1)

#Display the form
$form.showdialog()