﻿Add-PSSnapin Quest.ActiveRoles.ADManagement
#$a = get-content "c:\temp\larrynas.txt"
$a = import-csv C:\temp\technologymissingusers.csv
$array = @()
foreach ($i in $a) 
{
    #$i = $i.trimstart(" ")
    $object = "" | select LoginID, LastName, FirstName, Title, Department, Manager, Office, Location, Country, Email, Phonenumber, RDPStatus
    $testforuser = get-qaduser -name $i.name -includedproperties co | select lastname, firstname, samaccountname, title, department, city, email, phonenumber, l, co, manager
    if ($testforuser)
    {
       $object.LastName = $testforuser.lastname
       $object.FirstName = $testforuser.firstname
       $object.LoginID = $testforuser.samaccountname
       $object.Title = $testforuser.title
       $object.Department = $testforuser.department
       $object.Office = $testforuser.city
       $object.Email = $testforuser.email
       $object.Phonenumber = $testforuser.phonenumber
       $object.location = $testforuser.l
       $object.country = $testforuser.co
       $object.rdpstatus = $i.whateverthisis
       try
       {
            $TestManager = (get-qaduser ($testforuser.manager)).name
            $object.Manager = $TestManager
       }
       Catch
       {
        $object.Manager = "Manager not found"
       }
       $array += $object
    }
    else
    {
        $testforuser = get-qaduser imswest\$i
        if ($testforuser)
        {
            $object.LastName = $testforuser.lastname
            $object.FirstName = $testforuser.firstname
            $object.LoginID = $testforuser.samaccountname
            $object.Title = $testforuser.title
            $object.Department = $testforuser.department
            $object.Office = $testforuser.city
            $object.Email = $testforuser.email
            $object.Phonenumber = $testforuser.phonenumber
            try
            {
                $TestManager = (get-qaduser ($testforuser.manager)).name
                $object.Manager = $TestManager
            }
            Catch
            {
                $object.Manager = "Manager not found"
            }
            $array += $object
        }
        else
        {
        $object.LastName = "User not found"
        $object.FirstName = "User not found"
        $object.LoginID = $i.name
        $object.Title = "User not found"
        $object.Department = "User not found"
        $object.Office = "User not found"
        $array += $object
        }
    }
    $object
}
$array | export-csv c:\temp\bbglarrylist.csv