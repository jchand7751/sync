﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/12/2016 10:41 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Import-Module Microsoft.PowerShell.Security

$servers = "vmh001b007", "vmh001b008", "ina001b012", "ina001b013", "INA001b019"
$groupname = "IIS_iusrs"
foreach ($computer in $servers)
{
	$Group = [ADSI]"WinNT://$Computer/$GroupName,group"
	$Members = @($group.psbase.Invoke("Members"))
	$members | foreach { $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null) }
}

$user = "svc_spldev"

([ADSI]"WinNT://$computer/Administrators,group").Add("WinNT://$domain/$user")

$servers = "VMH001P016", "VMH001P017", "ina001p011", "ina001p012", "ina001p015"
foreach ($computer in $servers)
{
	$username = "pimco\svc_spl"
	$path = "\\$computer\l$\logs"
	$acl = Get-Acl $path
	$accessrule = New-Object system.security.AccessControl.FileSystemAccessRule($username, "modify,write,ReadAndExecute", "ContainerInherit,ObjectInherit", "None", "Allow")
	$acl.AddAccessRule($accessrule)
	set-acl -aclobject $acl $path
}