﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.57
	 Created on:   	6/19/2014 3:38 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Param ($NewNodeName)
#vma0b1p002
#Caption
#IP

$ResolvedIP = ([System.Net.DNS]::GetHostAddresses($NewNodeName)).ipaddresstostring
If ($ResolvedIP)
{$ResolvedIP = $ResolvedIP.ToString()}
else
{
	Write-Warning "IP not found"
	exit
}


$ResolvedHostname = ([System.Net.DNS]::GetHostEntry($NewNodeName)).hostname
If ($ResolvedHostName)
{ }
else
{
	Write-Warning "Hostname not found"
	exit
}

$swis = connect-swis vma001p087 -credential (get-credential)

$NewNodeProps = @{
	EntityType = "Orion.Nodes";
	IPAddress = $ResolvedIP;
	Caption = $ResolvedHostname;
	DynamicIP = $False;
	EngineID = 1;
	Status = 1;
	UnManaged = $False;
	Allow64BitCounters = $true;
	SysObjectID = "";
	MachineType = "";
	VendorIcon = "";
	ObjectSubType = "SNMP";
	SNMPVersion = 2;
	Community = "ntsystems";
	City = "";
	IPAddressGUID = [guid]::NewGuid();
	Location = "";
	Contact = "";
	NodeDescription = "";
	Vendor = "";
	IOSImage = "";
	IOSVersion = "";
}

Write-Host "Creating node"
$newNodeUri = New-SwisObject $swis –EntityType "Orion.Nodes" –Properties $newNodeProps
$nodeProps = Get-SwisObject $swis -Uri $newNodeUri
$poller = @{
	NetObject = "N:" + $nodeProps["NodeID"];
	NetObjectType = "N";
	NetObjectID = $nodeProps["NodeID"];
}
Write-Host "Adding SNMP and CPU generic pollers"
$poller["PollerType"] = "V.Details.SNMP.Generic";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "V.Statistics.SNMP.Generic";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "V.Status.SNMP.Generic";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.Details.SNMP.Generic";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.Uptime.SNMP.Generic";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.Cpu.SNMP.HrProcessorLoad";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.Memory.SNMP.HrStorage";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.AssetInventory.Snmp.Generic";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.Status.ICMP.Native";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.ResponseTime.ICMP.Native";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.ResponseTime.SNMP.Native";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.Status.SNMP.Native";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
$poller["PollerType"] = "N.Topology_Layer3.SNMP.ipNetToMedia";
$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller

#$poller["PollerType"] = "N.Details.SNMP.Generic";
#$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
#$poller["PollerType"] = "N.Uptime.SNMP.Generic";
#$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
#$poller["PollerType"] = "N.Cpu.SNMP.CiscoGen3";
#$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller
#$poller["PollerType"] = "N.Memory.SNMP.CiscoGen3";
#$pollerUri = New-SwisObject $swis -EntityType "Orion.Pollers" -Properties $poller

#Add Volumes

<#
$volPoller = @{
	PollerType = "$volPollerType";
	NetObject = "V:" + $newVol.VolumeID;
}

New-SwisObject $target -EntityType "Orion.Pollers" -Properties $volPoller | Out-Null

$sourceVolumes = Get-SwisData $source "SELECT Nodes.Volumes.Uri FROM Orion.Nodes WHERE NodeID=@node" @{ node = $sourceNode.NodeID }
$sourceVolProps = Get-SwisObject $source $sourceVolume
$newVolUri = New-SwisObject $target -EntityType "Orion.Volumes" -Properties $targetVolProps

$drives = Get-WmiObject -ComputerName nb-7-1232-2 -Class win32_Volume -Filter DriveType=3
$drives = $drives | sort DriveLetter
foreach ($drive in $drives){
    $VolumeDescription = "$($drive.Caption) Label:$($drive.Label)  Serial Number:$([Convert]::ToString($drive.SerialNumber, 16))";
    $VolumeCaption = "$($drive.Caption) Label:$($drive.Label)  $([Convert]::ToString($drive.SerialNumber, 16))";

#>

Write-Host "Adding interfaces"
#Discover interfaces
$DiscoveredInt = Invoke-SwisVerb $swis Orion.NPM.Interfaces DiscoverInterfacesOnNode $nodeProps["NodeID"]

#Find Active Nics
$ServerActiveConnections = gwmi win32_networkadapter -ComputerName $NewNodeName | where { $_.adaptertype -like "ethernet 802.3" -and $_.netconnectionstatus -eq 2 }
$discoveredInt.discoveredinterfaces.discoveredliteinterface.count
foreach ($interface in $discoveredInt.discoveredinterfaces.discoveredliteinterface)
{
	for ($x = 0; $x -lt $ServerActiveConnections.count; $x++)
	{
		#Write-Host " "
		#($interface).caption."`#text"
		#Write-Host " "
		#write-host "$($ServerActiveConnections[$x].Name) ·*"
		#Write-Host "---------------"
		if (($interface).caption."`#text" -like "$($ServerActiveConnections[$x].Name)*" -and ($interface).caption."`#text" -like "*$($ServerActiveConnections[$x].NetConnectionID)")
		{
			$cleanIfaceName = $($interface.caption."`#text")
			$cleanIfaceindex = $($interface.ifIndex)
			#$cleanIfaceName
			#$cleanifaceindex
			$newIfaceProps = @{
				NodeID = $nodeProps["NodeID"];
				InterfaceName = $cleanIfaceName;
				InterfaceIndex = $cleanIfaceindex;
				ObjectSubType = "SNMP";
				Status = 0;
			}
			$newIfaceProps
			#Add Interfaces
			$newIfUri = New-SwisObject $swis -EntityType "Orion.NPM.Interfaces" -Properties $newIfaceProps
		}
		else
		{
			($interface).caption."`#text"
			write-host "did not match"
			Write-host "$($ServerActiveConnections[$x].Name)*"
			Write-Host "or"
			*$($ServerActiveConnections[$x].NetConnectionID)
		}
	}
}



