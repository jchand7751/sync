﻿$array = @()
foreach ($i in $b) 
{ 
    $possiblenames = $null
    $possiblenames = get-qaduser -displayname ($i.replace("...","*"))
    $object = "" | select UglyName, Multiple, DisplayName, Full_Name, Login_Name, Title, Department, Office, Desk, Manager
    if ($possiblenames.count -gt 1)
    {
        $possiblenames[0] | select displayname, samaccountname
        $object.uglyname = $i
        $object.displayname = $possiblenames[0].displayname
        $object.multiple = "Yes"
        $object.Full_Name = $possiblenames[0].name
        $object.Login_Name = $possiblenames[0].samaccountname
        $object.Title = $possiblenames[0].title
        $object.Department = $possiblenames[0].department
        $object.Office = $possiblenames[0].city
        $object.Desk = $possiblenames[0].physicalDeliveryOfficeName
        try
        {
            $TestManager = (get-qaduser ($possiblenames[0].manager)).name
            $object.Manager = $TestManager
        }
        Catch
        {
            $object.Manager = "Manager not found"
        }
        $object
        $array += $object
    }
    elseif ($possiblenames.count -eq 1)
    {
        $possiblenames | select displayname, samaccountname
        $object.uglyname = $i
        $object.displayname = $possiblenames.displayname
        $object.multiple = "No"
        $object.Full_Name = $possiblenames.name
        $object.Login_Name = $possiblenames.samaccountname
        $object.Title = $possiblenames.title
        $object.Department = $possiblenames.department
        $object.Office = $possiblenames.city
        $object.Desk = $possiblenames.physicalDeliveryOfficeName
        try
        {
            $TestManager = (get-qaduser ($possiblenames.manager)).name
            $object.Manager = $TestManager
        }
        Catch
        {
            $object.Manager = "Manager not found"
        }
        $object
        $array += $object
    }
    else
    {
        $object.uglyname = $i
        $object.displayname = "No user found"
        $object.Login_name = "No user found"
        $object.multiple = "No"
        $object
        $array += $object
    }
}
