param (
   [string]$action = "install",
   [string]$exec_id,
   [string]$agent_version
)
start-sleep -s 5

$OSMOSIX_INSTALL_DIR = 'c:\Program Files'
$STAGE_DIR= "{0}\cliqrstage" -f $OSMOSIX_INSTALL_DIR
$C3_STAGE_DIR= "{0}\c3agent" -f $STAGE_DIR
$C3_STAGE_CLIQR_DIR= "{0}\osmosix" -f $C3_STAGE_DIR
$C3_BACKUP_DIR= "{0}\backup" -f $STAGE_DIR

$OSMOSIX_HOME= "{0}\osmosix" -f $OSMOSIX_INSTALL_DIR
$PRSRV = "{0}\bin\prunsrv.exe" -f $OSMOSIX_HOME
$LOG_DIR="{0}\log" -f $STAGE_DIR
$LOG_FILE="C:/Program Files/cliqrstage/log/c3upgrade.log"
if(!(Test-Path $LOG_DIR)){
    mkdir $LOG_DIR
}

if(Test-Path $C3_BACKUP_DIR){
    rm -recurse -force $C3_BACKUP_DIR
}

$C3_AGENT_DIR="{0}\c3agent" -f $OSMOSIX_INSTALL_DIR
$C3_CLIQR_FOLDER="{0}\osmosix" -f $C3_AGENT_DIR
$C3_JETTY_FOLDER="{0}\jetty" -f $C3_AGENT_DIR
$C3_PROP_FILE="{0}\etc\c3upgrade.prop" -f $OSMOSIX_HOME

$JETTY_SERVICE_OLD_NAME="JettyService"
$JETTY_HOME="C:\opt\jetty"
$JETTY_SERVICE_NEW_NAME="JettyService"
$JAVA_FOLDER="{0}\Java" -f $OSMOSIX_INSTALL_DIR
$JAVA_FOLDER_NAME="jre1.8.0_121"
$JAVA_FOLDER_PATH="{0}\$JAVA_FOLDER_NAME" -f $JAVA_FOLDER

$PROFILE_PROPERTIES="{0}\etc\profile.properties" -f $C3_CLIQR_FOLDER
$CLOUD_FILE="{0}\etc\cloud" -f $C3_CLIQR_FOLDER

function write_to_log($msg) {
        echo "$msg" >> $LOG_FILE
        echo "$msg"
        return 0
}

function check_error($status, $msg, $exit_status) {
	if(!$status){
		echo "Error : $msg" >> $LOG_FILE
		if($exit_status -eq 2){
		    write_to_log "Restoring the agent"
            restore_old_agent_files
            write_to_log "Restoring the agent completed"
            update_agent_status_in_prop_file "UPGRADE-FAILURE-RESTORE-SUCCESS"
            write_to_log "Updated the prop file after restore"
		}
		if($exit_status -eq 3){
            update_agent_status_in_prop_file "UPGRADE-FAILURE-RESTORE-FAILED"
            write_to_log "Updated the prop file after upgrade and restore failure"
		}
        exit $exit_status
	}
	return 0
}

function start_stop_service($service_name, $service_action) {
	$a = Get-WMIObject -Query "Select * From Win32_Service where Name='$service_name'"
        if( $a -eq $null ){
                write_to_log "The service $service_name doesnot exist. Skipping the $service_action of this service"
                return 0
        }
	if ( $service_action -eq "start" ) {
		write_to_log "Starting the service $service_name"
		Start-Service "$service_name"
		check_error "$?" "Failed to start $service_name" -1
		write_to_log "Started the service $service_name"
	}
	elseif ( $service_action -eq "stop" ) {
        write_to_log "Stopping the service $service_name"
		#Stop-Service "$service_name"
		#Added to fix hanging Jetty issue 6/16
		(gwmi win32_service | where { $_.name -eq $service_name }).stopservice()
		sleep 3
		if ((gwmi win32_service | where { $_.name -eq $service_name }).state -eq "Stop Pending")
		{
			Stop-Process -Id ((gwmi win32_service | where { $_.name -eq $service_name }).processid) -Force
		}
		check_error "$?" "Failed to stop $service_name" -1
        write_to_log "Stopped the service $service_name"
    }
	else {
		write_to_log "Unknown service_action $service_name , doing nothing"
		exit -1
	}
}

function delete_service($service_name) {
	$a = Get-WMIObject -Query "Select * From Win32_Service where Name='$service_name'"
        if( $a -eq $null ){
                write_to_log "The service $service_name doesnot exist. Skipping the deletion of this service"
                return 0
        }
	write_to_log "Deleting the service $service_name"
	cmd /c sc delete "$service_name"
	Start-Sleep -s 5
	$b = Get-WMIObject -Query "Select * From Win32_Service where Name='$service_name'"
	if( $b -ne $null ){
		write_to_log "Failed to delete the service $service_name"
		exit 2
	}
	write_to_log "Deleted the service $service_name"
	start-sleep 3
	return 0
}

function create_prop_file() {
    if($action -ne "upgrade"){
        return 0
    }
    if($exec_id -eq "3.2.6"){
        return 0
    }
    write_to_log "creating the property file : $C3_PROP_FILE"
    if(Test-Path $C3_PROP_FILE){
            rm -force $C3_PROP_FILE
    }

    if($action -eq "upgrade"){
        $action_progress="UPGRADING"
        echo "agentStatus=$action_progress" > $C3_PROP_FILE
    }
    else {
        $action_progress="INSTALLING"
        echo "agentStatus=$action_progress" > $C3_PROP_FILE
    }

    $date=date
    echo "lastOperationTimeStamp=$date" >> $C3_PROP_FILE
    echo "currentAgentVersion=$agent_version" >> $C3_PROP_FILE
    echo "logFile=$LOG_FILE" >> $C3_PROP_FILE
    if($exec_id -ne 0){
        echo "actionExecutionId=$exec_id" >> $C3_PROP_FILE
    }
    write_to_log "created the property file : $C3_PROP_FILE"
}

function update_agent_status_in_prop_file($agent_status){
    if($action -ne "upgrade"){
        return 0
    }
    if($exec_id -eq "3.2.6"){
        return 0
    }
    write_to_log "updating the property file with agent status $agent_status"
    echo "agentStatus=$agent_status" > $C3_PROP_FILE
    $date=date
    echo "lastOperationTimeStamp=$date" >> $C3_PROP_FILE
    echo "currentAgentVersion=$agent_version" >> $C3_PROP_FILE
    echo "logFile=$LOG_FILE" >> $C3_PROP_FILE
    if($exec_id -ne 0){
        echo "actionExecutionId=$exec_id" >> $C3_PROP_FILE
    }
    write_to_log "Updated the property file with agent status $agent_status"
}

function copy_old_agent_files() {
	write_to_log "Copying config files from prev agent..."
	if(Test-Path $OSMOSIX_HOME\lib\Newtonsoft.Json.dll){
                Copy-item -path $OSMOSIX_HOME\lib\Newtonsoft.Json.dll -destination $C3_STAGE_CLIQR_DIR\lib -force
                check_error "$?" "Failed to copy into cliqrstage folder" 1
        }
	if(Test-Path $OSMOSIX_HOME\etc\AGENTINSTALLED){
		Copy-item -path $OSMOSIX_HOME\etc\AGENTINSTALLED -destination $C3_STAGE_CLIQR_DIR\etc -force
		check_error "$?" "Failed to copy into cliqrstage folder" 1
	}

	if(Test-Path $OSMOSIX_HOME\etc\buildType){
        Copy-item -path $OSMOSIX_HOME\etc\buildType -destination $C3_STAGE_CLIQR_DIR\etc -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }

	if(Test-Path $OSMOSIX_HOME\etc\cloud){
        Copy-item -path $OSMOSIX_HOME\etc\cloud -destination $C3_STAGE_CLIQR_DIR\etc -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }

	if(Test-Path $OSMOSIX_HOME\etc\component){
        Copy-item -path $OSMOSIX_HOME\etc\component -destination $C3_STAGE_CLIQR_DIR\etc -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }

	if(Test-Path $OSMOSIX_HOME\etc\hostid){
        Copy-item -path $OSMOSIX_HOME\etc\hostid -destination $C3_STAGE_CLIQR_DIR\etc -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }

	if(Test-Path $OSMOSIX_HOME\etc\region){
        Copy-item -path $OSMOSIX_HOME\etc\region -destination $C3_STAGE_CLIQR_DIR\etc -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }

	if(Test-Path $OSMOSIX_HOME\etc\user-data){
        Copy-item -path $OSMOSIX_HOME\etc\user-data -destination $C3_STAGE_CLIQR_DIR\etc -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }

	if(Test-Path $OSMOSIX_HOME\etc\profile.properties){
        Copy-item -path $OSMOSIX_HOME\etc\profile.properties -destination $C3_STAGE_CLIQR_DIR\etc -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }

    if(Test-Path $OSMOSIX_HOME\.cliqrAppInstalled){
        Copy-item -path $OSMOSIX_HOME\.cliqrAppInstalled -destination $C3_STAGE_CLIQR_DIR -force
        check_error "$?" "Failed to copy cliqrAppInstalled into cliqrstage folder" 1
    }

    if(Test-Path $C3_PROP_FILE){
            Copy-item -path $C3_PROP_FILE -destination $C3_STAGE_CLIQR_DIR\etc -force
            check_error "$?" "Failed to copy c3upgrade.prop into cliqrstage folder" 1
    }

	if (Test-Path $OSMOSIX_HOME\logs) {
		Copy-item -path $OSMOSIX_HOME\logs -destination $C3_STAGE_CLIQR_DIR -recurse
	}
	else {
		New-Item -Path $C3_STAGE_CLIQR_DIR\logs -ItemType Directory
	}

	if(Test-Path $OSMOSIX_HOME\bin\prunsrv.exe){
        Copy-item -path $OSMOSIX_HOME\bin\prunsrv.exe -destination $C3_STAGE_CLIQR_DIR\bin -force
        check_error "$?" "Failed to copy into cliqrstage folder" 1
    }
	write_to_log "Completed copying config files from prev agent ..."
	return 0
}

function create_c3_links() {
	write_to_log "Creating all required links for c3agent..."
	cd $C3_AGENT_DIR
	check_error "$?" "Failed to cd into c3agent folder" 2
	if(!(Test-Path "osmosix")){
		check_error "False" "osmosix folder missing in c3agent folder" 2
	}
	if(!(Test-Path "jetty")){
		check_error "False" "jetty folder missing in c3agent folder" 2
	}
    if(!(Test-Path "$JAVA_FOLDER_NAME")){
		check_error "False" "$JAVA_FOLDER_NAME folder missing in c3agent folder" 2
	}
	cmd /c mklink /d "$OSMOSIX_HOME" "$C3_CLIQR_FOLDER"
	check_error "$?" "Failed to create symlink for osmosix folder" 2
	write_to_log "Created the symlink for $OSMOSIX_HOME"

    cmd /c mklink /d "$JETTY_HOME" "$C3_JETTY_FOLDER"
    check_error "$?" "Failed to create symlink for jetty folder" 2
    write_to_log "Created the symlink for $JETTY_HOME"

    if(!(Test-Path $JAVA_FOLDER_PATH)){
       cmd /c mklink /d "$JAVA_FOLDER_PATH" "$C3_AGENT_DIR\$JAVA_FOLDER_NAME"
       check_error "$?" "Failed to create symlink for $JAVA_FOLDER_NAME folder" 2
       write_to_log "Created the symlink for $JAVA_FOLDER_PATH"
    }
	cmd /c "$OSMOSIX_HOME\etc\installJettyService.bat"
	check_error "$?" "Failed to install jetty service" 2
	write_to_log "Created the new JettyService"
}


function remove_old_jetty_service() {
    if ( $exec_id -eq "3.2.6" ) {
	delete_service "CliQrBootstrappingService"
        delete_service "CliQrAgentService"
	delete_service "CliQrDFSStartupService"
        write_to_log "Skipping JettyService deletion as it is a 3.2.6 agent upgrade"
	Start-Sleep 10
	taskkill.exe /F /IM rundll32.exe
    }
    else {
        delete_service "$JETTY_SERVICE_OLD_NAME"
    }
}

function restore_old_jetty_service(){
        write_to_log "Restoring the old JettyService"
		if(Test-Path $JAVA_FOLDER_PATH){
            cmd /c rmdir $JAVA_FOLDER_PATH
		}
		if(Test-Path $JAVA_FOLDER_PATH){
            rm -force -recurse $JAVA_FOLDER_PATH
        }
		mv "$C3_AGENT_DIR\$JAVA_FOLDER_NAME" "$JAVA_FOLDER"
		cmd /c "$OSMOSIX_HOME\etc\installJettyService.bat"
		check_error "$?" "Failed to install jetty service from old installJettyService.bat" 3
		write_to_log "Restoring the old JettyService completed"
}

function backup_old_agent_files(){
    write_to_log "Backing up the old agent files"
	mkdir $C3_BACKUP_DIR
	mv "$OSMOSIX_HOME" "$C3_BACKUP_DIR"
	check_error "$?" "Failed to osmosix folder into cliqrstage backup folder" 1
	if ( $exec_id -eq "3.2.6" ) {
        write_to_log "3.2.6 agent upgrade skipping the JETTY_HOME backup"
    }
    else {
        mv "$JETTY_HOME" "$C3_BACKUP_DIR"
    }

	write_to_log "Backup complete for the folders $OSMOSIX_HOME and  $JETTY_HOME"
}

function restore_old_agent_files(){
    write_to_log "Restoring the old agent files"
	cmd /c rmdir "$OSMOSIX_HOME"
	mv "$C3_BACKUP_DIR\osmosix" "$OSMOSIX_INSTALL_DIR"
	check_error "$?" "Failed to move osmosix folder from backup into $OSMOSIX_INSTALL_DIR" 3
	cmd /c rmdir "$JETTY_HOME"
	mv "$C3_BACKUP_DIR\jetty" "C:\opt"
	check_error "$?" "Failed to move osmosix folder from backup into $OSMOSIX_INSTALL_DIR" 3
	restore_old_jetty_service
	rm -recurse -force $C3_AGENT_DIR
	start_services
	check_error "$?" "Failed to start the services" 3
	write_to_log "Completed the restore of old agent files"
}

function place_new_agent_and_links(){
    write_to_log "Placing the new agent links"
    if(Test-Path "$C3_AGENT_DIR"){
       rm -force -recurse $C3_AGENT_DIR
    }
    mv "$C3_STAGE_DIR" "$OSMOSIX_INSTALL_DIR"
    check_error "$?" "Failed to move c3agent folder into C:\Program Files\ from cliqrstage" 2
    create_c3_links
    write_to_log "Completed placing the new agent links"
}

function stop_services() {
    write_to_log "Stopping the services"
    start_stop_service "CliQrStartupService" "stop"
    if ( $exec_id -eq "3.2.6" ) {
        write_to_log "3.2.6 agent upgrade - stopping old services"
	start_stop_service "CliQrDFSStartupService" "stop"
        start_stop_service "CliQrAgentService" "stop"
        start_stop_service "CliQrBootstrappingService" "stop"
        start-sleep 5
	if(!(Test-Path "C:\opt\temp")){
            mkdir 'C:\opt\temp'
   	}
	taskkill.exe /F /IM rundll32.exe
    }
    else{
        start_stop_service "$JETTY_SERVICE_OLD_NAME" "stop"
    }
    write_to_log "Stopping the services complete.."
}

function start_services() {
    Copy-Item "$C3_CLIQR_FOLDER\lib\agent.war" "$JETTY_HOME\webapps"
    write_to_log "Starting the services"
    start_stop_service "$JETTY_SERVICE_OLD_NAME" "start"
    #Start-Sleep 5
    #start_stop_service "CliQrStartupService" "start"
     write_to_log "Starting the services complete"
}

function create_profile() {
    (Get-WmiObject -class Win32_TSGeneralSetting -Namespace root\cimv2\terminalservices -Filter "TerminalName='RDP-tcp'").SetUserAuthenticationRequired(0)
    if(!(Test-Path $PROFILE_PROPERTIES)){
        if(Test-Path $CLOUD_FILE){
            $CLOUD_TYPE=Get-Content $CLOUD_FILE
            $CLOUD_TYPE = $CLOUD_TYPE.substring(0,1).toupper()+$CLOUD_TYPE.substring(1)
            "cloud=$CLOUD_TYPE" | Out-File -Encoding ascii $PROFILE_PROPERTIES
        }
        else{
            write_to_log "Cannot find the cloud file, we cannot proceed further"
            exit -1
        }
    }
    Start-Sleep 5
}

stop_services
start-sleep 5
create_prop_file

if(!(Test-Path $C3_STAGE_CLIQR_DIR)){
        write_to_log "c3stage directory missing, cannot proceed"
        update_agent_status_in_prop_file "UPGRADE-FAILURE-RESTORE-SUCCESS"
        exit -1
}

if(!(Test-Path $OSMOSIX_HOME)){
        write_to_log "Osmosix home directory missing, cannot proceed"
        update_agent_status_in_prop_file "UPGRADE-FAILURE-RESTORE-SUCCESS"
        exit -1
}



if(Test-Path $C3_CLIQR_FOLDER){
    cmd /c rmdir "$OSMOSIX_HOME"
    cmd /c rmdir "$JETTY_HOME"
	mv "$C3_CLIQR_FOLDER" "$OSMOSIX_INSTALL_DIR"
	mv "$C3_JETTY_FOLDER" "$JETTY_HOME"
}

copy_old_agent_files
remove_old_jetty_service
backup_old_agent_files
place_new_agent_and_links

if($action -eq "upgrade"){
    $action_complete="UPGRADED"
    update_agent_status_in_prop_file $action_complete
}
else {
    $action_complete="INSTALLED"
    update_agent_status_in_prop_file $action_complete
}

create_profile
start_services
