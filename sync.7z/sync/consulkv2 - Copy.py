import argparse
import requests
import logging
import sys
import os
import ast

logging.basicConfig(level=logging.INFO)

parser = argparse.ArgumentParser(description='Modify Consul CMDB KV Store')
parser.add_argument('--project', required=True, type=str, help='Specify a project name')
parser.add_argument('--department', required=True, type=str, help='Specify a department name')
parser.add_argument('--component', type=str, help='Specify a component name')
parser.add_argument('--artifactorylabel', required=True, type=str, help='Specify an artifactory label')
parser.add_argument('--environment', required=False, type=str, help='Specify an environment', default='dev')
parser.add_argument('--file', type=str, help='Specify a file for configs')
#parser.add_argument('--data', type=dict, help='Specify a file for configs',default={})
#parser.add_argument('--d', type=json.loads)
parser.add_argument('--data', type=str, default="")

args = parser.parse_args()
#argsdata = parser.parse_args(['d'])


#define variables from arguments
project = args.project
department = args.department
component = args.component
environment = args.environment
artifactorylabel = args.artifactorylabel
file = args.file
#Take the data string (formatted as a dictionary) and turn it into an actual dictionary
if args.data != "":
     data = ast.literal_eval(args.data)
else:
      data = ""

#Write to the consul CMDB KV store with the full artifactory path, the package version key will be tagged with the buildlabel argument
#default value for builds - if environment is null then default to dev

try:
	if data != "":
         for key, value in data.iteritems():
             print "%s - %s" % (key, value)
             logging.info("INFO: Writing to CMDB at: http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel, key))
             r=requests.put("http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel, key), verify=False, data=value)
	#else:
	   #logging.info("INFO: Writing to CMDB at: http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel))
	   #r=requests.put("http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/" % (department, project, component, environment, artifactorylabel), verify=False, data=buildlabel)
except requests.exceptions.HTTPError as e:
    # Whoops it wasn't a 200
    logging.exception("ERR: Non 200 on request to CMDB")
    sys.exit(1)
except Exception as e:
	logging.exception("ERR: Caught a non 200 error")
	sys.exit(1)

#If we have a config file create a new directory with the config file name and set all the kvs under it
if file:
     if os.path.exists(file):
         fp = open(file, "r")
         content = fp.read()
         fp.close()
     for line in content.splitlines():
	     if line.rfind("=") != -1:
	         key = line.split("=")[0]
	         value = line.split("=")[1]
	         filename = (os.path.basename(file)).rsplit(".")[0]
	         #print "the key is %s" % key
	         #print "the value is %s" % value
	         print "INFO: Writing to CMDB at: http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel, filename, key)
	         r=requests.put("http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel, filename, key), verify=False, data=value)


#for item in data
#   item.key
#   item.value#

#for key, value in data.iteritems():
#   print "%s - %s" % (key, value)
#   logging.info("INFO: Writing to CMDB at: http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s" % (department, project, component, environment, artifactorylabel, key))
#   r=requests.put("http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/%s/%s/%s/%s/%s/" % (department, project, component, environment, artifactorylabel, key), verify=False, data=value)

