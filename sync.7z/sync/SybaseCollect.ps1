﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/4/2016 5:11 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$array = @()
$files = Get-ChildItem \\nasshare\share\test\SybaseResults
foreach ($result in $files)
{
	$file = get-content \\nasshare\share\test\SybaseResults\$($result.Name)
	$object = "" | select User, PC, SybaseFolderFileCount, SybaseFolderSize, iSQLtest, iSQLVersion, EnvironmentPath, SybaseEnvVariable, SybaseOCSEnvVariable, ODBC32BitMerantDriverTest, ODBC32bitSybaseASEDriverTest, ODBC64bitSybaseASEDriverTest, ODBC32bitSybaseIQDriverTest, ODBC64bitSybaseIQDriverTest
	$object.User = (($($result.Name) -replace ("SybaseCheck-")).split("-") | where { $_ -like "*.txt" }) -replace ".txt"
	$object.PC = (($($result.Name) -replace ("SybaseCheck-")) -replace ($object.user)) -replace ("-.txt")
	$object.SybaseFolderFileCount = $file[1] -replace "File Count: "
	$object.SybaseFolderSize = $file[2] -replace "File Size: "
	$object.iSQLtest = $file[([array]::indexof($file, "iSQL Test") + 3)]
	$object.iSQLVersion = $file[([array]::indexof($file, "iSQL Version") + 1)]
	$object.EnvironmentPath = ""
	$object.SybaseEnvVariable = $file[([array]::indexof($file, "Environment Sybase") + 1)]
	$object.SybaseOCSEnvVariable = $file[([array]::indexof($file, "Environment Sybase_OCS") + 1)]
	$object.ODBC32BitMerantDriverTest = if (($file[([array]::indexof($file, "ODBC 32bit MERANT Driver") + 1)]) -like "SQLSTATE =IM002") { $file[([array]::indexof($file, "ODBC 32bit MERANT Driver") + 3)] } else { ($file[([array]::indexof($file, "ODBC 32bit MERANT Driver") + 1)]) }
	$object.ODBC32bitSybaseASEDriverTest = if (($file[([array]::indexof($file, "ODBC 32bit Sybase ASE Driver") + 1)]) -like "SQLSTATE =IM002") { $file[([array]::indexof($file, "ODBC 32bit Sybase ASE Driver") + 3)] } else { ($file[([array]::indexof($file, "ODBC 32bit Sybase ASE Driver") + 1)]) }
	$object.ODBC64bitSybaseASEDriverTest = if (($file[([array]::indexof($file, "ODBC 64bit Sybase ASE Driver") + 1)]) -like "SQLSTATE =IM002") { $file[([array]::indexof($file, "ODBC 64bit Sybase ASE Driver") + 3)] } else { ($file[([array]::indexof($file, "ODBC 64bit Sybase ASE Driver") + 1)]) }
	$object.ODBC32bitSybaseIQDriverTest = if (($file[([array]::indexof($file, "ODBC 32bit Sybase IQ Driver") + 1)]) -like "SQLSTATE =IM002") { $file[([array]::indexof($file, "ODBC 32bit Sybase IQ Driver") + 3)] } else { ($file[([array]::indexof($file, "ODBC 32bit Sybase IQ Driver") + 1)]) }
	$object.ODBC64bitSybaseIQDriverTest = if (($file[([array]::indexof($file, "ODBC 64bit Sybase IQ Driver") + 1)]) -like "SQLSTATE =IM002") { $file[([array]::indexof($file, "ODBC 64bit Sybase IQ Driver") + 3)] } else { ($file[([array]::indexof($file, "ODBC 64bit Sybase IQ Driver") + 1)]) }
	
	$object
	$array += $object
}