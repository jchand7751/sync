﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/4/2015 9:09 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($Floor)
Add-PSSnapin Quest.ActiveRoles.ADManagement
Connect-QADService vms001p7
$computers = Get-QADComputer -ComputerName nb-$floor* -sizelimit 0 | select name
$array = @()
foreach ($computer in $computers.name)
{
	$object = "" | select Computer, UEV, Appsense, LoggedInUser
	$object.Computer = $computer
	if ((Test-Connection -ComputerName $computer -Count 1 -Quiet) -eq $true)
	{
		try
		{
			$object.Appsense = (Get-Service -ComputerName $computer -Name "AppSense Client Communications Agent" -ea 'Stop').status
		}
		catch
		{
			$object.Appsense = "Not installed"
		}
		try
		{
			$object.UEV = (Get-Service -ComputerName $computer -Name UevAgentService -ea 'Stop').status
		}
		catch
		{
			$object.UEV = "Not installed"
		}
		$object.LoggedInUser = (gwmi Win32_ComputerSystem -ComputerName $computer).username
		$object
		$array += $object
	}
	else
	{
		$object.Appsense = "Computer offline"
		$object.UEV = "Computer offline"
		$object
		$array += $object
	}
}
$array | Export-Csv c:\temp\nb$floor-UEVreport.csv -Force