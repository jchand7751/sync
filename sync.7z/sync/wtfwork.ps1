﻿$a = get-content C:\temp\someDLs.txt

$array = @()
foreach ($i in $a) 
{
    $b = get-qadgroup $i | get-qadgroupmember -Indirect
    $b.count
    foreach ($g in $b) 
    {
        $b
        $object = "" | select loginid, DL ; 
        $object.loginid = $g.samaccountname
        $object.DL = $i
        $array += $object
    }
}

$arr = $array
$array2 = @()
foreach ($i in $arr) 
{
    $object = "" | select LoginID, LastName, FirstName, Title, Department, Manager, Office, Location, Country, Email, Phonenumber, DL
    $testforuser = get-qaduser -samaccountname $i.loginid -includedproperties co | select lastname, firstname, samaccountname, title, department, city, email, phonenumber, l, co, manager
    if ($testforuser)
    {
       $object.LastName = $testforuser.lastname
       $object.FirstName = $testforuser.firstname
       $object.LoginID = $testforuser.samaccountname
       $object.Title = $testforuser.title
       $object.Department = $testforuser.department
       $object.Office = $testforuser.city
       $object.Email = $testforuser.email
       $object.Phonenumber = $testforuser.phonenumber
       $object.location = $testforuser.l
       $object.country = $testforuser.co
       $object.DL = $i.DL
       try
       {
            $TestManager = (get-qaduser ($testforuser.manager)).name
            $object.Manager = $TestManager
       }
       Catch
       {
        $object.Manager = "Manager not found"
       }
       $array2 += $object
    }
}