﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/17/2016 4:30 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


powershell.exe -command "&{ do { $checkdask = test-path E:\vendor\pimco_common\pypimco_infra\anaconda\400.1\pithon\Scripts\dask-scheduler.exe; sleep 1; write-host "checking" }until ($a -eq $true) }"

powershell.exe -command "&{ $counter=0 ; $path="E:\vendor\pimco_common\pypimco_infra\anaconda\400.1\pithon\Scripts\dask-scheduler.exe" ; do { $a = test-path $path; sleep 1; $counter++ }until ($a -eq $true -or $counter -ge 300) ; start-process $path}"

E:\vendor\pimco_common\pypimco_infra\anaconda\400.1\pithon\Scripts\dask-scheduler.exe

powershell.exe -command "&{ test-path E:\vendor\pimco_common\pypimco_infra\anaconda\400.1\pithon\Scripts\dask-schasd }"

function WaitForFile($File)
{
	while (!(Test-Path "E:\vendor\pimco_common\pypimco_infra\anaconda\400.1\pithon\Scripts\dask-scheduler.exe")) { Start-Sleep -s 5 }}  

	
