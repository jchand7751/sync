﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/24/2013 10:15 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

#$domains = "sscims.com", "imswest.sscims.com", "development.enterprise.sscims.com", "beta.enterprise.sscims.com", "pimco.imswest.sscims.com", "enterprise.sscims.com"
$domains = "sscims.com", "imswest.sscims.com"
$DCarray = @()
foreach ($i in $domains)
	{
	$domainconnect = Connect-QADService $i
	$DCarray += Get-QADComputer -searchroot "OU=Domain Controllers,$($domainconnect.defaultnamingcontext.dn)"
	}

foreach ($DC in $DCarray)
	{
	$DC.name
	$DC.guid
	REPADMIN /syncall /A /e /q $DC.name
	}