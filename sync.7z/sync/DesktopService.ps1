﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/4/2016 3:46 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Determine whether you're a UEV user or an Appsense user and start the required service(s).
#>
$Username = ((whoami) -split "pimco\\")[1]
$computer = hostname
$logfile = "C:\temp\ServiceStartup-$username-$computer.txt"

#Functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

Add-Content -Path $logfile "$(executiontime) - Starting script"
$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$Username))"
$searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com'
$user = $searcher.FindOne().GetDirectoryEntry()
$uevcheck = if (($user.memberof | where { $_ -like "CN=UEV_Users*" }) -notlike "") { "True" } else { "False" }
$appsensecheck = if (($user.memberof | where { $_ -like "*Appsense*" }) -notlike "") { "True" } else { "False" }

if ($user -like "")
{
	Add-Content -Path $logfile "$(executiontime) - Couldn't find a user for $username"
	Add-Content -Path $logfile "$(executiontime) - Script complete"
	Exit
}

if ($uevcheck -eq "True" -and $appsensecheck -eq "True")
{
	Add-Content -Path $logfile "$(executiontime) - $Username is a member of both groups, please resolve"
	Add-Content -Path $logfile "$(executiontime) - Script complete"
	Exit
}

if ($uevcheck -eq "False" -and $appsensecheck -eq "False")
{
	Add-Content -Path $logfile "$(executiontime) - $Username is a member of neither group, please resolve"
	Add-Content -Path $logfile "$(executiontime) - Script complete"
	Exit
}

switch ($uevcheck)
{
	"True" {
		Add-Content -Path $logfile "$(executiontime) - UEV user"
		if ((Get-Service -Name UevAgentService).status -eq "Running")
		{
			Add-Content -Path $logfile "$(executiontime) - UEV service already started"
		}
		else
		{
			try
			{
				Write-Verbose "Starting UEV on local PC"
				Add-Content -Path $logfile "$(executiontime) - Starting UEV on remote PC"
				(gwmi win32_service -filter "Name='UevAgentService'" -ComputerName $computer).StartService() | Out-Null
			}
			catch
			{
				Write-Warning "Failed to start UevAgentService on $computer"
				Add-Content -Path $logfile "$(executiontime) - Failed to start UevAgentService on $computer"
			}
		}
		
		#Stop appsense services
		$AppsenseServices = "'Appsense Client Communications Agent'", "'AppSense EmCoreService'", "'AppSense Watchdog Service'"
		foreach ($service in $AppsenseServices)
		{
			try
			{
				Write-Verbose "Stopping $service"
				Add-Content -Path $logfile "$(executiontime) - Stopping $service"
				(gwmi win32_service -filter "Name=$service" -ComputerName $computer).StopService() | Out-Null
			}
			Catch
			{
				Write-Warning "Failed to stop $service"
				Add-Content -Path $logfile "$(executiontime) - Failed to stop $service"
			}
		}
	}
	default { }
}

switch ($appsensecheck)
{
	"True" {
		Add-Content -Path $logfile "$(executiontime) - UEV service already started"
		if (((gwmi win32_service -filter "Name='Appsense Client Communications Agent'").state) -eq "Running")
		{
			Add-Content -Path $logfile "$(executiontime) - Stopping Appsense service already started"
		}
		else
		{
			$AppsenseServices = "'Appsense Client Communications Agent'", "'AppSense EmCoreService'", "'AppSense Watchdog Service'"
			foreach ($service in $AppsenseServices)
			{
				try
				{
					Write-Verbose "Starting $service"
					Add-Content -Path $logfile "$(executiontime) - Starting $service"
					(gwmi win32_service -filter "Name=$service" -ComputerName $computer).StartService() | Out-Null
				}
				Catch
				{
					Write-Warning "Failed to start $service"
					Add-Content -Path $logfile "$(executiontime) - Failed to start $service"
				}
			}
		}
		
		#Stop appsense services
		$AppsenseServices = "UEVAgentService"
		foreach ($service in $UEVServices)
		{
			try
			{
				Write-Verbose "Stopping $service"
				Add-Content -Path $logfile "$(executiontime) - Stopping $service"
				(gwmi win32_service -filter "Name=$service" -ComputerName $computer).StopService() | Out-Null
			}
			Catch
			{
				Write-Warning "Failed to stop $service"
				Add-Content -Path $logfile "$(executiontime) - Failed to stop $service"
			}
		}
	}
	default { }
}

Add-Content -Path $logfile "$(executiontime) - Script complete"