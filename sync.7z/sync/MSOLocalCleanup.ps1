﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/16/2017 3:47 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#Add-PSSnapin Quest.ActiveRoles.ADManagement
#Get-QADGroup -Name o365- -Service pimco.imswest.sscims.com | Set-QADUser -Service pimco.imswest.sscims.com -ObjectAttributes @{ cloudsync = "True" } -whatif

Connect-Msolservice
$users = get-msoluser
$users = $users | where { $_.userprincipalname -like "*onmicrosoft.com" }
foreach ($u in $users)
{
	$ask = Read-host "Would you like to remove $($u.userprincipalname)? (Y/N)"
	if ($ask -eq "Y")
	{
		$u | Remove-Msoluser -force
	}
}

#Find SKU
$array = @()
$users | foreach {
	if ($_.licenses.accountskuid.contains("PIMCO:YAMMER_ENTERPRISE_STANDALONE") -eq $true)
	{
		write-host "$($_.userprincipalname) has the wrong yammer sku"
		$array += $_.userprincipalname
	}
}

$array = @()
$users | foreach {
	$object = "" | select User, E3, Yammer, CRM
	$object.User = $_.userprincipalname
	if ($_.licenses.accountskuid.contains("PIMCO:ENTERPRISEPACK") -eq $true)
	{
		write-host "$($_.userprincipalname) has E3"
		$object.E3 = "Yes"
	}
	else
	{
		$object.E3 = "No"
	}
	
	if ($_.licenses.accountskuid.contains("PIMCO:CRMSTANDARD") -eq $true)
	{
		write-host "$($_.userprincipalname) has CRM"
		$object.CRM = "Yes"
	}
	else
	{
		$object.CRM = "No"
	}
	
	if (($_.licenses.servicestatus | where { $_.serviceplan.servicename -eq "YAMMER_ENTERPRISE" }).provisioningstatus -eq "Success")
	{
		write-host "$($_.userprincipalname) has YAMMER"
		$object.Yammer = "Yes"
	}
	else
	{
		$object.Yammer = "No"
	}
	
	$array += $object
}