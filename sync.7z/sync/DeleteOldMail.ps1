﻿
#Define variables
$whoami = ((whoami) -split "\\")[1]
$LogPath = "C:\temp\OutlookEmailCleanup-$whoami.txt"
$timestamp = (Get-Date -UFormat %Y-%m-%d-%H%M)

#Create the log file
if  ((Test-Path $LogPath) -eq $true)
{
	if ((Get-Content $LogPath | Select-String "folder exists" -Quiet) -eq $true -or (Get-Content $LogPath | Select-String "folder created" -Quiet) -eq $true)
	{
		#log file indicates success, skipping
		Write-Host "log file indicates success, skipping"
		#exit
	}
}
else
{
	New-Item -Path $LogPath -ItemType File | Out-Null
	Add-Content -Path $LogPath "$timestamp - Script started" | Out-Null
}

#Check if Outlook is open, and account for potential multiple users on the machine
$testps = (gwmi win32_process | where {$_.processname -eq "Outlook.exe"}).getowner() | where {$_.user -notlike $null} -ErrorAction SilentlyContinue

Try
{
    $outlook =  New-Object -comobject outlook.application
}
Catch
{
    Write-Warning "Could not create the com object, exiting"
    Add-Content -Path $LogPath "$timestamp - Could not create the com object"
    Exit
}



$inboxpath = (($outlook.application.getnamespace("mapi")).getdefaultfolder("olfolderinbox")).fullfolderpath

$90dayfolder =  ((($outlook.application.getnamespace("mapi")).getdefaultfolder("olfolderinbox")).folders | where {$_.fullfolderpath -eq ($inboxpath + "\" + "90daydeletionfolder")})
foreach ($mailitem in $90dayfolder.items)
{
    $today = Get-date
    if ($mailitem.ReceivedTime -le ($today.AddDays(-30)))
    {
        write-host "$($mailitem.subject) is old, removing"
    }
    else
    {
        write-host "$($mailitem.subject) isn't old enough"
    }
}

$subfolders = (((($outlook.application.getnamespace("mapi")).getdefaultfolder("olfolderinbox")).folders) | where {$_.fullfolderpath -eq $90dayfolder.fullfolderpath}).folders



$global:foldertree = @()

function FindSubfoldersForCurrentFolder
{
    Param ($folderpath)
    #$folderpath
    #$basecut = ($folderpath.split("\\")).count
    #$subthis = ($folderpath.split("\\")).count - 5
    $global:foldertree += $folderpath
    $endfolder = ($folderpath.split("\"))[5..($folderpath.split("\\")).count]
    
    $endfolder = [string]$endfolder -replace " ","\"

    $parentpath = ($folderpath.replace($endfolder, "")).trimend("\\")
    #$parentpath = $folderpath.replace(($90dayfolder.fullfolderpath), "")

    #difference from 90dayfolderpath
    #$folderpath.replace($parentpath, "")
    #Folder after root
    #$firstfolder = (($folderpath.replace($parentpath, "")) -split "\\")[0]
    $firstfolder = (($folderpath.replace($90dayfolder.fullfolderpath + "\", "")) -split "\\")[0]

    $parentpath = $parentpath + "\" + $firstfolder
    #if ((($folderpath.replace($parentpath, "")) -split "\\").count -ge 2)
    #if ((($folderpath.replace(($90dayfolder.fullfolderpath), "")) -split "\\").count -ge 2)
    #$parentpath
    #$endfolder
    if ($folderpath)
    {
        $splitpath = (($folderpath.replace($parentpath, "")) -split "\\")
        #$splitpath = (($folderpath.replace($90dayfolder.FullFolderPath, ""))).trimstart("\") -split "\\"
        #$splitpath.count
        
        $endpath = $null
        #$query = '($90dayfolder.folders | where {$_.fullfolderpath -eq ' + '"' + "$($90dayfolder.fullfolderpath)" + '\' + "$firstfolder" + '"' + "}).folders"
        $query = '$90dayfolder.folders'
        for ($x = 0 ; $x -lt $splitpath.count ; $x++)
        {
            $splitpath = ($folderpath.replace($parentpath, "")) -split "\\"
            #$splitpath = (($folderpath.replace($90dayfolder.FullFolderPath, ""))).trimstart("\") -split "\\"
            #$splitpath = (($folderpath.replace($90dayfolder.FullFolderPath, ""))) -split "\\"
            #write-host ""
            #write-host "Get the whatever path"
            #$splitpath
            #write-host "----------"
            $pastendpath = $endpath
            
            if ($x -ge 2)
            {
                $pastendpath = "\" + $endpath
                
            }
            $endpath = $splitpath[$x] + "\"
            if ($x -eq 3)
            {
                #write-host "X is 3"
                $parentpath = $parentpath + "\" + $($splitpath[1])
                #$parentpath
                $endpath = $splitpath[$x] + "\"
            }
            if ($x -eq 4)
            {
               # write-host "X is 4"
                $parentpath = $parentpath + "\" + $($splitpath[1])
               # $parentpath
                $endpath = $splitpath[$x - 1] + "\"
            }
            
            #write-host "this is the endpath: "$endpath
            $appendingpath = $parentpath + $pastendpath + $endpath
            $appendingpath = $appendingpath.trimend("\\")
            #$appendingpath
            $query = "(" + $query + ' | where {$_.fullfolderpath -eq ' + '"' + "$appendingpath" + '"' + "}).folders"
        }
        #$query
        $itemsquery = $query.trimend(".folders")
        $itemsquery = $itemsquery + ".items"
        $items = invoke-expression $itemsquery

        foreach ($mailitem in $items)
        {
            $today = Get-date
            if ($mailitem.ReceivedTime -le ($today.AddDays(-30)))
            {
                write-warning "Removing message with subject $($mailitem.Subject) - Sender $($mailitem.SenderName) - ReceivedDate $($mailitem.ReceivedTime)"
                Add-Content -Path $LogPath "$timestamp - Removing message with subject $($mailitem.Subject) - Sender $($mailitem.Sender) - ReceivedDate $($mailitem.ReceivedTime)" | Out-Null
                $mailitem.Delete()
            }
            else
            {
                #write-host "Leaving message alone with subject $($mailitem.Subject) - Sender $($mailitem.SenderName) - ReceivedDate $($mailitem.ReceivedTime)"
            }
        }

        $checkformorefolders = invoke-expression $query
        if ($checkformorefolders)
        {
            foreach ($folder in $checkformorefolders) 
            {
                #$global:foldertree += $folder.fullfolderpath
                #$folder.fullfolderpath
                FindSubfoldersForCurrentFolder $folder.fullfolderpath
            }
        }

    }
    
    if (($90dayfolder.folders | where {$_.fullfolderpath -eq $folderpath}).folders)
    {
        #$global:foldertree += ($90dayfolder.folders | where {$_.fullfolderpath -eq $fullfolderpath}).folders | foreach {$_.fullfolderpath}
        #($90dayfolder.folders | where {$_.fullfolderpath -eq $fullfolderpath}).folders | foreach {$_.fullfolderpath}
        #($90dayfolder.folders | where {$_.fullfolderpath -eq $fullfolderpath}).folders | foreach ($_) {FindSubFoldersForCurrentFolder $_.fullfolderpath}
        foreach ($mailitem in $90dayfolder.items)
        {
            $today = Get-date
            if ($mailitem.ReceivedTime -le ($today.AddDays(-30)))
            {
                write-warning "Removing message with subject $($mailitem.Subject) - Sender $($mailitem.SenderName) - ReceivedDate $($mailitem.ReceivedTime)"
                Add-Content -Path $LogPath "$timestamp - Removing message with subject $($mailitem.Subject) - Sender $($mailitem.Sender) - ReceivedDate $($mailitem.ReceivedTime)" | Out-Null
                $mailitem.Delete()
            }
            else
            {
                #write-host "Leaving message alone with subject $($mailitem.Subject) - Sender $($mailitem.SenderName) - ReceivedDate $($mailitem.ReceivedTime)"
            }
        }
    }
        #write-host "this is folder tree"
#$global:foldertree
}

#do {} until ($SubfoldersforCurrentFolder -eq $null)

foreach ($i in $subfolders)
{
    FindSubfoldersForCurrentFolder $i.fullfolderpath
}