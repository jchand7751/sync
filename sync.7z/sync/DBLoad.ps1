﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/22/2015 10:45 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($type)

function DBLoadSW
{
	[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
	
	$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("ind001p001")
	$db = New-Object Microsoft.SqlServer.Management.Smo.Database
	$db = $srv.Databases.Item("SolarWindsOrion")
	$query = $db.ExecuteWithResults("
	WITH Total_cores(Numberofcores, NodeId) AS
	(
	
	SELECT SUM(NUMBEROFCORES), A.NodeID
	FROM [SolarWindsOrion].[dbo].[AssetInventory_Processor] A WITH (NOLOCK)
	JOIN [SolarWindsOrion].[dbo].[Nodes] N WITH (NOLOCK)
	ON A.NodeID = N.NodeID
	GROUP BY A.NodeID
	),
	Total_capacity(TotalCapacity, NodeId) as
	(
	SELECT SUM(m.CapacityMB), m.NodeID
	FROM [SolarWindsOrion].[dbo].[AssetInventory_MemoryModule] M WITH (NOLOCK)
	JOIN [SolarWindsOrion].[dbo].[Nodes] N WITH (NOLOCK)
	ON m.NodeID = N.NodeID
	GROUP BY M.NodeID
	)
	SELECT N.NodeID, N.Caption, N.LastBoot, N.Environment, N.Department, [Totalcapacity], Numberofcores  FROM
	[SolarWindsOrion].[dbo].[Nodes] N WITH (NOLOCK)
	JOIN
	[Total_capacity] TC
	ON N.NodeID = TC.NodeId
	JOIN  Total_cores TT
	ON N.NodeID = TT.NodeId")
	$swarray = @()
	for ($i = 0; $i -lt $query.Tables.Count; $i++)
	{
		foreach ($row in $query.Tables[$i].rows)
		{
			$object = New-Object psobject
			#Get number of properties this object has
			$objectproperties = ($query.tables[$i].rows | gm | where { $_.membertype -eq "property" })
			for ($x = 0; $x -lt $objectproperties.count; $x++)
			{
				$object | Add-Member noteproperty -Name $objectproperties[$x].name -Value $row.$($objectproperties[$x].name)
			}
			$swarray += $object
		}
	}
	$swarray
	
	#CREATE TABLE SWTable (SW_ID INT IDENTITY(1, 1) PRIMARY KEY CLUSTERED, Caption NVARCHAR(max), Department NVARCHAR(max), Environment NVARCHAR(max), LastBoot NVARCHAR(max), NodeID NVARCHAR(max), NumberofCores NVARCHAR(max), TotalCapacity NVARCHAR(max))
	#GO
	
	[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
	
	$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("ina001d001")
	$db = New-Object Microsoft.SqlServer.Management.Smo.Database
	$db = $srv.Databases.Item("jamestest")
	
	$properties = ($swarray | gm | where { $_.membertype -eq "NoteProperty" }).name
	#Write to DB
	foreach ($item in $swarray)
	{
		$executestring = $null
		for ($x = 0; $x -lt $properties.count; $x++)
		{
			if ($item.($properties[$x]) -notlike "")
			{
				$executestring = $executestring + ", " + "@$($properties[$x]) = " + "'" + "$($item.$($properties[$x]))" + "'"
			}
		}
		$executestring = $executestring.trimstart(", ")
		#$executestring
		$ds = $db.ExecuteNonQuery("Exec usp_insertsw $executestring")
	}
}

function DBLoadAppD
{
	#Query AppDynamics
	$applications = curl --user queryaccount@customer1:Pimco123 http://prodpmappdyn2:8090/controller/rest/applications?output=JSON
	#Convert to object
	$applications = $applications | out-string | ConvertFrom-Json
	$appdarray = @()
	foreach ($app in $applications)
	{
		$tiersinapplication = curl --user queryaccount@customer1:Pimco123 http://prodpmappdyn2:8090/controller/rest/applications/$($app.name)/tiers?output=JSON
		$tiersinapplication = $tiersinapplication | out-string | ConvertFrom-Json
		$tiersinapplication | Add-Member -NotePropertyName Application -NotePropertyValue $($app.name)
		$tiersinapplication | Add-Member -NotePropertyName AppID -NotePropertyValue $($app.id)
		foreach ($tier in $tiersinapplication)
		{
			$nodesrunningthistier = curl --user queryaccount@customer1:Pimco123 http://prodpmappdyn2:8090/controller/rest/applications/$($app.name)/tiers/$($tier.id)/nodes?output=JSON
			$nodesrunningthistier = $nodesrunningthistier | out-string | ConvertFrom-Json
			$tier | Add-Member -notepropertyname nodes -notepropertyvalue ([string]$($nodesrunningthistier.machinename))
			#$tier
			$appdarray += $tier
		}
		#$array += $tiersinapplication
	}
	
	#CREATE TABLE AppDTable (AppD_ID INT IDENTITY(1, 1) PRIMARY KEY CLUSTERED, AgentType NVARCHAR(max), Description NVARCHAR(max), ID NVARCHAR(max), Name NVARCHAR(max), NumberofNodes NVARCHAR(max), Type NVARCHAR(max), Application NVARCHAR(max), AppID NVARCHAR(max), Nodes NVARCHAR(max))
	#GO
	
	[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
	
	$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("ina001d001")
	$db = New-Object Microsoft.SqlServer.Management.Smo.Database
	$db = $srv.Databases.Item("jamestest")
	#Write to DB
	#The old way
	<#
	foreach ($item in $appdarray)
	{
		$variable1 = "'" + $item.agenttype + "'"
		$variable2 = "'" + $item.Description + "'"
		$variable3 = "'" + $item.ID + "'"
		$variable4 = "'" + $item.Name + "'"
		$variable5 = "'" + $item.NumberofNodes + "'"
		$variable6 = "'" + $item.Type + "'"
		$variable7 = "'" + $item.Application + "'"
		$variable8 = "'" + $item.AppID + "'"
		$variable9 = "'" + $item.Nodes + "'"
		$ds = $db.ExecuteNonQuery("INSERT INTO AppDTable(AgentType, Description, ID, Name, NumberofNodes, Type, Application, AppID, Nodes ) VALUES ($variable1, $variable2, $variable3, $variable4, $variable5, $variable6, $variable7, $variable8, $variable9)")
	}
	#>
	$properties = ($appdarray | gm | where { $_.membertype -eq "NoteProperty" }).name
	foreach ($item in $appdarray)
	{
		$executestring = $null
		for ($x = 0; $x -lt $properties.count; $x++)
		{
			if ($item.($properties[$x]) -notlike "")
			{
				$executestring = $executestring + ", " + "@$($properties[$x]) = " + "'" + "$($item.$($properties[$x]))" + "'"
			}
		}
		$executestring = $executestring.trimstart(", ")
		#$executestring
		$ds = $db.ExecuteNonQuery("Exec usp_insertappd $executestring")
	}
}


function DBLoadIIS
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement
	$serverarray = Get-QADComputer -OSName "Windows Server 2008*" -SizeLimit 0 | select name
	
	$RunspaceCollection = @()
	$RunspacePool = [RunspaceFactory]::CreateRunspacePool(1, 40)
	$RunspacePool.Open()
	
	$scriptblock = { param ($server); write-verbose "starting script"; \\naspmhome\technology\Chandler_James\Private\Appsense\scripts\IISDetails.ps1 $server }
	
	foreach ($Server in $serverarray)
	{
		
		#Create a PowerShell object to run add the script and argument.
		$Powershell = [PowerShell]::Create().AddScript($ScriptBlock).AddArgument($($Server.name))
		#Specify runspace to use
		$Powershell.RunspacePool = $RunspacePool
		
		#Create Runspace collection
		[Collections.Arraylist]$RunspaceCollection += New-Object -TypeName PSObject -Property @{
			Runspace = $PowerShell.BeginInvoke()
			PowerShell = $PowerShell
		}
	}
	
	$RunspaceTotal = $RunspaceCollection.count
	$CompletionCount = 0
	$Resultsarray = @()
	while ($RunspaceCollection)
	{
		foreach ($Runspace in $RunspaceCollection.ToArray())
		{
			if ($Runspace.Runspace.IsCompleted)
			{
				#write-host "Run space finished"
				if ($Runspace.Powershell.HadErrors -eq $true)
				{
					$runspace.powershell.streams.error
				}
				#write the data
				$resultsarray += $Runspace.PowerShell.EndInvoke($Runspace.Runspace)
				$Runspace.PowerShell.EndInvoke($Runspace.Runspace)
				#close the session
				$Runspace.PowerShell.Dispose()
				#$runspace.powershell
				$RunspaceCollection.Remove($Runspace)
				$CompletionCount++
				Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
				Write-host "Total count: $RunspaceTotal"
				write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
			}
			else
			{
				sleep 5
				write-host "Run space not done"
				Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
				Write-host "Total count: $RunspaceTotal"
				write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
			}
		}
	}
	
	$array = $Resultsarray
	
	for ($x = 0; $x -lt $array.count; $x++)
	{
		$array[$x] | Add-Member noteproperty -Name id -Value ($x + 1)
	}
	
	#$array
	$array | Export-Csv c:\temp\dbtest1.csv
	
	#CREATE TABLE IISTable (IIS_ID INT IDENTITY(1, 1) PRIMARY KEY CLUSTERED, Server NVARCHAR(max), Name NVARCHAR(max), ParentSiteID NVARCHAR(max), ParentSiteName NVARCHAR(max), SiteID NVARCHAR(max), LogDIrectory NVARCHAR(max), Path NVARCHAR(max), Authentication NVARCHAR(max), Bindings NVARCHAR(max), AppPoolName NVARCHAR(max), AppPool32bitenabled NVARCHAR(max), AppPoolCredential NVARCHAR(max), AppPoolVersion NVARCHAR(max), Type NVARCHAR(max), Webconfig NVARCHAR(max), Id NVARCHAR(max), IISPath NVARCHAR(max))
	#GO
	
	[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
	
	$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("ina001d001")
	$db = New-Object Microsoft.SqlServer.Management.Smo.Database
	$db = $srv.Databases.Item("jamestest")
	#Write to DB
	<#
	foreach ($item in $array)
	{
		$variable1 = "'" + $item.server + "'"
		$variable2 = "'" + $item.Name + "'"
		$variable3 = "'" + $item.ParentSiteID + "'"
		$variable4 = "'" + $item.ParentSiteName + "'"
		$variable5 = "'" + $item.SiteID + "'"
		$variable6 = "'" + $item.LogDirectory + "'"
		$variable7 = "'" + $item.Path + "'"
		$variable8 = "'" + $item.Authentication + "'"
		$variable9 = "'" + $item.Bindings + "'"
		$variable10 = "'" + $item.appPoolName + "'"
		$variable11 = "'" + $item.apppool32bitenabled + "'"
		$variable12 = "'" + $item.apppoolcredential + "'"
		$variable13 = "'" + $item.apppoolversion + "'"
		$variable14 = "'" + $item.type + "'"
		$variable15 = "'" + $item.webconfig + "'"
		$variable16 = "'" + $item.id + "'"
		$variable17 = "'" + $item.iispath + "'"
		$ds = $db.ExecuteNonQuery("INSERT INTO IISTable(Server, Name, ParentSiteID, ParentSiteName, SiteID, LogDirectory, Path, Authentication, Bindings, AppPoolName, AppPool32bitenabled,AppPoolCredential, AppPoolVersion, Type, Webconfig, Id, IISpath ) VALUES ($variable1, $variable2, $variable3, $variable4, $variable5, $variable6, $variable7, $variable8, $variable9, $variable10, $variable11, $variable12, $variable13, $variable14, $variable15, $variable16, $variable17)")
	}
	#>
	$properties = ($array | gm | where { $_.membertype -eq "NoteProperty" }).name
	foreach ($item in $array)
	{
		$executestring = $null
		for ($x = 0; $x -lt $properties.count; $x++)
		{
			if ($item.($properties[$x]) -notlike "")
			{
				$executestring = $executestring + ", " + "@$($properties[$x]) = " + "'" + "$($item.$($properties[$x]))" + "'"
			}
		}
		$executestring = $executestring.trimstart(", ")
		$executestring
		$ds = $db.ExecuteNonQuery("Exec usp_insertiis $executestring")
	}
}

switch ($type)
{
	"IIS" { DBLoadIIS }
	"AppD" { DBLoadAppD }
}

<#
foreach ($thing in $array)
{
	if ($thing.parentsitename)
	{
		$wut = ($thing.parentsitename + "/" + $thing.name)
		#write-host $wut
		$result = $appdarray | where { $_.name -like $wut }
		if ($result)
		{
			$thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue "https://appd/controller/#/location=APP_COMPONENT_MANAGER&timeRange=last_12_hours.BEFORE_NOW.-1.-1.720&application=$($result.appid)&component=$($result.id)&dashboardMode=force"
		}
		else
		{
			$thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue ""
		}
	}
	else
	{
		$wut = ($thing.name)
		#write-host $wut
		$result = $appdarray | where { $_.name -eq $wut }
		if ($result)
		{
			$thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue "https://appd/controller/#/location=APP_COMPONENT_MANAGER&timeRange=last_12_hours.BEFORE_NOW.-1.-1.720&application=$($result.appid)&component=$($result.id)&dashboardMode=force"
			#"https://appd/controller/#/location=APP_COMPONENT_MANAGER&timeRange=last_12_hours.BEFORE_NOW.-1.-1.720&application=$($result.appid)&component=$($result.id)&dashboardMode=force"
		}
		else
		{
			$thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue ""
		}
	}
}
#>