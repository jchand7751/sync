﻿$wait_time = 600   #POLLING INTERVAL
$num_times = 2     #NO OF TIMES TO CHECK ON ANY GIVEN DAY.
$target = “FLAG”
$MyProcCMD = "\\pimco.imswest.sscims.com\netlogon\Batch\FlagAppStartupV2.bat" #<-- cmd to start proc
$UserName = $env:username
$ComputerName = $env:computername
$EmailFrom = "NoReply_Flag_Notification@Pimco.com"
$EmailTo = "Vinodkumar.Kadambalithaya@pimco.com,james.chandler@pimco.com"
$LimitEmailTo = "FlagDevelopment@pimco.com,james.chandler@pimco.com"

$process = gps "FLAG" -ea 0

$counter = 0
$lastCheckDate = Get-Date -format d
while ($true)
{
	start-sleep -s $wait_time
	$currentdate = Get-Date -format d
	if ($currentdate -ne $lastCheckDate)
	{ $counter = 0 }
		$lastCheckDate = $currentdate
	if ($counter -lt $num_times)
	{
		$process = gps "FLAG" -ea 0
		if (!$process)
		{
			$counter++
			#process has stopped - start it
			$wmi = ([wmiclass]"win32_process").Create($MyProcCMD)
			
			#Send an email indicating a restart for the user
			$EmailBody = "Flag applicaton has restarted for $username on $computername"
			$EmailSubject = "Flag restarted"
			$Message = New-Object Net.Mail.MailMessage($EmailFrom, $EmailTo, $EmailSubject, $EmailBody)
			$SMTPClient = New-Object Net.Mail.SmtpClient("mailhost.pimco.com", 25)
			#$SMTPClient.EnableSsl = $true
			#$SMTPClient.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
			$SMTPClient.Send($Message)
		}
	}
	else
	{
		#Send an email when the counter limit has been hit
		$EmailBody = "Flag Applicaton has reached the restart limit of $num_times for $username on $computername"
		$EmailSubject = "Flag restart limit reached"
		$Message = New-Object Net.Mail.MailMessage($EmailFrom, $LimitEmailTo, $EmailSubject, $EmailBody)
		$SMTPClient = New-Object Net.Mail.SmtpClient("mailhost.pimco.com", 25)
		$SMTPClient.Send($Message)
	}
}
