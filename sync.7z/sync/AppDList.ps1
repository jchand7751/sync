﻿$a = import-csv C:\temp\AppDlistFinal.csv
$array = @()
foreach ($i in $a)
{
    $object = "" | select Server, IIS, Installed, Status, Department
    $object.server = $i.servers
    $object.department = $i.department
    Try
    {
        $iis = Get-service -comp $i.servers -Name W3SVC -ea stop
        $object.iis = $true
    }
    Catch
    {
        $object.iis = $false
    }
    
    if ($object.iis -eq $true)
    {
        Try
        {
            $appd = Get-service -comp $i.servers -Name AppDynamics.Agent.Coordinator_service -ea stop
            $object.installed = $true
        }
        Catch
        {
            $object.installed = $false
        }
    }
    #$object
    $array += $object
}
$array