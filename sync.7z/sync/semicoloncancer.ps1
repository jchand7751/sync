﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/9/2016 10:31 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Import-Module GroupPolicy
$gponames = "ProxyAU - Internet Explorer", "ProxyDE - Internet Explorer", "ProxyHK - Internet Explorer", "ProxyJP - Internet Explorer", "ProxyNB - Internet Explorer", "ProxyNJDR - Internet Explorer", "ProxyNY - Internet Explorer", "ProxySG - Internet Explorer", "ProxyUK - Internet Explorer"
$script:errorflag = @()
foreach ($gpo in $gponames)
{
	try
	{
		$gpoxml = get-gporeport -Name $gpo -reporttype XML -ea Stop
	}
	catch
	{
		Send-MailMessage -From NoReplyMail@PimcoProxyGPOCheck.com -To "james.chandler@pimco.com" -Subject "Proxy GPO Check" -Body "$gpo was not found" -BodyAsHtml -SmtpServer "vme001py.pimco.imswest.sscims.com"
		throw "Can't find GPO - $gpo"
	}
	
	$value = ((((((((((([xml]$gpoxml).gpo).User).extensiondata) | where { $_.name -eq "Windows Registry" }).extension).registrysettings).registry | where { $_.name -eq "ProxyOverride" }).properties).value) -split ";") -split ","
	if ($value[-1] -eq " <local>" -or $value[-1] -eq "<local>")
	{
		#"$gpo is match"
		$script:errorflag += $false
	}
	else
	{
		$script:errorflag += $true
		Send-MailMessage -From NoReplyMail@PimcoProxyGPOCheck.com -To "james.chandler@pimco.com" -Subject "Proxy GPO Check" -Body "$gpo does not appear to have a semi-colon specified after the last entry, please check ASAP." -BodyAsHtml -SmtpServer "vme001py.pimco.imswest.sscims.com"
	}
}

$temparray = @()
foreach ($i in $gponames) { $temparray += ($i + ",") }
$gponameshtml = $temparray -replace ","," <br>"
if ($script:errorflag -notcontains $true)
{
	Send-MailMessage -From NoReplyMail@PimcoProxyGPOCheck.com -To "james.chandler@pimco.com" -Subject "Proxy GPO Check" -Body "Proxy GPO settings look correct for the following GPOs: <br> <br> $gponameshtml" -BodyAsHtml -SmtpServer "vme001py.pimco.imswest.sscims.com"
}