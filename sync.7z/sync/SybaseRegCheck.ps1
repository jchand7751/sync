﻿$array = @()
foreach ($comp in $list)
{
    $object = "" | select PC, User, SybaseSelectMethodValue, Status
    $object.PC = $comp

    $object.user = (gwmi win32_computersystem -comp $comp).username

    if (test-connection -comp $comp -Count 1 -quiet)
    {
    }
    else
    {
        $object.status = "PC Offline"
    }

    try
    {
        $object.SybaseSelectMethodValue = (Get-RegString -comp $comp -Hive LocalMachine -Key SOFTWARE\Wow6432Node\ODBC\ODBC.INI\sybase -Value SelectMethod).data
    }
    catch
    {
        $object.SybaseSelectMethodValue = "Key does not exist"
    }
    $object
    $array += $object
}