﻿$a = get-content C:\temp\vappexport.csv
$array = @()

$a = $a.replace(";",",")
$blah = '"name","serverame","blank1","blank2","protocol","port","path" ' + $a

foreach ($i in $a) 
{
    $object = "" | select ConnectionName, ServerName, Path, Department, Environment
    $b = ($i -split ",") -replace '"'
    $object.ConnectionName = $b[0]
    $object.servername = $b[1]
    $object.Path = $b[6]
    $object.Department = $b[6].split("\\")[0]
    $object.Environment = $b[6].split("\\")[1]
    $object
    $array += $object
}