﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/1/2013 10:06 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================


Add-PSSnapin VMware.VimAutomation.Core
Connect-VIServer ina000pv
Connect-VIServer ina041pv
Connect-VIServer vma0b0v51vc
Connect-VIServer ina0z0pv
Connect-VIServer vma000v51vc

$Clusters = Get-View -viewtype ClusterComputeResource
$Pimcoclusters | Where-Object {$_.name -like "*Pimco*"}
$AllVMs = Get-View -ViewType VirtualMachine

$VMArray = @()
foreach ($i in $AllVMs[875..885])
	{
	$TempVMObject = "" | Select-Object Name, Cluster, GuestOS, size
	$TempVMObject.name = $i.name
	$TempVMObject.Cluster = (Get-View (Get-View $i.runtime.host).parent).name
	$TempVMObject.GuestOS = $i.guest.guestfullname
	$disks = Get-HardDisk -VM $i.name -disktype flat
    $size = $null
	foreach ($i in $disks)
        {
        $size = $size + $i.capacityGB
        }
	$TempVMObject.size = $size
	$VMArray += $TempVMObject
	}
$PimcoVMs = @()
$PimcoVMs = $VMArray | where {$_.cluster -like "*pimco*"}


function GetLastLogons
{
Param ($computer)
#$computer
	
#$events = Get-Winevent -ComputerName $computer -MaxEvents 10 -FilterXml "<QueryList> <Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and Task = 12544 and (EventID=4624)]]</Select> </Query> </QueryList>"
#$events = Get-Winevent -ComputerName $computer -MaxEvents 50 -FilterXml "<QueryList> <Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and Task = 12544 and (EventID=4624)]] and *[EventData[Data[@Name='TargetDomainName'] and (Data='PIMCO')]] and *[EventData[Data[@Name='LogonType'] and (Data='10')]] </Select> </Query> </QueryList>"	
#$events = Get-Winevent -ComputerName $computer -MaxEvents 1 -FilterXml "<QueryList> <Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and Task = 12544 and (EventID=4624)]] and *[EventData[Data[@Name='LogonType'] and (Data='10')]] </Select> </Query> </QueryList>"	
$events = Get-WinEvent -ComputerName $computer -LogName 'Security' -FilterXPath 'Event[System[EventID=4624] and EventData[Data[@Name="TargetDomainName"]="PIMCO" and Data[@Name="LogonType"]="10"]]' -MaxEvents 1
	
<#
New-Item -Type filename c:\Temp\tempfile.txt
foreach ($i in $events )
	{
	$i | Out-File c:\Temp\tempfile.txt -Append
	}
#>

#$events = $events | where {$_.message -like "Pimco" -and $_.message -notlike "svc*"}
	
for ($x = 0 ; $x -lt $events.count ; $x++)
	{
	New-Item -Type file c:\Temp\tempfile-$x.txt | Out-Null
	$events[$x].message | Out-File c:\Temp\tempfile-$x.txt -Append
	}
#$cleanevents = Get-Content c:\Temp\tempfile.txt

$allcleanevents = for ($x = 0 ; $x -lt $events.count ; $x++)
	{
	$cleanevents = Get-Content c:\Temp\tempfile-$x.txt
	Remove-Item c:\Temp\tempfile-$x.txt -force
	$cleanevents = $cleanevents | Select-String "Account Name:"
	$cleanevents[1]
	}

#foreach ($i in $allcleanevents)
$fulldetails = @()
for ($x = 0 ; $x -lt $allcleanevents.count ; $x++)
	{
	$tempobject = "" | select TimeCreated, Account
	$tempobject.timecreated = $events[$x].timecreated
	$tempobject.account = ([string]$allcleanevents[$x] -replace "Account Name:") -replace '\s+', ''
	$fulldetails += $tempobject
	}

$fulldetails
}

#multiple events
<#
foreach ($i in $PimcoVMs[3])
	{
	$tp = Test-Connection $i.name
	if ($tp)
		{	
		$eventdetails = GetLastLogons $i.name
		$TempVMObject = "" | select Name, Cluster, LogonTime, Account, Size
		$TempVMObject.name = $i.name
		$TempVMObject.Cluster = $i.cluster
		$TempVMObject.size = $i.size
		for ($x = 0 ; $x -lt $eventdetails.count ; $x++)
			{
			$TempVMObject.LogonTime += [string]$eventdetails[$x].timecreated + " "
			$TempVMObject.Account += $eventdetails[$x].account + " "
			}
		$TempVMObject
		}
	}
#>

function GetLastLogon
{
Param ($computer)
#$computer
	
#$events = Get-Winevent -ComputerName $computer -MaxEvents 10 -FilterXml "<QueryList> <Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and Task = 12544 and (EventID=4624)]]</Select> </Query> </QueryList>"
#$events = Get-Winevent -ComputerName $computer -MaxEvents 50 -FilterXml "<QueryList> <Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and Task = 12544 and (EventID=4624)]] and *[EventData[Data[@Name='TargetDomainName'] and (Data='PIMCO')]] and *[EventData[Data[@Name='LogonType'] and (Data='10')]] </Select> </Query> </QueryList>"	
#$events = Get-Winevent -ComputerName $computer -MaxEvents 1 -FilterXml "<QueryList> <Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and Task = 12544 and (EventID=4624)]] and *[EventData[Data[@Name='LogonType'] and (Data='10')]] </Select> </Query> </QueryList>"	
$events = Get-WinEvent -ComputerName $computer -LogName 'Security' -FilterXPath 'Event[System[EventID=4624] and EventData[Data[@Name="TargetDomainName"]="PIMCO" and Data[@Name="LogonType"]="10"]]' -MaxEvents 1
	
<#
New-Item -Type filename c:\Temp\tempfile.txt
foreach ($i in $events )
	{
	$i | Out-File c:\Temp\tempfile.txt -Append
	}
#>
#$events = $events | where {$_.message -like "Pimco" -and $_.message -notlike "svc*"}
	
$x = 0
New-Item -Type file c:\Temp\tempfile-$x.txt | Out-Null
$events.message | Out-File c:\Temp\tempfile-$x.txt -Append
	
$cleanevents = Get-Content c:\Temp\tempfile-$x.txt
Remove-Item c:\Temp\tempfile-$x.txt -force
$cleanevents = $cleanevents | Select-String "Account Name:"
$Allcleanevents = $cleanevents[1]

#foreach ($i in $allcleanevents)
$fulldetails = @()
$tempobject = "" | select TimeCreated, Account
$tempobject.timecreated = $events.timecreated
$tempobject.account = ($allcleanevents -replace "Account Name:") -replace '\s+', ''
$fulldetails += $tempobject

$fulldetails
}

$finalarray = @()
#single events
foreach ($i in $PimcoVMs)
	{
	$tp = Test-Connection $i.name
	if ($tp)
		{
		if ($i.guestOS -like "*Windows Server*")
			{
			$eventdetails = GetLastLogon $i.name
			$TempVMObject = "" | select Name, Cluster, LastPimcoLogonTime, LastPimcoLogonAccount, Size
			$TempVMObject.name = $i.name
			$TempVMObject.Cluster = $i.cluster
			$TempVMObject.size = $i.size
			$TempVMObject.LastPimcoLogonTime = $eventdetails.timecreated
			$TempVMObject.LastPimcoLogonAccount = $eventdetails.account
			$TempVMObject
			$finalarray += $TempVMObject
			}
			else
				{
				$TempVMObject = "" | select Name, Cluster, LastPimcoLogonTime, LastPimcoLogonAccount, Size
				$TempVMObject.name = $i.name
				$TempVMObject.Cluster = $i.cluster
				$TempVMObject.size = $i.size
				$TempVMObject.LastPimcoLogonTime = "N/A"
				$TempVMObject.LastPimcoLogonAccount = "N/A"
				$TempVMObject
				$finalarray += $TempVMObject
				}
		}
	}
