﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.57
	 Created on:   	6/3/2014 6:19 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   8/27/2013 11:49 AM
# Created by:   z548410
# Organization:
# Filename:
#========================================================================
Param ($computer)
$testcon = Test-Connection $computer -Quiet -Count 1
$script:array = @()
if ($testcon)
{
	$LocalAdmin = ([ADSI]"WinNT://$Computer/Remote Desktop Users")
	$UserNames = @($LocalAdmin.psbase.Invoke("Members"))
	$UserList = $Usernames | foreach { $_.gettype().invokemember("Name", 'GetProperty', $null, $_, $null) }
	$parentlist = $UserNames | foreach { $_.gettype().invokemember("parent", 'GetProperty', $null, $_, $null) }
	for ($x = 0; $x -lt ($UserList.count); $x++)
	{
		$object = "" | select Computer, User
		$object.computer = $computer
		$object.user = ((($parentlist[$x] -replace "WinNT://") -replace "IMSWEST/") -replace "PIMCO/") + "\" + $UserList[$x]
		#$object
		$script:array += $object
	}
}
else
{
	$object = "" | select Computer, User
	$object.user = "Offline"
	$object.computer = $computer
	#$object
	$script:array += $object
}
$script:array | select *