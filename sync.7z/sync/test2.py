#!/usr/bin/env python
print "CLIQR_EXTERNAL_SERVICE_LOG_MSG_START"
print "Starting region script"
import os, sys
os.system("yum -y install python-requests")
#os.system("pip install requests")
#os.system("pip install json")
import requests, json
from requests.auth import HTTPBasicAuth

#TENANT = os.environ['samlAuthDomain']
TENANT = 'cloud-techservices'
#USERID = os.environ['launchUserId']
USERID = '24'
#USER = os.environ['launchUserName']
USER = "James.Chandler_o"
#TENANTID = os.environ['launchVendorId']
TENANTID = '6'
#NODEID = os.environ['cliqrNodeId']
NODEID = '421eccf1-2c29-1513-65fe-61551ec583da'
#JOBID = os.environ['JOB_ID']
JOBID = '332'
headers = {'Content-type': 'application/json'}



if TENANT == "cloud-techservices":
  print "tenant is cloud-techservices"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-technologyserv_l'
  ADMINPASSW = '79A795B51117AF01'
  GROUPID = '6'
  #get the owner of this deployment
  #user = "James.Chandler_o
  #passw = "CB064FB74C59C7E3"


#Get the user's key
r = requests.get("https://10.155.6.21/v1/users/%s/keys" % (USERID), headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))
print r
dset = r.json()
PASSW = dset['apiKey']['key'].encode('ascii')
print PASSW

#search all VMs by the NODEID
#r = requests.get("https://10.155.6.21/v1/jobs/%s" % (JOBID), headers=headers, verify=False, auth=(user, passw))
#r = requests.get('https://10.155.6.21/v1/virtualMachines?size=0&search=%s&status=Running%2CStarting' % (NODEID), headers=headers, verify=False, auth=(USER, PASSW))
r = requests.get('https://10.155.6.21/v1/virtualMachines?size=0&search=%s' % (NODEID), headers=headers, verify=False, auth=(USER, PASSW))
dset = r.json()

#From that search get the VM ID
VMID = dset['details']['virtualMachineDetails'][0]['id'].encode('ascii')

#Get the current permissions
r = requests.get("https://10.155.6.21/v1/acls/?id=%s&resourceName=VIRTUAL_MACHINE" % (VMID), headers=headers, verify=False, auth=(USER, PASSW))
dset = r.json()

#Add the new group
insertUserGroups=[
        {
            "description": "", 
            "id": "%s" % (GROUPID), 
            "name": "vmadmingroup", 
            "perms": [
                "administration", 
                "write", 
                "read", 
                "delete"
            ], 
            "resource": "https://10.155.6.21/v1/acls/%s" % (GROUPID), 
            "tenantId": "%s" % (TENANTID)
        }
    ]

dset['userGroups']=insertUserGroups
json_data = json.dumps(dset)
#Set the new acl permissions
r = requests.put('https://10.155.6.21/v1/acls', data=json_data, headers=headers, verify=False, auth=(USER, PASSW))

#print environment
print "CLIQR_EXTERNAL_SERVICE_LOG_MSG_END"