﻿#Get all pimco users
$users = get-qaduser -sizelimit 0 -includedproperties serviceprincipalname

foreach ($account in $users)
{
    #loop through the users' SPNs and find the ones that have devpmora14 and display the account + SPN
    if ($account.serviceprincipalname | where {$_ -like "*vma001p048*"})
    {
        $account.name
        $account.serviceprincipalname
        write-host ""
    }
}