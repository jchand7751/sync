﻿param ($computername)
.\PsExec.exe \\$computername -i -h powershell.exe -command 'enable-psremoting -force' -accepteula