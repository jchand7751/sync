﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   3/13/2014 12:29 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================


Add-PSsnapin Quest.ActiveRoles.ADManagement
Connect-qadservice vms001p4.pimco.imswest.sscims.com
$users = Get-qaduser -sizelimit 0
$group1 = Get-qadgroupmember "appsense migrated" -sizelimit 0
$group2 = Get-qadgroupmember "appsense personalized users" -sizelimit 0
$userarray = @()
foreach ($i in $users)
    {
    $testfor1 = $null
    $testfor2 = $null
    $testfor1 = $group1 | where {$_.name -eq $i.name}
    $testfor2 = $group2 | where {$_.name -eq $i.name}
    if (!$testfor1 -and !$testfor2)
        {
        $i
        $userarray += $i
        }
    }
$Userarray | Select Name, SamAccountName, ParentContainer | Export-csv C:\UsersMissingFromAppSense.csv    