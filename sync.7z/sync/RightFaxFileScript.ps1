﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/11/2013 12:06 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

function setup
{
$script:foundfilearray = New-Object system.collections.arraylist
Remove-Item c:\Temp\rightfaxscriptlog.txt -force
$script:logfile = New-item -type file c:\Temp\rightfaxscriptlog.txt
$script:Emailspammax = 20
$script:emailspamcount = 0
}

function Main
{
Param($script:foundfilearray)

$currentroundfilearray = @()
	
#$rightfaxservers = "inx000p4", "inx000p5"
#$path = "E$\Program Files\RightFax\Doctransport\*.ipk"

$timeout = 10	
$path = "c$\Temp\rightfax"
$server = "localhost"	

	
$time = Get-Date
$tp = Test-Path \\$server\$path
if ($tp)
	{}
	else
		{
		Write-Warning "Could not reach server path, exiting"
		exit
		}
if ($time)
	{
	$files = Get-Childitem \\$server\$path -Filter *.ipk | where {$_.lastwritetime -le "$($time.addminutes(-15))"}
	}
	else
		{
		Write-Warning "Could not get current time, exiting"
		exit
		}
if ($script:emailspamcount -ge $script:emailspammax)
	{
	Write-Host "Email spam max reached. Exiting"
	exit
	}
	
if ($files)
	{
	foreach ($foundfile in $files)
		{
		$tempobject = "" | select Name, Lastwritetime, NotificationSent
		$tempobject.name = $foundfile.Name
		$tempobject.lastwritetime = $foundfile.LastWriteTime
		$currentroundfilearray += $tempobject
		}

	$difference = (compare $currentroundfilearray $script:foundfilearray -Property name, lastwritetime) | where {$_.sideindicator -ne "=>"}
	if ($difference)
		{
		foreach ($item in $difference) 
			{
			Write-Host "Adding $(($currentroundfilearray | where {$_.name -eq $item.name -and $_.lastwritetime -eq $item.lastwritetime}).name)"
			$script:foundfilearray.Add(($currentroundfilearray | where {$_.name -eq $item.name -and $_.lastwritetime -eq $item.lastwritetime}))
			}
		}

	$cleareditems = (compare $script:foundfilearray $currentroundfilearray -Property name, lastwritetime) | where {$_.sideindicator -ne "=>"}
	if ($cleareditems)
		{
		foreach ($item in $cleareditems) 
			{
			Write-Host "Removing $(($script:foundfilearray | where {$_.name -eq $item.name -and $_.lastwritetime -eq $item.lastwritetime}).name)"
			$script:foundfilearray.remove(($script:foundfilearray | where {$_.name -eq $item.name -and $_.lastwritetime -eq $item.lastwritetime}))
			}
		}

	foreach ($i in $script:foundfilearray)
		{
		if ($i.notificationsent -eq $null)
			{
			Write-Host "Sending an email about $($i.name)"
			$i.notificationsent = $true
			$script:emailspamcount++
			}
		}
	}
	else
		{
		Write-Host "No old files were found"
		}

Write-Host "Sleeping for $timeout seconds"
sleep $timeout
Main $script:foundfilearray
}	

#Execution
Setup
Main $script:foundfilearray
