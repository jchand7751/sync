﻿#find events across server
Param ($servername)

#AD related events
#eventID 40961 source LsaSrv
#eventid 11166 source DnsApi
#eventID 5719 source Netlogon
#eventID 5721 source netlogon
#eventid 3210 source netlogon

$today = Get-Date

$cleanstart = $today.adddays($counter)
$cleanend = ($today.adddays(-90)).adddays($counter)

$datestart = Get-Date $cleanstart -UFormat "%Y-%m-%d"
$dateend = Get-Date $cleanend -UFormat "%Y-%m-%d"

$uglydatestring = "TimeCreated[@SystemTime&gt;='$($dateend)T08:00:01.000Z' and @SystemTime&lt;='$($datestart)T07:59:00.999Z'"
#$uglydatestring
$events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='System'><Select Path='System'>*[System[Provider[@Name='Netlogon' or @Name='LsaSrv' or @Name='DnsApi' and (EventID=40961) or (EventID=5719) or (EventID=5712) or (EventID=11166) or (EventID=3210)]]]</Select></Query></QueryList>" -Computername $servername
#$events
$events | where {$_.timecreated -ge $dateend} | select TimeCreated, MachineName, ProviderName, ID, LevelDisplayName, Message
#Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='System'><Select Path='System'>*[System[Provider[@Name='Netlogon' or @Name='LsaSrv' or @Name='DnsApi'] and $($uglydatestring) ]]]</Select></Query></QueryList>" -Computername $servername