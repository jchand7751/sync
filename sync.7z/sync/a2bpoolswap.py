#!/usr/bin/env python
import os, sys
import requests, json, datetime
import time
import socket
#import infoblox

#time.sleep(45)

#Disable warning messages from urllib3 library
requests.packages.urllib3.disable_warnings()

print "CLIQR_EXTERNAL_SERVICE_LOG_MSG_START"

BIGIP_AUTH_KEY="c3ZjX2Y1Oktlcjk4OHFh"
#BIGIP_ADDRESS="10.155.41.4"
#BIGIP_URL_BASE = 'https://%s/mgmt/tm' % BIGIP_ADDRESS
bigip = requests.session()
bigip.verify = False
bigip.headers.update({'Content-Type' : 'application/json','authorization': 'Basic '+BIGIP_AUTH_KEY})
CLIQR_A_JOBID = os.environ['DeploymentService_DeploymentService_1_JOB_ID']
CLIQR_A_DEPENV = os.environ['DeploymentService_DeploymentService_1_CliqrDepEnvName']
CLIQR_B_JOBID = os.environ['DeploymentService_DeploymentService_2_JOB_ID']
CLIQR_B_DEPENV = os.environ['DeploymentService_DeploymentService_2_CliqrDepEnvName']
TENANT = os.environ['samlAuthDomain']
headers = {'Content-type': 'application/json'}

def getCurrentTime():
    return datetime.datetime.now().isoformat()

def get_virtualserver(bigipbaseurl, bigip, vs):
    print "[INFO]: ",getCurrentTime()," Fetching VS info for %s ......." % vs
    req=bigip.get('%s/ltm/virtual/%s' % (bigipbaseurl, vs))
    data = req.json()
    #print data
    return data['pool'].split("/")[2].encode('ascii')
    #if req.status_code == 200:
    #    return True
    #return False

def modify_virtualserverpool(bigipbaseurl, bigip, vs, pool):
    print "[INFO]: ",getCurrentTime()," Changing pool on %s ......." % vs
    payload = {}
    payload['pool'] = pool
    req=bigip.patch('%s/ltm/virtual/%s' % (bigipbaseurl,vs), data=json.dumps(payload))
    if req.status_code == 200:
        return req.status_code

def get_bigipaddress():
    envName = os.environ['CliqrDepEnvName']
    region = os.environ['region']
    region = region.lower()
    region = region.replace(" ","")

    # Hardcoded for now. Will have to call infoblox to return this bigIP Address. 
    bigipaddress = ""
    if region == "irvine":
        if envName == "sandbox":
           bigipaddress = "10.155.41.4"    
        elif envName == "dev":
           bigipaddress = "10.155.41.4"     
        elif envName == "beta":
           bigipaddress = "10.155.49.2"    
        elif envName == "preprod":
           bigipaddress = "10.155.57.4"    
        elif envName == "prod":
            bigipaddress = "10.155.61.4"     
        else:
            bigipaddress = "10.155.41.4" 
    elif region == "newjersey":
        bigipaddress = "10.155.124.4"  
        #10.155.90.11
        #10.155.90.12

    print "[INFO]: ",getCurrentTime()," Use F5 API (BIGIP) Address %s for %s environment ......." % (bigipaddress,envName)
    return bigipaddress

BIGIP_ADDRESS = get_bigipaddress()
BIGIP_URL_BASE = 'https://%s/mgmt/tm' % BIGIP_ADDRESS
bigipbaseurl = 'https://%s/mgmt/tm' % BIGIP_ADDRESS

if TENANT == "cloud-techservices":
  print "Region setup: tenant is cloud-techservices"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-technologyserv_l'
  ADMINPASSW = '79A795B51117AF01'
  GROUPID = '6'

if TENANT == "cloud-fotech":
  print "Region setup: tenant is cloud-fotech"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-frontofficetec_m'
  ADMINPASSW = '5DB9F20074DD8A59'
  GROUPID = '7'

if TENANT == "cloud-tlc":
  print "Region setup: tenant is cloud-tlc"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-tradelegalcomp_C'
  ADMINPASSW = '4AB0340F5966EFF9'
  GROUPID = '8'

if TENANT == "cloud-cftech":
  print "Region setup: tenant is cloud-cftech"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-clientfacingte_H'
  ADMINPASSW = '1E06FFCF291DDB18'
  GROUPID = '9'

if TENANT == "cloud-pimcocommon":
  print "Region setup: tenant is cloud-pimcocommon"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-pimcocommon_G'
  ADMINPASSW = '031BC9BC59451B35'
  GROUPID = '10'

if TENANT == "cloud-analytics":
  print "Region setup: tenant is cloud-analytics"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-analytics_F'
  ADMINPASSW = 'A15088C9A3E2BF2F'
  GROUPID = '11'

if TENANT == "cloud-business":
  print "Region setup: tenant is cloud-business"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-businessfuncti_J'
  ADMINPASSW = 'E3F3753E5D12BAB9'
  GROUPID = '12'

if TENANT == "cloud-pmapps":
  print "Region setup: tenant is cloud-pmapps"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-pmapplications_K'
  ADMINPASSW = '799183C045731A09'
  GROUPID = '13'

#Look up job ID for A - get deployment name
r = requests.get("https://10.155.6.21/v2/jobs/%s" % (CLIQR_A_JOBID), headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))
dset = r.json()
CLIQR_A_JOBNAME = dset['name'].encode('ascii')

#Look up job ID for B - get deployment name
r = requests.get("https://10.155.6.21/v2/jobs/%s" % (CLIQR_B_JOBID), headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))
dset = r.json()
CLIQR_B_JOBNAME = dset['name'].encode('ascii')

#Create the VIP name based on the deployment name
#"cliqr_sandbox_rib1.4_vip"
VS_NAME_A = "cliqr_" + CLIQR_A_DEPENV + "_" + CLIQR_A_JOBNAME + "_vip"
VS_NAME_B = "cliqr_" + CLIQR_A_DEPENV + "_" + CLIQR_B_JOBNAME + "_vip"

#Get the pool name based on the virtual server name from above
POOL_NAME_A = get_virtualserver(bigipbaseurl, bigip, VS_NAME_A)

#Get the pool name based on the virtual server name from above
POOL_NAME_B = get_virtualserver(bigipbaseurl, bigip, VS_NAME_B)

#Modify pool from A - B
modify_virtualserverpool(BIGIP_URL_BASE, bigip, VS_NAME_A, POOL_NAME_B)

#Modify pool from B - A
modify_virtualserverpool(BIGIP_URL_BASE, bigip, VS_NAME_B, POOL_NAME_A)

print "CLIQR_EXTERNAL_SERVICE_LOG_MSG_END"



r = requests.get("https://10.155.6.21/v2/jobs/%s" % (CLIQR_A_JOBID), headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))

curl --request PUT --data 'hello consul' https://consul.rocks/v1/kv/foo



requests.put("http://pimcloudcmdb/%s" % (CLIQR_A_JOBID), verify=False

requests.put("http://pimcloudcmdb/v1/kv/test", data="test", verify=False)

requests.put("http://pimcloudcmdb/v1/kv/v1/cliqr/apps/aml/latestdevpackage", verify=False, data="test1")

r=requests.get("http://pimcloudcmdb/v1/kv/v1/cliqr/apps/aml/latestdevpackage", verify=False)
data = r.json()
value = data[0]['Value'].encode('ascii').decode('base64','strict')