﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/3/2016 9:09 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$addinname
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\AE2setup.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$Username = ((whoami) -split "pimco\\")[1]
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins

#endregion

#region Create variables and arrays

#endregion

#region Script functions

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"
Add-Log -Type 'Information' -Message "Running as $Username"
try
{
	Add-Log -Type 'Information' -Message "Starting AddInUpdater"
	\\naspm\TA_Tools_Rep\Installers\AddInUpdater.exe /silent /version:PROD /install:ae2_loader /requires:ae_vsto:true, ae_dig:true
}
catch
{
	Add-Log -Type 'Error' -Message "Failed to run AddInUpdater - $($error[0].Exception)"
}
Add-Log -Type 'Information' -Message "Script complete"
#endregion
