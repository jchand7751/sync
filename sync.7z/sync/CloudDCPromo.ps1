﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/12/2016 10:51 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#Parameters
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $True, Position = 0)]
	[string]$Sitename,
	[Parameter(Mandatory = $True, Position = 1)]
	[string]$IPAddress,
	[Parameter(Mandatory = $True, Position = 2)]
	[string]$DefaultGateway,
	[Parameter(Mandatory = $True, Position = 3)]
	[string]$PrefixLength,
	[Parameter(Mandatory = $True, Position = 4)]
	[string]$DNSServer1,
	[Parameter(Mandatory = $True, Position = 5)]
	[string]$DNSServer2,
	[Parameter(Mandatory = $True, Position = 6)]
	[string]$Location,
	[Parameter(Mandatory = $True, Position = 7)]
	[string]$User,
	[Parameter(Mandatory = $True, Position = 8)]
	[string]$Password
)
#variables

#$sitename = "Pimco-Cloud-NewJersey"
#$ipaddress = "10.155.71.11"
#$prefixlength = "24"
#$defaultgateway = "10.155.71.1"
#$dnsservers = "10.155.5.15", "10.155.5.16"
#$location = "newjersey"

$hostname = hostname

$restorepassword = ConvertTo-SecureString -AsPlainText -String "SPsd45T$M0tor" -force
$SecurePassword = ConvertTo-SecureString -AsPlainText -String $Password -force
$DomainCredential = New-Object System.Management.Automation.PSCredential $User, $SecurePassword

#Domain Controller Creation
Import-Module NetSecurity
Import-Module ServerManager
Import-Module NetTCPIP

#Set Disks
Get-Disk -Number 1 | Initialize-Disk
Get-Disk -Number 1 | New-Partition -Driveletter "E" -UseMaximumSize | Format-Volume -FileSystem NTFS -confirm:$false -Force

#Change Admin password

#Set Network
#Set-NetIPAddress -IPAddress $IPAddress -InterfaceAlias Ethernet0 -AddressFamily IPv4 -PrefixLength $Prefixlength
$DNSServers = @()
$DNSServers += $DNSServer1
$DNSServers += $DNSServer2
New-NetIPAddress –InterfaceAlias Ethernet0 –IPAddress $IpAddress -PrefixLength $PrefixLength -DefaultGateway $defaultgateway

# Get all network adapters
$adapters = Get-WmiObject Win32_NetworkAdapterConfiguration

# Set the DNS server search order for all of the previously-found adapters
#$adapters | where { $_.index -eq 12 } | ForEach-Object { $_.SetDNSServerSearchOrder($DNSServers) }
$adapters | where { $_.description -like "*vmxn*" } | ForEach-Object { $_.SetDNSServerSearchOrder($DNSServers) }

#$adapter = (Get-NetAdapter).interfacealias
#Set-DnsClientServerAddress -InterfaceAlias $adapter -ServerAddresses ("10.208.20.13", "10.208.20.14")
#Set-DnsClientServerAddress -InterfaceAlias Ethernet0 -ServerAddresses $dnsservers
#New-NetRoute -interfaceAlias Ethernet0 -NextHop $defaultgateway -destinationprefix “0.0.0.0/0”

#Disable Firewall
Get-NetFirewallProfile | Set-NetFirewallProfile -Enabled False

#Rename computer
#Rename-Computer -ComputerName $hostname -NewName $VMname -LocalCredential $LocalCredential -Force -PassThru -Restart

#DC Promo
Install-WindowsFeature -Name AD-Domain-Services
Install-WindowsFeature -Name RSAT-ADDS-Tools
Import-Module ADDSDeployment
Import-Module ActiveDirectory

Install-ADDSDomainController -Credential $DomainCredential -DomainName core.pimcocloud.net -DatabasePath e:\NTDS -LogPath e:\LOG -SiteName $sitename -SysvolPath e:\SYSVOL -SafeModeAdministratorPassword $restorepassword -Force
