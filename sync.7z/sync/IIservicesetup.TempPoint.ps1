﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/13/2016 5:03 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$cliqrvariableslocation = "C:\temp\userenv.ps1"
.$cliqrvariableslocation

ls "env:" | where { $_.name -like "apppool*" }


function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

Import-module BitsTransfer
Start-BitsTransfer -Source $env:appzipfile -destination e:\ -ProxyUsage NoProxy
sleep 10

$filename = ($env:appzipfile -split "/")[-1]
Expand-ZIPFile E:\$filename -destination e:

Import-Module WebAdministration