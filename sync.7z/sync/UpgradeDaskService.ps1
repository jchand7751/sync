﻿
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$DaskType
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\DaskUpdate.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
#endregion

#region Base functions

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

function StopDask
{
	try
	{
		Get-Service -Name Dask* | foreach { Add-Log -Type 'Information' -Message "Stopping $($_.name)"; $_ | Stop-Service -Force -ea 'Stop' }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to stop Dask services"
	}
}

function RemoveVendorPackages
{
	try
	{
		Get-ChildItem E:\vendor | foreach { Add-Log -Type 'Information' -Message "Removing $($_.name) from E:\vendor"; $_ | Remove-item -Recurse -Force -ea 'Stop' }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to clear E:\vendor"
	}
}

function UnRegisterService
{
	try
	{
		Get-Service -Name Dask* | foreach { Add-Log -Type 'Information' -Message "Removing service $($_.name)"; ."C:\temp\nssm.exe" remove $_.name confirm }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to unregister Dask services"
	}
}

function DownloadVendor
{
	try
	{
		download_packages -Vendor $env:vendor
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to download vendor packages"
	}
}

function ReRunSetup
{
	param ($DaskType)
	#Clear old path
	#$env:PATH = $env:pithonbase + "\" + $env:pithonver + "\pithon;" + $env:PATH
	$constructpath = $env:pithonbase + "\" + $env:pithonver + "\pithon\Scripts\dask" + $DaskType + "setup.ps1"
	.$constructpath
}

function SetRequiredServiceVariables
{
	[Environment]::SetEnvironmentVariable('daskVersion', $env:daskVersion, 'Machine')
}

#endregion

#region Main
SetRequiredServiceVariables
StopDask
RemoveVendorPackages
UnRegisterService
DownloadVendor
ReRunSetup $DaskType
#endregion