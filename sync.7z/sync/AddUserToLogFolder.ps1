﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/12/2016 11:44 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($username, $computer)

function AddUserToLogFolder
{
	param ($Username, $Computer)
	$path = "\\$computer\l$\logs"
	$acl = Get-Acl $path
	$accessrule = New-Object system.security.AccessControl.FileSystemAccessRule($username, "modify,write,ReadAndExecute", "ContainerInherit,ObjectInherit", "None", "Allow")
	$acl.AddAccessRule($accessrule)
	set-acl -aclobject $acl $path
}

AddUserToLogFolder -Username $username -Computer $computer