#Load modules
import requests, json

#Define variables
#ENVIRON = os.environ
TENANT = "cloud-cftech"
#TENANTID = os.environ['launchVendorId']

headers = {'Content-type': 'application/json'}

#Start Cloudcenter logging
print "CLIQR_EXTERNAL_SERVICE_LOG_MSG_START"
print "Starting region script"

if TENANT == "cloud-techservices":
  print "Region setup: tenant is cloud-techservices"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-technologyserv_l'
  ADMINPASSW = '79A795B51117AF01'
  GROUPID = '6'

if TENANT == "cloud-fotech":
  print "Region setup: tenant is cloud-fotech"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-frontofficetec_m'
  ADMINPASSW = '5DB9F20074DD8A59'
  GROUPID = '7'

if TENANT == "cloud-tlc":
  print "Region setup: tenant is cloud-tlc"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-tradelegalcomp_C'
  ADMINPASSW = '4AB0340F5966EFF9'
  GROUPID = '8'

if TENANT == "cloud-cftech":
  print "Region setup: tenant is cloud-cftech"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-clientfacingte_H'
  ADMINPASSW = '1E06FFCF291DDB18'
  GROUPID = '9'

if TENANT == "cloud-pimcocommon":
  print "Region setup: tenant is cloud-pimcocommon"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-pimcocommon_G'
  ADMINPASSW = '031BC9BC59451B35'
  GROUPID = '10'

if TENANT == "cloud-analytics":
  print "Region setup: tenant is cloud-analytics"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-analytics_F'
  ADMINPASSW = 'A15088C9A3E2BF2F'
  GROUPID = '11'

if TENANT == "cloud-business":
  print "Region setup: tenant is cloud-business"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-businessfuncti_J'
  ADMINPASSW = 'E3F3753E5D12BAB9'
  GROUPID = '12'

if TENANT == "cloud-pmapps":
  print "Region setup: tenant is cloud-pmapps"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-pmapplications_K'
  ADMINPASSW = '799183C045731A09'
  GROUPID = '13'

#r = requests.get('https://10.155.6.21/v1/virtualMachines?size=0&search=%s' % (NODEID), headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))
#dset = r.json()

r = requests.get('https://cloud-cftech/v1/virtualMachines?includeFilters=false&status=Running&appId=288' headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))
dset = r.json()

#From that search get the VM ID
VMID = dset['details']['virtualMachineDetails'][0]['id'].encode('ascii')