﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/2/2017 12:03 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer,

	[Parameter(Mandatory = $false, Position = 1, ParameterSetName = 'Location2')]
	[ValidateSet('Anonymous', 'Windows', 'Kerberos')]
	
	[string]$Authentication,

	[switch]$GUI
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\MSOlicenseassignment.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
	Import-Module MSOnline -ea 'Stop' | Out-Null
	Import-Module MSOnlineExtended -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays
#$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString)
#$msolcredential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
$msolcredential = Get-Credential
try
{
	#Get enabled cloud users
	$cloudusers = Get-QADUser -Service pimco.imswest.sscims.com -LdapFilter "(cloudsync=*)" -SizeLimit 0 -IncludedProperties cloudsync, AccountIsDisabled -ea 'Stop'
}
catch
{
	Add-Log -Type 'Error' -Message "Could not query domain users" -Throw
}
try
{
	#Get all synced users
	$msonlineusers = Get-MSOLUser -All -ea 'Stop'
}
catch
{
	Add-Log -Type 'Error' -Message "Could not query O365 users" -Throw
}

try
{
	$licenselist = Get-Content -Raw -Path c:\tmp\products2.json -ea 'Stop' | ConvertFrom-Json -ea 'Stop'
	$currentlist = Get-Content -Raw -Path c:\tmp\products2.json -ea 'Stop' | ConvertFrom-Json -ea 'Stop'
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load json license files" -Throw
}

$cloudusers = $cloudusers | where { $_.name -eq "chandler, james" }
#endregion

#region Script functions

function ConnectToTenant
{
	#Connect to the tenant
	try
	{
		Connect-MSOLService -Credential $msolcredential -ea Stop | Out-Null
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to connect to the MSOnline tenant" -Throw
	}
}

function FindUser
{
	param ($user)
	Add-Log -Type 'Information' -Message "Checking for a user that matches userprincipalname $($user.email)"
	try
	{
		#Find the specific user in the loop
		$script:selecteduser = $msonlineusers | where { $_.userprincipalname -eq $user.email } -ea 'Stop'
		$script:userFullLicenses = ((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -notlike "*-*" } -ea 'Stop'
		$script:userDividedLicenses = ((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -like "*-*" } -ea 'Stop'
		if ($script:selecteduser -like "" -or $script:selecteduser.count -ge 2)
		{
			throw "Error"
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to match a user in O365."
		break
	}
	Add-Log -Type 'Information' -Message "Found user"
}

function BuildLicenseObjectfromAD
{
	Add-Log -Type 'Information' -Message "Building a license object from AD for $($script:selecteduser.userprincipalname)"
	<#
	Using the JSON license list ($licenselist) as a base,
	enable divided licenses products that match the cloudsync attribute
	#>
	foreach ($lic in $script:userDividedLicenses)
	{
		#parent of product
		$parent = $lic.substring(0, 2)
		#product
		$product = $lic.substring(3, ($lic.length - 3))
		#subproducts of parent
		$productlist = ($licenselist | where { $_.licensename -eq $parent }).products
		#Enable the product
		($productlist | where { $_.productname -eq $product }).status = "Enabled"
		Add-Log -Type 'Information' -Message "Enabling $product"
	}
	
	<#
	Using the JSON license list ($licenselist) as a base,
	enable full licenses (all products) that match the cloudsync attribute on the 
	#>
	foreach ($lic in $script:userFullLicenses)
	{
		$productlist = ($licenselist | where { $_.licensename -eq $lic }).products
		#Enable the product
		#($productlist | where { $_.productname -eq "All" }).status = "Enabled"
		foreach ($product in $productlist)
		{
			$product.status = "Enabled"
			Add-Log -Type 'Information' -Message "Enabling $lic"
		}
	}
}

function BuildLicenseObjectfromMSO
{
	Add-Log -Type 'Information' -Message "Building a license object from O365 for $($script:selecteduser.userprincipalname)"
	<#
	Using the JSON license list ($currentlist) as a base,
	enable divided licenses products that match 
	#>
	foreach ($lic in $script:selecteduser.licenses)
	{
		$parent = $lic
		$parentsku = "PIMCO:" + $lic.accountsku.skupartnumber
		foreach ($enabled in ($parent.servicestatus | where { $_.provisioningStatus -ne "Disabled" }))
		{
			(($currentlist | where { $_.licensesku -eq $parentsku }).products | where { $_.productsku -eq $($enabled.serviceplan.servicename) }).status = "Enabled"
			Add-Log -Type 'Information' -Message "Enabling $($enabled.serviceplan.servicename)"
		}
	}
}

function BuildActionArray
{
	Add-Log -Type 'Information' -Message "Building the action array based on mismatched licenses"
	$script:mismatchedlicenses = @()
	#Loop through the sku list and find out if each product sku is enabled or disabled via AD attribute
	$skulist = $licenselist.products.productsku
	foreach ($sku in $skulist)
	{
		switch (($licenselist.products | where { $_.productsku -eq $sku }).status)
		{
			"Enabled" {
				if (($licenselist.products | where { $_.productsku -eq $sku }).status -ne ($currentlist.products | where { $_.productsku -eq $sku }).status)
				{
					$object = "" | select Action, SKU, LicenseName
					$object.Action = "Enable"
					$object.SKU = $sku
					$object.LicenseName = ($licenselist | where { $_.products.productsku -eq $sku }).licensename
					Add-Log -Type 'Information' -Message "$sku is enabled in Active Directory - Need to enable in O365"
					$script:mismatchedlicenses += $object
				}
			}
			"Disabled" {
				if (($licenselist.products | where { $_.productsku -eq $sku }).status -ne ($currentlist.products | where { $_.productsku -eq $sku }).status)
				{
					$object = "" | select Action, SKU, LicenseName
					$object.Action = "Disable"
					$object.SKU = $sku
					$object.LicenseName = ($licenselist | where { $_.products.productsku -eq $sku }).licensename
					Add-Log -Type 'Information' -Message "$sku is not enabled in Active Directory - Need to disable in O365"
					$script:mismatchedlicenses += $object
				}
			}
		}
	}
}

function RemoveLicensesFromDisabledUsers
{
	Add-Log -Type 'Information' -Message "Checking if the user is disabled"
	#Remove existing licenses if the account is disabled in AD
	if ($user.AccountIsDisabled -eq $true)
	{
		try
		{
			Add-Log -Type 'Information' -Message "Removing all licenses from $($script:selecteduser.userprincipalname)"
			$script:selecteduser | Set-MsolUserLicense -RemoveLicenses -ea 'Stop'
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Failed to remove all licenses from $($script:selecteduser.userprincipalname)"
		}
		break
	}
}

function SetLicenses
{
	$uniquelicensemismatch = $script:mismatchedlicenses.licensename | sort -unique
	foreach ($licensename in $uniquelicensemismatch)
	{
		foreach ($selectedlicense in ($licenselist | where { $_.licensename -eq $licensename }))
		{
			$DisabledPlans = [string]($selectedlicense.products | where { $_.status -eq "Disabled" }).productsku -replace (" ", "`", `"")
			$DisabledPlans = "`"" + $DisabledPlans + "`""
			#$selectedlicense.licensesku
			#$DisabledPlans
			#$newMSOL = New-MsolLicenseOptions -AccountSkuId $selectedlicense.licenseSku -DisabledPlans $DisabledPlans
			if ($script:selecteduser.licenses.accountskuid -contains $($selectedlicense.licenseSku))
			{
				try
				{
					Add-Log -Type 'Information' -Message "Adding AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$newMSOL = Invoke-Expression "New-MsolLicenseOptions -AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$script:selecteduser | Set-MsolUserLicense -Licenseoptions $newMSOL -ea 'Stop'
				}
				catch
				{
					Add-Log -Type 'Error' -Message "Failed to set licenses on $($script:selecteduser.userprincipalname)"
				}
			}
			else
			{
				try
				{
					Add-Log -Type 'Information' -Message "Adding AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$newMSOL = Invoke-Expression "New-MsolLicenseOptions -AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$script:selecteduser | Set-MsolUserLicense -Licenseoptions $newMSOL -AddLicenses $($selectedlicense.licenseSku) -ea 'Stop'
				}
				catch
				{
					Add-Log -Type 'Error' -Message "Failed to set licenses on $($script:selecteduser.userprincipalname)"
				}
			}
		}
	}
	
	#If all the products are disabled, remove the top level license
	Add-Log -Type 'Information' -Message "Checking if top level licenses should be removed"
	foreach ($license in $licenselist)
	{
		if ($license.products.status -contains "enabled")
		{ }
		else
		{
			if ($script:selecteduser.licenses.accountskuid -contains $($license.licensesku))
			{
				try
				{
					Add-Log -Type 'Information' -Message "Removing $($license.licensesku)"
					$script:selecteduser | Set-MsolUserLicense -RemoveLicenses $license.licensesku
				}
				catch
				{
					Add-Log -Type 'Error' -Message "Failed to set licenses on $($script:selecteduser.userprincipalname)"
				}
			}
		}
	}
}

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"
ConnectToTenant
#Loop through enabled cloud users
foreach ($user in $cloudusers)
{
	FindUser $user
	RemoveLicensesFromDisabledUsers
	BuildLicenseObjectfromAD
	BuildLicenseObjectfromMSO
	BuildActionArray
	SetLicenses
}
Add-Log -Type 'Information' -Message "Script complete"
#endregion