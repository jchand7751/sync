﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/10/2015 1:33 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($server)
Add-PSSnapin Quest.ActiveRoles.ADManagement
function getadminusers
{
	Param ($computer)
	$testcon = Test-Connection $computer -Quiet -Count 1
	$script:array = @()
	if ($testcon)
	{
		$LocalAdmin = ([ADSI]"WinNT://$Computer/Administrators")
		$UserNames = @($LocalAdmin.psbase.Invoke("Members"))
		$UserList = $Usernames | foreach { $_.gettype().invokemember("Name", 'GetProperty', $null, $_, $null) }
		$parentlist = $UserNames | foreach { $_.gettype().invokemember("parent", 'GetProperty', $null, $_, $null) }
		for ($x = 0; $x -lt ($UserList.count); $x++)
		{
			$object = "" | select Computer, User
			$object.computer = $computer
			$object.user = ((($parentlist[$x] -replace "WinNT://") -replace "IMSWEST/") -replace "PIMCO/") + "\" + $UserList[$x]
			#$object
			$script:array += $object
		}
	}
	else
	{
		$object = "" | select Computer, User
		$object.user = "Offline"
		$object.computer = $computer
		#$object
		$script:array += $object
	}
	$script:array | select *
}

$admins = getadminusers $server
$finishedarray = @()
foreach ($i in $admins)
{
	$results = Get-QADGroup $i.user | Get-QADGroupMember -Indirect -SizeLimit 0
	if ($results)
	{
		foreach ($u in $results)
		{
			$object = "" | select Server, User, Group
			$object.Server = $i.computer
			$object.Group = $i.user
			$object.User = $u.ntaccountname
			$finishedarray += $object
		}
	}
	else
	{
		$object = "" | select Server, User, Group
		$object.Server = $i.computer
		$object.Group = "N/A - Directly Added"
		$object.User = $i.user
		$finishedarray += $object
	}
}
$finishedarray





