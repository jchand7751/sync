﻿#Compare Bigfix export to AD Group
Param ($bigfixfile, $ADgroup)
$a = import-csv $bigfixfile
$b = get-qadgroup $adgroup | get-qadgroupmember -sizelimit 0
$array = @()
foreach ($user in $b)
{
    $object = "" | select User, loginname, PC
    $object.user = $user.name
    $object.loginname = $user.samaccountname
    $finduser = $a | where {$_."user name" -eq $user.samaccountname}
    if ($finduser)
    {
        $object.PC = [string]$finduser."Computer Name"
    }
    else
    {
        $object.PC = "Not found"
    }
    $object
    $array += $object 
}
$array