﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.53
	 Created on:   	4/16/2014 10:16 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$a = get-childitem "\\nasshare\share\PimcoIIS_InstallPackage\Powershell\Scripts\Beta\Logging\"
foreach ($i in $a)
{
	if (get-content $i.fullname | select-string "Error")
	{
		write-warning "Error found in log: $i.name"
		$errorstring = (get-content $i.fullname | select-string "Error")
		Write-Warning "$errorstring"
	}
	if (get-content $i.fullname | select-string "Warning")
	{
		write-warning "Warning found in log: $i.name"
		$warningstring = (get-content $i.fullname | select-string "Warning")
		Write-Warning "$warningstring"
	}
}