﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	06/28/2017 6:04 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   	CliqrIISPackageUpdate.ps1  	
	===========================================================================
	.DESCRIPTION
		IIS Update Script.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer,
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$packages = $env:packages
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\CliqrIISPackageUpdate.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$server = hostname
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
$reposource = "http://10.155.5.63:8080/"
$whoami = whoami

#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
	Import-Module WebAdministration -ea 'Stop' | Out-Null
	Import-Module NetTCPIP -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

#endregion

#region Main
Add-Log -Type Information -Message "Starting IIS package update script"
agentSendLogMessage "$(executiontime) - Starting IIS package update script"

#stop IIS to prevent locks
Add-Log -Type Information -Message "Stopping IIS"
agentSendLogMessage "$(executiontime) - Stopping IIS"
iisreset /stop

#Remove all sites
Get-website | Remove-Website

#App Pools to remove
$apppoolremove = (ls IIS:\AppPools | where { $_.name -notlike "*.net*" -and $_.name -ne "DefaultAppPool" }).name
foreach ($appool in $apppoolremove)
{
	try
	{
		Add-Log -Type Information -Message "Removing application pool: $appool"
		agentSendLogMessage "$(executiontime) - Removing application pool: $appool"
		Remove-WebAppPool -Name $appool
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to remove application pool: $appool"
		agentSendLogMessage "$(executiontime) - Failed to remove application pool: $appool"
	}
}

function DownloadAppPackages
{
	try
	{
		Add-Log -Type 'Information' -Message "Downloading packages: $packages"
		download_packages -Packages $packages
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to download packages"
	}
}

function SetRequiredApplicationVariables
{
	Add-Log -Type 'Information' -Message "Setting the variable packages: $packages"
	[Environment]::SetEnvironmentVariable('Packages', $packages, 'Machine')
}

#Remove existing files in packages
Add-Log -Type 'Information' -Message "Clearing out package data and deployed code"
Get-Childitem e:\apps | Remove-Item -Recurse -Force
Get-Childitem e:\inetpub | Remove-Item -Recurse -Force

SetRequiredApplicationVariables

#Download the updated packages
#powershell.exe "download_packages.ps1"

DownloadAppPackages

iisreset /start

#Run the IIS setup script again
powershell.exe "c:\pimcloud\cliqr-scripts\windows\iis\cliqriispackagesetupv2.ps1"


agentSendLogMessage "$(executiontime) - IIS Package update complete"
Add-Log -Type Information -Message "IIS Package update complete"
#endregion