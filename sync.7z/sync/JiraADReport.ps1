﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/1/2016 10:56 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($jsonticket)
Add-PSSnapin Quest.ActiveRoles.ADManagement
Connect-QADService Pimco.imswest.sscims.com

$password = Get-Content c:\secure\secure.p | ConvertTo-SecureString
$credential = New-Object System.Management.Automation.PSCredential pimco\s_jiraauto, $password
$password = $credential.getnetworkcredential().password
$account = "s_jiraauto"
$creds = $account + ":" + $password

#Issue ID
$issueid = $jsonticket.issue.key

#Selected group
$selectedgroup = $jsonticket.issue.fields.customfield_13606

#Selected fields
$selectedfields = $jsonticket.issue.fields.customfield_13607.value

#Requestor
$requestor = $jsonticket.user.emailaddress

$selectedparameters = "select"
foreach ($selection in $selectedfields)
{
	switch ($selection)
	{
		"Full Name" { Write-Host "Adding Full Name"; $selectedparameters = $selectedparameters + " Name," }
		"First Name" { $selectedparameters = $selectedparameters + " @{ Name='First Name'; Expression={`$_.firstname}}," }
		"Last Name" { $selectedparameters = $selectedparameters + " @{ Name='Last Name'; Expression={`$_.lastname}}," }
		"Logon Name" { $selectedparameters = $selectedparameters + " @{ Name='Logon Name'; Expression={`$_.samaccountname}}," }
		"Phone Number" { $selectedparameters = $selectedparameters + " @{ Name='Phone Number'; Expression={`$_.PhoneNumber}}," }
		"Email" { $selectedparameters = $selectedparameters + " Email," }
		"Title" { $selectedparameters = $selectedparameters + " Title," }
		"Location" { $selectedparameters = $selectedparameters + " @{ Name='Location'; Expression={`$_.l}}," }
		"Department" { $selectedparameters = $selectedparameters + " Department," }
		"Manager" { $selectedparameters = $selectedparameters + " @{ Name = 'Manager'; Expression = { (get-qaduser `$_.manager).name }}," }
		"Desk" { $selectedparameters = $selectedparameters + " @{ Name='Desk'; Expression={`$_.Office }}," }
		"Country/Region" { $selectedparameters = $selectedparameters + " @{ Name='Country/Region'; Expression={`$_.co }}," }
		"Object Type" { $selectedparameters = $selectedparameters + " @{ Name='Object Type'; Expression={`$_.type }}," }
		"Home Directory" { $selectedparameters = $selectedparameters + " @{ Name='Home Directory'; Expression={`$_.HomeDirectory }}," }
		"Assistant"  { $selectedparameters = $selectedparameters + " @{ Name='Assistant'; Expression={ (get-qaduser `$_.assistant).name }}," }
		"Cost Center" { $selectedparameters = $selectedparameters + " @{ Name='Cost Center'; Expression={`$_.extensionAttribute3 }}," }
		"Employee Type" { $selectedparameters = $selectedparameters + " @{ Name='Employee Type'; Expression={`$_.employeetype }}," }
		"All Email Addresses" { $selectedparameters = $selectedparameters + " @{ Name='All Email Addresses'; Expression={`([string]((`$_.proxyaddresses | where {`$_ -like 'SMTP*' }) -replace 'SMTP:', '')) }}," }
	}
}
$selectedparameters = $selectedparameters.trimend(",")
$query = "Get-QADGroup -Name '$selectedgroup' | Get-QADGroupMember -Indirect -sizelimit 0 -includedproperties l, office, co, type, assistant, extensionattribute3, employeetype | $selectedparameters"
#$query
try
{
	$results = Invoke-Expression $query
}
catch
{
	$results = $null
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""The request was invalid, please resubmit"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""11"" }}'
}

if ($results)
{
	$results | Export-Csv c:\temp\ADreportresults-$issueid.csv -NoTypeInformation
	curl.exe -u $creds -k -X POST -H "X-Atlassian-Token: nocheck" -F "file=@c:\\temp\\ADreportresults-$issueid.csv" -D- https://jira/rest/api/2/issue/$issueid/attachments
	
	#Get the issue with our attachment
	$updatedissue = curl.exe -k -u $creds -X GET -H "Content-Type: application/json" https://jira/rest/api/2/issue/$issueid
	$updatedissue = ConvertFrom-Json $updatedissue
	$attachmentlink = $updatedissue.fields.attachment.content
	#$attachmentlink
	#$command
	$command = "curl.exe -k -u $creds -H `"Content-Type: application/json`" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{`"`"body`"`": `"`"Attachment: $attachmentlink`"`" }'"
	#Post a comment with the link to the attachment because service desk is dumb
	Invoke-Expression $command
	#Close the issue
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""11"" }}'
}
else
{
	curl.exe -k -D- -u $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""The request was invalid, please resubmit"" }'
	
	#Close the issue
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""11"" }}'
}


