﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/3/2017 2:21 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Add-PSSnapin Quest.ActiveRoles.ADManagement
Import-Module MSOnline
Import-Module MSOnlineExtended


$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString)
$credential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password

<#
AccountSkuId
------------
PIMCO:CRMPLAN2
PIMCO:ENTERPRISEPREMIUM
PIMCO:POWERAPPS_INDIVIDUAL_USER
PIMCO:YAMMER_ENTERPRISE_STANDALONE
PIMCO:CRMSTANDARD
PIMCO:CRMTESTINSTANCE
PIMCO:OFFICESUBSCRIPTION
PIMCO:CRMSTORAGE
#>
#Get-QADUser "(&(!sAMAccountName=*tdy*)(!sAMAccountName=*driver*))"

try
{
	Connect-QADService pimco -ea 'Stop'
}
catch
{
	Write-Warning "Failed to connect "	
}
#Get-QADUser -samaccountname jchandle | Set-QADUser -ObjectAttributes @{ cloudsync = "Yammer Enterprise|Microsoft Dynamics CRM Online Professional|Office 365 ProPlus"}

$skuid = @{
	"Microsoft Dynamics CRM Online Basic" = "PIMCO:CRMPLAN2"
	"Office 365 Enterprise E5" = "PIMCO:ENTERPRISEPREMIUM"
	"PowerApps and Logic Flows" = "PIMCO:POWERAPPS_INDIVIDUAL_USER"
	"E3-Yammer" = "PIMCO:ENTERPRISEPACK-YAMMER_ENTERPRISE"
	"Microsoft Dynamics CRM Online Professional" = "PIMCO:CRMSTANDARD"
	#"CRMTESTINSTANCE" = ""
	"E3-ProPlus" = "PIMCO:ENTERPRISEPACK-OFFICESUBSCRIPTION"
	#"CRMSTORAGE" = "Microsoft Dynamics CRM Online Additional Storage"
}

$skuarray = @()
$object = "" | select LicenseName, LicenseSku, Products
$object.licensename = "E3"
$object.licensesku = "PIMCO:ENTERPRISEPACK"
$object.products = @()

$object2 = "" | select ProductName, ProductSKU, Status
$object2.productname = "StaffHub"
$object2.productsku = "Deskless"
$object2.status = "Disabled"
$object.products += $object2

$object2 = "" | select ProductName, ProductSKU, Status
$object2.productname = "Flow"
$object2.productsku = "FLOW_O365_P3"
$object2.status = "Disabled"
$object.products += $object2
$skuarray += $object

$object = "" | select LicenseName, LicenseSku, Products
$object.licensename = "CRM Online"
$object.licensesku = "PIMCO:CRMSTANDARD"
$skuarray += $object




#Connect to the tenant
try
{
	Connect-MSOLService pimco.onmicrosoft.com -Credential $credential -ea Stop | Out-Null
}
catch
{
	throw "Failed to connect to O365 tenant!"
}
#Connect to local domain
try
{
	Connect-QADService pimco.imswest.sscims.com -ea Stop | Out-Null
}
catch
{
	throw "Failed to connect to local domain!"	
}
#Get enabled cloud users
#$cloudusers = Get-QADUser -LdapFilter "(cloudsync=true)" -SizeLimit 0
$cloudusers = Get-QADUser -LdapFilter "(cloudsync=*)" -SizeLimit 0 -IncludedProperties cloudsync, AccountIsDisabled
#Get all synced users
$msonlineusers = Get-MSOLUser -All
#Loop through enabled cloud users
foreach ($user in $cloudusers[-3])
{
	#Find the specific user in the loop
	$selecteduser = $msonlineusers | where { $_.userprincipalname -eq $user.email }
	if ($selecteduser)
	{
		#Create a sku list from the cloudsync attribute
		$msonlineskulist = $selecteduser.licenses.accountskuid
		
		#Add product skus
		#$selecteduser.licenses[0].servicestatus
		$Licenseobject = @()
		$ADcloudsyncvalue = (($user.cloudsync).split("|")).trimstart(" ")
		$uniquelicense = ((((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -like "*-*" }).substring(0, 3)) | sort -unique
		$uniquefulllicense = ((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -notlike "*-*" }
		foreach ($licensetype in $uniquelicense)
		{
			#$licensetype = $licensetype.trimstart(" ")
			write-host "this is the parent type $licensetype"
			
			$object = ($skuarray | where { $_.productname -eq $LicenseName })
			
			foreach ($parent in ($ADcloudsyncvalue | where { $_ -like "$licensetype*" }))
			{
				$parent
				$object.productskus = $object.productskus | where { $_ -ne $product }
			}
			$Licenseobject += $object
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			if ($licensetype -like "*-*")
			{
				$LicenseName = (($licensetype) -split "-")[0]
				$ProductName = (($licensetype) -split "-")[1]
				$object = ($skuarray | where { $_.productname -eq $LicenseName })
				#$ADskulist += $($skuid.$licensetype)
				#$LicenseName
				#$ProductName
				
				foreach ($product in ($skuarray | where { $_.productname -eq $LicenseName }).productskus)
				{
					#Write-Host "this is the product: $product"
					#Write-Host "this is the product name: $productname"
					if ($product -eq $ProductName)
					{
						$object.productskus = $object.productskus | where { $_ -ne $product }
					}
				}
				$Licenseobject += $object
			}
			else
			{
				$LicenseName = $licensetype
				$object = ($skuarray | where { $_.productname -eq $LicenseName })
				$Licenseobject += $object
			}
			
			if ($($skuid.$licensetype) -notlike "")
			{
				
			}
			
		}
		
		#Remove existing licenses if we don't match or if the account is disabled in AD
		if ((compare $ADskulist $msonlineskulist) -notlike "" -or $user.AccountIsDisabled -eq $true)
		{
			Write-Host "Removing all licenses from $($selecteduser.userprincipalname)"
			$selecteduser | Set-MsolUserLicense -RemoveLicenses
		}
		
		$productskulist = @()
		if ((compare $ADskulist $msonlineskulist) -notlike "")
		{
			
		}
	}
	else
	{
		Write-Warning "Could not find $($user.samaccountname) in O365 users"
	}
}


#Get disabled AD users
$disabledusers = Get-QADUser -Disabled -SizeLimit 0 -IncludedProperties cloudsync, AccountIsDisabled
foreach ($user in $disabledusers)
{
	#Find the specific user in the loop, if they exist remove any license because they're disabled
	$selecteduser = $msonlineusers | where { $_.userprincipalname -eq $user.email }
	if ($selecteduser)
	{
		Write-Host "Removing all licenses from $($selecteduser.userprincipalname) because they are disabled"
		$selecteduser | Set-MsolUserLicense -RemoveLicenses
	}
}



<#
$skus = Get-MsolAccountsku
foreach ($i in $skus)
{
	Write-Host "---------"
	Write-Host "SKU: $($i.accountskuid)"
	Write-Host "---------"
	Write-Host "--Sub Service plans:"
	$i.servicestatus
}

#######
$a = get-msoluser -userprincipalname james.chandler@pimco.com
$testsku = New-MsolLicenseOptions -AccountSkuId PIMCO:ENTERPRISEPACK -DisabledPlans SWAY
$a | Set-MsolUserLicense -Licenseoptions $testsku

######


	#Apply licenses based on cloudsync attribute
			foreach ($licensetype in (($user.cloudsync).split(" | ")))
			{
				if ($licensetype -ne "True" -and $licensetype -notlike "")
				{
					if ($licensetype -notlike "PIMCO:*")
					{
							
					}
					else
					{
						
						Write-Host "Adding $($skuid.$licensetype) license to $($selecteduser.userprincipalname)"
						try
						{
							$selecteduser | Set-MsolUserLicense -AddLicenses $($skuid.$licensetype) -ea Stop -whatif
						}
						catch
						{
							Write-Warning "Failed to set $($skuid.$licensetype) license to $($selecteduser.userprincipalname)"
						}
					}
				}
			}


#>