<#
	.SYNOPSIS
		Create a new IIS web application or root site.

	.DESCRIPTION
		Create a new IIS web application or root site

	.PARAMETER  Computer
		The server that the new site will be created on.

	.PARAMETER  Name
		The new site or root site name.

	.PARAMETER  Authentication
		Specify AnonymousAuthentication or WindowsAuthentication, default anonymous.

	.PARAMETER  Rootsite
		Specify the rootsite name for the new site, do not specify if the new site will be a root.
	
	.PARAMETER  UseAppPoolCredentials
		Specify credentials to be used for the app pool, otherwise inherit the server defaults.

	.EXAMPLE
		PS C:\> .\New-WebApp.ps1 -Computer vmh001d059 -Name testsite -Authentication WindowsAuthentication -Bindings testsite
				
		This example shows how to create a new site on vmh001d059 with name testsite, anonymous authentication, with bindings for: testsite, testsite.pimco.imswest.sscims.com, testsitedev, testsitedev.pimco... etc.

	.EXAMPLE 
		PS C:\> .\New-WebApp.ps1 -Computer vmh001d059 -Name appnamewcf -Authentication WindowsAuthentication -RootSite testroot
		
		This example shows how to create a new webapp on vmh001d059 with app name appnamewcf, Windows authentication, under root site testroot

	.EXAMPLE
		PS C:\> Name 'One value' 32
		'This is the output'
		This example shows how to call the Name function with positional parameters.

	.INPUTS
		System.String,System.Int32

	.OUTPUTS
		System.String

	.NOTES
		For more information about advanced functions, call Get-Help with any
		of the topics in the links listed below.

	.LINK
		about_functions_advanced

	.LINK
		about_comment_based_help

	.LINK
		about_functions_advanced_parameters

	.LINK
		about_functions_advanced_methods
#>

[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$Computer,
	
	[Parameter(Mandatory = $true, Position = 1, ParameterSetName = 'Location2')]
	[string]$Name,
	
	[Parameter(Mandatory = $false, Position = 1, ParameterSetName = 'Location2')]
    [ValidateSet('Anonymous','Windows','Kerberos')]
	[string]$Authentication,
	
	[Parameter(Mandatory = $false, Position = 1, ParameterSetName = 'Location2')]
	[string]$RootSite,

	[Parameter(Mandatory = $false, Position = 1, ParameterSetName = 'Location2')]
	[string]$Bindings,

    [Parameter(Mandatory = $false, Position = 1, ParameterSetName = 'Location2')]
    [string]$Port,

    [ValidateScript({If ($_ -match "^[a-zA-Z0-9_.-]+\\[a-zA-Z0-9_-]+$") {
            $script:Credential = get-credential $_
            $True
        } Elseif ($_.gettype().name -eq "PSCredential") {$script:Credential = $_ ; $true} Else {
            write-host ($_.gettype().name) ; Throw "Please specify the credential as domain\username"
        }})]
    #[string[]]$AppPoolCredential,
    $AppPoolCredential,

    [ValidateSet('v4.0','v2.0')]
    [string]$AppPoolVersion = "v4.0",

    [switch]$UseAppPoolCredentials,

    [switch]$GUI
)


function CheckForModule
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory = $true, Position = 1, ParameterSetName = 'Location1')]
		[string]$ModuleName
	)
	$ModuleList = Get-Module -list
	$TestModule = $ModuleList | where { $_.name -eq $ModuleName }
	if ($TestModule)
	{
		$ModuleRunning = Get-Module -Name $ModuleName
		if ($ModuleRunning)
		{
			Add-LogEntry "$ModuleName is already loaded"
		}
		else
		{
			Import-Module -Name $ModuleName
			Add-LogEntry "$ModuleName has been loaded"
		}
	}
	else
	{
		Write-Warning "The required module $modulename is not installed"
		Add-LogEntry "$ModuleName is not installed"
		exit
	}
}

#Define environment information
$global:FullScriptPath = $MyInvocation.MyCommand.Definition
$global:CurrentScriptName = $MyInvocation.MyCommand.Name
$global:CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#CheckForModule BaseModule
Import-module \\nasshare\share\PimcoIIS_InstallPackage\Powershell\Modules\BaseModule
$global:ExecutionTime = Add-Logstamp -file
$global:Executedby = whoami
$global:Guid = ([System.Guid]::NewGuid().toString())
Set-Logging

#set retry attemps
$script:retrycount = 10

function Retryfunction
{
Param ($CallingFunction)
	if ($retry -le $script:retrycount -or $retry -eq $null)
	{
		sleep 3
		$retry++
		Add-LogEntry "Retrying $CallingFunction"
		Write-Warning "Retrying $CallingFunction"
		Add-LogEntry "$($error[0].exception)"
		.$CallingFunction
	}
	else
	{
	$retry = $null
	}
}


function CreateSession
{
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "10" -CurrentOperation "Creating session on $Computer..."}
	Write-Verbose "Creating session on $Computer..."
	try {
	$script:session = New-PSSession -ComputerName $Computer -ErrorAction Stop
	}
	Catch
	{
		Write-Warning "Session creation failed on $computer"
		Add-LogEntry "Session creation failed on $computer"
		Exit-Script
	}
		Write-Verbose "Done"
	Add-LogEntry "Session created on $computer"
}

function ImportWebAdministration
{
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "20" -CurrentOperation "Importing Webadministration module..."}
	Write-Verbose "Importing Webadministration module..."
	try 
    {
		Import-Module webadministration -ErrorAction Stop
	}
	Catch
	{
	Add-LogEntry "Webadministration module not found"
	RemovingSession
	Exit-Script
	}
	Write-Verbose "Done"
	Add-LogEntry "Webadministration module loaded"
}

function CreateAppPool
{
	if ($retry -eq $null)
	{
        if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "40" -CurrentOperation "Creating app pool..."}
		Write-Verbose "Creating app pool..."
	}
	try 
    {
	    New-WebAppPool -Name $Name -ErrorAction Stop | Out-Null
	}
	Catch
	{
		Retryfunction CreateAppPool
		if ($retry -ge $script:retrycount)
			{
			Add-LogEntry "App pool creation failed"
			Write-Warning "App pool creation failed"
			RemovingSession
			Exit-Script
			}
	}
	if ($retry -eq $null)
		{
		Write-Verbose "Done"
		Add-LogEntry "App pool created: $Name"
		}
}

function CreateDirectory
{
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "30" -CurrentOperation "Creating directory..."}
	Write-Verbose "Creating directory..."
	Try 
	{
		New-Item -Name $Name -Type Directory -Path "\\$Computer\e$\inetpub" -ErrorAction Stop | Out-Null
	}
	Catch
	{
	Add-LogEntry "Folder creation failed"
	Write-Warning "Folder creation failed"
	}
	Write-Verbose "Done"
	Add-LogEntry "Directory created: \\$Computer\e$\inetpub\$name"
}

function CreateAppSite
{
	if ($retry -eq $null)
	{
        if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "40" -CurrentOperation "Creating application/website..."}
		Write-Verbose "Creating application/website..."
	}
	if ($RootSite)
	{
		Try 
        {
		    New-WebApplication -name $Name -Site $RootSite -PhysicalPath e:\inetpub\$($Name) -ApplicationPool $Name -ErrorAction Stop | Out-Null
		}
		Catch
		{
			Retryfunction CreateAppSite
			if ($retry -ge $script:retrycount)
				{
				Add-LogEntry "App/Website creation failed"
				Write-Warning "App/Website creation failed"
				RemovingSession
				Exit-Script
				}
		}
		if ($retry -eq $null)
		{	
		Add-LogEntry "New Application $name created under root site $rootsite"
		Write-Verbose "Done"
		}
	}
	else
	{
		#If no root site
		Try 
        {
			New-Website -Name $Name -ApplicationPool $Name -physicalpath e:\inetpub\$($Name) -ErrorAction Stop | Out-Null
		}
		Catch
		{
			Retryfunction CreateAppSite
			if ($retry -ge $script:retrycount)
				{
				Add-LogEntry "App/Website creation failed"
				Write-Warning "App/Website creation failed"
				RemovingSession
				Exit-Script
				}
		}
		if ($retry -eq $null)
		{
			Add-LogEntry "New Site created: $Name"
			Write-Verbose "Done"
		}
	}
}

function SetBindings
{
    if ($port -like $null)
    {
        $port = "8700"
    }
	#Get-website cfportal-client-alpha
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "60" -CurrentOperation "Setting bindings..."}
	Write-Verbose "Setting bindings..."
	if ($RootSite -like $null -and $Bindings)
	{
	Try
	{
		New-WebBinding $Name -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)dev"
		New-WebBinding $Name -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)dev.pimco.imswest.sscims.com"
		New-WebBinding $Name -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)beta"
		New-WebBinding $Name -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)beta.pimco.imswest.sscims.com"
		New-WebBinding $Name -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)"
		New-WebBinding $Name -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings).pimco.imswest.sscims.com"
	}
	Catch
	{
		Write-Warning "Binding addition failed"
		Add-LogEntry "Binding addition failed"
	}
		#Remove default binding
		Try
		{
		    Remove-WebBinding -Name $Name -port 80 -ErrorAction Stop
		}
		Catch
		{
		Write-Warning "Failed to remove default web binding"
		Add-LogEntry "Failed to remove default web binding"
		}
		Add-LogEntry "Bindings created for $Name"
		Write-Verbose "Done"
	}
	if ($RootSite -and $Bindings)
	{
		Try
		{
			New-WebBinding $Rootsite -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)dev" -ErrorAction Stop
			New-WebBinding $Rootsite -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)dev.pimco.imswest.sscims.com" -ErrorAction Stop
			New-WebBinding $Rootsite -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)beta" -ErrorAction Stop
			New-WebBinding $Rootsite -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)beta.pimco.imswest.sscims.com" -ErrorAction Stop
			New-WebBinding $Rootsite -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings)" -ErrorAction Stop
			New-WebBinding $Rootsite -IPAddress "*" -Port $($Port) -HostHeader "$($Bindings).pimco.imswest.sscims.com" -ErrorAction Stop
		}
		Catch
		{
			Write-Warning "Binding addition failed"
			Add-LogEntry "Binding addition failed"
		}
		
		#Remove default binding - There should not be a default binding for an existing root site
		Try
		{
			Remove-WebBinding -Name $Name -port 80 -ErrorAction Stop
		}
		Catch
		{
			#Write-Warning "A default web binding was not found for port 80"
			Add-LogEntry "Failed to remove default binding (it probably doesn't exist)"
		}
		Add-LogEntry "Bindings created for $Rootsite"
		Write-Verbose "Done"
	}
}

function SetAuthentication
{
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "50" -CurrentOperation "Setting authentication"}
	Write-Verbose "Setting authentication..."
	if ($RootSite -like $null -and $Authentication)
	{
		#Write-Verbose "Authentication set and Rootsite NOT set"
		switch ($Authentication)
		{
			"Anonymous"
			{
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $Name -value true -ErrorAction Stop
				}
				Catch
				{	
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
				
				Try
				{
				    Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $Name -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
			}
			
			"Windows"
			{
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $Name -value true -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
				
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $Name -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
			}
			
            "Kerberos"
			{
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $Name -value true -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
				
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $Name -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}

                Try
                {
                    $Providers = (Get-WebConfigurationProperty -Filter /system.webserver/security/authentication/windowsauthentication -location $Name -name providers).collection
                    $NewProviders = $Providers | where {$_.value -ne "NTLM"}
                    Set-WebConfigurationProperty -Filter /system.webserver/security/authentication/windowsauthentication -location $Name -name providers -Value $NewProviders -ErrorAction stop
                }
                Catch
                {
                    Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to modify providers"
						Add-LogEntry "Failed to modify providers"
					}
                }
            }

			Default { Write-Verbose "Authentication not specified, inheriting from root site" }
		}
		Add-LogEntry "$Authentication set on site $Name"
	}
	
	if ($Authentication -and $RootSite)
	{
		#Write-Verbose "Authentication set and Rootsite set"
		switch ($Authentication)
		{
			"Anonymous"
			{
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($Rootsite)/$($Name)" -value true -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
				
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($Rootsite)/$($Name)" -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
			}
			
			"Windows"
			{
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($Rootsite)/$($Name)" -value true -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
				
				Try
				{
				    Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($Rootsite)/$($Name)" -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
			}
			
            "Kerberos"
			{
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($Rootsite)/$($Name)" -value true -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}
				
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($Rootsite)/$($Name)" -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set authentication"
						Add-LogEntry "Failed to set authentication"
					}
				}

                Try
                {
                    $Providers = (Get-WebConfigurationProperty -Filter /system.webserver/security/authentication/windowsauthentication -location "$($Rootsite)/$($Name)" -name providers).collection
                    $NewProviders = $Providers | where {$_.value -ne "NTLM"}
                    Set-WebConfigurationProperty -Filter /system.webserver/security/authentication/windowsauthentication -location "$($Rootsite)/$($Name)" -name providers -Value $NewProviders -ErrorAction stop
                }
                Catch
                {
                    Retryfunction SetAuthentication
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to modify providers"
						Add-LogEntry "Failed to modify providers"
					}
                }
			}

			Default { Write-Verbose "Authentication not specified, inheriting from defaults" }
		}
		Add-LogEntry "$Authentication set on app $($RootSite)/$($Name)"
	}
	Write-Verbose "Done"
}

function StartWebsite
{
	if ($rootsite)
	{ }
	else
	{
		#Start the website
        if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "90" -CurrentOperation "Starting the site..."}
		Write-Verbose "Starting the site..."
		Try
		{
		    Start-Website -Name $Name -ErrorAction Stop
		}
		Catch
		{
			Write-Warning "Site failed to start"
			Add-LogEntry "Site failed to start"
		}
		Add-LogEntry "Starting website $Name"
		Write-Verbose "Done"
	}
}

function RemovingSession
{
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "99" -CurrentOperation "Removing the created session"}
	Write-Verbose "Removing the created session"
	Remove-PSSession $script:session
	Add-LogEntry "Removing session on $Computer"
	if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "100" -CurrentOperation "Done"}
    Write-Verbose "Done"
}

function SetUseAppPoolCredentials
{
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "75" -CurrentOperation "Setting UseAppPoolCredentials..."}
	Write-Verbose "Setting UseAppPoolCredentials..."
	if ($RootSite -like $null -and $UseAppPoolCredentials)
	{
		switch ($UseAppPoolCredentials)
		{
			"True"
			{
                #Write-Verbose "UseAppPoolCredentials set to true and Rootsite NOT set"
				Try
				{
				    Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location $Name -value true -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetUseAppPoolCredentials
					if ($retry -ge $script:retrycount)
					{
						Add-LogEntry "Failed to set Use AppPool credentials to true"
						Write-Warning "Failed to set Use AppPool use credentials to true"	
					}
				}
			}
			
			"False"
			{
                #Write-Verbose "UseAppPoolCredentials set to false and Rootsite NOT set"
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location $Name -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetUseAppPoolCredentials
					if ($retry -ge $script:retrycount)
					{
						Add-LogEntry "Failed to set Use AppPool credentials to false"
						Write-Warning "Failed to set Use AppPool credentials to false"
					}
				}
			}
			
			Default { Write-Verbose "App Pool Credentials not specified correctly, inheriting from root site" }
		}
		Add-LogEntry "UseAppPoolCredentials set to $UseAppPoolCredentials on site $Name"
	}
	
	if ($UseAppPoolCredentials -and $RootSite)
	{
		#Write-Verbose "Use App Pool Credentials set to true and Rootsite set"
		switch ($UseAppPoolCredentials)
		{
			"True"
			{
                #Write-Verbose "Use App Pool Credentials set to true and Rootsite set"
				Try
				{
				    Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location "$($Rootsite)/$($Name)" -value true -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetUseAppPoolCredentials
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set Use AppPool credentials to true"
						Add-LogEntry "Failed to set Use AppPool credentials to true"
					}
				}
			}
			
			"False"
			{
				Try
				{
					Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location "$($Rootsite)/$($Name)" -value false -ErrorAction Stop
				}
				Catch
				{
					Retryfunction SetUseAppPoolCredentials
					if ($retry -ge $script:retrycount)
					{
						Write-Warning "Failed to set Use AppPool credentials to false"
						Add-LogEntry "Failed to set Use AppPool credentials to false"
					}
				}
			}
			
			Default { Write-Verbose "UseAppPoolCredentials not specified correctly, inheriting from defaults" }
		}
		Add-LogEntry "UseAppPoolCredentials set to $UseAppPoolCredentials on app $($RootSite)/$($Name)"
	}
	Write-Verbose "Done"
}


function SetAppPoolCredentials
{
	if ($retry -eq $null)
	{
        if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "60" -CurrentOperation "Setting app pool credentials..."}
		Write-Verbose "Setting app pool credentials..."
	}
	try 
    {
		$GetPool = Get-Item "iis:\AppPools\$($Name)"
        $GetPool.processmodel.username = $script:Credential.username
        $GetPool.processmodel.Password = $script:Credential.GetNetworkCredential().password
        $GetPool.processmodel.identityType = "SpecificUser"
        $GetPool | Set-Item
        Restart-WebAppPool -Name $Name -ErrorAction Stop
	}
	Catch
	{
		Retryfunction SetAppPoolCredentials
		if ($retry -ge $script:retrycount)
			{
			Add-LogEntry "App pool credentials failed"
			Write-Warning "App pool credentials failed"
			RemovingSession
			Exit-Script
			}
	}
	if ($retry -eq $null)
		{
		Write-Verbose "Done"
		Add-LogEntry "App pool credentials set: $Name"
		}
}

function SetAppPoolRuntimeVersion
{
	if ($retry -eq $null)
	{
        if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "80" -CurrentOperation "Setting app pool runtime version..."}
		Write-Verbose "Setting app pool runtime version..."
	}
	try 
    {
		$GetPool = Get-Item "iis:\AppPools\$($Name)"
        $GetPool.managedRunTimeVersion = $AppPoolVersion
        $GetPool | Set-Item
        Restart-WebAppPool -Name $Name -ErrorAction Stop
	}
	Catch
	{
		Retryfunction SetAppPoolRuntimeVersion
		if ($retry -ge $script:retrycount)
			{
			Add-LogEntry "Set App pool Runtime Version failed"
			Write-Warning "Set App pool Runtime Version failed"
			RemovingSession
			Exit-Script
			}
	}
	if ($retry -eq $null)
		{
		Write-Verbose "Done"
		Add-LogEntry "App pool version set: $apppoolversion"
		}
}

function BackupConfig
{
    if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "25" -CurrentOperation "Backing up applicationHost.config on $Computer..."}
	Write-Verbose "Backing up applicationHost.config on $Computer..."
    Try 
    {
         Copy-item \\$Computer\C$\Windows\System32\inetsrv\config\applicationHost.config \\$Computer\C$\Windows\System32\inetsrv\config\applicationHost.old -Force
    }
    Catch
    {
        if ($gui) {Write-Progress -Status "Running" -Activity "Site/App Creation" -PercentComplete "30" -CurrentOperation "Failed to backup applicationHost.config on $Computer..."}
	    Write-Verbose "Failed to backup up applicationHost.config on $Computer..."
    }

}

###Main###
ImportWebAdministration
BackupConfig
CreateDirectory
CreateAppPool
CreateAppSite
SetAuthentication
SetBindings
SetUseAppPoolCredentials
If ($script:Credential)
{
    SetAppPoolCredentials
}
SetAppPoolRuntimeVersion
StartWebsite
Exit-Script


###ToDo###

#msdeploy to similar servers

#x-servername-header

#health check

#configure remote in