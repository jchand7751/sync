﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/5/2015 5:11 PM
	 Created by:   	jchandle
	 Organization: 	Pimco
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Anaconda setup.
#>
#Variables and Environment setup
$logfile = "C:\temp\AnacondaSetupLog.txt"
$setupdirectory = "C:\temp\anacondasetup"
$applicationdirectory = "C:\Anaconda"
$packagearray = "cx_oracle", "xlwings", "pymongo", "pyodbc"
$matlabsetup = "\\ina001p093\e$\program files\MATLAB\MATLAB Production Server\R2014b\client\"
$finishflag = "C:\temp\anacondafinishflag.txt"


function executiontime 
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

Add-Content -Path $logfile "$(executiontime) - Starting script"

if (Test-Path $finishflag)
{
	Add-Content -Path $logfile "$(executiontime) - Install detected already, exiting"
	exit	
}


c:
cd \
if (Test-Path $setupdirectory)
{ }
else
{
	try
	{
		mkdir $setupdirectory -ea 'Stop'
	}
	catch
	{
		Write-Warning "Directory creation failed"
		Add-Content -Path $logfile "$(executiontime) - Error: Directory creation failed"
		exit
	}
}

<#install being handled by Bigfix
#Run the install silently
.\Anaconda-2.2.0-Windows-x86_64.exe /S /InstallationType=AllUsers /AddToPath=1 /RegisterPython=1 /D=C:\Anaconda
#Wait for it to finish
$counter = 0
do { $Checkprocess = Get-Process -name Anaconda-2.2.0-Windows-x86_64; Write-Host "Waiting for install to finish"; sleep 1; $counter++ }
until ($checkprocess -like $null -or $counter -ge "300")
#>

if (Test-Path $applicationdirectory)
{
	#Get installed packages
	try
	{
		$installedpackages = conda list
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Error: Anaconda setup failure, can't run conda command"
	}
	#Check for which packages we need to install
	foreach ($package in $packagearray)
	{
		foreach ($line in $installedpackages)
		{
			$found = $false
			if ($line.contains($package)) { write-host "$package is already installed"; $found = $true; break }
			else
			{
				Write-Warning "$package not on this line"
			}
		}
		if ($found -ne $true)
		{
			conda install $package --yes
		}
	}
	
	if (Test-Path $matlabpath)
	{
		#Write-Host "Matlab appears to be installed"
		Add-Content -Path $logfile "$(executiontime) - Install appears to be finished"
		New-Item -Type File $finishflag -Force
		exit	
	}
	else
	{
		try
		{
			copy $matlabsetup $setupdirectory -Recurse -ea 'Stop' -force
		}
		catch
		{
			Write-Warning "Matlab copy failed"
			Add-Content -Path $logfile "$(executiontime) - Error: Matlab copy failed"
		}
		try
		{
			cd $setupdirectory\client\python -ea 'Stop'
			python setup.py install
		}
		catch
		{
			Write-Warning "Matlab install failed"
			Add-Content -Path $logfile "$(executiontime) - Error: Matlab install failed"
		}
	}
}
else
{
	Write-Warning "Anaconda isn't installed, or it's installed in the wrong directory"
	Add-Content -Path $logfile "$(executiontime) - Error: Anaconda isn't installed or it's installed in the wrong directory"
}
Add-Content -Path $logfile "$(executiontime) - Script finished"

