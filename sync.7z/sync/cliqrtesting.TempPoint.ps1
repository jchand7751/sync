﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/11/2016 1:44 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#enable dev cloud for user
Add-PSSnapin Quest.ActiveRoles.ADManagement
curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/users/98" -d "{ ""action"": ""MANAGE_CLOUDS"", ""manageCloudsData"": { ""activateRegions"": [ { ""regionId"": ""2"" } ], ""storageSize"": 0 } }"

#Create an SSO type user with details - not using Activation profile
curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/users/" -d "{ ""firstName"": ""Virgil"", ""lastName"": ""Gherghel"", ""password"": ""asdfghjk"", ""emailAddr"": ""Virgil.Gherghel@pimco.com"", ""companyName"": ""TECH-Infrastructure"", ""phoneNumber"": """", ""externalId"": ""vgherghe"", ""tenantId"": 1, ""activationData"": { ""activateRegions"": [ { ""regionId"": ""1"" } ], ""agreeToContract"": true, ""sendActivationEmail"": false, ""importApps"": [] } }"


curl.exe -k -X GET -H "Accept: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/users?size=0"

$users = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/users?size=0" }

#$users = $users | ConvertFrom-Json
#$users.users | select

#Create a service
curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/tenants/1/services" -d "@svc1.json"

#Reset password
curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/users/2" -d "@adminpw.json"


#upload icon and get value to pass to json
curl.exe -k -X POST -H "Accept: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/appstore/upload" --form logoImageFile=@ubuntu1404.png

#WORKING
$user = Get-QADUser vgherghe

#Stage new User with Activation profile (using AD variables)
Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/users/" -d "{ `"`"firstName`"`": `"`"$($user.firstname)`"`", `"`"lastName`"`": `"`"$($user.lastname)`"`", `"`"password`"`": `"`"===redacted===`"`", `"`"emailAddr`"`": `"`"$($user.email)`"`", `"`"companyName`"`": `"`"$($user.department)`"`", `"`"phoneNumber`"`": `"`"`"`", `"`"externalId`"`": `"`"$($user.samaccountname)`"`", `"`"tenantId`"`": 1, `"`"activationProfileId`"`": 8 } "}
#Add user to dev cloud
Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u cliqradmin:13B2BAAF5C2EB62C "https://10.155.5.112/v1/users/102" -d "{ `"`"action`"`": `"`"MANAGE_CLOUDS`"`", `"`"manageCloudsData`"`": { `"`"activateRegions`"`": [ { `"`"regionId`"`": `"`"2`"`" } ], `"`"storageSize`"`": 0 } } " }

#API Create Group
#from file
curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups" -d "@pimcloudfotech.json" -s

#from variable
$a = (Get-Content c:\tmp\pimcloudfotech.json).replace('"', '""')
curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups" -d "$a" -s

#make variable
$c = Convertfrom-Json -InputObject "$a"

#make object
$groups = Get-QADGroup -Name pimcloud-*
foreach ($i in $groups)
{
	$object = "" | select tenantId, name, description, users, roles
	$object.tenantId = 1
	$object.name = $i.name
	$object.users = @()
	$roles = "" | select id
	$roles.id = 2
	$object.roles = @()
	$object.roles += $roles
	$object = $object | ConvertTo-Json
	$object = $object.replace('"', '""')
	curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups" -d "$object" -s
}

#API submit job
$result = curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $user "https://$url/v1/jobs" -d "@jsontest2.json" | ConvertFrom-Json

try
{
	#$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $user "https://$url/v1/jobs/3333333333" | ConvertFrom-Json
	$result = curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $user "https://$url/v1/jobs" -d "@jsontest2.json" | ConvertFrom-Json
	if ($result.code -eq 400 -or $result.errors)
	{
		throw "Exception"
	}
	sleep 10
}
catch
{
	throw "Result is not correct"
}

do
{
	try
	{
		#$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $user "https://$url/v1/jobs/3333333333" | ConvertFrom-Json
		$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $user "https://$url/v1/jobs/$($result.id)" | ConvertFrom-Json
		if ($jobstatus.code -eq 400 -or $jobstatus.errors)
		{
			throw "Exception"	
		}
		sleep 60
	}
	catch
	{
		$jobstatus = "JobError"
	}
}
until
($jobstatus -eq "JobError" -or $jobstatus -eq "JobRunning" -or $jobstatus -eq "JobCanceling")
switch ($jobstatus)
{
	"JobError" { throw "Job errored" }
	"JobCanceling" { throw "Job errored" }
	"JobRunning" { write-host "Job completed successfully";  exit 0 }
}
$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"

#Broken right now
curl.exe -k -X GET -H "Accept: application/json" -u $user "https://$url/v1/tenants/tenantId/vms?depEnvId=1&ccmOnly=ccmOnly" | ConvertFrom-Json

$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $user "https://$url/v1/jobs/3155" | ConvertFrom-Json

$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?size=0" -s | ConvertFrom-Json
$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?includeTerminated=true&size=0" -s | ConvertFrom-Json

$jobstatus = $jobstatus | where { $_.jobs.deploymentinfo.isdeploymentterminated -eq "True" }
$jobstatus = $jobstatus | where { $_.jobs.deploymentinfo.isdeploymentterminated -eq $false }

$jobstatus = foreach ($job in $jobstatus.jobs)
{
	$wtf = $job.deploymentinfo.isdeploymentterminated
	if ($wtf -eq $false)
	{
		$job
	}
}
$vmarray = @()
$vmarray1 = @()
function randomfunction
{
	#$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?includeTerminated=true&size=0" -s | ConvertFrom-Json
	$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?includeTerminated=true&size=0" -s
	[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
	$jsonserial = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
	$jsonserial.MaxJsonLength = 500000000
	$jobstatus = $jsonserial.DeserializeObject($jobstatus)
	
	$jobstatus = foreach ($job in $jobstatus.jobs)
	{
		$wtf = $job.deploymentInfo.isDeploymentTerminated
		if ($wtf -eq $false)
		{
			$job
		}
	}
	
	foreach ($i in $jobstatus.id)
	{
		Write-Host "Job $i"
		$query = (curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://10.155.5.112/v1/jobs/$i/nodes" -s | ConvertFrom-Json).nodes.virtualmachines.id
		
		Write-Host "VM(s) $Query"
		$vmarray += $query
		$vmarray
	}
	
	$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?includeTerminated=true&size=0" -s | ConvertFrom-Json
	
	$jobstatus = foreach ($job in $jobstatus.jobs)
	{
		$wtf = $job.deploymentInfo.isDeploymentTerminated
		if ($wtf -eq $true)
		{
			$job
		}
	}
	
	foreach ($i in $jobstatus.id)
	{
		Write-Host "Job $i"
		$query = (curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://10.155.5.112/v1/jobs/$i/nodes" -s | ConvertFrom-Json).nodes.virtualmachines.id
		Write-Host "VM(s) $Query"
		$vmarray1 += $query
	}
}


$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"

function Get-CliqrGroup
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$Name,
		[Parameter(Mandatory = $false, Position = 0)]
		$ID
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	$groups = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups?size=0" -s
	[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
	$jsonserial = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
	$jsonserial.MaxJsonLength = 500000000
	$groups = $jsonserial.DeserializeObject($groups)
	
	if ($Name)
	{
		$selectedgroup = ($groups.groups | where { $_.name -like $name })
		if ($selectedgroup -notlike $null)
		{
			$selectedgroup
		}
	}
	
	if ($ID)
	{
		$selectedgroup = ($groups.groups | where { $_.id -eq $ID })
		if ($selectedgroup -notlike $null)
		{
			$selectedgroup
		}
	}
	
	if ($Name -like $null -and $ID -like $null)
	{
		$groups.groups
	}
}

function Stop-CliqrJob
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$JobID
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	try
	{
		$command = curl.exe -k -X PUT -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid`?action=stop" -s | ConvertFrom-Json
		if ($command.code -eq 400 -or $command.errors -or $command.msg -ne "Stopping the app")
		{
			throw "Exception"
		}
	}
	catch
	{
		throw "Stopping job $JobID has failed"
	}
	Write-Output "Job $jobid is stopping"
}

function Get-CliqrJob
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$JobID,
		[Parameter(Mandatory = $false, Position = 0)]
		$Owner,
		[Parameter(Mandatory = $false, Position = 0)]
		$Name
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	if ($JobID)
	{
		try
		{
			$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid" -s | ConvertFrom-Json
			if ($jobstatus.code -eq 400 -or $jobstatus.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		Write-Output $jobstatus.jobs
	}
	
	if ($Owner)
	{
		$getuserid = (Get-CliqrUser -LogonName $Owner).id
		try
		{
			$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?size=0" -s | ConvertFrom-Json
			if ($jobstatus.code -eq 400 -or $jobstatus.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		$jobstatus.jobs | where { $_.depInitiatingUserId -eq $getuserid }
	}
	
	if ($Name)
	{
		try
		{
			$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?size=0" -s | ConvertFrom-Json
			if ($jobstatus.code -eq 400 -or $jobstatus.errors)
			{
				throw "Exception"
			}
			$jobstatus.jobs = $jobstatus.jobs | where { $_.displayname -like "*$Name*" }
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		Write-Output $jobstatus.jobs
	}
	
	if ($Owner -like $null -and $JobID -like $null -and $Name -like $null)
	{
		try
		{
			$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?size=0" -s | ConvertFrom-Json
			#$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid?includeTerminated=true&size=0" -s | ConvertFrom-Json
			if ($jobstatus.code -eq 400 -or $jobstatus.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		Write-Output $jobstatus.jobs
	}
	if ($Owner -like $null -and $JobID -like $null -and $Name -like $null -and $IncludeTerminated -eq $true)
	{
		try
		{
			$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?size=0" -s | ConvertFrom-Json
			#$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid?includeTerminated=true&size=0" -s | ConvertFrom-Json
			if ($jobstatus.code -eq 400 -or $jobstatus.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		Write-Output $jobstatus.jobs
	}
}

function Delete-CliqrJob
{
	param ($jobid)
	try
	{
		$command = curl.exe -k -X DELETE -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid" -s | ConvertFrom-Json
		if ($command.code -eq 400 -or $command.errors)
		{
			throw "Exception"
		}
	}
	catch
	{
		throw "Deleting job $jobid has failed"
	}
	Write-Output "Job $jobid is deleting"
}

function Get-CliqrUser
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$Name,
		[Parameter(Mandatory = $false, Position = 0)]
		$LogonName
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	if ($logonname)
	{
		try
		{
			$users = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" -s | ConvertFrom-Json
			if ($users.code -eq 400 -or $users.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			
		}
		$users.users | where { $_.externalId -eq $logonname}
	}
	
	if ($Name)
	{ }
	
	if ($Name -like $null -and $LogonName -like $null)
	{
		try
		{
			$users = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" -s | ConvertFrom-Json
			if ($users.code -eq 400 -or $users.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			
		}
		$users.users
	}
}


function Get-CliqrApp
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$AppID,
		[Parameter(Mandatory = $false, Position = 0)]
		$Name
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	if ($AppID)
	{
		try
		{
			$appdetails = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/apps/$appID" -s | ConvertFrom-Json
			if ($appdetails.code -eq 400 -or $appdetails.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		Write-Output $appdetails
	}
	
		
	if ($Name)
	{
		try
		{
			$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs?size=0" -s | ConvertFrom-Json
			if ($jobstatus.code -eq 400 -or $jobstatus.errors)
			{
				throw "Exception"
			}
			$jobstatus.jobs = $jobstatus.jobs | where { $_.displayname -like "*$Name*" }
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		Write-Output $jobstatus.jobs
	}
}

function Get-CliqrGroupMemberOf
{
	param ($externalid)
	(Get-CliqrGroup).name | foreach ($_) { write-host $_; (get-cliqrgroup -Name $_).users.externalId; write-host "----" ; write-host ""}	
}

(Get-CliqrGroup).name | foreach ($_) { if (get-cliqrgroup -Name $_).users.externalId; write-host "----"; write-host "" }

https://10.155.5.112/v1/jobs?appDetails=true&includeBenchmark=false&status=running&page=0&size=50&total_pages=0&total_entries=0&sort=id-&order=asc

$users = Get-CliqrUser

foreach ($user in $users)
{
	$jobids = (Get-CliqrJob -Owner $user.externalid).id
	foreach ($id in $jobids)
	{
		Get-CliqrJob -JobID $id
	}
	
	
}



function Get-CliqrJobDetails
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$JobID
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	if ($JobID)
	{
		try
		{
			$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid" -s | ConvertFrom-Json
			if ($jobstatus.code -eq 400 -or $jobstatus.errors)
			{
				throw "Exception"
			}
		}
		catch
		{
			Write-Warning "The specified command was incorrect"
			return
		}
		Write-Output $jobstatus
	}
	
	
}

#Share VM to winston with
curl.exe -k "https://cloud-fotech/v1/acls/" -X PUT -H "Content-Type: application/json" -d "@addwinston.json" -u James.Chandler_p:9F8E1DBCE57389C3
