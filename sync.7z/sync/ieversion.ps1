﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   3/17/2014 10:58 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

$key = ((Get-RegKey -comp localhost -Hive Localmachine -Key "SOFTWARE\Microsoft\Internet Explorer" | where {$_.key -eq "SOFTWARE\Microsoft\Internet Explorer\Version Vector"}).key)
(get-regvalue -key ((Get-RegKey -comp localhost -Hive Localmachine -Key "SOFTWARE\Microsoft\Internet Explorer" | where {$_.key -eq "SOFTWARE\Microsoft\Internet Explorer\Version Vector"}).key) -Value IE).data

function Get-IEVersion
{
	Param ($computername)
	(get-regvalue -key ((Get-RegKey -comp $computername -Hive Localmachine -Key "SOFTWARE\Microsoft\Internet Explorer" | where {$_.key -eq "SOFTWARE\Microsoft\Internet Explorer\Version Vector"}).key) -Value IE).data
}