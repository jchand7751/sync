﻿
Add-PSSnapin Quest.ActiveRoles.ADManagement

Connect-QADService vms001p5
$servers = Get-QADComputer -SearchRoot "OU=Windows,OU=Servers,OU=IA,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"
foreach ($server in $servers)
{
	if ((Test-Path \\$server\C$\Oracle\product\11.2.0\client32\Network\Admin\tnsnames.ora) -eq $true)
	{
		mkdir C$\Oracle\product\11.2.0\client32\Network\Admin\backup32
		copy-item C$\Oracle\product\11.2.0\client32\Network\Admin\tnsnames.ora
	}
	
	if ((Test-Path \\$server\C$\Oracle\product\11.2.0\client64\Network\Admin\tnsnames.ora) -eq $true)
	{
		mkdir C$\Oracle\product\11.2.0\client32\Network\Admin\backup64
		copy-item \\$server\C$\Oracle\product\11.2.0\client64\Network\Admin\tnsnames.ora C$\Oracle\product\11.2.0\client32\Network\Admin\backup64
	}
}