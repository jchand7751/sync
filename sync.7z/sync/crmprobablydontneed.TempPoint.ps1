﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/21/2017 4:03 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$array = @()
foreach ($i in $combinedusers)
{
	if ((get-qaduser -SamAccountName $i."ldap id" -DontuseDefaultIncludedProperties) -like $null)
	{
		$object = "" | select Name, Samaccountname, Department, CRMUSER
		$object.name = "MISSING"
		$object.Samaccountname = $i."ldap id"
		$object.department = "MISSING"
		$object.CRMUSER = $i."CRM User"
		$object
		$array += $object
	}
	else
	{
		$object = "" | select Name, Samaccountname, Department, CRMUSER
		$found = get-qaduser -SamAccountName $i."ldap id" -DontUseDefaultIncludedProperties -IncludedProperties name, samaccountname, department
		$object.name = $found.name
		$object.samaccountname = $found.samaccountname
		$object.department = $found.department
		$object.CRMUSER = $i."CRM User"
		$object
		$array += $object
	}
}