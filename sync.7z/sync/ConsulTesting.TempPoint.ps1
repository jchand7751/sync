﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/10/2017 6:54 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$url = "v2/applications/cliqr/services/Pimco%20IIS%208.5/jobid-35104/virtualmachines/name"


function ConvertToString
{
	param ($value)
	[System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($value))
}

function ConsulLookup
{
	param ($URL)
	$url = "http://pimcloudcmdb/v1/kv/" + $url + "?recurse"
	$a = curl.exe $URL -s | convertfrom-json
	$a | foreach { $_.value = (ConverTToString $_.value) }
	$a | select key, value | fl
}

