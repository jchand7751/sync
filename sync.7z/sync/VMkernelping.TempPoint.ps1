﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/1/2016 2:20 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#VM Kernel PING
$a = Get-EsxCli -VMHost csv035mgmtc001-n003.core.pimcocloud.net
($a.network.diag.ping(2, $null, $null, "10.155.2.141", 'vmk2', $null, $null, $null, $null, $null, $null, $null, $null)).summary