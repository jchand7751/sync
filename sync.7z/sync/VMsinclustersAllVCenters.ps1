﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/9/2013 11:11 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================


Add-PSSnapin VMware.VimAutomation.Core

function findvmsincluster
{
Param ($vcenter, $cluster)

$selectedcluster = $script:allclusters | where {$_.name -eq $cluster}
$hostlist = $selectedcluster.host
foreach ($i in $hostlist) 
	{
	$selected = get-view $i
	$vmsonhost = $selected.vm
	$clusterinfo = Get-View $selected.parent
	foreach ($vm in $vmsonhost)
		{
		$vmdetails = Get-view $vm
		$object = "" | select Cluster, Hostname, VMname, VCenter, CPUs, powerstate
		$object.vcenter = $vcenter
		$object.cluster = $clusterinfo.name
		$object.hostname = (get-view $i).name
		$object.vmname = if ($vmdetails.guest.hostname) {$vmdetails.guest.hostname} else {$vmdetails.name}
		$object.cpus = $vmdetails.summary.config.numcpu
		$object.powerstate = $vmdetails.guest.gueststate
		$script:array += $object
		}    
	}
}

$vcenters = "ina000pv", "vma000v51vc", "ina0z0pv", "vma0b0v51vc", "ina041pv"
#$vcenters = "ina0z0pv", "ina041pv"
$script:array = @()

foreach ($vc in $vcenters)
	{
	Disconnect-VIServer * -Confirm:$false -Force
	Connect-VIServer $vc
	$script:allclusters = Get-view -viewtype clustercomputeresource
	$script:vmhosts = Get-view -viewtype hostsystem
	foreach ($clusteritem in $script:allclusters)
		{
		findvmsincluster $vc $clusteritem.name
		}
	}

$script:array | export-csv c:\temp\mastervmlist.csv

