import requests, json
from requests.auth import HTTPBasicAuth

ADMIN = 'cloud-technologyserv_l'
ADMINPASSW = '79A795B51117AF01'
GROUPID = '6'
headers = {'Content-type': 'application/json'}

ADMIN = 'cliqradmin'
ADMINPASSW = '82D37A77DB1A5603'


#Get all users in tenant
r = requests.get("https://10.155.6.21/v1/users?size=0", headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))

#Find a specific user from parameter


#Make a trash table of applications and who owns them

#Get applications as user
r = requests.get("https://10.155.6.21/v1/apps?size=0", headers=headers, verify=False, auth=(USER, PASSW))


#Get the current permissions
r = requests.get("https://10.155.6.21/v1/acls/?id=%s&resourceName=APPLICATION" % (APPID), headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))

USER= "James.Chandler_k2"
USERID = "148"

r = requests.get("https://10.155.6.21/v1/users/%s/keys" % (USERID), headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))
dset = r.json()
PASSW = dset['apiKey']['key'].encode('ascii')



APPID = "530"

#Get the current permissions
r = requests.get("https://10.155.6.21/v1/acls/?id=%s&resourceName=APPLICATION" % (APPID), headers=headers, verify=False, auth=(USER, PASSW))
dset = r.json()


#Add the user to the existing permissions
dset['users'].append(insertUser)

#Save the data to a json format
json_data = json.dumps(dset)

#Set the new acl permissions
r = requests.put('https://10.155.6.21/v1/acls', data=json_data, headers=headers, verify=False, auth=(USER, PASSW))






for user in r.json()['users']:
     if user['emailAddr'] == "James.Chandler@pimco.com":
         print user['id']
         print user['username']

for app in r.json()['apps']:
     if app['name'] == "NoAdmins":
         print app['id']
         print app['name']


import pprint
pp = pprint.PrettyPrinter(indent=4)
pp.pprint(r.json())

insertUserGroups=[
        {
            "description": "", 
            "id": "%s" % (GROUPID), 
            "name": "vmadmingroup", 
            "perms": [
                "administration", 
                "write", 
                "read", 
                "delete"
            ], 
            "resource": "https://10.155.6.21/v1/acls/%s" % (GROUPID), 
            "tenantId": "%s" % (TENANTID)
        }
    ]

insertUser=[   
    {   
        'emailAddr': 'James.Chandler@pimco.com',
        'enabled': True,
        'firstName': 'James',
        'id': '148',
        'lastName': 'Chandler',
        'perms': [   'administration',
                      'write',
                      'read',
                      'execute',
                      'delete'
        ],
        'resource': 'https://10.155.6.21/v1/acls/148?id=530&resourceName=APPLICATION',
        'tenantId': '6',
        'type': 'STANDARD',
        'username': 'James.Chandler_k2'
    }
]

insertUser={
        'emailAddr': 'Akshit.Chauhan@pimco.com',
        'enabled': True,
        'firstName': 'Akshit',
        'id': '275',
        'lastName': 'Chauhan',
        'perms': [   'administration',
                      'write',
                      'read',
                      'execute',
                      'delete'
        ],
        'tenantId': '6',
        'username': 'Akshit.Chauhan_j4'
    }