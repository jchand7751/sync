﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/29/2013 12:18 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
#Param($allhosts)
[CmdletBinding()]
Param(
   [Parameter(Mandatory=$true,Position=0)]
   [ValidateScript({$(Add-PSSnapin VMware.VimAutomation.Core ; Connect-VIserver $_ )})]
   [string]$VCenter = $(if ($VCenter) { Read-Host -prompt "VCenter Server"}),
    
   [Parameter(Mandatory=$true,Position=1,ParameterSetName='Location2')]
   $VMHosts = $(if ($VMhosts) { Read-Host -prompt "VM Host(s)"})

	#[Parameter(Mandatory=$false,Position=2,ParameterSetName='Location3')]
   	#$Allhosts
)
#$mighosts = "inv000b6.imswest.sscims.com", "inv000b7.imswest.sscims.com", "inv000b8.imswest.sscims.com", "inv000pm.imswest.sscims.com", "inv000pn.imswest.sscims.com", "inv000po.imswest.sscims.com", "inv000pp.imswest.sscims.com", "inv000ps.imswest.sscims.com", "inv000pt.imswest.sscims.com", "inv000pu.imswest.sscims.com", "inv000py.imswest.sscims.com", "inv000pz.imswest.sscims.com"
#$mighosts = "inv000pc1.imswest.sscims.com", "inv000pc2.imswest.sscims.com", "inv000pc3.imswest.sscims.com", "inv000pc4.imswest.sscims.com", "inv000pc4.imswest.sscims.com", "inv000pc5.imswest.sscims.com", "inv000pc6.imswest.sscims.com", "inv000pc7.imswest.sscims.com", "inv000pc8.imswest.sscims.com", "inv000pc9.imswest.sscims.com", "inv000pca.imswest.sscims.com", "inv000pcb.imswest.sscims.com", "inv000pcc.imswest.sscims.com"
#$mighosts = "inv000p9.imswest.sscims.com"
$mighosts = $VMHosts -replace ","," ,"
#$mighosts
#Read-Host "stopping"
if ($allhosts)
	{Write-Host "found allhosts"
	}
	else
	{	
		$allhosts = get-view -viewtype hostsystem
	}

$array = @()
$script:fullhbaarray =  @()



Function CheckforSnapin
{
$testsnapin = Get-PSSnapin | where {$_.name -like "VMware.VIM*"}
if ($testsnapin)
    {}
    else
        {
        Add-PSSnapin VMware.VimAutomation.Core
        }
}

Function ConnecttoVCenter
{
Param ($Vcenter)

if ($Vcenter)
	{
	if ($defaultviservers)
    	{
    	Disconnect-VIServer * -Confirm:$false
    	Connect-VIServer $vcenter
    	}
    	else
        	{
        	Connect-VIServer $vcenter
        	}
	}
	else
		{
		Write-Warning "No VCenter specified!"
		exit
		}
}


function findHBAFirmware
{
Param ($VMhost, $user, $password)
$checkforSSHrunning = Get-VMHostService -VMHost $VMHost| where {$_.key -eq "TSM-SSH"}
if ($checkforsshrunning.running -eq $false)
    {
    $checkforsshrunning | start-vmhostservice
    }
$version = .\plink.exe -pw $password $user@$vmhost vmware -v
$finddevice = .\plink.exe -pw $password $user@$vmhost ls /proc/scsi/
$finddevice = [string]($finddevice | select-string "lpfc*")
$hbalist = .\plink.exe -pw $password $user@$vmhost ls /proc/scsi/$finddevice
$hbaarray = @()
    
if ($version -like "Vmware ESX Server 3*")
    {
    foreach ($port in $hbalist)
        {
        $object = "" | select Host, BoardNumber, Name, Driver, Firmware
        $object.host = $vmhost
        $details = .\plink.exe -pw $password root@$vmhost cat /proc/scsi/$finddevice/$port
        $object.boardnumber = $details[2] -replace "boardnum: "
        $object.driver = $details[0]
        $object.name = ($details[1] -split "on")[0]
        $object.firmware = $details[4] -replace "Firmware Version: "
        $hbaarray += $object
        $script:fullhbaarray += $object
        }
    $hbaarray[0]
    }    
}

function findHBAFirmwarev51
{
Param ($VMhost, $user, $password, $version)
$checkforSSHrunning = Get-VMHostService -VMHost $VMHost| where {$_.key -eq "TSM-SSH"}
if ($checkforsshrunning.running -eq $false)
    {
    $checkforsshrunning | start-vmhostservice
    }
$testconnection = .\plink.exe -pw $password $user@$vmhost echo test
    if ($testconnection -ne "test")
        {
        Write-warning "SSH test was unsuccessful, please check password and SSH service"
		}
	else
	{
	#$user = whoami
	#$version = plink.exe -pw $password $user@$vmhost vmware -v
	$finddevice = .\plink.exe -pw $password $user@$vmhost ls /proc/scsi/
	$finddevice = [string]($finddevice | select-string "lpfc*")
	$hbalist = .\plink.exe -pw $password $user@$vmhost ls /proc/scsi/$finddevice
	$hbaarray = @()

	if ($version -like "Vmware ESXi 5*" -or $version -like "Vmware ESXi 5*")
	    {
	    foreach ($port in $hbalist)
	        {
	        $object = "" | select Host, BoardNumber, Name, Driver, Firmware
	        $details = .\plink.exe -pw $password $user@$vmhost cat /proc/scsi/$finddevice/$port
	        $object.host = $vmhost
	        $object.boardnumber = $details[2] -replace "boardnum: "
	        $object.driver = $details[0]
	        $object.name = ($details[1] -split "on")[0]
	        $object.firmware = $details[4] -replace "Firmware Version: "
	        $hbaarray += $object
	        $script:fullhbaarray += $object
	        }
	    $hbaarray[0]
	    }
	  
	if ($version -like "Vmware ESX 4*" -or $version -like "Vmware ESXi 4*")
		{
			foreach ($port in $hbalist)
	        {
				$object = "" | select Host, BoardNumber, Name, Driver, Firmware
		        $details = .\plink.exe -pw $password $user@$vmhost cat /proc/scsi/$finddevice/$port
				$object.host = $vmhost
		        $object.boardnumber = $details[2] -replace "boardnum: "
		        $object.driver = $details[0]
		        $object.name = ($details[1] -split "on")[0]
		        $object.firmware = $details[3] -replace "Firmware Version: "
		        $hbaarray += $object
		        $script:fullhbaarray += $object
			}
			$hbaarray[0]
		}
		
	if ($version -like "Vmware ESX Server 3*")
	    {
	    foreach ($port in $hbalist)
	        {
	        $object = "" | select Host, BoardNumber, Name, Driver, Firmware
	        $object.host = $vmhost
	        $details = .\plink.exe -pw $password root@$vmhost cat /proc/scsi/$finddevice/$port
	        $object.boardnumber = $details[2] -replace "boardnum: "
	        $object.driver = $details[0]
	        $object.name = ($details[1] -split "on")[0]
	        $object.firmware = $details[4] -replace "Firmware Version: "
	        $hbaarray += $object
	        $script:fullhbaarray += $object
	        }
	    $hbaarray[0]
	    }    
	}
}

<#
foreach ($i in $mighosts)
	{
	$tempobject = "" | select hostname, OSversion, Vendor, Model, HBA, Driver, firmware
	$password = Read-host "Enter root password"
	$thishost = ($allhosts | where {$_.name -eq $i})
	$tempobject.hostname = $thishost.name
	$tempobject.osversion = $thishost.summary.config.product.fullname
	$tempobject.HBA = ($thishost.hardware.pcidevice | where {$_.devicename -like "*fibre*"})[0].devicename
	$tempobject.vendor = $thishost.hardware.systeminfo.vendor
	$tempobject.model = $thishost.hardware.systeminfo.model
	$tempobject.firmware = (findhbafirmware $thishost.name $password).firmware
    $tempobject.driver = (findhbafirmware $thishost.name $password).driver
    $tempobject
	$array += $tempobject
	}
    
foreach ($i in $mighosts)
	{
	$tempobject = "" | select hostname, OSversion, Vendor, Model, HBA, Driver, firmware
	#$password = Read-host "Enter root password"
	$thishost = ($allhosts | where {$_.name -eq $i})
	$tempobject.hostname = $thishost.name
	$tempobject.osversion = $thishost.summary.config.product.fullname
	$tempobject.HBA = ($thishost.hardware.pcidevice | where {$_.devicename -like "*fibre*"})[0].devicename
	$tempobject.vendor = $thishost.hardware.systeminfo.vendor
	$tempobject.model = $thishost.hardware.systeminfo.model
	$tempobject.firmware = (findhbafirmwarev51 $thishost.name $password).firmware
    $tempobject.driver = (findhbafirmwarev51 $thishost.name $password).driver
    $tempobject
	$array += $tempobject
	}
#>

CheckforSnapin
ConnecttoVCenter $VCenter

foreach ($i in $mighosts)
{
	$tempobject = "" | select hostname, OSversion, Vendor, Model, HBA, Driver, firmware, ProductVersion
	$thishost = ($allhosts | where {$_.name -eq $i})
	$tempobject.hostname = $thishost.name
	$tempobject.osversion = $thishost.summary.config.product.fullname
	$tempobject.HBA = ($thishost.hardware.pcidevice | where {$_.devicename -like "*fibre*"})[0].devicename
	$tempobject.vendor = $thishost.hardware.systeminfo.vendor
	$tempobject.model = $thishost.hardware.systeminfo.model
	$tempobject.productversion = $thishost.summary.config.product.version
	if ($tempobject.productversion -like "4.1.0" -or $tempobject.productversion -like "4*" -or $tempobject.productversion -like "5*")
	{
		Write-Host "Host OS is: $($tempobject.osversion)"
		$user = Read-host "Enter your admin account name (imswest\) or root for host $i"
		$pw = read-host "Please enter the account password" -assecurestring | ConvertFrom-SecureString | out-file c:\temp\pwenc.ps
		#$password = Read-host "Enter your admin password or the root password"
		$password = get-content c:\temp\pwenc.ps | convertto-securestring
		$credential = New-object -typename System.management.automation.pscredential -argumentlist $user,$password
		$password = $credential.getnetworkcredential().password
		Remove-Item c:\Temp\pwenc.ps -Force
		$tempobject.firmware = (findhbafirmwarev51 $thishost.name $user $password $tempobject.OSversion).firmware
    	$tempobject.driver = (findhbafirmwarev51 $thishost.name $user $password $tempobject.OSversion).driver
    	$tempobject
		$array += $tempobject
	}
	else
	{
		Write-Host "Host OS is: $($tempobject.osversion)"
		$user = "root"
		$pw = read-host "Please enter the root password for host $i" -assecurestring | ConvertFrom-SecureString | out-file c:\temp\pwenc.ps
		#$password = Read-host "Enter your admin password or the root password"
		$password = get-content c:\temp\pwenc.ps | convertto-securestring
		$credential = New-object -typename System.management.automation.pscredential -argumentlist $user,$password
		$password = $credential.getnetworkcredential().password
		Remove-Item c:\Temp\pwenc.ps -Force
		$tempobject.firmware = (findhbafirmware $thishost.name $user $password $tempobject.OSversion).firmware
    	$tempobject.driver = (findhbafirmware $thishost.name $user $password $tempobject.OSversion).driver
    	$tempobject
		$array += $tempobject
	}
}
$array
$array | Export-Csv c:\Temp\hosthbainfo.csv -Force