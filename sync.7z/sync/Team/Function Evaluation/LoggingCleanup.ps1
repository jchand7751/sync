function loggingcleanup
{
	Log "Ending script"
	Remove-Variable global:FullScriptPath
	Remove-Variable global:currentScriptName
	Remove-Variable global:currentExecutingPath
	Remove-Variable global:CurrentScriptEnvironment
	Remove-Variable global:ExecutionTime
	Remove-Variable global:Logpath
}