
function CheckForSnapin
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1,ParameterSetName='Location1')]
		[string]$SnapinName
	)
	$SnapinList = Get-PSSnapin -Registered
	$TestSnapin = $SnapinList | where {$_.name -eq $SnapinName}
	if ($TestSnapin)
	{
		$SnapinRunning = Get-PSSnapin -Name $ModuleName
		if ($SnapinRunning)
		{
			Log "$SnapinName is already loaded"
		}
		else
		{
			Add-PSSnapin -Name $SnapinName	
			Log "$SnapinName has been loaded"
		}
	}
	else
	{
		Write-Warning "The required PSSnapin $SnapinName is not installed"
		Log "$SnapinName is not installed"
		exit
	}
}