﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   2/13/2014 10:18 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Function Set-Logging
{
	$error.clear()
	if ($global:currentExecutingPath.ToLower().contains("beta"))
	{
		$global:CurrentScriptEnvironment = "Beta"
	}	
		elseif ($global:currentExecutingPath.ToLower().contains("development"))
		{
			$global:CurrentScriptEnvironment = "Development"
		}
		elseif ($global:currentExecutingPath.ToLower().contains("production"))
		{
			$global:CurrentScriptEnvironment = "Production"
		}
		else
		{
			$global:CurrentScriptEnvironment = "Undetermined"
		}
	
	if ((Test-Path "$(-join $global:currentExecutingPath[0..((-join ($global:currentExecutingPath[0..($global:currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\") -eq $true)
	{
		Write-Host "Logging folder found, creating file"
		$global:Logpath = "$(-join $global:currentExecutingPath[0..((-join ($global:currentExecutingPath[0..($global:currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\$($CurrentScriptName -replace '.ps1')-$executiontime.log"
		Write-Host "$global:Logpath"
		if ((Test-Path $global:Logpath) -eq $true)
		{
			for ($x = 1 ; $checkit -eq $true ; $x++)
			{
				if (Test-Path ($global:Logpath + "-" + $x) -eq $true)
				{
					$checkit = $false
				}
				else
				{
					$checkit = $true
					$global:Logpath = $global:Logpath + "-" + $x
				}
			}
			
			$x = 0
			do {$global:Logpath = ($global:Logpath).trimend("-$x.log") ; $x++ ; $global:Logpath = ($global:Logpath).trimend(".log") + "-" + "$x.log"}
			until ((Test-Path $global:Logpath) -eq $false)
		}
		else
		{
			New-Item -Type File $global:Logpath -ErrorAction Stop
		}
	}
	else
	{
		Write-Warning "No logging path found, script will NOT be logged"
		$global:Logpath = $null
	}
	Add-LogEntry "Full Script Path: $global:FullScriptPath"
	Add-LogEntry "Current Script Name: $global:currentScriptName"
	Add-LogEntry "Current Script Environment: $global:CurrentScriptEnvironment"
	Add-LogEntry "Script Logpath: $global:Logpath"
	Add-LogEntry "Script Execution Date/Time: $global:ExecutionTime"
	Add-LogEntry "Script Executed By: $Executedby"
	Add-LogEntry ""
	Add-LogEntry "-------------------------------------------------------------------------------------"
	Add-LogEntry ""	
}
