﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.48
	 Created on:   	4/1/2014 12:35 PM
	 Created by:   	Dean Rose 
	 Organization: 	State Street IMS 
	 Filename:     	Connect-vC.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
	Function Connect-vC {
	Param ($Vcenter)
	
		if ($Vcenter) {
			if ($defaultviservers) {
				Disconnect-VIServer * -Confirm:$false
				Connect-VIServer $vcenter
			} else {
				Connect-VIServer $vcenter
			}
		} else {
			Write-Warning "vCenter NOT specified!"
			exit
		}
	}
