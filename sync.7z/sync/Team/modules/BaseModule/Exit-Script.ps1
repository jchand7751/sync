function loggingcleanup
{
	Log "Ending script"
	Remove-Variable FullScriptPath -Scope global
	Remove-Variable currentScriptName -Scope global
	Remove-Variable currentExecutingPath -Scope global
	Remove-Variable CurrentScriptEnvironment -Scope global
	Remove-Variable ExecutionTime -Scope global
	Remove-Variable Logpath -Scope global
	exit
}