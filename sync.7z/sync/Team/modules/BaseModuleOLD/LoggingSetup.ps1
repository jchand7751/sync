﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   2/13/2014 10:18 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Function LoggingSetup
{
	if ($CurrentExecutingPath.indexof("Beta") -ne -1)
	{
		$CurrentScriptEnvironment = "Beta"
	}	
		elseif ($CurrentExecutingPath.indexof("Experimental") -ne -1)
		{
			$CurrentScriptEnvironment = "Experimental"
		}
		elseif ($CurrentExecutingPath.indexof("Production") -ne -1)
		{
			$CurrentScriptEnvironment = "Production"
		}
		else
		{
			$CurrentScriptEnvironment = "Undetermined"
		}
	
	if ((Test-Path "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\") -eq $true)
	{
		Write-Host "Logging folder found, creating file"
		$Logpath = "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\$($CurrentScriptName -replace '.ps1')-$script:executiontime.log"
		New-Item -Type File $Logpath -ErrorAction Stop
	}
	else
	{
		Write-Warning "No logging path found, script will NOT be logged"
		$Logpath = $null
	}
}