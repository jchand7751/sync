﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/24/2013 5:11 PM
# Created by:   z548410
# Organization: SANMigration.ps1
<#
This script is used for the SAN migration project.
A cluster and vcenter need to be specified. 
The script will do the following: 
Connect to specified vcenter
Find the specified cluster
Create an inventory of current VMs and their power states 
Put cluster hosts in maintenance mode
Un-register VMs
Sanity reboot
Shutdown hosts
Pause for storage team to present new storage
Power hosts back on
Import new LUNs
Rename LUNs
Rescan and refresh HBAs on multiple hosts
Search new datastores and re-register VMs and templates
Create a new inventory with new VMIDs
Start VMs that should be powered on
Confirm original inventory to new inventory

#>
#========================================================================
[CmdletBinding()]
Param(
   [Parameter(Mandatory=$true,Position=0)]
   #[ValidateScript({$(Add-PSSnapin VMware.VimAutomation.Core ; Connect-VIserver $_ )})]
   [string]$VCenter = $(if ($VCenter) { Read-Host -prompt "VCenter Server"}),
    
   [Parameter(Mandatory=$true,Position=1)]
   #[ValidateScript({$(Add-PSSnapin VMware.VimAutomation.Core ; Get-Datacenter -name $_ )})]
   [string]$Cluster = $(if ($Cluster) { Read-Host -prompt "Cluster"}
   )
)


function prereqs
{
Param($cluster)
$checkforputty = Test-path "C:\SANMigration\putty\plink.exe"
$checkforiLO = Test-path "C:\SANMigration\iLOtool\cpqlocfg.exe"
$checkforiLOscriptfile = Test-path "C:\SANMigration\iLOtool\Set_Host_Power.xml"
$checkforinstalledupdate = gwmi win32_quickfixengineering | where {$_.hotfixid -like "KB2701373"}
$checkforrawfile = Test-Path "C:\SANMigration\$cluster-rawmappings.csv"
if ($checkforinstalledupdate)
    {
    $checkforinstalledupdate = $true
    }
    else
        {
        $checkforinstalledupdate = $false
        }

switch ($checkforputty)
    {
    "True" {}
    "False" {Write-warning "Putty is missing, exiting" ; exit}
    }
switch ($checkforilo)
    {
    "True" {}
    "False" {Write-warning "ilo tool is missing, exiting" ; exit}
    }
switch ($checkforiloscriptfile)
    {
    "True" {}
    "False" {Write-warning "ilo script file is missing, exiting" ; exit}
    }
switch ($checkforinstalledupdate)
    {
    "True" {}
    "False" {Write-warning "PShell fix is missing, please install it" ; exit}
    }
switch ($checkforrawfile)
    {
    "True" {}
    "False" {Write-warning "RDM csv file is missing, please run LUN script" ; exit}
    }    
}

function CopyReqs
{
$tp = Test-path C:\SANMigration
if ($tp)
    {
    #Remove-item c:\SANMigration -force
	xcopy "\\nasprod\Systems\Common\IT\Technology Operations\Microsoft Server Team\Powershell\Scripts\Beta\SANMigration" c:\SANMigration\ /E /Y
    }
	else
		{
		mkdir c:\SANMigration
		xcopy "\\nasprod\Systems\Common\IT\Technology Operations\Microsoft Server Team\Powershell\Scripts\Beta\SANMigration" c:\SANMigration\ /E
		}
}

Function CheckforSnapin
{
$testsnapin = Get-PSSnapin | where {$_.name -like "VMware.VIM*"}
if ($testsnapin)
    {}
    else
        {
        Add-PSSnapin VMware.VimAutomation.Core
        }
}

Function ConnecttoVCenter
{
Param ($Vcenter)

if ($Vcenter)
	{
	if ($defaultviservers)
    	{
    	Disconnect-VIServer * -Confirm:$false
    	Connect-VIServer $vcenter
    	}
    	else
        	{
        	Connect-VIServer $vcenter
        	}
	}
	else
		{
		Write-Warning "No VCenter specified!"
		exit
		}
}

function SanityReboot
{
if ($script:selectedcluster)
	{
	foreach ($hostsystem in $script:selectedcluster.host)
		{
        $hostdata = Get-View $hostsystem
		Get-VMHost -Id $hostdata.moref | Restart-VMHost -force -RunAsync
        }
    }        
}

function PowerOnHost
{
if ($script:selectedcluster)
	{
	foreach ($hostsystem in $script:selectedcluster.host)
		{
		$password = Read-Host "Enter iLO password"
		$temphostname = ((Get-View $hostsystem).name)
		if ($temphostname)
			{
			$temphostname = "rib-" + ($temphostname -split "\.")[0] + ".ims.ilo"
				$temphostname
			#."C:\Program Files (x86)\HP\HP Lights-Out Configuration Utility\cpqlocfg.exe" -servername $temphostname -u administrator -p $password -f C:\local\iLOsamplescripts4.00.0\Get_Host_Power.xml
			."C:\SANMigration\iLOTool\cpqlocfg.exe" -servername $temphostname -u administrator -p $password -f C:\SANMigration\iLOTool\Set_Host_Power.xml
			}
			else
				{
				Write-Warning "Couldn't find host!"
				Exit
				}
		}
	}
	else
		{
		Write-Warning "Selected cluster not found!"
		exit
		}
}
	
function FindCluster
{
Param($cluster)
$allclusters = Get-View -ViewType clustercomputeresource
$script:selectedcluster = $allclusters | Where-Object {$_.name -eq $cluster}
}

function reattachRAW
{
$rawidentifiers = import-csv c:\sanmigration\$cluster-rawmappings.csv | where {$_.rawmappedto -notlike $null}
foreach ($hostsystem in $script:selectedcluster.host[0])
    {
    $lunhost = Get-VMHost -id $hostsystem 
    foreach ($rawdev in $rawidentifiers)
        {
        $vm = $rawdev.rawmappedto
        $identifier = $rawdev.identifier
        $lun = $rawdev.lun
        #$disktype = $rawdev.disktype
        $disktype = "RawVirtual"
        Write-host "Mapping lun $lun with identifier $identifier to $vm"
        $deviceName = ($lunhost | Get-ScsiLun | Where {$_.CanonicalName -eq $identifier}).ConsoleDeviceName
        New-HardDisk -VM $vm -DiskType $disktype -DeviceName $deviceName #-whatif
        }
    }
}
	
function removeRAWs
{
if ($script:selectedcluster)
	{
	foreach ($hostsystem in $selectedcluster.host)
		{
		$vmsonhost = (Get-View $hostsystem).vm
		foreach ($vm in $vmsonhost)
			{
			$vmstat = Get-View $vm
			$RawVirtualdisks = get-vm -id $vmstat.moref | get-harddisk -DiskType RawVirtual
            $RawPhysicaldisks = get-vm -id $vmstat.moref | get-harddisk -DiskType RawPhysical
 			if ($RawVirtualDisks)
                {
                foreach ($disk in $RawVirtualdisks)
                    {
                    write-host "Removing RawVirtual disk $($disk.name) from VM $($disk.parent)"
                    $disk | Remove-harddisk #-whatif
                    }
                }
            if ($RawPhysicalDisks)
                {    
                foreach ($disk in $RawPhysicaldisks)
                    {
                    write-host "Removing RawPhysical disk $($disk.name) from VM $($disk.parent)"
                    $disk | Remove-harddisk #-whatif
                    }
                }    
            }
		}
	}
	else
		{
		Write-Warning "Selected cluster not found"
		exit
		}
}    
    
function VMdetails
{
$script:vminfoarray = @()
if ($script:selectedcluster)
	{
	foreach ($hostsystem in $selectedcluster.host)
		{
		$vmsonhost = (Get-View $hostsystem).vm
		foreach ($vm in $vmsonhost)
			{
			$tempobject = "" | select ClusterName, HostName, VMName, VMstatus, VMID, ToolsStatus
			$vmstat = Get-View $vm
			$tempobject.clustername = $cluster
			$tempobject.hostname = (Get-View $vmstat.runtime.host).name
			$tempobject.VMname = $vmstat.name
			$tempobject.vmstatus = $vmstat.runtime.powerstate
			$tempobject.VMID = [string]($vmstat.moref)
            $tempobject.ToolsStatus = $vmstat.toolsstatus
            #$RawVirtualdisks = get-vm -id $vmstat.moref | get-harddisk -DiskType RawVirtual
            #$RawPhysicaldisks = get-vm -id $vmstat.moref | get-harddisk -DiskType RawPhysical
            #$tempobject.rawdisks =
			$tempobject
			$script:vminfoarray += $tempobject
			}
		}
	}
	else
		{
		Write-Warning "Selected cluster not found"
		exit
		}
}

function ShutdownVMs
{
foreach ($vm in $script:vminfoarray)
	{
	Write-Host "Shutting down $($vm.vmname)"
	Get-VM -Id $vm.vmid | Shutdown-VMGuest -Confirm:$false -ErrorAction SilentlyContinue #-WhatIf
	}
}

function PutHostsinMaintenance
{
if ($script:selectedcluster)
	{
	foreach ($hostsystem in $script:selectedcluster.host)
		{
		$hostdata = Get-View $hostsystem
		Get-VMHost -Id $hostdata.moref | Set-VMHost -State Maintenance -RunAsync
		}
	}
	else
		{
		Write-Warning "Selected cluster not found!"
		exit
		}
}

function ShutdownHost
{
if ($script:selectedcluster)
	{
	foreach ($hostsystem in $script:selectedcluster.host)
		{
		$hostdata = Get-View $hostsystem
		Get-VMHost -Id $hostdata.moref | Stop-VMHost -Confirm:$false -RunAsync
		}
	}	
	else
		{
		Write-Warning "Selected cluster not found!"
		exit
		}	
}

function powerVMsbackon
{
$needpowerVMs = ($script:vminfoarrayoriginalstate | where {$_.vmstatus -eq "poweredOn"})
foreach ($powervms in $needpowerVMs)
	{
	$newvmid = ($script:vminfoarray | where {$_.vmname -eq $powervms.vmname}).vmid
	Get-VM -Id $newvmid | Start-VM -ErrorAction SilentlyContinue
    Get-VM -Id $newvmid | Get-VMQuestion | Set-VMQuestion -Option “I moved it” -Confirm:$false
	#write-host "Starting vmid $($newvmid)"	
	}	
}

function powerVMsbackon35
{
$needpowerVMs = ($script:vminfoarrayoriginalstate | where {$_.vmstatus -eq "poweredOn"})
foreach ($powervms in $needpowerVMs)
	{
	$newvmid = ($script:vminfoarray | where {$_.vmname -eq $powervms.vmname}).vmid
	Get-VM -Id $newvmid | Start-VM -ErrorAction SilentlyContinue
    Get-VM -Id $newvmid | Get-VMQuestion | Set-VMQuestion -Option “Create” -Confirm:$false
	#write-host "Starting vmid $($newvmid)"	
	}	
}

function UnRegisterVMs
{
if ($script:vminfoarrayoriginalstate)
	{
	foreach ($unregvm in $script:vminfoarrayoriginalstate)
		{
        write-host "Unregistering VM $($vmunreg.name)"
		$vmunreg = Get-View $unregvm.vmid
        $vmunreg.unregistervm()
		}
	}
	else
		{
		Write-Warning "Original state variable is missing"
		exit
		}
}


function UnmountDatastores
{
.\plink.exe -pw "#g****" root@inv000lu1.imswest.ssims.com esxcfg-volume -l
	
.\plink.exe -pw "#g*****" root@inv000lu1.imswest.sscims.com esxcli storage filesystem unmount -l Oracle-Lab-SAN1

esxcli corestorage claimrule add --rule 192 –t location –A vmhba1 –L 1 –P MASK_PATH
esxcli corestorage claimrule add --rule 193 –t location –A vmhba0 –L 1 –P MASK_PATH

esxcli corestorage claimrule load
esxcli corestorage claimrule list

esxcli corestorage claiming reclaim –d naa.ID

esxcli corestorage claimrule delete --rule 192
esxcli corestorage claimrule load
	
}

function GetClusterversion
{
foreach ($hostsystem in $script:selectedcluster.host[0])
	{
	$hostdata = Get-View $hostsystem
    $hostpw = Read-host "Enter root password for $($hostdata.name)"
    #-batch
    
    $checkforSSHrunning = Get-VMHostService -VMHost $hostdata.name | where {$_.key -eq "TSM-SSH"}
    if ($checkforsshrunning.running -eq $false)
        {
        $checkforsshrunning | start-vmhostservice
        }
    
    $testconnection = C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) echo test
    if ($testconnection -ne "test")
        {
        Write-warning "SSH test was unsuccessful, please check password and SSH service"
        GetClusterVersion
        }
    $script:clusterversion = C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) vmware -v
    $script:clusterversion = ($script:clusterversion -split " build*")[0]
    }        
}

function ReAddandSignatureLuns
{
foreach ($hostsystem in $script:selectedcluster.host[0])
	{
	$hostdata = Get-View $hostsystem
    $hostpw = Read-host "Enter root password for $($hostdata.name)"
    #-batch
    
    $checkforSSHrunning = Get-VMHostService -VMHost $hostdata.name | where {$_.key -eq "TSM-SSH"}
    if ($checkforsshrunning.running -eq $false)
        {
        $checkforsshrunning | start-vmhostservice
        }
    
    $testconnection = C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) echo test
    if ($testconnection -ne "test")
        {
        Write-warning "SSH test was unsuccessful, please check password and SSH service"
        ReAddandSignatureLuns
        }
        else
            {
            $getUUID = C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) esxcfg-volume -l
        	$numberofdatastores = $getUUID.length
        	for ($x=0; $x -lt $numberofdatastores ; $x = $x + 5) 
        		{
        		$uuid= (($getUUID[$x] -replace "VMFS3 UUID/label: ") -split "/")[0]
        		C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) esxcfg-volume -r $uuid
        		} 
        	#$uuid= (($getUUID[0] -replace "VMFS3 UUID/label: ") -split "/")[0]
        	#$uuid
        	
        	#Get-VMHost -Id $hostdata.moref | Get-VMHostStorage -RescanAllHba
            }
	}
}

function ReAddandSignatureLuns35
{
foreach ($hostsystem in $script:selectedcluster.host[0])
	{
	$hostdata = Get-View $hostsystem
    $hostpw = Read-host "Enter root password for $($hostdata.name)"
    #-batch
    
    $checkforSSHrunning = Get-VMHostService -VMHost $hostdata.name | where {$_.key -eq "TSM-SSH"}
    if ($checkforsshrunning.running -eq $false)
        {
        $checkforsshrunning | start-vmhostservice
        }
    
    $testconnection = C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) echo test
    if ($testconnection -ne "test")
        {
        Write-warning "SSH test was unsuccessful, please check password and SSH service"
        ReAddandSignatureLuns
        }
        else
            {
            #$getUUID = C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) esxcfg-volume -l
        	C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) "echo '1' > /proc/vmware/config/LVM/EnableResignature"

            C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) vmkfstools -V
            
            C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) "echo '0' > /proc/vmware/config/LVM/EnableResignature"
            
            C:\SANMigration\Putty\plink.exe -pw $hostpw root@$($hostdata.name) vmkfstools -V

            }
	}
}

function RenameDatastores
{
if (($script:selectedcluster.host.count) -gt "1")
    {
    #foreach ($hostsystem in $script:selectedcluster.host[1])
	foreach ($hostsystem in $script:selectedcluster.host)	
        {
        $hostdata = Get-view $hostsystem
        Get-VMHost -Id $hostdata.moref | Get-VMHostStorage -RescanAllHba
        Get-VMHost -Id $hostdata.moref | Get-VMHostStorage -Refresh
        }
    }  
    
foreach ($hostsystem in $script:selectedcluster.host[0])
	{
	$hostdata = Get-View $hostsystem
    ##change me ##
    #Get-VMHost -Id $hostdata.moref | Get-VMHostStorage -RescanAllHba
	#$getsnapDSnames = (Get-VMHost -Id $hostdata.moref | Get-Datastore) | where {$_.name -notlike "*local*"}	
	Get-VMHost -Id $hostdata.moref | Get-VMHostStorage -Refresh
    $getsnapDSnames = (Get-VMHost -Id $hostdata.moref | Get-Datastore) | where {$_.extensiondata.summary.multiplehostaccess -eq $true}
    foreach ($i in $getsnapDSnames)
		{
		$remove = "snap" + "-" + (($i.name -split "-")[1]) + "-"
		$rename = $i.name -replace $remove
		$ConfirmRename = Read-Host "Renaming $($i.name) to $rename (y/n)"
		switch($ConfirmRename)
			{
			"y"	{Get-Datastore -name $i.name | Set-Datastore -Name $rename -confirm:$false}
			"n"	{
				Write-Host "No selected"
				$rename = Read-Host "Type the name you want to use for datastore $($i.name)"
				Get-Datastore -name $i.name | Set-Datastore -Name $rename -confirm:$false
				}
			Default {RenameDatastores}	
			}
		}	
	}
}

function TakeHostsOutofMaintenance
{
foreach ($hostsystem in $script:selectedcluster.host)
	{
	$hostdata = Get-View $hostsystem
	Get-VMHost -Id $hostdata.moref | Set-VMHost -State Connected -RunAsync #-WhatIf
	}
}

function Register-VMX {
  param($entityName = $null,$dsNames = $null,$template = $false,$ignore = $null,$checkNFS = $false,$whatif=$false)
 
  function Get-Usage{
    Write-Host "Parameters incorrect" -ForegroundColor red
    Write-Host "Register-VMX -entityName  -dsNames [,...]"
    Write-Host "entityName   : a cluster-, datacenter or ESX hostname (not together with -dsNames)"
    Write-Host "dsNames      : one or more datastorename names (not together with -entityName)"
    Write-Host "ignore       : names of folders that shouldn't be checked"
    Write-Host "template     : register guests ($false)or templates ($true) - default : $false"
    Write-Host "checkNFS     : include NFS datastores - default : $false"
    Write-Host "whatif       : when $true will only list and not execute - default : $false"
  }
 
  if(($entityName -ne $null -and $dsNames -ne $null) -or ($entityName -eq $null -and $dsNames -eq $null)){
    Get-Usage
    break
  }
 
  if($dsNames -eq $null){
    switch((Get-Inventory -Name $entityName).GetType().Name.Replace("Wrapper","")){
      "Cluster"{
        #$dsNames = Get-Cluster -Name $entityName | Get-VMHost | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | % {$_.Name}
		Write-Warning "Option not supported"
		Exit
      }
      "Datacenter"{
        #$dsNames = Get-Datacenter -Name $entityName | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | % {$_.Name}
		Write-Warning "Option not supported"
		Exit		
      }
      "VMHost"{
        #$dsNames = Get-VMHost -Name $entityName | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | % {$_.Name}
		Write-Warning "Option not supported"
		Exit		
      }
      Default{
        Get-Usage
        exit
      }
    }
  }
  else{
    $dsNames = Get-Datastore -Name $dsNames | where {$_.Type -eq "VMFS" -or $checkNFS} | Select -Unique | % {$_.Name}
  }
 
  $dsNames = $dsNames | Sort-Object
  $pattern = "*.vmx"
  if($template){
    $pattern = "*.vmtx"
  }
 
  foreach($dsName in $dsNames){
    Write-Host "Checking: " -NoNewline; Write-Host -ForegroundColor yellow $dsname
    $ds = Get-Datastore $dsName | Select -Unique | Get-View
    $dsBrowser = Get-View $ds.Browser
    $dc = Get-View $ds.Parent
    while($dc.MoRef.Type -ne "Datacenter"){
      $dc = Get-View $dc.Parent
    }
    $tgtfolder = Get-View $dc.VmFolder
    $esx = Get-View $ds.Host[0].Key
    $pool = Get-View (Get-View $esx.Parent).ResourcePool
 
    $vms = @()
    foreach($vmImpl in $ds.Vm){
      $vm = Get-View $vmImpl
      $vms += $vm.Config.Files.VmPathName
    }
    $datastorepath = "[" + $ds.Name + "]"
 
    $searchspec = New-Object VMware.Vim.HostDatastoreBrowserSearchSpec
    $searchspec.MatchPattern = $pattern
 
    $taskMoRef = $dsBrowser.SearchDatastoreSubFolders_Task($datastorePath, $searchSpec)
 
    $task = Get-View $taskMoRef
    while ("running","queued" -contains $task.Info.State){
      $task.UpdateViewData("Info.State")
    }
    $task.UpdateViewData("Info.Result")
    foreach ($folder in $task.Info.Result){
      if(!($ignore -and (&{$res = $false; $folder.FolderPath.Split("]")[1].Trim(" /").Split("/") | %{$res = $res -or ($ignore -contains $_)}; $res}))){
        $found = $FALSE
        if($folder.file -ne $null){
          foreach($vmx in $vms){
            if(($folder.FolderPath + $folder.File[0].Path) -eq $vmx){
              $found = $TRUE
            }
          }
          if (-not $found){
            if($folder.FolderPath[-1] -ne "/"){$folder.FolderPath += "/"}
            $vmx = $folder.FolderPath + $folder.File[0].Path
            if($template){
              $params = @($vmx,$null,$true,$null,$esx.MoRef)
            }
            else{
              $params = @($vmx,$null,$false,$pool.MoRef,$null)
            }
            if(!$whatif){
              $taskMoRef = $tgtfolder.GetType().GetMethod("RegisterVM_Task").Invoke($tgtfolder, $params)
              Write-Host "`t" $vmx "registered"
            }
            else{
              Write-Host "`t" $vmx "registered" -NoNewline; Write-Host " ==> What If"
            }
          }
        }
      }
    }
    Write-Host "All VMs have been registered"
  }
}

function RegisterVMs
{
foreach ($hostsystem in $script:selectedcluster.host[0])
	{
	$hostdata = Get-View $hostsystem
    ##change me ##
	#$getrealDSnames = (Get-VMHost -Id $hostdata.moref | Get-Datastore) | where {$_.extensiondata.summary.multiplehostaccess -eq $true}	
	$getrealDSnames = (Get-VMHost -Id $hostdata.moref | Get-Datastore)
    foreach ($DatastoreRenamed in $getrealDSnames)
		{
		Register-VMX -dsnames $DatastoreRenamed.name #-whatif:$true
		Register-VMX -dsnames $DatastoreRenamed.name -template:$true #-whatif:$true 
		}
	}
}


################# Execution ################################
function Execution
{
}

#Copy files from share to local machine
CopyReqs

#Check to make sure everything is good
PreReqs $cluster

#Load Vmware modules
CheckforSnapin

#Connect to VCenter
ConnecttoVCenter $VCenter

#Get the selected cluster
FindCluster $cluster

#Get the details of all the VMs
VMDetails

#Load a script array with the power state and details of the original VMs
$script:vminfoarrayoriginalstate = $script:vminfoarray
$script:vminfoarrayoriginalstate | export-csv c:\SANMigration\$cluster-VMInfoOriginalState.csv
$script:vminfoarray | export-csv c:\SANMigration\$cluster-VMInfoArray.csv

Read-host "VMDetails should be exported in c:\temp"

Shutdown the VMs
ShutdownVMs

Read-host "VMs should be shutdown"

#Loop the details until all the VMs are shutdown
$counter = 0
do {VMDetails ; $counter++ ; $counter}
	until (($CheckforPoweredonVMs = ($script:vminfoarray | where {$_.vmstatus -eq "PoweredOn"})) -eq $null)

#Remove raw LUNs
removeRAWs

Read-host "All Raw devices should be removed"

#Put the hosts in maintenance mode
PutHostsinMaintenance

Read-host "Hosts should be in maintenance"

#Sanity reboot
SanityReboot

Read-host "Please verify sanity reboot. (Luns etc.)"


#Unregister VMs
UnRegisterVMs

Read-host "VMs should be unregistered"

#Unmount the datastores


#Shutdown the hosts
ShutdownHost

#Wait for user response to power hosts back on
Read-Host "Pausing until Storage is zoned and ready, press enter once ready"

#Power hosts back on
PowerOnHost

#Waiting again for hosts to fully come up
Read-Host "Waiting until hosts are fully powered on, press enter once ready"

#Determine version
GetClusterVersion

#Load and resignature the new datastores
Switch($script:clusterversion)
    {
    "VMware ESX Server 3.5.0" {ReAddandSignatureLuns35}
    "VMware ESXi 4.1.0" {ReAddandSignatureLuns}
    "VMware ESX 4.1.0" {ReAddandSignatureLuns}
    }

Read-host "Disks should be resignatured"

#Rename the datastores
RenameDatastores

Read-host "Datastores should be renamed"

#Exit maintenance mode
TakeHostsOutofMaintenance

Read-host "Hosts should exit Maintenance"

#Register the VMs
RegisterVMs

Read-host "VMs should be re-registered"

#Waiting for VMs to register
Read-host "Press enter when all VMs have registered"

#Get the details of all the VMs because their IDs have changed
VMDetails
$script:vminfoarray | export-csv c:\SANMigration\$cluster-VMInfoArray-NewIDs.csv

Read-host "VMs should be exported newIDs"

#Attach raw luns per exported csv for the cluster
ReattachRaw

Read-host "VMs should have RAW luns re-attached"

#Power on the VMs and answer move question
Switch($script:clusterversion)
    {
    "VMware ESX Server 3.5.0" {powerVMsbackon35}
    "VMware ESXi 4.1.0" {powerVMsbackon}
    "VMware ESX 4.1.0" {powerVMsbackon}
    }


Read-host "VMs should be back online"

#Check status
VMDetails
compare $script:vminfoarrayoriginalstate $script:vminfoarray


################ End Execution ##############################




