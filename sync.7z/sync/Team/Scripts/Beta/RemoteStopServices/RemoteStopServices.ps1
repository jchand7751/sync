﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   2/27/2014 2:22 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param ($computername)
Import-Module BaseModule2

#Define environment information
$global:FullScriptPath = $MyInvocation.MyCommand.Definition
$global:CurrentScriptName = $MyInvocation.MyCommand.Name
$global:CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$global:ExecutionTime = logstamp -file
$Executedby = whoami
LoggingSetup


#Test connection to server
$testcon = Test-Connection -ComputerName $computername -Quiet -Count 1
if ($testcon)
	{}
else
{
	Write-Warning "$computername is offline"
	Log "$computername is offline"
	exit
}

#Determine OS
$OSversion = (gwmi win32_operatingsystem -ComputerName $computername).caption

#Get golden service list
switch ($OSversion)
{
	"Microsoft Windows Server 2008 R2 Enterprise" 
	{
		$testpath = Test-Path c:\Temp\goldenservices2008r2.csv
		if ($testpath) 
		{
			$goldenservicelist = Import-Csv c:\Temp\goldenservices2008r2.csv
		} 
		else 
		{
			Write-Warning "Golden service list not found"
			Log "Golden service list not found"
		}
	}
	"Microsoft(R) Windows(R) Server 2003, Standard Edition" 
	{
		$testpath = Test-Path c:\Temp\goldenservices2003.csv
		if ($testpath) 
		{
			$goldenservicelist = Import-Csv c:\Temp\goldenservices2003.csv
		} 
		else 
		{
			Write-Warning "Golden service list not found"
			Log "Golden service list not found"
		}
	}
	default {Write-Warning "OS could not be determined on $computername" ; Log "OS could not be determined on $computername" ; exit}
}


#loop through server service list and stop anything that doesn't match a name in the golden list

#Get servers service list
$findservices = get-service -comp $Computername | where {$_.status -eq "Running"}

$shutdownservices = compare $goldenservicelist $findservices -Property servicename | where {$_.sideindicator -eq "=>"}

if ($shutdownservices)
{
	foreach ($service in $shutdownservices)
	{
		#stop-service -inputobject $findservice
		#Get-Service -ComputerName $computername -ServiceName $service.servicename
		#Stop-Service $service.servicename -ErrorVariable $err
		Log "Attempting to stop $($service.servicename) on $computername"
		Stop-Service -InputObject $(Get-Service -ComputerName $computername -ServiceName $($service.servicename)) -ErrorVariable $err -WhatIf
		if ($err)
		{
			Write-Warning "$($service.servicename) failed to stop on $computername with the following error: $($err.exception)"
			Log "$($service.servicename) failed to stop on $computername with the following error: $($err.exception)"
		}
		else
		{
			Write-Host "$($service.servicename) stopped successfully"
			Log "Service $($service.servicename) stopped successfully"
		}
	}
}
else
{
	Write-Warning "No application services found $computername"
	Log "No application services found on $computername"
}

#Closing cleanup
Log "Ending script"
Remove-Variable global:FullScriptPath
Remove-Variable global:currentScriptName
Remove-Variable global:currentExecutingPath
Remove-Variable global:CurrentScriptEnvironment
Remove-Variable global:ExecutionTime
Remove-Variable global:Logpath