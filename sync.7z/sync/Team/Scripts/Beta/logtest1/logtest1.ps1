﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   1/10/2014 11:15 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

Add-PSSnapin Quest.ActiveRoles.ADManagement
Function logstamp {
	#returns a padded timestamp string like 200705231132
	$now=Get-Date
	$yr=$now.Year.ToString()
	$mo=$now.Month.ToString()
	$dy=$now.Day.ToString()
	$hr=$now.Hour.ToString()
	$mi=$now.Minute.ToString()
	
	if ($mo.length -lt 2) {
	$mo="0"+$mo #pad single digit months with leading zero
	}
	
	if ($dy.length -lt 2) {
	$dy="0"+$dy #pad single digit day with leading zero
	}
	
	if ($hr.length -lt 2) {
	$hr="0"+$hr #pad single digit hour with leading zero
	}
	
	if ($mi.length -lt 2) {
	$mi="0"+$mi #pad single digit minute with leading zero
	}
	
	write-output $yr$mo$dy$hr$mi
}

function Log {
	param([string]$filename,[string]$text)
	if ($filename)
	{
		Out-File $filename -append -noclobber -inputobject "$(Invoke-Expression logstamp) - $text" -encoding ASCII
	}
}


Function LoggingSetup
{
	if ($CurrentExecutingPath.indexof("Beta") -ne -1)
	{
		$Script:CurrentScriptEnvironment = "Beta"
	}	
		elseif ($CurrentExecutingPath.indexof("Experimental") -ne -1)
		{
			$Script:CurrentScriptEnvironment = "Experimental"
		}
		elseif ($CurrentExecutingPath.indexof("Production") -ne -1)
		{
			$Script:CurrentScriptEnvironment = "Production"
		}
		else
		{
			$Script:CurrentScriptEnvironment = "Undetermined"
		}
	
	if ((Test-Path "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\") -eq $true)
	{
		Write-Host "Logging folder found, creating file"
		$Script:Logpath = "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\$($CurrentScriptName -replace '.ps1')-$script:executiontime.log"
		New-Item -Type File $Script:Logpath -ErrorAction Stop
	}
	else
	{
		Write-Warning "No logging path found, script will NOT be logged"
		$Script:Logpath = $null
	}
}

function ExampleofLogging
{
	Connect-QADService imswest.sscims.com | Out-Null
	Log $script:Logpath "Connecting to AD"
	Get-QADUser -SamAccountName z548410 | Out-Null
	Log $script:Logpath "Getting User"
}

#Define environment information
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$Script:ExecutionTime = logstamp
LoggingSetup
Write-Host ""
Write-Host ""
Write-Host "Full Script Path: "$FullScriptPath
Write-Host "Current Script Name: "$currentScriptName
Write-Host "Current Executing Path: "$currentExecutingPath
Write-Host "Current Script Environment: "$CurrentScriptEnvironment
Write-Host "Script Execution Date/Time: "$script:ExecutionTime
Write-Host "Script Logpath: "$script:Logpath
Write-Host ""
Write-Host "-------------------------------------------------------------------------------------"
Write-Host ""
Write-Host ""
ExampleofLogging

