﻿	<#
	.SYNOPSIS
	Script to restart service on Windows server.

	.DESCRIPTION
	Script to restart service on Windows server.

	.PARAMETER
	Domain		The domain the Windows server is located in.
	Computer	The Windows server to reatart the service on.
	Service		The service to be restarted.

	.EXAMPLE
	PS> RestartService.ps1 -Computer <server> -Name <service name>
	#>
[CmdletBinding()]
Param(
	[Parameter(Mandatory=$true,Position=0)]
	[string]$Domain,
	[Parameter(Mandatory=$true,Position=1)]
	[string]$Computer,
	[Parameter(Mandatory=$true,Position=2)]
	[string]$Service
)

[Void] ([Reflection.Assembly]::LoadWithPartialName("System.ServiceProcess"))

$domainResult = ""
$computerResult = ""
$testResult = ""
$serviceResult = ""
$Error = ""

Write-Host ""

# Change to proper domain
try {
	$domainResult = Connect-QADService -Service $Domain -ErrorAction Stop
}
catch [System.Management.Automation.ItemNotFoundException] {
	Write-Host -ForegroundColor Red 'ItemNotFound'
	Write-Host -ForegroundColor Red ($Domain + " is not a valid domain name.")
	Write-Host ""
}

# Get-QADService successful.  Display Domain Name.
Write-Host -ForegroundColor Gray $domainResult.Domain
Write-Host -ForegroundColor Gray "Domain is valid."
Write-Host ""

# Check for server to exist in A.D.
try {
	$computerResult = Get-QADComputer -Identity $Computer -ErrorAction Stop
}
catch [System.Management.Automation.ItemNotFoundException] {
	Write-Host -ForegroundColor Red 'ItemNotFound'
	Write-Host -ForegroundColor Red ($Computer + " is not in Active Directory.")
	Write-Host ""
}

# Get-ADComputer successful.  Display DNS Host Name.
Write-Host -ForegroundColor Blue $computerResult.DNSHostName
Write-Host -ForegroundColor Blue "Server exists in Active Directory."
Write-Host ""

# Check for server to be running and accessible.
$testResult = Test-Connection -ComputerName $computerResult.DNSHostName -Count 1 -BufferSize 16 -Quiet
if ($testResult -match 'True') {
	Write-Host -ForegroundColor Green $computerResult.DNSHostName
	Write-Host -ForegroundColor Green "Server is accessible."
	Write-Host ""

	# Check for service to be on server.
	try {
		$serviceResult = Get-Service -ComputerName "$Computer" -Name "$Service" -ErrorAction Stop
	}
	catch [System.Management.Automation.ItemNotFoundException] {
		Write-Host -ForegroundColor Red 'ItemNotFound'
		Write-Host -ForegroundColor Red ("Service '" + $Service + "' does not exist on " + $Computer + ".")
		Write-Host ""
	}
	
	if (($serviceResult.Status -eq "Stopped") -or ($serviceResult.Status -eq "Running")) {
		# Restart service if running.
		#Restart-Service -InputObject $(Get-Service -ComputerName $Computer -Name $Service)
		Write-Host -ForegroundColor Cyan ("Service '" + $Service + "' was found in a '" + $serviceResult.Status + "' state.")
		Write-Host -ForegroundColor Cyan ("Service '" + $Service + "' is restarting.")
		Write-Host ""
		try {
			Restart-Service -InputObject $(Get-Service -ComputerName $Computer -Name $Service)
		}
		catch [System.Management.Automation.ItemNotFoundException] {
			Write-Host -ForegroundColor Red 'ItemNotFound'
			Write-Host -ForegroundColor Red ("Service '" + $Service + "' could not be found.")
			Write-Host ""
		}
		catch [System.Management.Automation.SessionStateException] {
			Write-Host -ForegroundColor Red 'SessionState'
			Write-Host -ForegroundColor Red ("Service '" + $Service + "' is in a bad session state.")
			Write-Host ""
		}
		catch [System.Management.Automation.RuntimeException] {
			Write-Host -ForegroundColor Red 'Runtime'
			Write-Host -ForegroundColor Red ("Service '" + $Service + "' is in a bad runtime.")
			Write-Host ""
		}
		catch [System.Exception] {
			Write-Host -ForegroundColor Red 'Exception'
			Write-Host -ForegroundColor Red ("Service '" + $Service + "' had an exception.")
			Write-Host ""
		}

<#		catch {
			if ($Error[0].Exception -match "Microsoft.PowerShell.Commands.ServiceCommandException") {
				Write-Host -ForegroundColor Red 'System.InvalidOperationException'
				Write-Host -ForegroundColor Red ("Service '" + $Service + "' cannot be stopped.")
				Write-Host ""
			} elseif ($Error[0].Exception -match "Microsoft.PowerShell.Commands.ServiceOperationBaseCommand") {
				Write-Host -ForegroundColor Red 'System.InvalidOperationException'
				Write-Host -ForegroundColor Red ("Service '" + $Service + "' cannot be stopped.")
				Write-Host ""
			} elseif ($Error[0].Exception -match "Microsoft.PowerShell.Commands.RestartServiceCommand") {
				Write-Host -ForegroundColor Red 'System.InvalidOperationException'
				Write-Host -ForegroundColor Red ("Service '" + $Service + "' cannot be stopped.")
				Write-Host ""
			} elseif ($Error[0].Exception -match "System.ServiceProcess.ServiceController") {
				Write-Host -ForegroundColor Red 'System.InvalidOperationException'
				Write-Host -ForegroundColor Red ("Service '" + $Service + "' cannot be stopped.")
				Write-Host ""
			}
		}
#>
		finally {
			if ($Error -ne "") {
				Write-Host ("Error code is " + $Error[0].Exception)
			}
		}
		
	} else {
		# Service is not running or stopped.  Show current status of service and exit.
		Write-Host -ForegroundColor Yellow ("Service '" + $Service + "' is not running or stopped.")
		Write-Host -ForegroundColor Yellow ("Service '" + $Service + "' status is '" + $serviceResult.Status + "'.")
		Write-Host -ForegroundColor Yellow "Nothing will be done.  Exiting script."
		Write-Host ""
	}

} else {
	Write-Host -ForegroundColor Yellow $computerResult.DNSHostName
	Write-Host "Server is not accessible."
	Write-Host ""
}

