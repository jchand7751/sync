﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/28/2015 1:24 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   	windowsinit.ps1  	
	===========================================================================
	.DESCRIPTION
		Cliqr Windows Init Script.
#>
#Import Modules
Import-module BitsTransfer
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

#Environment Setup
$logfile = "C:\temp\CliqrInitLog.txt"
$server = hostname
$key = 203, 117, 112, 91, 119, 165, 146, 173, 140, 253, 20, 134, 174, 241, 213, 16
$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString -Key $key)
$credential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
$cliqrvars = Get-Content C:\temp\userenv.ps1
$clientrb = "C:\chef\client.rb"
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrresumefile = "C:\Program Files\Osmosix\.cliqrRebootResumeInit"
$reposource = "http://10.155.5.63:8080/"
#$deploymentenv = ((($cliqrvars | foreach { $_ } | where { $_ -like '$env:cliqrdepenvname*' }) -split "=")[1] -replace "'", "") -replace ";"
#$runlist = ((($cliqrvars | foreach { $_ } | where { $_ -like '$env:runlist*' }) -split "=")[1] -replace "'", "") -replace ";"

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

function Executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if (Test-Path $logfile -ne $true)
	{
		New-Item -ItemType File $logfile -Force
	}
}

function CheckNetwork
{
	#check for the network
	Add-Content -Path $logfile "$(executiontime) - Network info:"
	agentSendLogMessage "$(executiontime) - Network info:"
	$ipaddress = (Get-NetIPAddress -InterfaceAlias ethernet1 -AddressFamily ipv4 -ea SilentlyContinue).ipaddress
	$dns = [string]((Get-NetIPConfiguration -ea SilentlyContinue).dnsserver | where { $_.addressfamily -eq "2" }).serveraddresses
	Add-Content -Path $logfile "$(executiontime) - IP: $ipaddress"
	agentSendLogMessage "$(executiontime) - IP: $ipaddress"
	Add-Content -Path $logfile "$(executiontime) - DNS: $dns"
	agentSendLogMessage "$(executiontime) - DNS: $dns"
	do
	{
		sleep 5
		$ipaddress = (Get-NetIPAddress -InterfaceAlias ethernet1 -AddressFamily ipv4 -ea SilentlyContinue).ipaddress
		if ($ipaddress -notlike "10.155.*")
		{
			Add-Content -Path $logfile "$(executiontime) - Seems like we don't have an IP yet"
			agentSendLogMessage "$(executiontime) - Seems like we don't have an IP yet"
		}
		else
		{
			Add-Content -Path $logfile "$(executiontime) - Network setup complete"
			agentSendLogMessage "$(executiontime) - Network setup complete"
			$ippass = $true
		}
	}
	until ($ippass -eq $true)
}

function LoadCliqrEnvVariables
{
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocation
		sleep 1
		$counter++
		Add-Content -Path $logfile "$(executiontime) - Checking for User Environment file"
		agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 5
	)
	
	if ($counter -ge 5)
	{
		Add-Content -Path $logfile "$(executiontime) - Didn't find user environment file"
		agentSendLogMessage "$(executiontime) - Didn't find user environment file"
	}
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

function TestConnectivity
{
	if ((Test-Connection core.pimcocloud.net -count 1 -Quiet) -ne $true)
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to ping domain"
		agentSendLogMessage "$(executiontime) - Failed to ping domain"
		Add-Content -Path $logfile "$(executiontime) - $error[0]"
		agentSendLogMessage "$(executiontime) - $error[0]"
	}
	else
	{
		Add-Content -Path $logfile "$(executiontime) - Unable to resolve core.pimcocloud.net"
		agentSendLogMessage "$(executiontime) - Unable to resolve core.pimcocloud.net"
	}
}

function PartitionDisks
{
	Get-Disk -Number 1 | New-Partition -Driveletter "E" -UseMaximumSize | Format-Volume -FileSystem NTFS -confirm:$false -Force
	Get-Disk -Number 2 | New-Partition -Driveletter "L" -UseMaximumSize | Format-Volume -FileSystem NTFS -confirm:$false -Force
}

function JoinDomain
{
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Attempting to join core.pimcocloud.net with oupath OU=$($env:cliqrdepenvname),OU=irvine,ou=data_center,dc=core,dc=pimcocloud,dc=net"
		agentSendLogMessage "$(executiontime) - Attempting to join core.pimcocloud.net with oupath OU=$($env:cliqrdepenvname),OU=irvine,ou=data_center,dc=core,dc=pimcocloud,dc=net"
		Add-Computer -ComputerName $server -Domain core.pimcocloud.net -DomainCredential $Credential -OUPath "OU=$($env:cliqrdepenvname),OU=irvine,ou=data_center,dc=core,dc=pimcocloud,dc=net" -ea stop #-Restart
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to join domain"
		agentSendLogMessage "$(executiontime) - Failed to join domain"
		Add-Content -Path $logfile "$(executiontime) - $error[0]"
		agentSendLogMessage "$(executiontime) - $Error[0]"
		#cliqr doesn't quit on throw....
		throw $error
	}
}

function ChefSetup
{
	#Chef setup
	Start-BitsTransfer -Source http://10.155.5.63:8080/cheffiles.zip -destination c:\temp -ProxyUsage NoProxy
	
	#Download the JSON for this service
	Expand-ZIPFile -File "C:\temp\cheffiles.zip" -Destination "C:\chef"
	
	#Create client.rb
	New-item -ItemType file $clientrb
	Add-Content -Path $clientrb "log_level        :info"
	Add-Content -Path $clientrb "log_location     STDOUT"
	Add-Content -Path $clientrb "chef_server_url  'https://chef.core.pimcocloud.net/organizations/pimco'"
	Add-Content -Path $clientrb "validation_client_name 'pimco-validator'"
	Add-Content -Path $clientrb "validation_key 'c:\chef\pimco-validator.pem'"
	Add-Content -Path $clientrb "client_key 'c:\chef\client.pem'"
	Add-Content -Path $clientrb "no_proxy  'localhost, 127.*, 10.*, *.pimcocloud.net, *.core.pimcocloud.net'"
	Add-Content -Path $clientrb "environment '$($env:cliqrdepenvname)'"
	#Add-Content -Path $clientrb "http_proxy               'http://proxynb.pimco.imswest.sscims.com:8080'"
	#Add-Content -Path $clientrb "https_proxy              'http://proxynb.pimco.imswest.sscims.com:8080'"
	
	Add-Content -Path $logfile "$(executiontime) - Running Chef command: chef-client -r $($env:runlist)"
	agentSendLogMessage "$(executiontime) - Running Chef command: chef-client -r $($env:runlist)"
	#Run Chef with Cliqr Env variable
	chef-client -r $env:runlist
	#chef-client -r -j
}

function CreateTMP
{
	if (test-path c:\tmp)
	{ }
	else
	{
		mkdir c:\tmp
	}
}

function DownloadAppProfileJson
{
	Start-BitsTransfer -Source http://10.155.5.63:8080/"$($env:cliqrWebServerType).json" -destination c:\temp -ProxyUsage NoProxy
	sleep 4
	Rename-Item c:\temp\"$($env:cliqrWebServerType).json" c:\temp\createiis.json
}

function GrantAccessRights
{
	#Give user admin rights to sandbox
	#Need to run this as something else...won't have rights to query AD
	<#
	if ($env:cliqrdepEnvname -eq "sandbox")
	{
        Invoke-Command localhost {
	        $usersemail = ($env:launchUserName -split("_r"))[0] + "@pimco.com"
	        $searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(mail=$usersemail))"
	        $searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com'
	        $user = $searcher.FindOne().GetDirectoryEntry()
	        $userlogin = $user.samaccountname
	        Add-Content -Path $logfile "$(executiontime) - Adding $userlogin to local admins group"
	        try
	        {
	            ([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://Pimco/$userlogin") | Out-Null
	        }
	        catch
	        {
	            Add-Content -Path $logfile "$(executiontime) - Failed to add $userlogin to local admins group"
	        }
        } -Credential $Credential -Authentication 'Credssp' -ea Stop
	}
	#>
	if ($env:cliqrdepEnvname -eq "sandbox")
	{
		Add-Content -Path $logfile "$(executiontime) - Adding pimco\$($env:userExternalId) to local admins group"
		agentSendLogMessage "$(executiontime) - Adding pimco\$($env:userExternalId) to local admins group"
		try
		{
			([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$($env:userExternalId)") | Out-Null
		}
		catch
		{
			Add-Content -Path $logfile "$(executiontime) - Failed to add $userlogin to local admins group"
			agentSendLogMessage "$(executiontime) - Failed to add $userlogin to local admins group"
		}
	}
	
}

### Main ###

CreateLogFile
Add-Content -Path $logfile "$(executiontime) - Starting script"
agentSendLogMessage "$(executiontime) - Starting script"
CreateTMP

#Lookup current step
$stepfinder = Get-Content $cliqrresumefile -ea SilentlyContinue
#If the resume flag is NOT there we are on step 1
if ((Test-Path $cliqrresumefile) -eq $false)
{
	#Run step 1
	LoadCliqrEnvVariables
	PartitionDisks
	JoinDomain
	"step2" | Out-File C:\tmp\.cliqrRebootResumeInit -force
	Add-Content -Path $logfile "$(executiontime) - Step 1 complete, rebooting"
	agentSendLogMessage "$(executiontime) - Step 1 complete, rebooting"
	exit 0
}
else
{
	switch ($stepfinder)
	{
		"step2" { Add-Content -Path $logfile "$(executiontime) - Resuming from reboot, starting step 2"; agentSendLogMessage "$(executiontime) - Resuming from reboot, starting step 2"; GrantAccessRights; ChefSetup; Add-Content -Path $logfile "$(executiontime) - Initialization complete"; agentSendLogMessage "$(executiontime) - Initialization complete" }
	}
}

