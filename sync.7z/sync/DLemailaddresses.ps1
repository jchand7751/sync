﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/8/2016 2:50 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$larrylist = get-qadgroup -IncludedProperties proxyaddresses -sizelimit 0 | select name, grouptype, proxyaddresses
$implarrylist = $larrylist | select name, grouptype, proxyaddresses | where { $_.proxyaddresses -notlike "" }

$array = @()

foreach ($i in $implarrylist)
{
	$object = "" | select Name, GroupType, Addresses
	$object.Name = $i.name
	$object.Grouptype = $i.grouptype
	$object.Addresses = ((([string]($i.proxyaddresses | where { $_ -notlike "X400*" })) -replace " ", ",") -replace "smtp:", " ").trimstart(" "); $array += $object
	$object
}