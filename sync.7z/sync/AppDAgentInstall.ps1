﻿[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$Department,

    [Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer
)

function local
{
    function installagent
    {
        $AgentPath = "\\nasshare\share\PimcoIIS_InstallPackage\AppDynamics\Agents\$department"
        new-item -type directory c:\temp\appdynamics  | out-null
        copy $AgentPath\dotnetagentsetup.msi c:\temp\appdynamics
        copy $AgentPath\AD_Config.xml c:\temp\appdynamics
        #msiexec /i $agentpath\dotNetAgentSetup.msi /q /norestart /lv "AgentInstaller.log" AD_SetupFile=$agentpath\AD_Config.xml
        Write-host "Installing new agent"
        cmd /c START /WAIT MSIEXEC /i c:\temp\appdynamics\dotnetagentsetup.msi /q /norestart /lv 'c:\temp\appdynamics\AgentInstaller.log' AD_SetupFile='c:\temp\appdynamics\AD_Config.xml'
        write-host "Restarting IIS"
        #iisreset
    }
    Write-host "Looking for a previous install"
    $CheckforExisting = gwmi win32_product -Filter "name='AppDynamics .NET Agent'"
    if ($CheckforExisting)
    {
        Write-host "Found a previous install"
        $script:oldinstallsource = $CheckforExisting.installsource + $CheckforExisting.Packagename
        if (Test-Path $script:oldinstallsource)
        {
            try
            {
                Write-host "Removing old agent"
                #cp $script:oldinstallsource c:\temp
                #$localuninstallsource = "c:\temp\" + $CheckforExisting.Packagename
                msiexec /uninstall $script:oldinstallsource /q /norestart
            }
            catch
            {
                Write-Warning "Uninstall failure"
                $uninstalled = $false
                #write to log and quit
                exit
            }
            try
            {
                Write-host "Cleaning up old files"
                if (Test-path 'C:\Program Files\AppDynamics')
                {
                    Remove-Item -Path 'C:\Program Files\AppDynamics' -Recurse -Force -ea stop
                }
                if (Test-path 'C:\ProgramData\AppDynamics')
                {
                    Remove-Item -Path 'C:\ProgramData\AppDynamics' -Recurse -Force -ea stop
                }
            }
            catch
            {
                Write-warning "Cleanup failure"
                $cleanup = $false
            }
            try
            {
                installagent
            }
            catch
            {
                write-warning "New agent failed to install"
            }   
        }
    }
    else
    {
        write-host "Old agent not found"
        try
        {
            Write-host "Cleaning up old files just in case"
            if (Test-path 'C:\Program Files\AppDynamics')
            {
                Remove-Item -Path 'C:\Program Files\AppDynamics' -Recurse -Force -ea stop
            }
            if (Test-Path 'C:\ProgramData\AppDynamics')
            {
                Remove-Item -Path 'C:\ProgramData\AppDynamics' -Recurse -Force -ea stop
            }
        }
        catch
        {
            Write-warning "Cleanup failure"
            $cleanup = $false
        }
        installagent
    }
}

function remote
{
    try
    {
        $script:session = new-pssession -ComputerName $computer -ErrorAction Stop
    }
    catch
    {
        write-warning "Session creation failed"
        exit
    }

    function copyagent
    {
        write-host "Copying new $department agent"
        $AgentPath = "\\nasshare\share\PimcoIIS_InstallPackage\AppDynamics\Agents\$department"
        new-item -type directory \\$computer\c$\temp\appdynamics | out-null
        copy $AgentPath\dotnetagentsetup.msi \\$computer\c$\temp\appdynamics
        copy $AgentPath\AD_Config.xml \\$Computer\c$\temp\appdynamics
    }

    function copyoldagent
    {
        if ($script:oldinstallsource.contains(":"))
        {
            $script:oldinstallsource = $script:oldinstallsource -replace (":","$")
            $script:oldinstallsource = "\\$computer" + "\" + $script:oldinstallsource -replace (":","$")
            new-item -type directory \\$computer\c$\temp\appdynamics\oldagent | out-null
            copy $script:oldinstallsource \\$computer\c$\temp\appdynamics\oldagent
        }
        else
        {
            new-item -type directory \\$computer\c$\temp\appdynamics\oldagent | out-null
            copy $script:oldinstallsource \\$computer\c$\temp\appdynamics\oldagent
        }
    }

    function installagentremote
    {
        sleep 10
        Write-host "Installing new agent"
        invoke-command -Session $script:session {cmd /c START /WAIT MSIEXEC /i c:\temp\appdynamics\dotnetagentsetup.msi /q /norestart /lv 'c:\temp\appdynamics\AgentInstaller.log' AD_SetupFile='c:\temp\appdynamics\AD_Config.xml'} -ea stop
        <#
        do 
        {
            write-host "Waiting for msi install to start"
            $check = (gwmi win32_process -comp $computer -filter "name='msiexec.exe'").commandline
            $found = $check | where {$_ -eq "MSIEXEC  /i c:\temp\appdynamics\dotnetagentsetup.msi /q /norestart /lv c:\temp\appdynamics\AgentInstaller.log AD_SetupFile=c:\temp\appdynamics\AD_Config.xml"}
            sleep 1
        }
        until 
        (
            $found -eq "MSIEXEC  /i c:\temp\appdynamics\dotnetagentsetup.msi /q /norestart /lv c:\temp\appdynamics\AgentInstaller.log AD_SetupFile=c:\temp\appdynamics\AD_Config.xml"
        )
        write-host "found it"
        do 
        {
            write-host "Waiting for msi install to finish"
            $check = (gwmi win32_process -comp $computer -filter "name='msiexec.exe'").commandline
            $found = $check | where {$_ -eq "MSIEXEC  /i c:\temp\appdynamics\dotnetagentsetup.msi /q /norestart /lv c:\temp\appdynamics\AgentInstaller.log AD_SetupFile=c:\temp\appdynamics\AD_Config.xml"}
            sleep 1
        }
        until 
        (
            $found -eq $null
        )
        #>
        write-host "Restarting IIS"
        sleep 10
        #invoke-command -Session $script:session {iisreset} -ea stop
    }
    function restartservice
    {
        try
        {
            invoke-command -Session $script:session {restart-service -Name AppDynamics.Agent.Coordinator_service} -ea stop
        }
        catch
        {
            Write-Warning "Service restart failed"
        }
    }
    Copyagent
    Write-host "Looking for a previous install"
    $CheckforExisting = gwmi win32_product -comp $computer -Filter "name='AppDynamics .NET Agent'"
    if ($CheckforExisting)
    {
        Write-host "Found a previous install"
        $script:oldinstallsource = $CheckforExisting.installsource + $CheckforExisting.Packagename
        copyoldagent
        if (Test-Path $script:oldinstallsource)
        {
            $script:oldinstallsource = "C:\temp\appdynamics\oldagent\$($checkforexisting.packagename)"
            try
            {
                $script:oldinstallsource
                Write-host "Removing old agent"
                #invoke-command -Session $script:session {cmd /c START /WAIT msiexec /uninstall $args[0] /q /norestart} -ArgumentList $script:oldinstallsource -ea stop
                invoke-command -Session $script:session {msiexec /uninstall $args[0] /q /norestart} -ArgumentList $script:oldinstallsource -ea stop
            }
            catch
            {
                Write-Warning "Uninstall failure"
                $uninstalled = $false
                #write to log and quit
                exit
            }
            $counter = 0
            do 
            {
                write-host "Waiting for msi uninstall to start"
                $check = (gwmi win32_process -comp $computer -filter "name='msiexec.exe'").commandline
                $found = $check | where {$_ -eq '"C:\Windows\system32\msiexec.exe"  /uninstall C:\temp\appdynamics\oldagent\dotnetagentsetup.msi /q /norestart'}
                sleep 1
                $counter++
            }
            until 
            (
                $found -eq '"C:\Windows\system32\msiexec.exe"  /uninstall C:\temp\appdynamics\oldagent\dotnetagentsetup.msi /q /norestart' -or $counter -eq 60
            )
            write-host "found it"
            do 
            {
                write-host "Waiting for msi to finish"
                $check = (gwmi win32_process -comp $computer -filter "name='msiexec.exe'").commandline
                $found = $check | where {$_ -eq '"C:\Windows\system32\msiexec.exe"  /uninstall C:\temp\appdynamics\oldagent\dotnetagentsetup.msi /q /norestart'}
                sleep 1
            }
            until 
            (
                $found -eq $null
            )
            #>
            try
            {
                Write-host "Cleaning up old files"
                sleep 40
                if (Test-path "\\$computer\C$\Program Files\AppDynamics")
                {
                    Remove-Item -Path "\\$computer\C$\Program Files\AppDynamics" -Recurse -Force -ea stop
                }
                if (Test-path "\\$computer\C$\ProgramData\AppDynamics")
                {
                    Remove-Item -Path "\\$computer\C$\ProgramData\AppDynamics" -Recurse -Force -ea stop
                }
            }
            catch
            {
                Write-warning "Cleanup failure"
                $cleanup = $false
            }
            try
            {
                sleep 60
                $script:session | Remove-PSSession
                $script:session = new-pssession -ComputerName $computer -ErrorAction Stop
                installagentremote
                restartservice
            }
            catch
            {
                write-warning "New agent failed to install"
            }   
        }
        else
        {
            write-warning "Didn't find old agent copy"
        }
    }
    else
    {
        write-host "Old agent not found"
        try
        {
            Write-host "Cleaning up old files just in case"
            if (Test-path "\\$computer\C$\Program Files\AppDynamics")
            {
                Remove-Item -Path "\\$computer\C$\Program Files\AppDynamics" -Recurse -Force -ea stop
            }
            if (Test-path "\\$computer\C$\ProgramData\AppDynamics")
            {
                Remove-Item -Path "\\$computer\C$\ProgramData\AppDynamics" -Recurse -Force -ea stop
            }
        }
        catch
        {
            Write-warning "Cleanup failure"
            $cleanup = $false
        }
        $script:session | Remove-PSSession
        $script:session = new-pssession -ComputerName $computer -ErrorAction Stop
        installagentremote
        restartservice
    }
    #clean up session
    $script:session | Remove-PSSession
}


##main##
if ($computer)
{
    remote
}
else
{
    local
}