﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/13/2016 12:58 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$hostname = hostname
$computer = [ADSI]"LDAP://CN=$hostname,CN=Computers,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"
$targetou = [ADSI]"LDAP://OU=Workstations - Regular,OU=AppsenseWorkstations,OU=Windows 7,OU=NB Workstations,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"
$computer.psbase.MoveTo($targetOU)
$computer = [ADSI]"LDAP://CN=$hostname,OU=Workstations - Regular,OU=AppsenseWorkstations,OU=Windows 7,OU=NB Workstations,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"
$group = [ADSI]"LDAP://CN=UEV_Computers,OU=UEV,OU=Applications,OU=Groups,OU=Operations,OU=Users,OU=CORP,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"
$group.add($computer.Path)