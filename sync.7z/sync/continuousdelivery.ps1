﻿
#if continous delivery was checked
if ($env:continousdelivery)
{
    foreach ($string in $iisapps)
    {
        #loop through all of the IIS apps and create separate watchers for them
        $department = (($string -split "E:\\apps\\pimcloud\\")[1] -split "\\")[0]
        $project = ((($string -split "E:\\apps\\pimcloud\\")[1] -split "$department\\") -split "\\")[1]
        $component = ((($string -split "E:\\apps\\pimcloud\\")[1] -split "$department\\$project\\") -split "\\")[1]
        $artifactorylabel = ((($string -split "E:\\apps\\pimcloud\\")[1] -split "$department\\$project\\$component\\") -split "\\")[1]
        if ([string]$string -match "-dev" -or [string]$string -match "//dev//")
        {
            $environment = "dev"
        }
        if ([string]$string -match "-beta" -or [string]$string -match "//beta//")
        {
            $environment = "beta"
        }
        if ([string]$string -match "prod" -or [string]$string -match "//prod//")
        {
            $environment = "prod"
        }
        $watchpath = "v1/apps/pimcloud/$department/$project/$component/$environment/$environment/$artifactorylabel/version"


        #$wp = "v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version"
        $json = get-content C:\pimcloud\cliqr-scripts\windows\consul\configbase.json
        $json1 = ConvertFrom-Json -InputObject ([string]$json)
        $watchesarray = @()
        $watches = "" | select type, key, args
        $watches.type = "key"
        $watches.key = $watchpath
        $watchstring = '["powershell.exe", "start-process powershell.exe -argumentlist -command "C:\pimcloud\cliqr-scripts\windows\consul\watcherscript.ps1 -watchpath ' + $watchpath + '""]'
        #$watches.args = '["powershell.exe", "start-process powershell.exe -argumentlist -command "c:\tmp\watcherscript.ps1 -watchpath v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version""]'
        $watches.args = $watchstring
        $watchesarray += $watches
        $json1 | Add-Member -Name watches -MemberType noteproperty -Value $watchesarray
        $json1 | ConvertTo-Json | out-file c:\consul\config.json

        $a = get-content c:\consul\config.json
        $a = $a -replace '\"\[','['
        $a = $a -replace '\]\"',']'
        $a = $a -replace '\"\[','['
        $a = $a -replace '\\"','"'
        $a = $a -replace '-command "',"'-command "
        $a = $a -replace '""]',"'`"]"
        $a | out-file c:\consul\config.json -Encoding ascii

        #["powershell.exe", "start-process powershell.exe -argumentlist -command 'c:\\tmp\\watcherscript.ps1 -watchpath v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version'"]
    }
}