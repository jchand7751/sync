﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	8/10/2016 12:03 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	CliqrEnvironmentVariableTask.ps1
	===========================================================================
	.DESCRIPTION
		Wait for Cliqr environment variables and complete setup.
#>
do { $waitforcliqrenvironment = Test-Path c:\temp\userenv.ps1; sleep 1 }
until
($waitforcliqrenvironment -eq $true)
if ($waitforcliqrenvironment -eq $true)
{
	c:\temp\cliqrinjectsetup.ps1
}