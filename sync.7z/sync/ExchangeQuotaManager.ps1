﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	11/28/2016 5:16 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	ExchangeQuotaManager.ps1
	===========================================================================
	.DESCRIPTION
		Exchange quota manager script.
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$QuotaName
)

#endregion

#region Base variables and environment information
$date = (Get-Date -uformat "%Y-%m-%d")
$logfile = "c:\temp\ExchangeQuotaManager-$date.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module ActiveDirectory -ea 'Stop' | Out-Null
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.Admin -ea 'SilentlyContinue' | Out-Null
	Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -ea 'SilentlyContinue' | Out-Null
	Add-PSSnapin Microsoft.Exchange.Management.Powershell.Support -ea 'SilentlyContinue' | Out-Null
	."C:\Program Files\Microsoft\Exchange Server\V14\bin\RemoteExchange.ps1"
	Connect-ExchangeServer -auto
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

	#Define Quota information
	$QuotaArray = @()
	$QuotaArray += [PSCustomObject]@{
		Name = "10GB Quota"
		#Enter quota sizes in bytes
		IssueWarningAmount = ([Microsoft.Exchange.Data.ByteQuantifiedSize]8589934592) #8GB
		ProhibitSendAmount = ([Microsoft.Exchange.Data.ByteQuantifiedSize]12884901888) #12GB
		#ProhibitReceiveAmount = "unlimited"
		Group = "MBLimit10"
	}
	$QuotaArray += [PSCustomObject]@{
		Name = "25GB Quota"
		#Enter quota sizes in bytes
		IssueWarningAmount = ([Microsoft.Exchange.Data.ByteQuantifiedSize]21474836480) #20GB
		ProhibitSendAmount = ([Microsoft.Exchange.Data.ByteQuantifiedSize]26843545600) #25GB
		#ProhibitReceiveAmount = "unlimited"
		Group = "MBLimit25"
}
	<#
	$QuotaArray += [PSCustomObject]@{
		Name = "No limits"
		IssueWarningAmount = "unlimited"
		ProhibitSendAmount = "unlimited"
		#ProhibitReceiveAmount = "unlimited"
		Group = "MBLimitNone"
	}
	#>
#endregion

#region Script functions

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"
#Loop through the quota array
foreach ($Quota in $QuotaArray)
{
	#The quota we're looking up from the array
	$SelectedQuota = $Quota
	$Group = $SelectedQuota.Group
	#Look up the group members in AD and get their mailboxes
	try
	{
		$QuotaGroupMembers = Get-ADGroup -filter { Name -eq $Group } -Server pimco.imswest.sscims.com | Get-ADGroupMember
		$QuotaGroupMailboxes = @()
		foreach ($Member in $QuotaGroupMembers)
		{
			try
			{
				$MemberAlias = $($Member.SamAccountName)
				##Make this better
				#$QuotaGroupMailboxes += Get-Mailbox -filter { alias -eq $MemberAlias }
				#$QuotaGroupMailboxes += Get-Mailbox -filter { name -eq $MemberAlias } -ResultSize 1 -ErrorAction 'Stop'
				#$QuotaGroupMailboxes += Get-Mailbox -ANR $MemberAlias
				#I have no idea why this is so dumb
				$expression = "Get-Mailbox -filter { alias -eq '$MemberAlias' } -ResultSize 1 -ErrorAction 'Stop'"
				$QuotaGroupMailboxes += Invoke-Expression -Command $expression
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to look up user information" -Throw
			}
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to look up quota information" -Throw
	}
	#Compare the members' mailbox limits to the ones defined in the quota array
	foreach ($Member in $QuotaGroupMailboxes)
	{
		<#
		if ($Member.ProhibitSendReceiveQuota -ne $SelectedQuota.ProhibitReceiveAmount)
		{
			Add-Log -Type 'Warning' -Message "$($Member.Name) does not have an issue warning amount that matches $($SelectedQuota.Name) - attempting to set to the correct value $($SelectedQuota.ProhibitReceiveAmount)"
			try
			{
				$Member | Set-Mailbox -ProhibitSendReceiveQuota $SelectedQuota.ProhibitReceiveAmount -UseDatabaseQuotaDefaults $false -ErrorAction 'Stop'
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set prohibit receive quota for $($Member.name)!"
			}
		}
		else
		{
			Add-Log -Type 'Information' -Message "$($Member.Name) has a matching receive quota amount to the configured policy $($SelectedQuota.Name)"
		}
		#>
		if ($Member.ProhibitSendQuota -eq "unlimited")
		{
			Add-Log -Type 'Warning' -Message "$($Member.Name) does not have a prohibit send amount that matches $($SelectedQuota.Name) - attempting to set to the correct value $($SelectedQuota.ProhibitSendAmount.toGB())"
			try
			{
				$Member | Set-Mailbox -ProhibitSendQuota $SelectedQuota.ProhibitSendAmount -UseDatabaseQuotaDefaults $false -ProhibitSendReceiveQuota "unlimited" -ErrorAction 'Stop' #-Whatif
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set prohibit send quota for $($Member.name)!"
			}
		}
		elseif ($Member.ProhibitSendQuota.value.toMB() -ne $SelectedQuota.ProhibitSendAmount.toMB() -or $Member.UseDatabaseQuotaDefaults -ne $false)
		{
			Add-Log -Type 'Warning' -Message "$($Member.Name) does not have a prohibit send amount that matches $($SelectedQuota.Name) - attempting to set to the correct value $($SelectedQuota.ProhibitSendAmount.toGB())"
			try
			{
				$Member | Set-Mailbox -ProhibitSendQuota $SelectedQuota.ProhibitSendAmount -UseDatabaseQuotaDefaults $false -ProhibitSendReceiveQuota "unlimited" -ErrorAction 'Stop' #-Whatif
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set prohibit send quota for $($Member.name)!"
			}
		}
		else
		{
			Add-Log -Type 'Information' -Message "$($Member.Name) has a matching send quota amount to the configured policy $($SelectedQuota.Name)"
		}
		if ($Member.IssueWarningQuota -eq "unlimited")
		{
			Add-Log -Type 'Warning' -Message "$($Member.Name) does not have an issue warning amount that matches $($SelectedQuota.Name) - attempting to set to the correct value $($SelectedQuota.IssueWarningAmount.toGB())"
			try
			{
				$Member | Set-Mailbox -IssueWarningQuota $SelectedQuota.IssueWarningAmount -UseDatabaseQuotaDefaults $false -ProhibitSendReceiveQuota "unlimited" -ErrorAction 'Stop' #-Whatif
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set warning quota for $($Member.name)!"
			}
		}
		elseif ($Member.IssueWarningQuota.value.toMB() -ne $SelectedQuota.IssueWarningAmount.toMB() -or $Member.UseDatabaseQuotaDefaults -ne $false)
		{
			Add-Log -Type 'Warning' -Message "$($Member.Name) does not have an issue warning amount that matches $($SelectedQuota.Name) - attempting to set to the correct value $($SelectedQuota.IssueWarningAmount.toGB())"
			try
			{
				$Member | Set-Mailbox -IssueWarningQuota $SelectedQuota.IssueWarningAmount -UseDatabaseQuotaDefaults $false -ProhibitSendReceiveQuota "unlimited" -ErrorAction 'Stop' #-Whatif
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set warning quota for $($Member.name)!"
			}
		}
		else
		{
			Add-Log -Type 'Information' -Message "$($Member.Name) has a matching warning quota amount to the configured policy $($SelectedQuota.Name)"
		}
	}
}
Add-Log -Type 'Information' -Message "Script complete"
Send-MailMessage -From "ExchangeQuotaManager@NoReplyPimco.com" -Attachments $logfile -Body "Please see attached" -Subject "Exchange quota results" -To "james.chandler@pimco.com", "MVijaykumar@StateStreet.com" -SmtpServer pimcomailrelay-nb.pimco.imswest.sscims.com
#endregion