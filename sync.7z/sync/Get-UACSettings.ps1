﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/16/2016 9:49 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
function Get-UACSettings
{
	param ($computer)
	Import-Module PSRemoteRegistry
	$values = "EnableLUA", "ConsentPromptBehaviorAdmin", "PromptOnSecureDesktop"
	foreach ($i in $values)
	{
		(Get-RegValue -Hive LocalMachine -Key Software\Microsoft\Windows\CurrentVersion\Policies\System -Value $i -Computer $computer ).data
	}
}
Get-UACSettings