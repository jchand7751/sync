﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/9/2016 4:12 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


Import-Module ActiveDirectory
Import-Module GroupPolicy
$myGPO = Get-GPO -name "Flag Task" -Domain pimco
$myGPOID = "*" + $myGPO.Id + "*"
$Path = get-ADObject -Filter  { gPLink -Like $myGPOID }
foreach ($OU in $Path.distinguishedname)
{
	New-GPLink -Name "TEST - Pimco Bulletinboard" -Target $OU -WhatIf
}
