﻿#$wp = "v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version"
$json = get-content H:\public\JC\consul\configbase.json
$json1 = ConvertFrom-Json -InputObject ([string]$json)
$watchesarray = @()
$watches = "" | select type, key, args
$watches.type = "key"
$watches.key = $wp
$watchstring = '["powershell.exe", "start-process powershell.exe -argumentlist -command "c:\tmp\watcherscript.ps1 -watchpath ' + $wp + '""]'
#$watches.args = '["powershell.exe", "start-process powershell.exe -argumentlist -command "c:\tmp\watcherscript.ps1 -watchpath v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version""]'
$watches.args = $watchstring
$watchesarray += $watches
$json1 | Add-Member -Name watches -MemberType noteproperty -Value $watchesarray
$json1 | ConvertTo-Json | out-file c:\tmp\jsontest1.json

$a = get-content c:\tmp\jsontest1.json
$a = $a -replace '\"\[','['
$a = $a -replace '\]\"',']'
$a = $a -replace '\"\[','['
$a = $a -replace '\\"','"'
$a = $a -replace '-command "',"'-command "
$a = $a -replace '""]',"'`"]"
$a | out-file c:\tmp\jsontest1.json -Encoding ascii

#["powershell.exe", "start-process powershell.exe -argumentlist -command 'c:\\tmp\\watcherscript.ps1 -watchpath v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version'"]