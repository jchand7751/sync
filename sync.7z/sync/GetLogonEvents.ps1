<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.57
	 Created on:   	6/13/2014 11:17 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#Findlogons
Param ($comp)
Add-PSSnapin Quest.ActiveRoles.ADManagement
Connect-QADService VMS001p4 | Out-Null
$computer = Get-QADComputer -name $comp
#$ComputerArray = @()
$ResultArray = @()
#$ComputerArray += Get-QADComputer -name "NB-19*"
#$ComputerArray += Get-QADComputer -name "NB-20*"
#$ComputerArray += Get-QADComputer -name "nb-7-1232"
#foreach ($Computer in $ComputerArray)
#{
	
$Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624)  and TimeCreated[@SystemTime&gt;='2014-07-31T07:00:01.000Z' and @SystemTime&lt;='2014-08-05T06:59:00.999Z']]]</Select></Query></QueryList>" -Computername $computer.name

$loggedonuser = ((gwmi win32_computersystem -ComputerName $Computer.name).username) -replace "pimco\\", ""
	#Filter 1
if ($loggedonuser)
{ $userfound = $true }
else
{
	$userfound = $false
	for ($x = 0; $x -lt $Events.count; $x++)
	{
		$tempfile = [io.path]::GetTempFileName()
		$Events[$x].message | Out-File $tempfile
		#$Events[$x].message
		$CleanMessage = Get-Content $tempfile
		#Read-Host "Stop"
		$loggedonuser = (((Get-Content $tempfile | select-string "Account Name:")[1]) -replace "Account Name:", "").trimend("").trimstart("")
		$logontype = ((Get-Content $tempfile | select-string "logon type:") -replace "Logon Type:", "").trimend("").trimstart("")
		#$loggedonuser
		Remove-Item $tempfile -Force
		$checkuser = Get-QADUser -SamAccountName $loggedonuser
		if ($checkuser -and $logontype -ne 3)
		{
			#Write-Host "found a match"
			$userfound = $true
			break
		}
	}
}

if ($userfound -eq $false)
{
	Write-Warning "A user wasn't found on $comp"
	Exit
}

for ($x = 0; $x -lt $Events.count; $x++)
{
	if ($Events[$x].message | Select-String $loggedonuser)
	{
		$object = "" | select ComputerName, User, LogonTime, LogonType
		$object.user = $loggedonuser
		$object.computername = $Computer.name
		#Filter 2
		$tempfile = [io.path]::GetTempFileName()
		$object.logontime = $Events[$x].timecreated.tostring()
		$Events[$x].message | Out-File $tempfile
		$CleanMessage = Get-Content $tempfile
		$logontype = ((Get-Content $tempfile | select-string "logon type:") -replace "Logon Type:", "").trimend("").trimstart("")
		#$logontype
		switch ($logontype)
		{
			"7" { $object.logontype = "Unlock" }
			"2" { $object.logontype = "Local login" }
			"3" { $object.logontype = "Network login" }
		}
		Remove-Item $tempfile -Force
		#$object
		if ($ResultArray | where { $_.logontime -eq $object.logontime })
		{
			#write-host "duplicate found, skipping"
		}
		else
		{
			$ResultArray += $Object
		}
	}
}
#}
$ResultArray
$ResultArray | Export-Csv c:\temp\LogonEvents\$comp.csv
