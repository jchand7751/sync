﻿$server = hostname
$password = "Ker988qa" | ConvertTo-SecureString -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential "core\admjchandler", $password
Add-Computer -ComputerName $server -Domain core.pimcocloud.net -DomainCredential $Credential -OUPath "OU=test,OU=infra,OU=dept,OU=prod,OU=win-environments,OU=irvine,ou=data_center,dc=core,dc=pimcocloud,dc=net" -Restart