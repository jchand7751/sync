﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/30/2015 2:18 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		UEV Migration Script.
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 1)]
	[string]$Computer,
	
	[Parameter(Mandatory = $true, Position = 2)]
	[string]$Username
)
Write-Verbose "Starting script"
#param ($Computer, $username)

#Set Variables
$whoami = whoami
$logfile = "C:\temp\UEVMigration-$username-$computer.txt"

#Functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function getadminusers
{
	Param ($computer)
	$testcon = Test-Connection $computer -Quiet -Count 1
	$script:array = @()
	if ($testcon)
	{
		try
		{
			$LocalAdmin = ([ADSI]"WinNT://$Computer/Administrators")
		}
		catch
		{
			Write-Warning "Failed to access local admins group"
			Add-Content -Path $logfile "$(executiontime) - Failed to access local admins group"
		}
		$UserNames = @($LocalAdmin.psbase.Invoke("Members"))
		$UserList = $Usernames | foreach { $_.gettype().invokemember("Name", 'GetProperty', $null, $_, $null) }
		$parentlist = $UserNames | foreach { $_.gettype().invokemember("parent", 'GetProperty', $null, $_, $null) }
		for ($x = 0; $x -lt ($UserList.count); $x++)
		{
			$object = "" | select Computer, User
			$object.computer = $computer
			$object.user = ((($parentlist[$x] -replace "WinNT://") -replace "IMSWEST/") -replace "PIMCO/") + "\" + $UserList[$x]
			#$object
			$script:array += $object
		}
	}
	else
	{
		$object = "" | select Computer, User
		$object.user = "Offline"
		$object.computer = $computer
		#$object
		$script:array += $object
		Write-Warning "Failed to access local admins group"
		Add-Content -Path $logfile "$(executiontime) - Failed to access local admins group"
	}
	if ($script:array)
	{
		$script:array | select *

	}
	else
	{
		Write-Warning "Failed to access local admins group"
		Add-Content -Path $logfile "$(executiontime) - Failed to access local admins group"
	}
}

#Setup this PC

#Copy the FBR dll and executable
Write-Verbose "Setting up this PC"
if (Test-Path c:\temp\FBRInterface.dll)
{ }
else
{
	Copy-Item \\nasshare\share\test\FBRInterface.dll c:\temp
}
if (Test-Path c:\temp\FBRTool.exe)
{ }
else
{
	Copy-Item \\nasshare\share\test\FBRTool.exe c:\temp
}
if (Test-Path c:\temp\EmFsLibrary.dll)
{ }
else
{
	Copy-Item \\nasshare\share\test\EmFsLibrary.dll c:\temp
}

try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Quest snap-in not installed!"
	exit
}

#Create log file
Write-Verbose "Creating log file"
New-Item -Type File $logfile -Force | Out-Null
Add-Content -Path $logfile "$(executiontime) - Starting script - Running as $whoami"

#Connect to Pimco
try
{
	Write-Verbose "Connecting to Pimco AD"
	Add-Content -Path $logfile "$(executiontime) - Connecting to Pimco AD"
	Connect-QADService vms001p6 -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to connect to Pimco AD"
	Add-Content -Path $logfile "$(executiontime) - Failed to connect to Pimco AD"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	exit
}

#Get user's current groups
try
{
	Write-Verbose "Looking up user and adding current appsense groups to log file"
	Add-Content -Path $logfile "$(executiontime) - Looking up user and adding current appsense groups to log file"
	$currentgroups = Get-QADUser -SamAccountName $username -ea 'Stop' | Get-QADMemberOf -Indirect -Name "*appsen*" -ea 'Stop'
	foreach ($i in $currentgroups.name) { $stringgroups = $stringgroups + $i + ", " }
	Add-Content -Path $logfile "$(executiontime) - Current Appsense Groups: $stringgroups"
}
catch
{
	Write-Warning "Failed to lookup specified user"
	Add-Content -Path $logfile "$(executiontime) - Failed to lookup specified user"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	exit
}

#Make sure user's PC is up
try
{
	Write-Verbose "Looking for specified PC"
	Add-Content -Path $logfile "$(executiontime) - Looking for specified PC"
	Test-Connection -ComputerName $Computer -count 1 -ea Stop | Out-Null
}
catch
{
	Write-Warning "Failed to lookup specified user"
	Add-Content -Path $logfile "$(executiontime) - Failed to lookup specified user"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	exit
}

#Make sure UEV is installed already
try
{
	Write-Verbose "Checking PC for the UEV agent"
	Add-Content -Path $logfile "$(executiontime) - Checking PC for the UEV agent"
	Get-Service -ComputerName $Computer -Name "UevAgentService" -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to find UEV agent - please install via Bigfix or manually"
	Add-Content -Path $logfile "$(executiontime) - Failed to find UEV agent"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	exit
}

#Stop and disable appsense services
$AppsenseServices = "'Appsense Client Communications Agent'", "'AppSense EmCoreService'", "'AppSense Watchdog Service'"
foreach ($service in $AppsenseServices)
{
	try
	{
		Write-Verbose "Stopping $service"
		Add-Content -Path $logfile "$(executiontime) - Stopping $service"
		(gwmi win32_service -filter "Name=$service" -ComputerName $computer).StopService() | Out-Null
	}
	Catch
	{
		Write-Warning "Failed to stop $service"
		Add-Content -Path $logfile "$(executiontime) - Failed to stop $service"
	}
}

foreach ($service in $AppsenseServices)
{
	try
	{
		Write-Verbose "Disabling $service"
		Add-Content -Path $logfile "$(executiontime) - Disabling $service"
		(gwmi win32_service -filter "Name=$service" -ComputerName $computer).Changestartmode("Disabled") | Out-Null
	}
	Catch
	{
		Write-Warning "Failed to disable $service"
		Add-Content -Path $logfile "$(executiontime) - Failed to disable $service"
	}
}

$qaduser = Get-QADUser -SamAccountName $Username
#Remove user from Appsense groups
$AppsenseGroups = "AppSense-Test", "AppSense Migrated", "Appsense Personalized Users", "AppSense No Office", "AppSense Base User Group 2", "_AppSenseNYAll", "AppSense New Migraton Mode ON", "AppSense Web Interface Users", "AppsenseMigration7_12_13", "AppSense Base User Group 3"
foreach ($group in $AppsenseGroups)
{
	try
	{
		Write-Verbose "Removing user from $group"
		Add-Content -Path $logfile "$(executiontime) - Removing user from $group"
		
		Get-QADGroup $group | Remove-QADGroupMember -Member $qaduser -ea 'Stop' | Out-Null
	}
	catch
	{
		Write-Warning "Failed to remove user from $group"
		Add-Content -Path $logfile "$(executiontime) - Failed to remove user from $group"
	}
}

#Add user and PC to UEV group
try
{
	Write-Verbose "Adding user to UEV_Users group"
	Add-Content -Path $logfile "$(executiontime) - Adding user to UEV_Users group"
	Get-QADGroup "UEV_Users" | Add-QADGroupMember -Member $qaduser -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to remove user from $group"
	Add-Content -Path $logfile "$(executiontime) - Failed to add user to UEV_Users group"
}

try
{
	Write-Verbose "Adding computer to UEV_Computers group"
	Add-Content -Path $logfile "$(executiontime) - Adding computer to UEV_Computers group"
	$compname = $computer + "$"
	Get-QADGroup "UEV_Computers" | Add-QADGroupMember -Member $compname -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to add computer to UEV_Computers group"
	Add-Content -Path $logfile "$(executiontime) - Failed to add computer to UEV_Computers group"
}

#Export appsense registry function
function ExportAppsenseRegistry
{
	param ($Computer, $Username)
	
	c:
	cd\
	cd temp
	
	#Get current user's SID
	$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$Username))"
	$searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com'
	#$searcher.SearchRoot = 'LDAP://imswest.sscims.com'
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Looking up $Username in Pimco AD"
		Write-Verbose "Looking up $Username in Pimco AD"
		$user = $searcher.FindOne().GetDirectoryEntry()
	}
	catch
	{
		Write-Warning "Failed to find $Username in Pimco AD"
		Add-Content -Path $logfile "$(executiontime) - Failed to find $Username in Pimco AD"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		exit
	}
	
	function confirmprompt
	{
		if ($user)
		{
			Add-Content -Path $logfile "$(executiontime) - Confirming user"
			Write-Verbose "Confirming user"
			$confirmuser = Read-Host "Please confirm $($user.fullname) (y/n)"
		}
		switch ($confirmuser)
		{
			"y" { Add-Content -Path $logfile "$(executiontime) - User confirmed" }
			"n" {
				Write-Warning "User name was not confirmed"
				Add-Content -Path $logfile "$(executiontime) - User $($user.fullname) was not confirmed"
				Add-Content -Path $logfile "$(executiontime) - Script finished"
				exit
			}
			default { Write-Warning "Please select Y or N"; confirmprompt }
		}
	}
	
	#confirmprompt
	Add-Content -Path $logfile "$(executiontime) - Confirming user"
	Write-Verbose "Confirming user"
	if ($user.fullname -eq $qaduser.name)
	{
		
	}
	else
	{
		Write-Warning "User name was not confirmed"
		Add-Content -Path $logfile "$(executiontime) - User $($user.fullname) was not confirmed"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		exit
	}
	
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Finding user's SID value"
		Write-Verbose "Finding user's SID value"
		$binarySID = $user.ObjectSid.Value
		$stringSID = (New-Object System.Security.Principal.SecurityIdentifier($binarySID, 0)).Value
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to find user's SID"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		exit
	}
	#get the random Appsense folder string name
	#ps2....
	#$folders = (get-childitem C:\appsensevirtual\$stringSID -attributes Directory -force)
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Checking for an Appsense folder for the user under \\$Computer\C$\appsensevirtual\$stringSID"
		Write-Verbose "Checking for an Appsense folder for the user under \\$Computer\C$\appsensevirtual\$stringSID"
		$folders = (get-childitem \\$Computer\C$\appsensevirtual\$stringSID -Force -ea 'Stop') | where { $_.psIsContainer -eq $true }
	}
	catch
	{
		Write-Warning "Failed to find an Appsense folder for the user"
		Add-Content -Path $logfile "$(executiontime) - Failed to find an Appsense folder for the user"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		exit
	}
	#powershell 2.0 friendly...
	try
	{
		Write-Verbose "Creating a local folder for c:\temp\AppsenseRegistry\$username"
		Add-Content -Path $logfile "$(executiontime) - Creating a local folder for c:\temp\AppsenseRegistry\$username"
		mkdir c:\temp\AppsenseRegistry\$username -Force | Out-Null
	}
	catch
	{
		Write-Warning "Failed to create a folder for $username"
		Add-Content -Path $logfile "$(executiontime) - Failed to create a folder for $username"
	}
	#should just be one of these but just in case...
	foreach ($folder in $folders)
	{
		#Get all the personalized app folders
		#$apps = (get-childitem $folder.FullName -attributes Directory -force)
		$apps = (get-childitem $folder.FullName -force) | where { $_.psIsContainer -eq $true }
		foreach ($app in $apps)
		{
			#$app.name
			if ($($app.Name) -eq "Dsktp")
			{
				$fbrpath = $app.FullName + "\registry\SessionData\registry.fbr"
				$filename = ($app.name).replace(" ", "") + "SessionData.reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
				$fbrpath = $app.FullName + "\registry\GlobalShared\registry.fbr"
				$filename = ($app.name).replace(" ", "") + "GlobalShared.reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
				$fbrpath = $app.FullName + "\registry\GlobalShared\iconsettings.fbr"
				$filename = ($app.name).replace(" ", "") + "GlobalSharedIconsettings.reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
			}
			else
			{
				#give us some nice file names and get rid of spaces because the fbrtool is picky
				$fbrpath = $app.FullName + "\registry\settings.fbr"
				$filename = ($app.name).replace(" ", "") + ".reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
			}
			
		}
	}
}

ExportAppsenseRegistry -Computer $computer -Username $username

#Create a folder for the user in their c:\temp
try
{
	Write-Verbose "Creating a folder on remote PC for c:\temp\$username"
	Add-Content -Path $logfile "$(executiontime) - Creating a folder on remote PC for c:\temp\$username"
	mkdir \\$computer\c$\temp\$username -ea 'Stop' -Force | Out-Null
}
catch
{
	Write-Warning "Failed to create folder \\$computer\c$\temp\$username"
	Add-Content -Path $logfile "$(executiontime) - Failed to create folder \\$computer\c$\temp\$username"
}

try
{
	Write-Verbose "Copying registry files to remote PC"
	Add-Content -Path $logfile "$(executiontime) - Copying registry files to remote PC"
	Copy-Item c:\temp\AppsenseRegistry\$username\* \\$computer\c$\temp\$username -ea 'Stop'
}
catch
{
	Write-Warning "Failed to copy Appsense registry files to \\$computer\c$\temp\$username"
	Add-Content -Path $logfile "$(executiontime) - Failed to copy Appsense registry files to \\$computer\c$\temp\$username"
}
#Enable UEV service
try
{
	Write-Verbose "Changing start type of UEV service on remote PC"
	Add-Content -Path $logfile "$(executiontime) - Changing start type of UEV service on remote PC"
	(gwmi win32_service -filter "Name='UevAgentService'" -ComputerName $computer).ChangeStartMode("Automatic") | Out-Null
}
catch
{
	Write-Warning "Failed to change start type of UevAgentService on $computer"
	Add-Content -Path $logfile "$(executiontime) - Failed to change start type of UevAgentService on $computer"
}

#Start UEV service
try
{
	Write-Verbose "Starting UEV on remote PC"
	Add-Content -Path $logfile "$(executiontime) - Starting UEV on remote PC"
	(gwmi win32_service -filter "Name='UevAgentService'" -ComputerName $computer).StartService() | Out-Null
}
catch
{
	Write-Warning "Failed to start UevAgentService on $computer"
	Add-Content -Path $logfile "$(executiontime) - Failed to start UevAgentService on $computer"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	exit
}

#Check and see if user is an admin
#$checkforuser = getadminusers $computer | where { $_.user -like "Pimco\$username" }
#$checkforuser

#if ($($checkforuser).user -like "PIMCO\$username")
#{
#Get our XML
$xml = Get-Content \\nasshare\share\test\UEVAutomation\runonceregimporttask.xml
$xml = $xml -replace "%LogonDomain%\\%LogonUser%", "pimco\$username"
$xml | Out-File c:\temp\runonceregimport-$username.xml -Force
try
{
	#if the user is already an admin create this task on their PC
	Write-Verbose "Creating a task on remote PC"
	Add-Content -Path $logfile "$(executiontime) - Creating a task on remote PC"
	schtasks /Create /S $computer /XML c:\temp\runonceregimport-$username.xml /TN "Run Once Reg Import" /F
}
catch
{
	Write-Warning "Failed to create the scheduled task on $computer"
	Add-Content -Path $logfile "$(executiontime) - Failed to create the scheduled task on $computer"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	exit
}
#}
<#Non admin is randomly working now?!?
else
{
	#Get our XML
	$xml = Get-Content \\nasshare\share\test\UEVAutomation\runonceregimporttask.xml
	$xml = $xml -replace "%LogonDomain%\\%LogonUser%", "pimco\$username"
	$xml | Out-File c:\temp\runonceregimport.xml
	try
	{
		#if they are not an admin create this task that will remove them from admins after the script executes
		Write-Verbose "Creating a task on remote PC"
		Add-Content -Path $logfile "$(executiontime) - Creating a task on remote PC"
		schtasks /Create /S $computer /XML c:\temp\runonceregimport.xml /TN "Run Once Reg Import"
	}
	catch
	{
		Write-Warning "Failed to create the scheduled task on $computer"
		Add-Content -Path $logfile "$(executiontime) - Failed to create the scheduled task on $computer"
	}
	
	#Make user an admin so they can import registry at next relog
	try
	{
		Write-Verbose "Adding $username to local admins on $computer"
		Add-Content -Path $logfile "$(executiontime) - Adding $username to local admins on $computer"
		([ADSI]"WinNT://$computer/Administrators,group").Add("WinNT://Pimco/$username") | Out-Null
	}
	catch
	{
		Write-Warning "Failed to add $username to local admins on $computer"
		Add-Content -Path $logfile "$(executiontime) - Failed to add $username to local admins on $computer"
	}
}
#>

#Copy the import script to the target
try
{
	Write-Verbose "Copying reg file script to remote"
	Add-Content -Path $logfile "$(executiontime) - Copying reg file script to remote"
	Copy-Item \\nasshare\share\test\UEVAutomation\importregfiles.ps1 \\$computer\c$\temp -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to copy import registry script to \\$computer\c$\temp"
	Add-Content -Path $logfile "$(executiontime) - Failed to copy import registry script to \\$computer\c$\temp"
}

#Done
Write-Verbose "Done!"
Add-Content -Path $logfile "$(executiontime) - Script finished"
