﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/8/2015 12:08 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($Computer)

$array = @()
if (Test-Connection -ComputerName $Computer -Quiet -Count 1)
{
	Import-Module PSRemoteRegistry -Force
	$object = "" | select Computer, UserName, LoginName, Sid, SystemPath, UserPath, SystemPathLength, UserPathLength, WebSpherePath
	$SystemPath = (Get-RegValue -ComputerName $Computer -Hive LocalMachine -Key "SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Value Path).data
	$UserSidKeys = (Get-RegKey -ComputerName $Computer -Hive Users -Key "\").key | where { $_.length -gt "10" -and $_ -notlike "*_Classes" }
	foreach ($sid in $UserSidKeys)
	{
		$object = "" | select Computer, LoginName, Sid, SystemPath, UserPath, SystemPathLength, UserPathLength
		$object.Computer = $Computer
		$object.sid = $sid -replace ("\\")
		$objSID = New-Object System.Security.Principal.SecurityIdentifier ($object.sid)
		$objUser = $null
		$objUser = $objSID.Translate([System.Security.Principal.NTAccount])
		$object.LoginName = $objUser.Value
		$object.UserPath = (Get-RegValue -ComputerName $Computer -Hive Users -Key (($sid -replace ("\\")) + "\Environment") -Value Path).data
		$object.UserPathLength = ($object.userpath).length
		$object.SystemPath = $SystemPath
		$object.SystemPathLength = ($object.systempath).length
		#$object
		## Adding this
		$object.webspherepath = Test-Path "\\$Computer\C$\Program Files (x86)\IBM\WebSphere MQ\bin"
		$array += $object
	}
}
else
{
	$object = "" | select Computer, UserName, LoginName, Sid, SystemPath, UserPath, SystemPathLength, UserPathLength, WebSpherePath
	$object.Computer = $Computer
	$object.Username = "Offline"
	#$object
	$array += $object
}
$array
$array | export-csv E:\envvarsdata\file-$computer.csv -force