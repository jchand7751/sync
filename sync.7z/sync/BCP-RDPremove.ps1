﻿[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer,
    
    [ValidateScript({if (Test-Path $_) { if (((import-csv $_)[0]).desktop) { $script:filepath = $_ ; $script:computerlist = import-csv $_ ; $True } else { throw "CSV is not in the correct format" }}
        else {
            Throw "Path is not valid"
        }})]
    [string[]]$File
)


function Readlog
{
    Param ($computer)
    $script:csvlog = "C:\temp\csvlogfile.csv"
    $script:loglookup = import-csv $csvlog
    $script:results = $script:loglookup | where {$_.desktop -eq $computer}
}

function Removeitemsfromlog
{
    Param ($computer, $user)

    $logfile = "C:\temp\Rdplogfile.txt"
    if ($script:status -eq "Success")
    {
        write-host "Success!"
        Add-Content "Removed $user from Remote Desktop Users group on $Computer" -Path $logfile
        $script:loglookup | where {$_.desktop -ne $computer} | export-csv $script:csvlog
    }
}

function RemoveUserfromRDP
{
    Param ($computer, $user)

    $logfile = "C:\temp\Rdplogfile.txt"
    try
    {
        Write-host "Attemping to remove $user from $computer"
        $script:status = "Success"
        ([ADSI]"WinNT://$computer/Remote Desktop Users,group").Remove("WinNT://pimco/$user")
    }
    catch
    {
        write-warning "failed!"
        #write-warning "Adding user $script:userlogin failed"
        Add-Content "Failed to remove $user from Remote Desktop Users group on $Computer" -Path $logfile
        $script:status = "Failed"
    }
    RemoveItemsfromlog $computer $user
}

function dotheneedful
{
    #$script:results
    foreach ($item in $script:results)
    {
        #write-host "$($item.desktop) + $($item.user) + $($item.status)"
        switch ($item.status)
        {
            "Success" {RemoveUserFromRDP -Computer $item.desktop -User $item.user}
            "Exists" {}
            "Failed" {}
        }
    }
}

function testaccess
{
    Param ($computer)
    write-verbose "Verifying computer is online"
    if ((Test-Connection -ComputerName $computer -count 1 -Quiet) -eq $true)
    {
    }
    else
    {
        $logfile = "C:\temp\Rdplogfile.txt"
        if ((Test-Path $logfile) -ne $true)
        {
            New-Item -ItemType file $logfile | out-null
        }
        write-warning "$computer appears to be offline"
        Add-Content -value "$computer appears to be offline" -Path $logfile
        throw "$Computer appears to be offline"
    }
}

function Main
{
    ### Needful Steps ###
    Param ($computer)

    $stopflag = $false
    try 
    {
        testaccess $computer
    }
    catch
    {
        $stopflag = $true
    }

    if ($stopflag -ne $true)
    {
        Readlog $computer
        Dotheneedful
    }
}

### Running ###
if ($script:computerlist)
{
    $script:csvlog = "C:\temp\csvlogfile.csv"
    foreach ($i in $script:computerlist)
    {
        Main $i.desktop
    }
    if (import-csv $script:csvlog)
    {}
    else
    {
        remove-item -Path $script:csvlog
    }
}
else
{
    $script:csvlog = "C:\temp\csvlogfile.csv"
    Main $Computer
    if (import-csv $script:csvlog)
    {}
    else
    {
        remove-item -Path $script:csvlog
    }
}