﻿#DBA

CREATE TABLE IISTable (IIS_ID INT IDENTITY(1,1) PRIMARY KEY CLUSTERED, SiteAppName NVARCHAR(max), ParentSiteID NVARCHAR(max), ParentSiteName NVARCHAR(max), SiteID NVARCHAR(max), LogDirectory NVARCHAR(max), FolderPath NVARCHAR(max), Authentication NVARCHAR(max), Bindings NVARCHAR(max), AppPoolName NVARCHAR(max), AppPoolRuntime NVARCHAR(max), AppPoolCredential NVARCHAR(max), AppPoolNetVersion NVARCHAR(max), Type NVARCHAR(max), [Database] NVARCHAR(max), PID NVARCHAR(max), ServerName NVARCHAR(max)) 
GO


INSERT INTO IISTable(SiteAppName, ParentSiteID, ParentSiteName, SiteID, LogDirectory, FolderPath, Authentication, Bindings, AppPoolName, AppPoolRuntime, AppPoolCredential, AppPoolNetVersion, Type, Databas, PID, ServerName ) VALUES ('thissite', '21', 'test', '1', 'e:\inetpub\logs\logfiles\W3SVC1', 'IIS://VMA001P074/w3svc/1/ROOT/test', 'Secure', 'thissite', 'DefaultAppPool', '64bit', 'pimco\svcaccount', 'v4.0', 'App', 'Oracle', '111', 'VMA001P074')
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null 

$srv = new-Object Microsoft.SqlServer.Management.Smo.Server("ina001d001")
$db = New-Object Microsoft.SqlServer.Management.Smo.Database
$db = $srv.Databases.Item("jamestest")
#Write to DB
$ds = $db.ExecuteNonQuery("INSERT INTO IISTable(SiteAppName, ParentSiteID, ParentSiteName, SiteID, LogDirectory, FolderPath, Authentication, Bindings, AppPoolName, AppPoolRuntime, AppPoolCredential, AppPoolNetVersion, Type, [Database], PID, ServerName ) VALUES ('thissite2', '21', 'test', '1', 'e:\inetpub\logs\logfiles\W3SVC1', 'IIS://VMA001P074/w3svc/1/ROOT/test', 'Secure', 'thissite', 'DefaultAppPool', '64bit', 'pimco\svcaccount', 'v4.0', 'App', 'Oracle', '111', 'VMA001P075')")

#Query
$query = $db.ExecuteWithResults("Select * From iistable")

 $array = @()
 for($i = 0 ; $i -lt $query.Tables.Count ; $i++)
 {  
    foreach($row in $query.Tables[$i].rows) 
    { 
        $object = New-Object psobject
        #Get number of properties this object has
        $objectproperties = ($query.tables[$i].rows | gm | where {$_.membertype -eq "property"})
        for ($x = 0 ; $x -lt $objectproperties.count ; $x++)
        {
            $object  | Add-Member noteproperty -Name $objectproperties[$x].name -Value $row.$($objectproperties[$x].name)
        }
        $array +=$object
    }
}



<#
        $object = New-Object psobject 
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[0].columnname)" -Value $row."$($ts.Tables[$i].columns[0].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[1].columnname)" -Value $row."$($ts.Tables[$i].columns[1].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[2].columnname)" -Value $row."$($ts.Tables[$i].columns[2].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[3].columnname)" -Value $row."$($ts.Tables[$i].columns[3].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[4].columnname)" -Value $row."$($ts.Tables[$i].columns[4].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[5].columnname)" -Value $row."$($ts.Tables[$i].columns[5].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[6].columnname)" -Value $row."$($ts.Tables[$i].columns[6].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[7].columnname)" -Value $row."$($ts.Tables[$i].columns[7].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[8].columnname)" -Value $row."$($ts.Tables[$i].columns[8].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[9].columnname)" -Value $row."$($ts.Tables[$i].columns[9].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[10].columnname)" -Value $row."$($ts.Tables[$i].columns[10].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[11].columnname)" -Value $row."$($ts.Tables[$i].columns[11].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[12].columnname)" -Value $row."$($ts.Tables[$i].columns[12].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[13].columnname)" -Value $row."$($ts.Tables[$i].columns[13].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[14].columnname)" -Value $row."$($ts.Tables[$i].columns[14].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[15].columnname)" -Value $row."$($ts.Tables[$i].columns[15].columnname)"
        $object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[16].columnname)" -Value $row."$($ts.Tables[$i].columns[16].columnname)"
        #$object  | Add-Member noteproperty -Name "$($ts.Tables[$i].columns[17].columnname)" -Value $row."$($ts.Tables[$i].columns[17].columnname)"
        #>