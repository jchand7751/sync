﻿Param ($watchpath)
#v1/apps/pimcloud/$department/$project/$component/$environment/$environment/$artifactorylabel/version
#"http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version - value 1.1.61"
if (Test-Path c:\pimcloud\logs\watcherlogs.txt)
{}
else
{
    New-Item -ItemType File c:\pimcloud\logs\watcherlogs.txt
}
#$watchpath = "v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version"
$watchflag = $watchpath -replace "/","-"
$lastvalue = Get-Content c:\tmp\$watchflag
$value = c:\pimcloud\consul\consul.exe kv get $watchpath

#if the flag exists this isn't the first run...do the needful
if (Test-Path c:\tmp\$watchflag)
{
    #Compare the current value to the initial setup value or last value
    if ($value -eq $lastvalue)
    {
        Add-Content "Key value is $value - Stored value is $lastvalue - No need to update" -Path c:\pimcloud\logs\watcherlogs.txt
    }
    else
    {
        #powershell.exe "C:\pimcloud\cliqr-scripts\windows\iis\CliqrIISPackageUpdate.ps1" -Packages $env:packages
        Add-Content "Key value is $value - Stored value is $lastvalue - Updating code" -Path c:\pimcloud\logs\watcherlogs.txt
        Set-Content $value -Path c:\tmp\$watchflag
    }
}
else
{
    #first setup, save current value
    Add-Content "First run detected, creating watchflag file and setting value" -Path c:\pimcloud\logs\watcherlogs.txt
    New-Item -ItemType File C:\tmp\$watchflag
    Add-Content $value -Path c:\tmp\$watchflag
}