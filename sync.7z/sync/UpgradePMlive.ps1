﻿
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$pypimcoVersion = $env:pypimcoVersion,
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$PYTHONPATH = $env:PYTHONPATH,
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$PYPIMLIB_HOME = $env:PYPIMLIB_HOME,
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$PYPIMLIB_LIB_PATH = $env:PYPIMLIB_LIB_PATH,
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$packages = $env:packages,
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$pypimcobasepath = $env:pypimcobasepath
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\PMliveUpdate.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
#endregion

#region Base functions

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

function StopDask
{
	try
	{
		Add-Log -Type 'Information' -Message "Stopping Dask service"
		Get-Service -Name Dask* | foreach { Add-Log -Type 'Information' -Message "Stopping $($_.name)"; $_ | Stop-Service -Force -ea 'Stop' }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to stop Dask services"
	}
}

function RemoveAppPackages
{
	try
	{
		Get-ChildItem E:\apps | foreach { Add-Log -Type 'Information' -Message "Removing $($_.name) from E:\apps"; $_ | Remove-item -Recurse -Force -ea 'Stop' }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to clear E:\apps"
	}
}

function DownloadAppPackages
{
	try
	{
		Add-Log -Type 'Information' -Message "Downloading packages: $packages"
		download_packages -Packages $packages
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to download packages"
	}
}

function StartDask
{
	try
	{
		Add-Log -Type 'Information' -Message "Starting Dask services"
		Get-Service -Name Dask* | foreach { Add-Log -Type 'Information' -Message "Starting $($_.name)"; $_ | Start-Service -ea 'Stop' }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to start Dask services"
	}
}

function SetRequiredApplicationVariables
{
	Add-Log -Type 'Information' -Message "Setting the variable pypimcoVersion: $pypimcoVersion"
	Add-Log -Type 'Information' -Message "Setting the variable pythonpath: $pythonpath"
	Add-Log -Type 'Information' -Message "Setting the variable PYPIMLIB_HOME: $pypimcoBasePath\$pypimcoVersion\pypimco\pypimlib"
	Add-Log -Type 'Information' -Message "Setting the variable PYPIMLIB_LIB_PATH: $pypimcoBasePath\$pypimcoVersion\pypimco\binary\pimlib"
	Add-Log -Type 'Information' -Message "Setting the variable packages: $packages"
	[Environment]::SetEnvironmentVariable('pypimcoVersion', $pypimcoVersion, 'Machine')
	[Environment]::SetEnvironmentVariable('PYTHONPATH', $PYTHONPATH, 'Machine')
	[Environment]::SetEnvironmentVariable('PYPIMCOBASEPATH', $pypimcoBasePath, 'Machine')
	[Environment]::SetEnvironmentVariable('PYPIMLIB_HOME', "$pypimcoBasePath\$pypimcoVersion\pypimco\pypimlib", 'Machine')
	[Environment]::SetEnvironmentVariable('PYPIMLIB_LIB_PATH', "$pypimcoBasePath\$pypimcoVersion\pypimco\binary\pimlib", 'Machine')
	[Environment]::SetEnvironmentVariable('Packages', $packages, 'Machine')
}

function PMLiveSetup
{
	invoke-expression "$pypimcobasepath\$pypimcoVersion\pypimco\tech\microservices\pypimcolive\PMlivesetup.ps1 -pypimcobasepath $pypimcobasepath -pypimcoversion $pypimcoversion"
}
#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting Upgrade PM Live"
SetRequiredApplicationVariables
StopDask
RemoveAppPackages
DownloadAppPackages
StartDask
PMLiveSetup
Add-Log -Type 'Information' -Message "Upgrade complete"
#endregion