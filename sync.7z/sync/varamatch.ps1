﻿$vars = get-childitem env:
$b = import-csv c:\temp\variables.csv
$c = import-csv C:\temp\localvar.csv

#Completely missing variables and their values
(compare $c $b -Property key) | foreach ($_.key) {$tt = $_.key ; $b | where {$_.key -eq $tt} | select key, value}