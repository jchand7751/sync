﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/1/2015 1:23 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$a = get-qadcomputer -osname windows*
foreach ($i in $a)
{
	$i.name
	if (Test-Connection $i.name -count 1 -quiet)
	{
		try
		{
			$session = New-PSSession -ComputerName $i.name -ea stop
			invoke-command $session { ipconfig } -ea stop
		}
		catch
		{
			write-warning "Couldn't create session on $($i.name)"
			continue
		}
		
		$test = invoke-command $session { (Get-NetIPAddress -InterfaceAlias Ethernet0 -AddressFamily ipv4).PrefixLength }
		$test
		if ($test -ne 25)
		{
			invoke-command $session { Set-NetIPAddress -InterfaceAlias Ethernet0 -PrefixLength 25 -AddressFamily ipv4 }
		}
		Remove-PSSession $session
	}
}