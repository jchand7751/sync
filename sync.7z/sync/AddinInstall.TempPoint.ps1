﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/18/2016 4:51 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($addin)
$logfile = "C:\temp\AddinInstaller-$addin.txt"
$whoami = ((whoami) -split ("\\"))[1]
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

CreateLogFile
Add-Content -Path $logfile "$(executiontime) - Starting script"
Add-Content -Path $logfile "$(executiontime) - Running as $whoami"
Add-Content -Path $logfile "$(executiontime) - Installing $addin"
pushd \\naspm\TA_Tools_Rep\Installers
.\AddInUpdater.exe /silent /version:PROD /install:$addin /requires:pxl:false
if ($?)
{ }
else
{
	Add-Content -Path $logfile "$(executiontime) - ERROR - Install failed"
}
popd
Add-Content -Path $logfile "$(executiontime) - Script complete"