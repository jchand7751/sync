﻿Param ($ComponentName, $ApplicationDepartment, $ApplicationLastUp, $AlertName, $ApplicationID, $ApplicationAvailability, $NodeName, $ApplicationName)

#solarwinds email template

Function SendApplicationAlertEmail
{
    Param ($EmailFrom, $EmailTo, $EmailSubject, $EmailBody)
	# Send E-mail message
	$Message = New-Object Net.Mail.MailMessage($EmailFrom, $EmailTo, $EmailSubject, $EmailBody)
    $Message.isbodyhtml = $true
	$SMTPClient = New-Object Net.Mail.SmtpClient("mailhost.pimco.com", 25)
	$SMTPClient.Send($Message)

}

function Get-SQL
{
##Passing the servername
param(
  [string]$ServerName,
  $applicationid
)

 ## SQL connection and getting selected results 
 $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server=$servername;Database=master ;Integrated Security=True"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = "EXEC sp_SolarwindsApplicationAlert $ApplicationID"
$SqlCmd.Connection = $SqlConnection
$SqlCmd.CommandTimeout = 0
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet) | out-null  #to get rid of output
$sqlconnection.close()
$allperm=@() 


##selecting each row from the sql ouput and inserting into each particular row
$dataset.tables[0]
}


$logfile = "c:\temp\alertlogs.txt"
New-Item -Path $logfile -itemtype file
Add-Content -Path $logfile "$componentname"

#$comparray = @()
<#
#$ComponentName 
if (($ComponentName.split(",")) -ge 1)
{
    $array = $ComponentName.split(",") 
    foreach ($component in $array) 
    {
        $Comparray += (($component.split("("))[0]).trim(" ")
    }
}   
else
{
    $ComponentName = ($ComponentName.split("("))[0]
}
#>

$StartComponenttable = "<table>
<tr>
	<th>Component Name</th>
	<th>Component Status</th>
	<th>Error Message</th>
</tr>
"

$comparray = Get-Sql ind001p001 $ApplicationID

foreach ($i in $comparray)
{
$startComponenttable = $startcomponenttable + "<tr><td>$($i.component_name)</td><td>$($i.errorcode)</td><td>$($i.errormessage)</td></tr>"
}

$startComponenttable = $startcomponenttable + "</table>"

if ($Comparray.count -ge 1)
{
$emailbody = "
$ApplicationName - on $NodeName is $ApplicationAvailability
<br>
<br>
$StartComponentTable
Department: $ApplicationDepartment <br>
<br>
Last up: $ApplicationLastUp <br>
Details: http://solarwinds/Orion/View.aspx?NetObject=AA:$ApplicationID <br>
<br>
Alert Name: $alertname <br>
Acknowledge: http://solarwinds/Orion/NetPerfMn/Alerts.aspx <br>
<br>
"
}
else
{
$emailbody = "
$ApplicationName - on $NodeName is $ApplicationAvailability
<br>
<br>
Component: $ComponentName <br>
Department: $ApplicationDepartment <br>
<br>
Last up: $ApplicationLastUp <br>
Details: http://solarwinds/Orion/View.aspx?NetObject=AA:$ApplicationID <br>
<br>
Alert Name: $alertname <br>
Acknowledge: http://solarwinds/Orion/NetPerfMn/Alerts.aspx <br>
<br>
"
}

Add-Content -Path $logfile "$emailbody"

SendApplicationAlertEmail swalerts-critical@pimco.com "james.chandler@pimco.com,Virgil.Gherghel@pimco.com" "$ApplicationName - on $NodeName is $ApplicationAvailability" $Emailbody


