﻿#Word
#Excel
#PDF

$a = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Recentdocs\"
$a = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Recentdocs\.docx"
$a = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Recentdocs\.doc"
$a = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Recentdocs\.xls"
$a = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Recentdocs\.xlsx"
$a = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Recentdocs\.pdf"

$b = $a | gm | where {$_.membertype -eq "noteproperty" -and $_.definition -like "System.Byt*"}

#for ($x = 0 ; $x -lt (($b.name).count ; $x++)) {[System.Text.Encoding]::Unicode.Getstring($a.$x)}

for ($x = 0 ; $x -lt (($b.name).count - 1) ; $x++) {[System.Text.Encoding]::Unicode.Getstring($a.$x) ; write-host ""}

$c = for ($x = 0 ; $x -lt (($b.name).count - 1) ; $x++) {[System.Text.Encoding]::Unicode.Getstring($a.$x) ; write-host ""}
for ($x = 0 ; $x -lt $c.count ; $x++) {($c[$x].split(".")[0]) + "." + $c[$x].split(".")[2]}


##Remote
function getrecentitems
{
Param ($comp, $user, $ext)
$sid = (Get-qaduser -samaccountname $user).sid
$a = Get-Regvalue -ComputerName $comp -Hive users "$sid\Software\Microsoft\Windows\CUrrentVersion\Explorer\Recentdocs\.$ext"
#$b = $a.count - 1
$b = $a.count

$c = for ($x = 0 ; $x -lt $b ; $x++) {[System.Text.Encoding]::Unicode.Getstring($a[$x].data)}
#$c
#$cleanup = for ($x = 0 ; $x -lt $c.count ; $x++) {($c[$x].split(".")[0]) + "." + $c[$x].split(".")[2]}
$cleanup = for ($x = 0 ; $x -lt $c.count ; $x++) {(($c[$x] -split(".$ext"))[0]) + "." + $ext}
$cleanup
}