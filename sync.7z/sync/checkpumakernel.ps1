﻿$array = @()
$array += get-qadcomputer -name nb-6-* | select name
$array += get-qadcomputer -name nb-7-* | select name
$array += get-qadcomputer -name nb-8-* | select name
$array += get-qadcomputer -name nb-17-* | select name
$finarray = @()
foreach ($i in $array) 
{
    $object = "" | select Name, online, prodlogs, betalogs, processstarted
    $object.name = $i.name
    if (test-connection $i.name -quiet -count 1)
    {
        $object.online = "True"
        $object.betalogs = test-path "\\$($i.name)\c$\temp\PumaKernelBeta\PumaKernelBetaAppStartupTask.txt"
        $object.prodlogs = test-path "\\$($i.name)\c$\temp\PumaKernel\PumaKernelAppStartupTask.txt"
        if (gwmi win32_process -comp $i.name | where {$_.name -eq "Pimco.Desktop.PumaKernel.exe"})
        {
            $object.processstarted = "True"
        }
    }
    else
    {
        $object.online = "False"
    }
    $object
    $finarray += $object
}