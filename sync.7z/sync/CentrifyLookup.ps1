﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/5/2017 11:52 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


Set-CdmPreferredServer -Server vms035gw003 -domain core.pimcocloud.net
$zone = Get-CdmZone -Domain core.pimcocloud.net

$computer = Get-CdmManagedComputer -Zone $zone | where { $_.name -eq "clv035dl-51ecf4.core.pimcocloud.net" }
Get-CdmRoleAssignment -Computer $computer