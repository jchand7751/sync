﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/19/2017 1:24 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Function addUser($computer, $userName, $pass, $descript)
{
	Write-Host("Adding Local User: $userName")
	try
	{
		if ($computer)
		{
			$compName = $computer
		}
		else
		{
			$compName = $env:COMPUTERNAME
		}
		$cn = [ADSI]"WinNT://$compName"
		$user = $cn.Create('User', $userName)
		$user.SetPassword($pass)
		$user.setinfo()
		if ($descript)
		{
			$user.description = $descript
			$user.SetInfo()
		}
		else
		{
		}
	}
	catch
	{
		$_
	}
}

Function addToGroup($computer, $userName, $userGroup)
{
	Write-Host("Adding $userName to $userGroup...")
	if ($computer)
	{
		$compName = $computer
	}
	else
	{
		$compName = $env:COMPUTERNAME
	}
	try
	{
		$group = [ADSI]"WinNT://$compName/$userGroup,group"
		$group.Add("WinNT://$compName/$userName,user")
	}
	catch
	{
		$_
	}
}


$computers = "vma001zb001", "vma001zb002", "vma001zb005", "vma001zb006", "vma001zd012", "vma001zd010", "vma001zd011"
foreach ($i in $computers)
{
	addUser -computer $i -userName mimatute -pass Pimco123! -descript LocalAccount
	addToGroup -computer $i -userName mimatute -userGroup Administrators
}