﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   8/15/2013 11:08 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param ($VMobject)

Add-PSSnapin VMware.VimAutomation.Core
#$vm = Get-VM
#$vmhost = Get-VMHost

$triggeredalarms = Get-View alarmmanager

foreach ($i in $vmobject.extensiondata.triggeredalarmstate)
	{
	$i
	$triggeredalarms.acknowledgealarm($i.alarm,$vmobject.extensiondata.moref)
	}