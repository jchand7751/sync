﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/13/2016 5:03 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$cliqrvariableslocation = "C:\temp\userenv.ps1"
.$cliqrvariableslocation

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

if ($env:CliqrDepEnvName -like "sandbox")
{
	$filename = ($env:apppath -split "/")[-3] + "-" + ($env:apppath -split "/")[-2] + "-" + "DEV" + ".zip"
}
else
{
	$filename = ($env:apppath -split "/")[-3] + "-" + ($env:apppath -split "/")[-2] + "-" + (($env:CliqrDepEnvName).toupper()) + ".zip"
}

Import-module BitsTransfer
Start-BitsTransfer -Source ($env:apppath + "/" + $filename) -destination e:\ -ProxyUsage NoProxy
Start-BitsTransfer -Source http://10.155.5.63:8080/Carbon.dll -destination c:\temp\installed\ -ProxyUsage NoProxy

sleep 10

#$filename = ($env:appzipfile -split "/")[-1]
Expand-ZIPFile E:\$filename -destination e:

Import-Module WebAdministration
$apppools = ls "env:" | where { $_.name -like "site*" }

#create app pools
foreach ($i in $apppools)
{
	New-WebAppPool -Name $i.value
	
	$GetPool = Get-Item "iis:\AppPools\$($i.value)"
	$GetPool.processmodel.username = $env:serviceaccount
	$GetPool.processmodel.Password = $env:serviceaccountpassword
	$GetPool.processmodel.identityType = "SpecificUser"
	$GetPool | Set-Item
	Restart-WebAppPool -Name $i.value
}
$siteauthentication = ls "env:" | where { $_.name -like "siteauth*" }
$parentsites = ls "env:" | where { $_.name -like "parentS*" }
$sites = ls "env:" | where { $_.name -like "site*" }
foreach ($site in $sites)
{
	$parentofsite = ("parentsite" + ($site.name)[-1])
	$parentofsiteobj = $parentsites | where { $_.name -like $parentofsite }
	$authenticationofsite = ("siteauthentication" + ($site.name)[-1])
	$authenticationofsiteobj = $siteauthentication | where { $_.name -like $authenticationofsite }
	
	if ($parentofsiteobj.value -eq "none")
	{
		#Write-Host "$($site.name) is a root site"
		New-Website -Name $site.value -ApplicationPool $site.value -physicalpath "e:\inetpub\$($site.value)" -HostHeader ($env:iisAppName + "-sandbox") -Port 8700 | Out-Null
		#site bindings
		New-WebBinding $site.value -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-sandbox.core.pimcocloud.net")
		New-WebBinding $site.value -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-dev")
		New-WebBinding $site.value -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-dev.core.pimcocloud.net")
		New-WebBinding $site.value -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-beta")
		New-WebBinding $site.value -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-beta.core.pimcocloud.net")
		New-WebBinding $site.value -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-prod")
		New-WebBinding $site.value -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-prod.core.pimcocloud.net")
		#use app pool credentials
		Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location $site.value -value true
		
		if ($authenticationofsiteobj -eq "NTLM" -or $authenticationofsite -eq "Kerberos")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $site.value -value true
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $site.value -value false
		}
		if ($authenticationofsiteobj -eq "Anonymous")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $site.value -value false
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $site.value -value true
		}
	}
	else
	{
		#Write-Host "$($site.name) is an app"
		New-WebApplication -name $site.value -Site $parentofsiteobj.value -PhysicalPath "e:\inetpub\$($site.value)" -ApplicationPool $site.value -Force
		
		#use app pool credentials
		Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location "$($parentofsiteobj.value)/$($site.value)" -value true
		
		if ($authenticationofsiteobj -eq "NTLM" -or $authenticationofsite -eq "Kerberos")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($parentofsiteobj.value)/$($site.value)" -value true
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($parentofsiteobj.value)/$($site.value)" -value false
		}
		if ($authenticationofsiteobj -eq "Anonymous")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($parentofsiteobj.value)/$($site.value)" -value false
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($parentofsiteobj.value)/$($site.value)" -value true
		}
	}
}

#Register any windows services
$directories = ls e:\services -Directory
foreach ($dir in $directories)
{
	foreach ($exe in (ls $dir.fullname -filter *.exe))
	{
		C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /servicename=$($dir.name) /i $exe.fullname
	}
}

#change service account
try
{
	$serviceaccount = ($env:serviceaccount -split '\\')[-1]
	([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$serviceaccount") | Out-Null
}
catch
{
	#Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	#agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
}

#grant rights to logon as a service
$Identity = $env:serviceaccount
$privilege = "SeServiceLogonRight"
$CarbonDllPath = "C:\temp\installed\Carbon.dll"
[Reflection.Assembly]::LoadFile($CarbonDllPath)
[Carbon.Lsa]::GrantPrivileges($Identity, $privilege)

#Change service account on windows services
$Service = gwmi win32_service | where { $_.pathname -like ('"' + $exe.fullname + '"') }
$Service.Change($Null, $Null, $Null, $Null, $Null, $Null, $env:serviceaccount, $env:serviceaccountpassword, $Null, $Null, $Null)
$Service.StartService()

#add healthcheck site
mkdir e:\inetpub\healthcheck
Start-BitsTransfer -Source http://10.155.5.63:8080/probe.htm -destination e:\inetpub\healthcheck -ProxyUsage NoProxy
New-WebAppPool -Name healthcheck
New-Website -Name healthcheck -ApplicationPool healthcheck -physicalpath "e:\inetpub\healthcheck" -Port 8700 | Out-Null

#add HTTP response headers
$Hostname = hostname
C:\windows\System32\inetsrv\appcmd.exe set config -section:system.webServer/httpProtocol /-"customHeaders.[name='X-ServerName']"
C:\windows\System32\inetsrv\appcmd.exe set config -section:system.webServer/httpProtocol /+"customHeaders.[name='X-ServerName',value=`'$HostName`']"

iisreset
