﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/30/2015 12:00 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
$alldist = Get-QADGroup -GroupType Distribution -SizeLimit 0 | select Name, CreationDate, ManagedBy, Mail
$array = @()

foreach ($i in $alldist)
{
	$object = "" | select Name, CreationDate, EmailAddress, Manager
	$object.Name = $i.name
	$object.CreationDate = $i.creationdate
	$object.Emailaddress = $i.mail
	try
	{
		$TestManager = (get-qaduser ($i.managedby)).name
		$object.Manager = $TestManager
	}
	Catch
	{
		$object.Manager = "Manager not found"
	}
	$object
	$array += $object
}
$array | Export-Csv c:\temp\allDLs.csv

