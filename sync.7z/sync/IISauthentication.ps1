﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   1/3/2014 11:41 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param ($server, $iisversion)
switch ($IISversion)
	{
	"7" {
		[xml]$xml1 = Get-Content C:\Windows\System32\inetsrv\config\applicationhost.config
		$xml1.configuration."system.webserver".security.authentication.anonymousAuthentication.enabled
		$xml1.configuration."system.webserver".security.authentication.anonymousAuthentication.username
		$array
		}
	"7.5" {
		[xml]$xml = Get-Content \\$server\C$\Windows\System32\inetsrv\config\applicationhost.config
		$array = @()
		if (($xml.configuration.location).count)
			{
			for ($x = 0 ; $x -lt ($xml.configuration.location).count; $x++)
				{
				$object = "" | select Website, SecurityOverride, Authentication
				$object.Website = $xml.configuration.location[$x].path
				$object.SecurityOverride = $xml.configuration.location[$x].overridemode
				$xml.configuration.location[$x]."system.webserver".security.authentication | get-member | where {$_.membertype -eq "property"} | foreach ($_.name) {$checkedvalue = $xml.configuration.location[$x]."system.webserver".security.authentication.($_.name) ; if ($checkedvalue) {$object.authentication = $object.authentication + $_.name + " "}}
				$object
				$array += $object
				}
			}
			else
				{
				Write-Host "only 1 website"
				$object = "" | select Website, SecurityOverride, Authentication
				if ($xml.configuration.location.path -like $null)
					{
					$object.Website = "Default"
					}
			 	if (($xml.configuration."system.webserver".security.authentication.anonymousAuthentication.enabled) -eq $true)
					{
					$object.Authentication = "Anonymous"  + "\" + ($xml.configuration."system.webserver".security.authentication.anonymousAuthentication.username)
					}
				
				$object.SecurityOverride = $xml.configuration.location.overridemode
				$array += $object
				}
		$array
		}
	"6" {
		[xml]$xml2 = Get-Content \\$server\c$\Windows\System32\inetsrv\metabase.xml
		$count = ($xml2.configuration.mbproperty.iiswebvirtualdir).count
		foreach ($i in ($xml2.configuration.mbproperty.iiswebvirtualdir))
			{
			if ($i.path -notlike $null)
				{
				$i.authflags
				}
			}
		}
	}