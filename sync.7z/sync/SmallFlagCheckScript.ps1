﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.57
	 Created on:   	5/14/2014 4:09 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
function checkforWdrive
{
	$User = whoami
	$hostmachine = hostname
	$x = 0
	do {
		$testpath = Test-Path -Path W:
		sleep 1
		$x++
	}
	until ($testpath -eq $true -or $x -ge 600)
	if ($x -ge 600)
	{
		Send-MailMessage "Flag error on host $hostmachine. Logged in user: $user"
	}
	else
	{
	.\batchfile.bat	
	}
}

checkforWdrive