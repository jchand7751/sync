﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/13/2016 1:46 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


#DC PROMO WRAPPER
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $True, Position = 0)]
	[string]$VMName,
	[Parameter(Mandatory = $True, Position = 0)]
	[string]$ClusterName,
	[Parameter(Mandatory = $True, Position = 0)]
	[string]$TemplateName,
	[Parameter(Mandatory = $True, Position = 0)]
	[string]$DatastoreClusterName,
	[Parameter(Mandatory = $True, Position = 0)]
	[string]$Sitename,
	[Parameter(Mandatory = $True, Position = 1)]
	[string]$IPAddress,
	[Parameter(Mandatory = $True, Position = 2)]
	[string]$DefaultGateway,
	[Parameter(Mandatory = $True, Position = 3)]
	[string]$PrefixLength,
	[Parameter(Mandatory = $True, Position = 4)]
	[string]$DNSServer1,
	[Parameter(Mandatory = $True, Position = 5)]
	[string]$DNSServer2,
	[Parameter(Mandatory = $True, Position = 5)]
	[string]$Location,
	[Parameter(Mandatory = $True, Position = 5)]
	[string]$VCenter,
	[Parameter(Mandatory = $False, Position = 5)]
	[string]$VSwitch,
	[Parameter(Mandatory = $False, Position = 5)]
	[string]$PortGroup
)
#$script = "c:\tmp\script.ps1 -Sitename Pimco-Cloud-NewJersey -IPAddress 10.155.71.12 -PrefixLength 24 -DefaultGateway 10.155.71.1 -DNSServers `"10.155.5.15`", `"10.155.5.16`" -Location NewJersey -User $($DomainCredential.Username) -Password $($domaincredential.getnetworkcredential().password)"

c:
Add-PSSnapin Quest.ActiveRoles.ADManagement
Add-PSSnapin VMware.VimAutomation.Core


#Variables for later
$LocalCredential = Get-Credential Administrator
$DomainCredential = Get-Credential "Core\"

#Join VMware
Connect-Viserver $VCenter -Credential $DomainCredential

#Clone from template
#This needs to be a copy of CloudDCPromo.ps1
$PathToScriptFile = "c:\tmp\CloudDCPromo.ps1"
#$VMName = "vms0h5gw002"
$Cluster = Get-Cluster -Name $ClusterName
$SourceTemplate = Get-Template -Name $TemplateName
$DatastoreCluster = Get-DatastoreCluster -Name $DatastoreClusterName
$VMHost = ($Cluster | Get-VMhost | sort memoryusageGB)[0]
$VM = New-VM -Name $VMName -Template $SourceTemplate -Datastore $DatastoreCluster -ResourcePool $VMHost

#Set the Port group if specified
if ($portgroup)
{
	$pg = Get-VDPortgroup -Name $portgroup -ea 'Stop'
	$VM | Set-NetworkAdapter -Portgroup $pg -Confirm:$false -ea 'Stop'
}

if ($vswitch)
{
	$vm | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $vswitch -Confirm:$false
}

#Resize primary disk
($vm | Get-HardDisk) | Set-HardDisk -CapacityGB 100 -confirm:$false

#Add 40gb Disk
$VM | New-HardDisk -CapacityGB 40

#Start VM
$VM | Start-VM

#Wait for the VM to start - *** change this to wait for vmware tools instead ***
sleep 60

#Update tools

#Copy Script to VM
Get-Item $PathToScriptFile | Copy-VMGuestFile -Destination c:\ -VM $VM -LocalToGuest -GuestUser "administrator" -GuestPassword $($localcredential.getnetworkcredential().password)

#Disable IPv6
#$registrypath = "HKLM:\system\CurrentControlSet\Services\TCPIP6"
#$regvaluename = "DisabledComponents"
#$regvalue = "4294967279"

$script = 'New-Item -Path "HKLM:\system\CurrentControlSet\Services\TCPIP6" -Force | Out-Null'
Invoke-VMScript -ScriptText $script -VM $VM -GuestCredential $LocalCredential

$script = 'New-ItemProperty -Path "HKLM:\system\CurrentControlSet\Services\TCPIP6" -Name "DisabledComponents" -Value "4294967279" -PropertyType DWORD -Force | Out-Null'
Invoke-VMScript -ScriptText $script -VM $VM -GuestCredential $LocalCredential

#Rename the VM
$script = "Rename-Computer -NewName $VMname -Force -PassThru -Restart"
Invoke-VMScript -ScriptText $script -VM $VM -GuestCredential $LocalCredential -ea 'SilentlyContinue'

#Create the AD site if it doesnt exist
Write-Warning "CREATE THE AD SITE MANUALLY THIS HASNT BEEN SCRIPTED YET"

sleep 30

#Execute the script
#$sitename = "Pimco-Cloud-NewJersey"
#$ipaddress = "10.155.71.11"
#$prefixlength = "24"
#$defaultgateway = "10.155.71.1"
#$dnsservers = "10.155.5.15", "10.155.5.16"
#$location = "newjersey"
Write-Host "Please CAREFULLY confirm the following as DC setup will start now:"
Write-Host ""
Write-host "IP Address: $IPAddress"
Write-host "Subnet Mask: $Prefixlength"
Write-host "Default Gateway: $DefaultGateway"
Write-host "DNS Server1: $DNSServer1"
Write-host "DNS Server2: $DNSServer2"
Write-host "Site name: $Sitename"
Write-host "OU/Location: $Location"
Write-Host ""
$confirm = Read-Host "Please confirm (y/n)"

$script = "c:\CloudDCPromo.ps1 -Sitename $Sitename -IPAddress $IPAddress -PrefixLength $PrefixLength -DefaultGateway $DefaultGateway -DNSServer1 $DNSServer1 -DNSServer2 $DNSServer2 -Location $Location -User $($DomainCredential.Username) -Password $($domaincredential.getnetworkcredential().password)"
Invoke-VMScript -ScriptText $script -VM $VM -GuestCredential $LocalCredential -ea 'SilentlyContinue'

Write-Host "Sleeping for 5min so the DC can initialize"
sleep 300

$FQDN = $VMName + ".core.pimcocloud.net"
Connect-QADService $FQDN -Credential $DomainCredential

#Create the OU location
try
{
	get-qadobject -OrganizationalUnit "OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net"
}
catch
{
	Write-Warning "OU=$location, OU=data_center, DC=core, DC=pimcocloud, DC=net doesn't seem to exist, creating it"
	try
	{
		New-QADObject -Type "OrganizationalUnit" -Name $location -ParentContainer "OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net" -Credential $DomainCredential
	}
	catch
	{
		Write-Warning "Failed to create: OU=$location, OU=data_center, DC=core, DC=pimcocloud, DC=net"
	}
}
try
{
	get-qadobject -OrganizationalUnit "OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net"
}
catch
{
	Write-Warning "OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net doesn't seem to exist, creating it"
	try
	{
		New-QADObject -Type "OrganizationalUnit" -Name "mgmt" -ParentContainer "OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net" -Credential $DomainCredential
	}
	catch
	{
		Write-Warning "Failed to create: OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net"
	}
}
try
{
	get-qadobject -OrganizationalUnit "OU=mgmt02,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net"
}
catch
{
	Write-Warning "OU=mgmt02,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net doesn't seem to exist, creating it"
	try
	{
		New-QADObject -Type "OrganizationalUnit" -Name "mgmt02" -ParentContainer "OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net" -Credential $DomainCredential
	}
	catch
	{
		Write-Warning "Failed to create: OU=mgmt02,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net"
	}
}
try
{
	get-qadobject -OrganizationalUnit "OU=domain_controllers,OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net"
}
catch
{
	Write-Warning "OU=domain_controllers,OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net doesn't seem to exist, creating it"
	try
	{
		New-QADObject -Type "OrganizationalUnit" -Name "domain_controllers" -ParentContainer "OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net" -Credential $DomainCredential
	}
	catch
	{
		Write-Warning "Failed to create: OU=domain_controllers,OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net"
	}
}
try
{
	get-qadobject -OrganizationalUnit "OU=domain_controllers,OU=mgmt02,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net"
}
catch
{
	Write-Warning "OU=domain_controllers,OU=mgmt02,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net doesn't seem to exist, creating it"
	try
	{
		New-QADObject -Type "OrganizationalUnit" -Name "domain_controllers" -ParentContainer "OU=mgmt02,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Service "core.pimcocloud.net" -Credential $DomainCredential
	}
	catch
	{
		Write-Warning "Failed to create: OU=domain_controllers,OU=mgmt02,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net"
	}
}

#Move DC to correct OU
Get-QADComputer $VMName | Move-QADObject -NewParentContainer "OU=domain_controllers,OU=mgmt,OU=$location,OU=data_center,DC=core,DC=pimcocloud,DC=net" -Credential $DomainCredential -Service core.pimcocloud.net

<#
$vmname = "vms0i5gw001"
$clustername = "csv0i5mgmtc001"
$templatename = "mgmtTemplate-Win2k12r2-Template"
$datastoreclustername = "csv0i5mgmtc001_dsc001"
$sitename = "Pimco-Cloud-Phoenix"
$ipaddress = "10.155.141.11"
$defaultgateway = "10.155.141.1"
$prefixlength = "24"
$dnsserver1 = "10.155.5.15"
$dnsserver2 = "10.155.5.16"
$location = "phoenix"
$vswitch = "Infra-Servers"
#$portgroup = ""
#>
