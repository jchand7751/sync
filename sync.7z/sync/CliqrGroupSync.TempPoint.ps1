﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/30/2016 4:24 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$GroupName,
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\CliqrGroupSync.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions
function Get-CliqrGroup
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$Name,
		[Parameter(Mandatory = $false, Position = 0)]
		$ID
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	$groups = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups?size=0" -s
	[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
	$jsonserial = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
	$jsonserial.MaxJsonLength = 500000000
	$groups = $jsonserial.DeserializeObject($groups)
	
	if ($Name)
	{
		$selectedgroup = ($groups.groups | where { $_.name -like $name })
		if ($selectedgroup -notlike $null)
		{
			$selectedgroup
		}
	}
	
	if ($ID)
	{
		$selectedgroup = ($groups.groups | where { $_.id -eq $ID })
		if ($selectedgroup -notlike $null)
		{
			$selectedgroup
		}
	}
	
	if ($Name -like $null -and $ID -like $null)
	{
		$groups.groups
	}
}
#endregion

#region Main
$ADGroups = Get-QADGroup -Name "Pimcloud*" -ManagedBy "CN=s_pimcldpr,OU=ServiceAccounts,OU=IA,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com" -DontUseDefaultIncludedProperties -IncludedProperties Samaccountname -SizeLimit 0
foreach ($group in $ADGroups[8])
{
	$ADgroupmembers = ($group | Get-QADGroupMember -DontUseDefaultIncludedProperties -IncludedProperties Samaccountname -SizeLimit 0).samaccountname
	$Cliqrgroupmembers = (Get-CliqrGroup -Name $group.samaccountname).users.externalId
	
	$compare = compare $cliqrgroupmembers $adgroupmembers
	$badCliqrUsers = ($compare | where { $_.sideindicator -eq "<=" }).inputobject
	foreach ($user in $badCliqrUsers)
	{
		
	}
}

#endregion
