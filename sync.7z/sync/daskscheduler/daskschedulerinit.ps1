﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/24/2016 3:36 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Base variables and environment information
$logfile = "c:\temp\DaskSchedulerSetup.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$server = hostname
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
$reposource = "http://10.155.5.63:8080/"
$whoami = whoami

#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

#endregion

LoadCliqrEnvVariables

#Download carbon
Start-BitsTransfer -Source http://10.155.5.63:8080/Carbon.dll -destination c:\temp\installed\ -ProxyUsage NoProxy

#create command prompt script
$file = New-Item -Type File c:\temp\daskscheduler.ps1
"net use w: \\pimco.imswest.sscims.com\dfsworkdev /Persistent:YES" | Out-File $file -Append -Encoding Default
'$env:PYTHONPATH=E:\apps\pimcloud\pimco_common\pypimco\LATEST-dev\pypimco' | Out-File $file -Append -Encoding Default
"E:\vendor\pimcloud\pimco_common\pypimco_infra\anaconda\400.1\pithon\Scripts\dask-scheduler.exe" | Out-File $file -Append -Encoding Default

#Register Dask scheduler as a Windows service
."C:\Program Files\osmosix\bin\nssm.exe" install Dask-Scheduler %SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe -executionpolicy bypass -file c:\temp\daskscheduler.ps1

if ($env:CliqrDepEnvName -eq "prod" -or $env:CliqrDepEnvName -eq "preprod")
{
	#Give service account admin rights?
	try
	{
		$serviceaccount = ($env:serviceaccount -split '\\')[-1]
		([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$serviceaccount") | Out-Null
	}
	catch
	{
		#Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
		#agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	}
}
else
{
	#Give service account admin rights?
	try
	{
		$serviceaccount = ($env:nonprodserviceaccount -split '\\')[-1]
		([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$serviceaccount") | Out-Null
	}
	catch
	{
		#Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
		#agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	}
}


if ($env:CliqrDepEnvName -eq "prod" -or $env:CliqrDepEnvName -eq "preprod")
{
	#Grant rights to logon as a service
	$Identity = $env:serviceaccount
	$privilege = "SeServiceLogonRight"
	$CarbonDllPath = "C:\temp\installed\Carbon.dll"
	[Reflection.Assembly]::LoadFile($CarbonDllPath)
	[Carbon.Lsa]::GrantPrivileges($Identity, $privilege)
}
else
{
	#Grant rights to logon as a service
	$Identity = $env:nonprodserviceaccount
	$privilege = "SeServiceLogonRight"
	$CarbonDllPath = "C:\temp\installed\Carbon.dll"
	[Reflection.Assembly]::LoadFile($CarbonDllPath)
	[Carbon.Lsa]::GrantPrivileges($Identity, $privilege)
}

#Change service account on windows service
if ($env:CliqrDepEnvName -eq "prod" -or $env:CliqrDepEnvName -eq "preprod")
{
	$Service = gwmi win32_service | where { $_.name -eq "Dask-Scheduler" }
	$Service.Change($Null, $Null, $Null, $Null, $Null, $Null, "$env:serviceaccount", $env:serviceaccountpassword, $Null, $Null, $Null)
	$Service.StartService()
}
else
{
	$Service = gwmi win32_service | where { $_.name -eq "Dask-Scheduler" }
	$Service.Change($Null, $Null, $Null, $Null, $Null, $Null, "$env:nonprodserviceaccount", $env:nonprodserviceaccountpassword, $Null, $Null, $Null)
	$Service.StartService()
}

