

$vms = "clv035pw-6cba8c", "clv035pw-39eb2b", "clv0h5pw-8490e1", "clv0h5pw-75c09d"


get-partition -DriveLetter E | Remove-Partition -Confirm:$false
get-partition -DriveLetter L | Remove-Partition -Confirm:$false
get-partition -PartitionNumber 0 | Remove-Partition -confirm:$false
New-Partition -Driveletter E -Size 50GB -disknumber 0 | format-volume -force -confirm:$false
New-Partition -Driveletter G -Size 300GB -disknumber 0 | format-volume -force -confirm:$false
New-Partition -Driveletter F -UseMaximumSize -disknumber 0 | format-volume -force -confirm:$false
([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/SQLAdmin") | Out-Null
