﻿
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[switch]$WhatIf
)
#endregion

#region Base variables and environment information
$logfile = "c:\scripts\logging\PimcloudGroupSync.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$key = Get-Content "c:\scripts\kf.key"
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"

$cred1 = "c:\scripts\k1.sec"
$pimcocredential = New-Object System.Management.Automation.PSCredential pimco\svc_iisadmin, (Get-Content $cred1 | ConvertTo-SecureString -Key $key)
$cred2 = "c:\scripts\k2.sec"
$corecredential = New-Object System.Management.Automation.PSCredential core\svc_iisadmin, (Get-Content $cred2 | ConvertTo-SecureString -Key $key)

Connect-QADService pimco.imswest.sscims.com -Credential $pimcocredential

$Groups  = Get-QADGroup "pimcloud-*"
foreach ($i in $Groups)
{
	Add-Log -Type 'Information' -Message "Processing group $($i.name)"
	$currentpimcogroupmembers = @()
	$currentpimcogroupmembers += (Get-QADGroup $i.name -Service pimco.imswest.sscims.com | get-qadgroupmember -Service pimco.imswest.sscims.com -SizeLimit 0).samaccountname
	$currentpimcogroupmembers
	Connect-QADService core.pimcocloud.net -Credential $corecredential | Out-Null
	$currentcoregroupmembers = @()
	$currentcoregroupmembers += (Get-QADGroup $i.name -Service core.pimcocloud.net | get-qadgroupmember -Service core.pimcocloud.net -SizeLimit 0).samaccountname
	$currentcoregroupmembers
	$comparison = compare $currentpimcogroupmembers $currentcoregroupmembers
	if ($comparison)
	{
		#need to add is <=
		foreach ($usertobeadded in ($comparison | where { $_.sideindicator -eq "<=" }))
		{
			Add-Log -Type 'Information' -Message "Adding $($usertobeadded.inputobject) to $($i.name)"
			Get-QADUser -SamAccountName "$($usertobeadded.inputobject)" -Service pimco.imswest.sscims.com -Credential $pimcocredential | Add-QADGroupMember $i.name -Service core.pimcocloud.net -Credential $corecredential
		}
		#need to remove is =>
		foreach ($usertoberemoved in ($comparison | where { $_.sideindicator -eq "=>" }))
		{
			Add-Log -Type 'Information' -Message "Removing $($usertoberemoved.inputobject) to $($i.name)"
			Get-QADUser -SamAccountName "$($usertoberemoved.inputobject)" -Service pimco.imswest.sscims.com -Credential $pimcocredential | Remove-QADGroupMember $i.name -Service core.pimcocloud.net -Credential $corecredential
		}
	}
	else
	{
		Add-Log -Type 'Information' -Message "No changes needed to $($i.name)"
	}
}
Add-Log -Type 'Information' -Message "Script complete"
#endregion