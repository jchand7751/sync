function Get-CyberArkAccount
{
	param ($Accountname, $safe)
	
	$request = c:\temp\curl.exe -H "Accept:application/json" -H "Authorization: $script:Authcode" https://10.155.60.21/PasswordVault/WebServices/PIMServices.svc/Accounts?keywords=$accountname`&safe=$safe -k -s -i -b c:\temp\cookiefile.txt
	#$request[-1]
	if ($request[0] -ne "HTTP/1.1 200 OK")
	{
		$request[1]
		throw "Failed to query Cyberark"
	}
	else
	{
		#$request
		if (($request[-1] | convertfrom-json).count -ne 0)
		{
			$result = ($Request[-1] | convertfrom-json).accounts.properties
			$object = "" | select ID, Safe, Folder, Name, UserName, PolicyID, LogonDomain, Address, DeviceType
			$object.ID = ($request[-1] | ConvertFrom-Json).accounts.accountid
			$object.Safe = $result[0].value
			$object.Folder = $result[1].value
			$object.Name = $result[2].value
			$object.UserName = $result[3].value
			$object.PolicyID = $result[4].value
			$object.LogonDomain = $result[5].value
			$object.Address = $result[6].value
			$object.DeviceType = $result[7].value
			$object
		}
		else
		{
			Write-Warning "Could not find an account matching $Accountname"
		}
	}
}