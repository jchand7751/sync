function Get-CyberArkCredential
{
	param ($Accountid)
	
	$request = c:\temp\Curl.exe -H "Accept:application/json" -H "Authorization: $script:Authcode" https://10.155.60.21/PasswordVault/WebServices/PIMServices.svc/Accounts/$accountid/Credentials -k -s -i -b c:\temp\cookiefile.txt
	if ($request[0] -ne "HTTP/1.1 200 OK")
	{ $request; throw "Failed to query Cyberark"; }
	else
	{
		#$result = ($Request | convertfrom-json).CyberArkLogonResult
		$result = $request[-1]
		$result
	}
}
