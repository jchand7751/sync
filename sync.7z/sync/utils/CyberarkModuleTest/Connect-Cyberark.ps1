function Connect-CyberArk
{
	param ($environment, $credentialfileuser, $credentialfile, $credentialkey)
	try
	{
		#$request = curl.exe -H "Accept: application/json" -H "Content-Type:application/json" https://exv035tw-cpma1/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -d "@jsonpw" -s
		if ($credentialfile)
		{
			$password = Get-Content $credentialfile | ConvertTo-SecureString -Key (Get-Content $credentialkey)
			$credential = New-Object System.Management.Automation.PSCredential $credentialfileuser, $password
		}
		else
		{
			$credential = Get-Credential
		}
		#$expression = "curl.exe -H `"Accept: application/json`" -H `"Content-Type:application`/json`" https://10.155.60.21/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -s -d --% `"`{`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`"`}`""
		$expression = "c:\temp\curl.exe -H `"Accept: application/json`" -c c:\temp\cookiefile.txt -H `"Content-Type:application`/json`" https://10.155.60.21/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -i -k -s -d --% `"`{`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`"`}`""
		
		$Request = Invoke-Expression $expression
		
		if ($request[0] -ne "HTTP/1.1 200 OK")
		{ throw "Failed to query Cyberark" }
		else
		{
		}
	}
	catch
	{
		Write-Warning "Caught Exception"
	}
	$script:Authcode = ($Request[-1] | convertfrom-json).CyberArkLogonResult
}