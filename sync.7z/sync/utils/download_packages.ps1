﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/12/2017 4:08 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#region Parameter set
[CmdletBinding(
			   DefaultParameterSetName = ”3”
			   )]
Param (
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '1')]
	[string]$Packages,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '1')]
	[string]$Vendor,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '3')]
	[string]$Variables = "aslkdja"
	
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\downloadpackages.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
#endregion

#region Base functions

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

function SendOSLogstoCliqr
{
	Add-Log -Type Information -Message "Sending OS log data to Cliqr"
	agentSendLogMessage "OS logs:"
	foreach ($line in (Get-Content $OSinitlogfile))
	{
		agentSendLogMessage $line
	}
}

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

function ExpandPackages
{
	$expandedpackages = @()
	#Expand Zips
	$downloadedzip = ls e:\apps\*.zip
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:packagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\apps\$extractpath\$basename -ea 'SilentlyContinue'
			Expand-ZIPFile E:\apps\$filename -destination e:\apps\$extractpath$basename
			$expandedpackages += "e:\apps\$extractpath"
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
		}
	}
	
	#Expand 7Zips
	$downloadedzip = ls e:\apps\*.7z
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:packagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\apps\$extractpath\$basename -ea 'SilentlyContinue'
			.'C:\Program Files\7-Zip\7z.exe' x E:\apps\$filename -oe:\apps\$extractpath$basename
			$expandedpackages += "e:\apps\$extractpath"
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
		}
	}
}

function ExpandVendor
{
	$expandedvendorpackages = @()
	
	#Expand vendor Zips
	$downloadedzip = ls e:\vendor\*.zip
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:vendorpackagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\vendor\$extractpath\$basename -ea 'SilentlyContinue'
			Expand-ZIPFile E:\apps\$filename -destination e:\apps\$extractpath$basename
			$expandedpackages += "e:\vendor\$extractpath"
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
		}
	}
	
	#Expand vendor 7Zips
	$downloadedzip = ls e:\vendor\*.7z
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:vendorpackagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\vendor\$extractpath\$basename -ea 'SilentlyContinue'
			.'C:\Program Files\7-Zip\7z.exe' x E:\vendor\$filename -oe:\vendor\$extractpath$basename
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand vendor package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand vendor package: $basename"
		}
	}
}

function DownloadPackages
{
	param ($URLs)
	#$packages = $env:packages
	$URLList = $ExecutionContext.InvokeCommand.Expandstring($urls)
	$script:packagearray = $URLList -split " "
	if ($script:packagearray)
	{
		foreach ($pkg in $script:packagearray)
		{
			#$pkg = $ExecutionContext.InvokeCommand.Expandstring($pkg)
			$filename = ($pkg -split "/")[-1]
			try
			{
				Add-Log -Type Information -Message "Downloading package: $pkg"
				#Start-BitsTransfer -Source $pkg -destination e:\apps -ProxyUsage NoProxy -ea 'Stop'
				wget $pkg -UseBasicParsing -OutFile e:\apps\$filename -ea 'Stop'
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to download package: $pkg - $($Error[0])"
				#agentSendLogMessage "$(executiontime) - Failed to download package: $pkg"
			}
		}
	}
}

function DownloadVendor
{
	param ($URLs)
	#$packages = $env:vendor
	$URLList = $ExecutionContext.InvokeCommand.Expandstring($urls)
	$script:vendorpackagearray = $URLList -split " "
	if ($script:vendorpackagearray)
	{
		foreach ($pkg in $script:vendorpackagearray)
		{
			$filename = ($pkg -split "/")[-1]
			try
			{
				Add-Log -Type Information -Message "Downloading vendor: $pkg"
				#Start-BitsTransfer -Source $pkg -destination e:\vendor -ProxyUsage NoProxy -ea 'Stop'
				wget $pkg -UseBasicParsing -OutFile e:\vendor\$filename -ea 'Stop'
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to download vendor package: $pkg - $($Error[0])"
				#agentSendLogMessage "$(executiontime) - Failed to download vendor package: $pkg"
			}
		}
	}
}

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

#Main
if ($PsBoundParameters.Keys.count -eq 0)
{
	$PSBoundParameters.Keys = "default"
}
$ProgressPreference = 'SilentlyContinue'
switch ($PsBoundParameters.Keys)
{
	"Packages" { DownloadPackages -URLs $Packages; ExpandPackages }
	"Vendor" { DownloadVendor -URLs $Vendor; ExpandVendor }
	default { LoadCliqrEnvVariables; DownloadPackages -URLs $env:packages; DownloadVendor -URLs $env:vendor; ExpandPackages; ExpandVendor }
}