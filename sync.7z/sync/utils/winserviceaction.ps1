﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/06/2017 4:08 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	winserviceacton.ps1
	===========================================================================
	.DESCRIPTION
		Start/Stop/Restart a service (or multiple services).
#>
#region Parameter set
[CmdletBinding(
			   DefaultParameterSetName = ”1”
			   )]
Param (
	[Parameter(Mandatory = $true, Position = 0, ParameterSetName = '1')]
	[string]$Action,
	
	[Parameter(Mandatory = $true, Position = 0, ParameterSetName = '1')]
	[string]$Servicename
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\winserviceaction.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions

function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	#Import-module ModuleName -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Main

try
{
    if ((get-service -name $servicename -ea stop) -like $null)
    {
        if ((get-service -displayname $servicename -ea stop) -like $null)
        {
            Add-Log -Type 'Information' -Message "Performing $action on $servicename"
            $expression = "get-service -displayname ""$servicename"" -ea stop | $action-service -ea stop"
            #write-host $expression
            invoke-expression $expression
        }
        else
        {
            Add-Log -Type 'Error' -Message "Can't find a service name with $serviceName or displayname $servicename" -Throw
        }
    }
    else
    {
        Add-Log -Type 'Information' -Message "Performing $action on $servicename"
        $expression = "get-service -name ""$servicename"" -ea stop | $action-service -ea stop"
        #write-host $expression
        invoke-expression $expression
    }
}
catch
{
    exit 1
}
#endregion  

