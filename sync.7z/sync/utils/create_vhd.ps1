﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/03/2017 4:08 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Map a virtual disk.
#>
#region Parameter set
[CmdletBinding(
			   DefaultParameterSetName = ”3”
			   )]
Param (
	[Parameter(Mandatory = $true, Position = 0, ParameterSetName = '1')]
	[string]$DriveLetter,
	
	[Parameter(Mandatory = $true, Position = 0, ParameterSetName = '1')]
	[string]$SizeinMB
)
#endregion

#region Base variables and environment information
$logfile = "c:\pimcloud\logs\createvhd.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions

function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	#Import-module ModuleName -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

function CreateVirtualDrive($driveletter, $drivesizeMB)
{
    try
    {
        Add-Log -Type 'Information' -Message "Creating Virtual Disk with drive letter $driveletter and Mounting Disk Image"
        if ((Test-Path c:\pimcloud\virtualdisks) -eq $false)
        {
            try
            {
                New-Item -type Directory -Path c:\pimcloud\virtualdisks -ea stop| Out-Null
            }
            catch
            {
                Add-Log -Type 'Error' -Message "Unable to create virtualdisks folder"
            }
        }
        cmd /c echo create vdisk file=c:\pimcloud\virtualdisks\${driveletter}drive.vhd maximum=$drivesizeMB type=expandable | diskpart
        Mount-DiskImage -ImagePath "C:\pimcloud\virtualdisks\${driveletter}drive.vhd" -ea stop | Out-Null

        Add-Log -Type 'Information' -Message "Initializing Disk and Creating New Partition"
        (Get-Disk | where {$_.FriendlyName -eq "Microsoft Virtual Disk" -and $_.partitionstyle -eq "raw"}) | Initialize-Disk | Out-Null
        $vhd = (Get-Disk | where {$_.FriendlyName -eq "Microsoft Virtual Disk" -and $_.numberofpartitions -eq 1}).number
        New-Partition -DiskNumber $vhd -DriveLetter $driveletter -ea stop -UseMaximumSize | Out-Null
        Format-Volume -DriveLetter $driveletter -Force -confirm:$false -ea stop | Out-Null
    }
    catch
    {
        Add-Log -Type 'Error' -Message "Unable to Create Virtual Drive"
    }

}

function SetStartup
{
    $xml = Get-Content C:\pimcloud\cliqr-scripts\windows\utils\MapDrive.xml
    $xml = $xml -replace "C:\\temp\\wdrive.vhd", "C:\pimcloud\virtualdisks\${driveletter}drive.vhd"
    $xml | Out-File c:\pimcloud\virtualdisks\MapDrive.xml -Force
	Add-Log -Type 'Information' -Message "Creating a task on local server"
	schtasks /Create /XML c:\pimcloud\virtualdisks\MapDrive.xml /TN "MapDrive-${driveletter}" /F
}

#Main
CreateVirtualDrive -DriveLetter $DriveLetter -DriveSizeMB $sizeinMB
SetStartup