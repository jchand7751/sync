﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   3/5/2014 8:44 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1,ParameterSetName='Location1')]
		[string]$Username
	)

function CheckForModule
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1,ParameterSetName='Location1')]
		[string]$ModuleName
	)
	$ModuleList = Get-Module -list
	$TestModule = $ModuleList | where {$_.name -eq $ModuleName}
	if ($TestModule)
	{
		$ModuleRunning = Get-Module -Name $ModuleName
		if ($ModuleRunning)
		{
			Log "$ModuleName is already loaded"
		}
		else
		{
			Import-Module -Name $ModuleName	
			Log "$ModuleName has been loaded"
		}
	}
	else
	{
		Write-Warning "The required module $modulename is not installed"
		Log "$ModuleName is not installed"
		exit
	}
}

function CheckForSnapin
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1,ParameterSetName='Location1')]
		[string]$SnapinName
	)
	$SnapinList = Get-PSSnapin -Registered
	$TestSnapin = $SnapinList | where {$_.name -eq $SnapinName}
	if ($TestSnapin)
	{
		$SnapinRunning = Get-PSSnapin -Name $ModuleName
		if ($SnapinRunning)
		{
			Log "$SnapinName is already loaded"
		}
		else
		{
			Add-PSSnapin -Name $SnapinName	
			Log "$SnapinName has been loaded"
		}
	}
	else
	{
		Write-Warning "The required PSSnapin $SnapinName is not installed"
		Log "$SnapinName is not installed"
		exit
	}
}

#Define environment information
$global:FullScriptPath = $MyInvocation.MyCommand.Definition
$global:CurrentScriptName = $MyInvocation.MyCommand.Name
$global:CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$global:ExecutionTime = logstamp -script
$Executedby = whoami
LoggingSetup

#Load required Snapins and Modules
CheckForSnapin Quest.ActiveRoles.ADManagement
CheckForModule lync
CheckForModule BaseModule2

#Get the User
$usersettings = Get-QADUser -SamAccountName $username -ErrorVariable $err -IncludedProperties msRTCSIP-PrimaryUserAddress, msRTCSIP-PrimaryHomeServer, msRTCSIP-UserEnabled

if ($usersettings)
{
	$usersettings | select name, samaccountname, msRTCSIP-PrimaryUserAddress, msRTCSIP-PrimaryHomeServer, msRTCSIP-UserEnabled
}
else
{
	Write-Warning "A user with samaccountname $username was not found"
	Log $global:logpath "A user with samaccountname $username was not found"
}

#Check for email address on account

foreach ($i in $users1) 
{
	enable-csuser -Identity $i.ntaccountname -RegistrarPool "lyncnbfepool.pimco.imswest.sscims.com" -SipAddressType emailaddress -whatif
}