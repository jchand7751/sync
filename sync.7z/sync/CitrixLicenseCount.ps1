﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   1/10/2014 9:36 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

Function Get-FolderSize
{
Param ($folder)
$a = get-childitem $folder -recurse -Force | measure-object -property length -sum
$sizecheck = ([string]$a.sum).length
if ($sizecheck)
    {
    $b = "{0:N1}" -f ($a.sum / 1024 /1024)
    $resultob = new-object system.object
    $resultob | add-member -type noteproperty -name "folder" -value $folder
    $resultob | add-member -type noteproperty -name "sum" -value $a.sum
    $resultob | add-member -type noteproperty -name "size" -value "$b MB"
    $resultob
    }
    else
        {
        $b = "{0:N1}" -f ($a.sum / 1024 /1024)
        $resultob = new-object system.object
        $resultob | add-member -type noteproperty -name "folder" -value $folder
        $resultob | add-member -type noteproperty -name "sum" -value $a.sum
        $resultob | add-member -type noteproperty -name "size" -value "$b MB"
        $resultob
        }
}  

$array = @()
#$root = "\\pimco.imswest.sscims.com\dfspimcohome"
#$root = "\\imswest.sscims.com\dfsimshome"
$root = "\\nasprod"
$root = "\\nasprodplt\home"
#$subfolders = "Accounting", "AppDev", "Invsup", "Systems"


$subfolders = Get-ChildItem $root
$subfolders = $subfolders | where {$_.PSIsContainer -eq $true}
foreach ($folder in $subfolders)
	{
	$userfolders = Get-Childitem $root\$folder
	$userfolders = $userfolders | where {$_.PSIsContainer -eq $true}
	foreach ($usersubfolder in $userfolders)
		{
		#$object = "" | select FolderChecked, User, TSProfileExists, CreationTime, LastAccessTime
		$object = "" | select FolderChecked, User, ProfileExists, ProfileV2Exists, ProfileSize, ProfileV2Size, TSProfileExists, TSProfileSize
		
		$object.folderchecked = "$root\$folder\$usersubfolder\private\"
		$object.User = $usersubfolder.name
		$object.ProfileExists = (Test-Path $root\$folder\$usersubfolder\private\Profile)
		$object.ProfileV2Exists = (Test-Path $root\$folder\$usersubfolder\private\Profile.V2)
		$object.TSProfileExists = (Test-Path $root\$folder\$usersubfolder\private\TSProfile)
		if ($object.ProfileExists -eq $true)
			{
			#$TSPath = Get-Item $root\$folder\$usersubfolder\private\tsprofile.v2
			#$object.CreationTime = $TSPath.CreationTime
			#$object.LastAccessTime = $TSPath.LastAccessTime
			$object.profilesize = (Get-FolderSize $root\$folder\$usersubfolder\private\Profile).size
			}
			else
				{
				#$object.CreationTime = "Folder not found"
				#$object.LastAccessTime = "Folder not found"
				}
		if ($object.Profilev2Exists -eq $true)
			{
			#$TSPath = Get-Item $root\$folder\$usersubfolder\private\tsprofile.v2
			#$object.CreationTime = $TSPath.CreationTime
			#$object.LastAccessTime = $TSPath.LastAccessTime
			$object.profilev2size = (Get-FolderSize $root\$folder\$usersubfolder\private\Profile.V2).size
			}
			else
				{
				#$object.CreationTime = "Folder not found"
				#$object.LastAccessTime = "Folder not found"
				}
		if ($object.TSProfileExists -eq $true)
			{
			#$TSPath = Get-Item $root\$folder\$usersubfolder\private\tsprofile.v2
			#$object.CreationTime = $TSPath.CreationTime
			#$object.LastAccessTime = $TSPath.LastAccessTime
			$object.TSprofilesize = (Get-FolderSize $root\$folder\$usersubfolder\private\TSProfile).size
			}
			else
				{
				#$object.CreationTime = "Folder not found"
				#$object.LastAccessTime = "Folder not found"
				}
		$object
		$array += $object
		}
	}

$array | Export-Csv c:\Temp\CitrixLicenseCountSizeplt.csv