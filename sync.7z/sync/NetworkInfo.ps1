﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/25/2013 9:58 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param($Computer)

$tc = Test-Connection -ComputerName $Computer -Count 1 -Quiet
if ($tc -eq $true)
	{
	$gatherinfo = "" | select Hostname, IPaddress, SubnetMask, DefaultGateway, DNSServerSearchorder, WinsPrimary, WinsSecondary, DNSDomainSuffixSearchorder

	$networkstats = (get-wmiobject win32_networkadapterconfiguration -computer $Computer) | where {$_.ipenabled -eq $true}
	$connectionstats = get-wmiobject win32_networkadapter -computer $Computer | where {$_.netconnectionid -notlike $null}
	$gatherinfo.dnsdomainsuffixsearchorder = [string]$networkstats.dnsdomainsuffixsearchorder
	$gatherinfo.dnsserversearchorder = [string]$networkstats.dnsserversearchorder
	#$gatherinfo.macaddress = $networkstats.macaddress
	$gatherinfo.hostname = $computer
	$gatherinfo.ipaddress = [string]$networkstats.ipaddress
	$gatherinfo.subnetmask = [string]$networkstats.IPsubnet
	$gatherinfo.defaultgateway = [string]$networkstats.defaultipgateway
	$gatherinfo.winsprimary = $networkstats.winsprimaryserver
	$gatherinfo.winssecondary = $networkstats.winssecondaryserver
	#$gatherinfo.dnsdomain = $networkstats.dnsdomain
	#$gatherinfo.netconnection = $script:connectionstats.netconnectionID
	#$gatherinfo.domain = $computerstats.domain
	$gatherinfo
	}
	else
		{
		$gatherinfo = "" | select Hostname, IPaddress, SubnetMask, DefaultGateway, DNSServerSearchorder, WinsPrimary, WinsSecondary, DNSDomainSuffixSearchorder
		$gatherinfo.hostname = $computer
		$gatherinfo.IPAddress = "Host is offline"
		$gatherinfo
		}