﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/24/2015 3:00 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:		Get-Handle.ps1     	
	===========================================================================
	.DESCRIPTION
		Remotely check what process is holding the specified file open.
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 1)]
	[string]$Server,
	
	[Parameter(Mandatory = $true, Position = 2)]
	[string]$File,
	
	[switch]$Kill
)
$path = Split-Path $file
if (Test-Path ("\\" + $server + "\" + ($path -replace ":", "$")))
{}
else
{
	Throw "Path not found"
}

#Make sure handle is on the server
if (Test-Path \\$server\e$\tools\handle.exe)
{ }
else
{
	Throw "Handle is not installed"
}
#Invoke handle remotely and capture the results
try
{
	$handleresults = invoke-command $server { e:\tools\handle.exe $args -accepteula } -Args $path -ErrorAction Stop
}
catch
{
	Throw "Server invoking is not configured"
}
#Put the handle results into an object and then add it into an array
$handlecount = ($handleresults.count)
if ($handleresults[5] -eq "No matching handles found.")
{
	Write-Host "No matching handles found."
}
else
{
	$array = @()
	foreach ($line in $handleresults[5..$handlecount])
	{
		$object = "" | select Name, PID, Type, File
		$linecount = ((($line -split " pid: ") -split "type: ") -split " ").count
		$object.name = (((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[0]
		$object.pid = (((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[1]
		$object.type = (((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[2]
		$object.file = [string]((((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[4..$linecount])
		#$object
		if ($object.name -ne "System")
		{
			$array += $object
		}
	}
	#$array
	$results = $array | where { $_.file -eq $file }
	if ($results)
	{
		$results | foreach ($_) { Write-Host "$file is being held open by process $($_.pid) with name $($_.name)" }
		#$results
		if ($Kill)
		{
			$results | select PID -Unique | foreach ($_.pid) {
				Write-Host "Stopping process $($_.pid) on $Server"
				try
				{
					Invoke-Command $Server { Stop-Process -Id $args -WhatIf } -Args $($_.pid) -ea 'Stop'
				}
				catch
				{
					Write-Host "Failed to stop process $($_.pid) on $Server"
				}
			}
		}
		else
		{
			Write-Host "Results did not match the specified file"
		}
	}
}