﻿# ==============================================================================================
# 
# Microsoft PowerShell Source File -- Created with SAPIEN Technologies PrimalScript 2014
# 
# NAME: 
# 
# AUTHOR: PIMCO Administrator , PIMCO
# DATE  : 7/11/2014
# 
# COMMENT: 
# 
# ==============================================================================================

#Get-LastLoggedOn

Param ($computer, $logontype, $datestart, $dateend)

$today = get-Date 
#Get-Date -UFormat "%Y-%m-%d"
$counter = -1
#$cleanend = $today.adddays(+1)
do
{
    #$datestart = "2014-07-10"
    #$dateend = "2014-07-14"
    $cleanstart = $today.adddays($counter)
    $cleanend = ($today.adddays(1)).adddays($counter)

    $datestart = Get-Date $cleanstart -UFormat "%Y-%m-%d"
    $dateend = Get-Date $cleanend -UFormat "%Y-%m-%d"
    $counter--

    #$uglydatestring = "TimeCreated[@SystemTime&gt;='$($datestart)T07:00:01.000Z' and @SystemTime&lt;='$($dateend)T06:59:00.999Z'"
    $uglydatestring = "TimeCreated[@SystemTime&gt;='$($datestart)T08:00:01.000Z' and @SystemTime&lt;='$($dateend)T07:59:00.999Z'"

    #$Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624)  and $($uglydatestring)]]]</Select></Query></QueryList>" -Computername $computer
    $Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[EventData[Data[@Name='LogonType'] and (Data='7') or (Data='2') or (Data='11') or (Data='10')]] and *[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624) and $($uglydatestring)]]]</Select></Query></QueryList>" -Computername $computer
    #$Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[EventData[Data[@Name='LogonType'] and (Data='7') or (Data='2') or (Data='11') or (Data='10')]] and *[System[(EventID=4624)]]</Select></Query></QueryList>" -Computername $computer
   
    $ResultArray = @()

    for ($x = 0; $x -lt $Events.count; $x++)
    {
	    $object = "" | select ComputerName, User, LogonTime, LogonType

	    $object.computername = $computer
	    #Filter 2
	    $tempfile = [io.path]::GetTempFileName()
	    $object.logontime = $Events[$x].timecreated.tostring()
	    $Events[$x].message | Out-File $tempfile
	    $CleanMessage = Get-Content $tempfile
	    $loggedonuser = (((Get-Content $tempfile | Select-String "Account Name:")[1]) -replace "Account Name:", "").trimend("").trimstart("")
	    $object.user = $loggedonuser
	    $logontype = ((Get-Content $tempfile | select-string "logon type:") -replace "Logon Type:", "").trimend("").trimstart("")
	    #$logontype
	    switch ($logontype)
	    {
		    "11" { $object.logontype = "Cached login" }
            "10" { $object.logontype = "Remote login" }
            "7" { $object.logontype = "Unlock" }
		    "2" { $object.logontype = "Local login" }
		    "3" { $object.logontype = "Network login" }
	    }
	    Remove-Item $tempfile -Force
	    #$object
	    if ($ResultArray | where { $_.logontime -eq $object.logontime })
	    {
		    #write-host "duplicate found, skipping"
	    }
	    else
	    {
		    $ResultArray += $object
	    }
    }
    $ResultArray
    #read-host "full day search"
}
until ($resultarray | where {$_.logontype -eq "Unlock" -or $_.logontype -eq "Local Login" -or $_.logontype -eq "Remote Login" -or $_.logontype -eq "Cached Login"})
($resultarray | where {$_.logontype -eq "Unlock" -or $_.logontype -eq "Local Login" -or $_.logontype -eq "Remote Login" -or $_.logontype -eq "Cached Login"})