﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/1/2016 11:36 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$paths = "\\nasprodpmwin\pimcoapps_dev\pmapps\BatchReports", "\\nasprodpmwin\pimcoapps_beta\pmapps\BatchReports", "\\nasprodpmwin\pimcoapps_prod\pmapps\BatchReports"
$array = @()
foreach ($path in $paths)
{
	$permissionsugly = (Get-Acl $path).access
	
	foreach ($i in $permissionsugly)
	{
		$object = "" | select Path, UserorGroup, Permission
		$object.Path = $path
		$object.UserorGroup = $i.identityreference
		$object.Permission = ($i.FileSystemRights -replace ", Synchronize")
		$object
		$array += $object
	}
}

