﻿Param ($watchpath)
#v1/apps/pimcloud/$department/$project/$component/$environment/$environment/$artifactorylabel/version
"http://pimcloudcmdb/v1/kv/v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version - value 1.1.61"

$watchpath = "v1/apps/pimcloud/bogusdepartment/bogusproject/boguscomponent/dev/LATEST-trunk/version"

$value = .\consul.exe kv get $watchpath

powershell.exe "C:\pimcloud\cliqr-scripts\windows\iis\CliqrIISPackageUpdate.ps1" -Packages $env:packages