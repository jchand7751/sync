﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/12/2016 11:40 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($Groupname, $Computer)
function GetLocalGroupMembership
{
	param ($Groupname, $Computer)
	$Group = [ADSI]"WinNT://$Computer/$GroupName,group"
	$Members = @($group.psbase.Invoke("Members"))
	$members | foreach { $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null) }
}

GetLocalGroupMembership -Groupname $Groupname -Computer $computer