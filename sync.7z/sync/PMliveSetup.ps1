﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/6/2017 12:49 PM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$pypimcoVersion = $env:pypimcoVersion,
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$pypimcobasepath = $env:pypimcobasepath
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\PMliveSetup.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
#endregion

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile

function StartDask
{
	try
	{
		Add-Log -Type 'Information' -Message "Starting Dask services"
		Get-Service -Name Dask* | foreach { Add-Log -Type 'Information' -Message "Starting $($_.name)"; $_ | Start-Service -ea 'Stop' }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to start Dask services"
	}
}

function StopDask
{
	try
	{
		Add-Log -Type 'Information' -Message "Stopping Dask service"
		Get-Service -Name Dask* | foreach { Add-Log -Type 'Information' -Message "Stopping $($_.name)"; $_ | Stop-Service -Force -ea 'Stop' }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to stop Dask services"
	}
}

function SetupSybaseOdbc
{
	try
	{
		Get-OdbcDsn -Name "Sybase" -ErrorAction Stop
	}
	catch
	{
		Add-OdbcDsn -Name "Sybase" -DsnType "System" -DriverName "Adaptive Server Enterprise" -Platform "64-bit" -SetPropertyValue @("Server=trdbserver", "Port=5010")
	}
}

function ensure_tr_tas
{
	try
	{
		$tr_tas_ip = [System.Net.Dns]::GetHostAddresses("tr_tas")[0].IPAddressToString
	}
	catch
	{
		$tr_tas_ip = [System.Net.Dns]::GetHostAddresses("tr_tas.pimco.com")[0].IPAddressToString
		Add-Content  C:\Windows\System32\drivers\etc\hosts "`n$tr_tas_ip        tr_tas`n"
	}
}


function ExpandZip
{
	param ($downloadedzip, $extractlocation)
	$expandedpackages = @()
	#Expand Zips
	foreach ($zip in $downloadedzip)
	{
		if ((get-item $zip).extension -eq ".zip")
		{
			try
			{
				#Add-Log -Type Information -Message "Expanding $($zip.basename)"
				$basename = $zip.basename
				$filename = ($zip -split "\\")[-1]
				$extractpath = $extractlocation
				Expand-ZIPFile -file $zip -destination $extractpath
			}
			catch
			{
				#Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
				#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
			}
		}
	}
	
	#Expand 7Zips
	foreach ($zip in $downloadedzip)
	{
		if ((get-item $zip).extension -eq ".7z")
		{
			try
			{
				#Add-Log -Type Information -Message "Expanding $($zip.basename)"
				$basename = $zip.basename
				$filename = ($zip -split "\\")[-1]
				$extractpath = $extractlocation
				.'C:\Program Files\7-Zip\7z.exe' x $zip -o`$extractpath
			}
			catch
			{
				#Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
				#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
			}
		}
	}
}

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}
Add-Log -Type 'Information' -Message "Starting PM Live setup"
if (Test-Path "$pypimcobasepath\$pypimcoversion\pypimco\binary\w")
{
	rm $pypimcobasepath\$pypimcoversion\pypimco\binary\w -Recurse -Force
}
mkdir $pypimcobasepath\$pypimcoversion\pypimco\binary\w
expandzip -downloadedzip $pypimcobasepath\$pypimcoversion\pypimco\binary\w_environment.zip -extractlocation $pypimcobasepath\$pypimcoversion\pypimco\binary


. subst W: /D
. subst W: "$($pypimcobasepath)\$($pypimcoversion)\pypimco\binary\w"

SetupSybaseOdbc
ensure_tr_tas
if ((Get-Service -Name Dask*) -eq $null)
{ }
else
{
	StopDask
	StartDask
}
Add-Log -Type 'Information' -Message "PM Live setup complete"