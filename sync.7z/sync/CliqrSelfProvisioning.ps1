﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/14/2016 6:27 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Cliqr self-provisioning.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	$jsonticket
)
#endregion

#region Base variables and environment information
$logfile = "E:\scripts\CliqrSelfProvisioning\cliqrselfprovisioning.log"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#Jira credential
$password = Get-Content c:\secure\secure.p | ConvertTo-SecureString
$credential = New-Object System.Management.Automation.PSCredential pimco\s_jiraauto, $password
$password = $credential.getnetworkcredential().password
$account = "s_jiraauto"
$creds = $account + ":" + $password

#Cliqr credential
$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"

#s_pimcldpr
$pw = Get-Content c:\secure\secure1.p | ConvertTo-SecureString
$groupaddcredential = New-Object System.Management.Automation.PSCredential pimco\s_pimcldpr, $pw

#Issue ID
$issueid = $jsonticket.issue.key

#Selected clouds
$selectedclouds = $jsonticket.issue.fields.customfield_13700.value
$selectedenvironments = $jsonticket.issue.fields.customfield_13700.value

$cloudarray = @()
switch ($selectedclouds)
{
	"Sandbox" { $selectedclouds = $cloudarray += 1 }
	"Dev" { $selectedclouds = $cloudarray += 2 }
	"Beta" { $selectedclouds = $cloudarray += 3 }
	"Pre-prod" { $selectedclouds = $cloudarray += 4 }
	"prod" { $selectedclouds = $cloudarray += 5 }
}

#Requestor
$requestor = $jsonticket.issue.fields.reporter.name

#Selected department
$selecteddept = $jsonticket.issue.fields.customfield_11201.value

#Department Mapping
switch ($selecteddept)
{
	"Analytics" { $selecteddept = "analytics" }
	"Business Dept/User" { "" }
	"HR" { "" }
	"IMS" { $selecteddept = "infra" }
	"Tech: Client Facing, Management, Strategic" { $selecteddept = "cftech" }
	"Tech: Core / Technical Architecture" { $selecteddept = "coresvc" }
	"Tech: Data Architecture" { "" }
	"Tech: Front Office Tech" { $selecteddept = "fotech" }
	"Tech: Infra" { $selecteddept = "infra" }
	"Tech: PM Apps" { $selecteddept = "pmapps" }
	"Tech: Security" { $selecteddept = "security" }
	"Tech: Services or Operations" { $selecteddept = "techsvc" }
	"Tech: Trade Legal Compliance" { $selecteddept = "tlc" }
}

#endregion

#region Script functions

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting Script"
try
{
	Connect-QADService Pimco.imswest.sscims.com -ea 'Stop' | Out-Null
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Could not connect to domain" -Throw
}

try
{
	$user = Get-QADUser -SamAccountName $requestor -ea 'Stop'
	if ($user)
	{ }
	else
	{
		throw "Could not find the specified user $requestor"
	}
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Could not find the specified user $requestor" -Throw
}

#User Department Mapping
switch ($user.department)
{
	"Analytics" { $userdept = "analytics" }
	"Business Dept/User" { "" }
	"HR" { "" }
	"IMS" { $userdept = "infra" }
	"TECH-CF & Strategic Proj" { $userdept = "cftech" }
	"TECH-Management" { $userdept = "coresvc" }
	"Tech: Data Architecture" { "" }
	"TECH-Front Office" { $userdept = "fotech" }
	"TECH-Infrastructure" { $userdept = "infra" }
	"TECH-PM Applications" { $userdept = "pmapps" }
	"Tech: Security" { $userdept = "security" }
	"TECH-Technical Services" { $userdept = "techsvc" }
	"Tech: Trade Legal Compliance" { $userdept = "tlc" }
}

try
{
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" } -ea 'Stop'
	$cliqrusers = ($cliqrusers | ConvertFrom-Json -ea 'Stop').users
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Cliqr user query failed" -Throw
}

#Check for an existing Cliqr user
if (!($cliqrusers | where { $_.externalid -eq $requestor }))
{
	#User wasn't found in the Cliqr user lookup, create a new account
	#Stage new User with Activation profile (using AD variables)
	Add-Log -Type 'Information' -Message "Creating a new user Cliqr user for $requestor"
	Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/" -d "{ `"`"firstName`"`": `"`"$($user.firstname)`"`", `"`"lastName`"`": `"`"$($user.lastname)`"`", `"`"password`"`": `"`"===redacted===`"`", `"`"emailAddr`"`": `"`"$($user.email)`"`", `"`"companyName`"`": `"`"$($user.department)`"`", `"`"phoneNumber`"`": `"`"`"`", `"`"externalId`"`": `"`"$($user.samaccountname)`"`", `"`"tenantId`"`": 1, `"`"activationProfileId`"`": 8 } " } -ea 'Stop'
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" } -ea 'Stop'
	$cliqrusers = ($cliqrusers | ConvertFrom-Json -ea 'Stop').users
	$selectedcliqruser = ($cliqrusers | where { $_.externalid -eq $requestor })
	#clouds no longer needed
	<#
	foreach ($cloud in $selectedclouds)
	{
		Add-Log -Type 'Information' -Message "Adding $requestor to cloud $cloud - cliqr ID is $($selectedcliqruser.id)"
		Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/$($selectedcliqruser.id)" -d "{ `"`"action`"`": `"`"MANAGE_CLOUDS`"`", `"`"manageCloudsData`"`": { `"`"activateRegions`"`": [ { `"`"regionId`"`": `"`"$cloud`"`" } ], `"`"storageSize`"`": 0 } } " } -ea 'Stop'
	}
	#>
}
else
{
	$selectedcliqruser = ($cliqrusers | where { $_.externalid -eq $requestor })
	#Add user to selected clouds - no longer needed
	<#
	foreach ($cloud in $selectedclouds)
	{
		Add-Log -Type 'Information' -Message "Cliqr user found for $requestor"
		Add-Log -Type 'Information' -Message "Adding $requestor to cloud $cloud"
		Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/$($selectedcliqruser.id)" -d "{ `"`"action`"`": `"`"MANAGE_CLOUDS`"`", `"`"manageCloudsData`"`": { `"`"activateRegions`"`": [ { `"`"regionId`"`": `"`"$cloud`"`" } ], `"`"storageSize`"`": 0 } } " } -ea 'Stop'
	}
	#>
}

#Verify
try
{
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0&detail=true" } -ea 'Stop'
	$cliqrusers = ($cliqrusers | ConvertFrom-Json -ea 'Stop').users
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Could not query Cliqr users" -Throw
}

$usersregions = ($cliqrusers | where { $_.externalid -eq $requestor }).detail.regions

#No longer need regions
<#
$checkregionarray = @()
foreach ($region in $selectedclouds)
{
	$checkregionarray += ($usersregions -contains $region)
}

if ($checkregionarray -contains $false)
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Region add failed" -Throw
}
else
{
	Add-Log -Type 'Information' -Message "Region(s) verified"
}
#>

#Group adds
try
{
	foreach ($environment in $selectedenvironments)
	{
		$environment
		switch ($environment)
		{
			"Sandbox" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-sandbox"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-sandbox -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$selecteddept-sandbox"
					$user | Add-QADMemberOf -Group pimcloud-$selecteddept-sandbox -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"Dev" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-dev"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-dev -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$selecteddept-dev"
					$user | Add-QADMemberOf -Group pimcloud-$selecteddept-dev -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"Beta" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-beta"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-beta -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$selecteddept-beta"
					$user | Add-QADMemberOf -Group pimcloud-$selecteddept-beta -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"Pre-prod" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-preprod"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-preprod -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$selecteddept-preprod"
					$user | Add-QADMemberOf -Group pimcloud-$selecteddept-preprod -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"prod" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-prod"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-prod -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$selecteddept-prod"
					$user | Add-QADMemberOf -Group pimcloud-$selecteddept-prod -ea 'Stop' -Credential $groupaddcredential
				}
			}
		}
		
	}
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Information' -Message "Group add failed" -Throw
}

curl.exe -k -u $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Request completed successfully"" }'
curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""51"" }}'
Add-Log -Type 'Information' -Message "Setup for $requestor complete"
#endregion