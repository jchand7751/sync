﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/25/2013 11:13 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
import-module Microsoft.dhcp.powershell.admin
$scopes = get-dhcpscope -server vms001p4

$array = @()
foreach ($i in $scopes)
	{
	$object = "" | select ScopeName, Address, Mask, Description, IPRanges, ExclusionRanges, Reservations, DefaultGateway, DNSServers, WINSServers
	$object.scopename = $i.name
	$object.address = $i.address
	$object.mask = $i.subnetmask
	$object.defaultgateway = if ([string]($i.options | where {$_.optionname -eq "Router"}).values) {[string]($i.options | where {$_.optionname -eq "Router"}).values} else {"Not defined"}
	$object.dnsservers = if ([string](($i.options | where {$_.optionname -eq "DNS servers"}).values)) {[string](($i.options | where {$_.optionname -eq "DNS servers"}).values)} else {"Not defined"}
	$object.WINSServers =  if ([string](($i.options | where {$_.optionname -eq "WINS/NBNS Servers"}).values)) {[string](($i.options | where {$_.optionname -eq "WINS/NBNS Servers"}).values)} else {"Not defined"}
	$object.description = if ($i.description){$i.description} else {"Not defined"} 
	$object.ipranges = [string]$i.ipranges
	$object.exclusionranges = if ([string]$i.exclusionranges) {[string]$i.exclusionranges} else {"Not defined"}
	$object.reservations = if ([string]$i.reservations) {[string]$i.reservations} else {"Not defined"}
	$object
	$array += $object
	}