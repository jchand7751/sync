﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/23/2015 4:11 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($Computer)
$logpath = "\\nasprodpm3\PimcoApps\PMApps\Pimlib\logs"

if (Test-Connection -ComputerName $computer -Count 1 -Quiet)
{
	$Getitems = Get-childitem \\$computer\c$\scratch\pimlib_fun*
	foreach ($item in $Getitems)
	{
		$destinationpath = $logpath + "\" + ($item.name -split "\.")[0] +"." + ($item.name -split "\.")[1] + "." + $computer + "." + (([string]($item.name -split "\.")[2..10]) -replace " ", ".")
		#copy-item $item.fullname $logpath -force
		copy-item $item.fullname $destinationpath -force
	}
		#(gwmi -win32_computersystem -computer $computer).username
}