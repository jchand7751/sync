﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/30/2015 12:13 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($server, $samaccountname)
function LookupProfileLastUseTime
{
	param ($server, $samaccountname)
	
	$object = "" | select Server, LogonName, LastLogon
	#Find the user's sid
	$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$samaccountname))"
	$user = $searcher.FindOne().GetDirectoryEntry()
	$binarySID = $user.ObjectSid.Value
	$stringSID = (New-Object System.Security.Principal.SecurityIdentifier($binarySID, 0)).Value
	#$stringSID
	#Take the sid and search for a match on the server, convert the time into a useful format
	$lastusetime = ([WMI] '').ConvertToDateTime(((gwmi win32_userprofile -comp $server | where { $_.sid -eq $stringSID -and $_.lastusetime -notlike $Null }).lastusetime)).toshortdatestring()
	$object.Server = $server
	$object.LogonName = $samaccountname
	if ($lastusetime)
	{
		$object.LastLogon = $lastusetime
	}
	else
	{
		Write-Warning "Could not find a matching profile for $samaccountname"
		$object.LastLogon = "Not found"
	}
	$object
}
LookupProfileLastUseTime $server $samaccountname