﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/11/2015 10:35 AM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:	ExcelAddinInventory.ps1     	
	===========================================================================
	.DESCRIPTION
		Excel Addin inventory login script.
#>
#Variables and Environment setup
$logfile = "C:\temp\ExcelAddinLog.txt"

function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

Add-Content -Path $logfile "$(executiontime) - Starting script"

try
{
	$excel = new-object -comobject Excel.Application -ea 'Stop'
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - Error: Could not create Excel sessions via com object"
	exit
}

if (Test-Path c:\temp\exceladdins.csv)
{
	
	try
	{
		Remove-Item c:\temp\exceladdins.csv
		($excel.addins | select Title, FullName) | export-csv c:\temp\exceladdins.csv
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Error: Could not remove or create export file"
		exit
	}
}
else
{
	try
	{
		($excel.addins | select Title, FullName) | export-csv c:\temp\exceladdins.csv
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Error: Could not create export file"
		exit
	}
}