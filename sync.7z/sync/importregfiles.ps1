﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/14/2015 12:04 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Appsense registry import script.
#>

#Set Variables
$computername = hostname
$whoami = whoami
$domain = ($whoami -split "\\")[0]
$user = ($whoami -split "\\")[1]
$logfile = "C:\temp\RegImport-$user-$computername.txt"

#Functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

#Create log file
New-Item -Type File $logfile -Force

Add-Content -Path $logfile "$(executiontime) - Script started"

<#
$regfiles = Get-ChildItem -Path c:\temp\$env:username

#Rename the reg files from .txt to .reg
foreach ($file in $regfiles)
{
	Add-Content -Path $logfile "$(executiontime) - Renaming $($file.FullName) to $($file.BaseName).reg"
	try
	{
		Rename-Item $file.FullName ($file.BaseName + ".reg") -ErrorAction Stop
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to rename $($file.FullName)"
	}
}
#>

#Get the renamed reg files
$updatedregfiles = Get-ChildItem -Path c:\temp\$env:username

#Import the renamed reg files
foreach ($file in $updatedregfiles)
{
	Add-Content -Path $logfile "$(executiontime) - Importing reg file $($file.FullName)"
	regedit /S $file.FullName
}

<#Remove the user from local admins
#Started working totally clueless as to why...
try
{
	([ADSI]"WinNT://localhost/Administrators,group").Remove("WinNT://$domain/$user")
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - Failed to remove $domain\$user from local admins"
	exit
}
#>

#Clean up this script
try
{
	Remove-Item C:\temp\importregfiles.ps1 -Force
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - Failed to clean up script file"
}

#Remove the Task


#Force log off because you keep admin rights otherwise
#logoff

Add-Content -Path $logfile "$(executiontime) - Script finished"