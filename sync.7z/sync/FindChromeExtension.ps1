﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/2/2017 1:26 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
Connect-QADService pimco.imswest.sscims.com
$Computers = Get-QADComputer -operatingSystem "Windows 7*" -SizeLimit 0
$array = @()
foreach ($computer in $Computers[300..320])
{
	if ((Test-Connection -ComputerName $($computer.name) -Count 1 -Quiet) -eq $true)
	{
		$userpath = Get-ChildItem -Directory \\$($computer.name)\c$\users\
		foreach ($user in $userpath)
		{
			$object = "" | select Computer, User, Result, Version
			$object.Computer = $($computer.name)
			if ((Test-Path "\\$($computer.name)\c$\users\$($user.Name)\AppData\Local\Google\Chrome\User Data\Default\Extensions\jlhmfgmfgeifomenelglieieghnjghma\") -eq $true)
			{
				Write-Host "Found the extension!"
				$object.User = $user.Name
				$object.Result = "Found"
				$object.Version = [string](Get-ChildItem -Directory "\\$($computer.name)\c$\users\$($user.Name)\AppData\Local\Google\Chrome\User Data\Default\Extensions\jlhmfgmfgeifomenelglieieghnjghma\")
				$array += $object
			}
			else
			{
				$object.User = $user.Name
				$object.Result = "Not found"
				$object.Version = "N/A"
				$array += $object
			}
		}
	}
	else
	{
		$object = "" | select Computer, User, Result, Version
		$object.Computer = $($computer.name)
		$object.User = "N/A"
		$object.Result = "PC Offline"
		$object.Version = "N/A"
		$array += $object
	}
}
$array | Export-Csv c:\temp\ChromeExtensionsAllPCs.csv -Force