﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/15/2016 11:03 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$a = import-csv H:\Private\AppSense\find1011.csv
$nb10PCs = $a | where { $_.computer -like "nb-10*" }
$nb10users = ($nb10pcs | where { $_.user -notlike "<none>" }).user

foreach ($i in $nb10users)
{
	$i
	Set-GPPermissions -Name "TEST - SybaseCheckUK" -TargetName $i -TargetType User -PermissionLevel GpoApply -server vms001p5
}


$nb11PCs = $a | where { $_.computer -like "nb-11*" }
$nb11users = ($nb11pcs | where { $_.user -notlike "<none>" }).user
foreach ($i in $nb11users)
{
	$i
	Set-GPPermissions -Name "TEST - SybaseCheckUK" -TargetName $i -TargetType User -PermissionLevel GpoApply -server vms001p5
}