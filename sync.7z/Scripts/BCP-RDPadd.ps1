﻿[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer,
    
    [ValidateScript({if (Test-Path $_) { if (((import-csv $_)[0])."computer name") { $script:computerlist = import-csv $_ ; $True } else { throw "CSV is not in the correct format" }}
        else {
            Throw "Path is not valid"
        }})]
    [string[]]$File
)

function csvexport
{
    [CmdletBinding(DefaultParameterSetName='Delimiter',
      SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    param(
     [Parameter(Mandatory=$true, ValueFromPipeline=$true,
               ValueFromPipelineByPropertyName=$true)]
     [System.Management.Automation.PSObject]
     ${InputObject},

     [Parameter(Mandatory=$true, Position=0)]
     [Alias('PSPath')]
     [System.String]
     ${Path},
 
     #region -Append (added by Dmitry Sotnikov)
     [Switch]
     ${Append},
     #endregion 

     [Switch]
     ${Force},

     [Switch]
     ${NoClobber},

     [ValidateSet('Unicode','UTF7','UTF8','ASCII','UTF32',
                      'BigEndianUnicode','Default','OEM')]
     [System.String]
     ${Encoding},

     [Parameter(ParameterSetName='Delimiter', Position=1)]
     [ValidateNotNull()]
     [System.Char]
     ${Delimiter},

     [Parameter(ParameterSetName='UseCulture')]
     [Switch]
     ${UseCulture},

     [Alias('NTI')]
     [Switch]
     ${NoTypeInformation})

    begin
    {
     # This variable will tell us whether we actually need to append
     # to existing file
     $AppendMode = $false
 
     try {
      $outBuffer = $null
      if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer))
      {
          $PSBoundParameters['OutBuffer'] = 1
      }
      $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand('Export-Csv',
        [System.Management.Automation.CommandTypes]::Cmdlet)
        
        
     #String variable to become the target command line
     $scriptCmdPipeline = ''

     # Add new parameter handling
     #region Dmitry: Process and remove the Append parameter if it is present
     if ($Append) {
  
      $PSBoundParameters.Remove('Append') | Out-Null
    
      if ($Path) {
       if (Test-Path $Path) {        
        # Need to construct new command line
        $AppendMode = $true
    
        if ($Encoding.Length -eq 0) {
         # ASCII is default encoding for Export-CSV
         $Encoding = 'ASCII'
        }
    
        # For Append we use ConvertTo-CSV instead of Export
        $scriptCmdPipeline += 'ConvertTo-Csv -NoTypeInformation '
    
        # Inherit other CSV convertion parameters
        if ( $UseCulture ) {
         $scriptCmdPipeline += ' -UseCulture '
        }
        if ( $Delimiter ) {
         $scriptCmdPipeline += " -Delimiter '$Delimiter' "
        } 
    
        # Skip the first line (the one with the property names) 
        $scriptCmdPipeline += ' | Foreach-Object {$start=$true}'
        $scriptCmdPipeline += '{if ($start) {$start=$false} else {$_}} '
    
        # Add file output
        $scriptCmdPipeline += " | Out-File -FilePath '$Path'"
        $scriptCmdPipeline += " -Encoding '$Encoding' -Append "
    
        if ($Force) {
         $scriptCmdPipeline += ' -Force'
        }

        if ($NoClobber) {
         $scriptCmdPipeline += ' -NoClobber'
        }   
       }
      }
     } 
  

  
     $scriptCmd = {& $wrappedCmd @PSBoundParameters }
 
     if ( $AppendMode ) {
      # redefine command line
      $scriptCmd = $ExecutionContext.InvokeCommand.NewScriptBlock(
          $scriptCmdPipeline
        )
     } else {
      # execute Export-CSV as we got it because
      # either -Append is missing or file does not exist
      $scriptCmd = $ExecutionContext.InvokeCommand.NewScriptBlock(
          [string]$scriptCmd
        )
     }

     # standard pipeline initialization
     $steppablePipeline = $scriptCmd.GetSteppablePipeline(
            $myInvocation.CommandOrigin)
     $steppablePipeline.Begin($PSCmdlet)
 
     } catch {
       throw
     }
    
    }

    process
    {
      try {
          $steppablePipeline.Process($_)
      } catch {
          throw
      }
    }

    end
    {
      try {
          $steppablePipeline.End()
      } catch {
          throw
      }
    }
    <#

    .ForwardHelpTargetName Export-Csv
    .ForwardHelpCategory Cmdlet

    #>
}


function testaccess
{
    Param ($computer)
    write-verbose "Verifying computer is online"
    if ((Test-Connection -ComputerName $computer -count 1 -Quiet) -eq $true)
    {
    }
    else
    {
        $logfile = "C:\temp\Rdplogfile.txt"
        $csvlog = "C:\temp\csvlogfile.csv"
        if ((Test-Path $logfile) -ne $true)
        {
            New-Item -ItemType file $logfile | out-null
        }
        write-warning "$computer appears to be offline"
        Add-Content -value "$computer appears to be offline" -Path $logfile
        throw "$Computer appears to be offline"
    }
}

function checkforacurrentlogonuser
{
    Param ($computer)

    if (((gwmi win32_computersystem -comp $computer).username))
    {
        $script:userlogin = (((gwmi win32_computersystem -comp $computer).username) -split "PIMCO\\")[1]
    }
    else
    {
        throw "No logged on user"
    }
}

function findlastlocallogonuser
{
    Param ($computer)

    write-verbose "Checking event logs for a recent logon"
    $today = get-Date 
    #Get-Date -UFormat "%Y-%m-%d"
    $counter = 0
    #$cleanend = $today.adddays(+1)
    do
    {
        #$datestart = "2014-07-10"
        #$dateend = "2014-07-14"
        $cleanstart = $today.adddays($counter)
        $cleanend = ($today.adddays(1)).adddays($counter)

        $datestart = Get-Date $cleanstart -UFormat "%Y-%m-%d"
        $dateend = Get-Date $cleanend -UFormat "%Y-%m-%d"
        $counter--

        #$uglydatestring = "TimeCreated[@SystemTime&gt;='$($datestart)T07:00:01.000Z' and @SystemTime&lt;='$($dateend)T06:59:00.999Z'"
        $uglydatestring = "TimeCreated[@SystemTime&gt;='$($datestart)T08:00:01.000Z' and @SystemTime&lt;='$($dateend)T07:59:00.999Z'"

        $Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624)  and $($uglydatestring)]]]</Select></Query></QueryList>" -Computername $computer
        $ResultArray = @()

        for ($x = 0; $x -lt $Events.count; $x++)
        {
	        $object = "" | select ComputerName, User, LogonTime, LogonType

	        $object.computername = $computer
	        #Filter 2
	        $tempfile = [io.path]::GetTempFileName()
	        $object.logontime = $Events[$x].timecreated.tostring()
	        $Events[$x].message | Out-File $tempfile
	        $CleanMessage = Get-Content $tempfile
	        $loggedonuser = (((Get-Content $tempfile | Select-String "Account Name:")[1]) -replace "Account Name:", "").trimend("").trimstart("")
	        $object.user = $loggedonuser
	        $logontype = ((Get-Content $tempfile | select-string "logon type:") -replace "Logon Type:", "").trimend("").trimstart("")
	        #$logontype
	        switch ($logontype)
	        {
		        "11" { $object.logontype = "Cached interactive login" }
                "10" { $object.logontype = "Remote login" }
                "7" { $object.logontype = "Unlock" }
		        "2" { $object.logontype = "Local login" }
		        "3" { $object.logontype = "Network login" }
	        }
	        Remove-Item $tempfile -Force
	        #$object
	        if ($ResultArray | where { $_.logontime -eq $object.logontime })
	        {
		        #write-host "duplicate found, skipping"
	        }
	        else
	        {
		        $ResultArray += $object
	        }
        }
        #$ResultArray
        #read-host "full day search"
        #$counter
    }
    until (($resultarray | where {$_.logontype -eq "Unlock" -or $_.logontype -eq "Local Login" -or $_.logontype -eq "Cached interactive login" -or $_.logontype -eq "Remote login"}) -or $counter -ge 3)
    
    if ($resultarray | where {$_.logontype -eq "Unlock" -or $_.logontype -eq "Local Login" -or $_.logontype -eq "Cached interactive login" -or $_.logontype -eq "Remote login"})
    {
        $script:userlogin = (($resultarray | where {$_.logontype -eq "Unlock" -or $_.logontype -eq "Local Login" -or $_.logontype -eq "Cached interactive login" -or $_.logontype -eq "Remote login"})[0]).user
    }
}

function addusertoRDPgroup
{
    Param ($computer)

    if ((([ADSI]"WinNT://$computer/Remote Desktop Users,group").psbase.invoke("Members") | foreach-object {$_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)}) -contains $script:userlogin)
    {
        $script:status = "Exists"
    }
    else
    {
        try 
        {
            $script:status = "Success"
            ([ADSI]"WinNT://$computer/Remote Desktop Users,group").Add("WinNT://pimco/$script:userlogin")
        }
        catch
        {
            #write-warning "Adding user $script:userlogin failed"
            $script:status = "Failed"
        }
    }
}

function writechangelog
{
    Param ($computer)

    $logfile = "C:\temp\Rdplogfile.txt"
    $csvlog = "C:\temp\csvlogfile.csv"
        if ((Test-Path $logfile) -ne $true)
        {
            New-Item -ItemType file $logfile | out-null
        }

    $object = "" | select user, desktop, status
    $object.user = $script:userlogin
    $object.desktop = $computer
    $object.status = $script:status
    if (Test-path $csvlog)
    {
        #$object | export-csv -Append -Path $csvlog
        $object | csvexport -Append -Path $csvlog
    }
    else
    {
        New-Item -ItemType file $csvlog | out-null
        $object | export-csv -Path $csvlog
    }

    switch ($script:status)
    {
        "Exists" {
                    Add-Content "$script:userlogin (Name: $($script:ADobject.properties.name) - Department: $($script:ADobject.properties.department)) was already added to Remote Desktop Users group on $Computer" -Path $logfile
                    write-warning "$script:userlogin (Name: $($script:ADobject.properties.name) - Department: $($script:ADobject.properties.department)) was already added to Remote Desktop Users group on $Computer"
                 }
        "Failed" {
                    Add-Content "Failed to add $script:userlogin (Name: $($script:ADobject.properties.name) - Department: $($script:ADobject.properties.department)) to Remote Desktop Users group on $Computer" -Path $logfile
                    write-warning "Failed to add $script:userlogin (Name: $($script:ADobject.properties.name) - Department: $($script:ADobject.properties.department)) to Remote Desktop Users group on $Computer"
                 }
        default {
                    Add-Content "Successfully added $script:userlogin (Name: $($script:ADobject.properties.name) - Department: $($script:ADobject.properties.department)) to Remote Desktop Users group on $Computer" -Path $logfile
                    write-host "Successfully added $script:userlogin to Remote Desktop Users group on $Computer"
                }
    }
}

function adlookup
{
    Param($samname)

    $searcher = [adsisearcher]"(Samaccountname=$samname)"
    $searcher.searchroot = "LDAP://DC=Pimco,DC=imswest,DC=sscims,DC=com"
    $script:ADobject = $searcher.findone()
    #.properties.department
}

function Main
{
    Param($computer)
    
    $logfile = "C:\temp\Rdplogfile.txt"
    $csvlog = "C:\temp\csvlogfile.csv"    
    $stopflag = $false
    try 
    {
        testaccess $computer
    }
    catch
    {
        $stopflag = $true
    }

    if ($stopflag -ne $true)
    {
        try 
        {
            write-verbose "Checking for a current logged on user"
            checkforacurrentlogonuser $computer
        }
        catch
        {
            $error[0]
            write-verbose "A current logged on user was not found"
            findlastlocallogonuser $computer
        }
        finally
        {
            if ($script:userlogin)
            {
                write-verbose "Adding found user to RDP group"
                adlookup $script:userlogin
                addusertoRDPgroup $computer
                writechangelog $computer
            }
            else
            {
                write-warning "A user could not be found locally or from logs on $computer, exiting"
                Add-Content "A user could not be found locally or from logs on $computer, exiting" -Path $logfile
            }
        }
    }
}

### Running ###
if ($script:computerlist)
{
    foreach ($i in $script:computerlist)
    {
        Main $i."computer name"
    }
}
else
{
    Main $Computer
}