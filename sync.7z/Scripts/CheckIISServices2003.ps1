﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/12/2013 6:46 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param ($comp)

#2003 Check IIS services

$testcon = Test-Connection $comp -Quiet -Count 1
if ($testcon)
	{
	$result1 = $null
	$checksmtp = Get-service -Name SMTPSVC -Comp $comp
	$checkFTP = Get-Service -Name msftpsvc -Comp $comp
	$checkNNTP = Get-Service -Name nntpsvc -Comp $comp
	if ($checksmtp)
		{
		[string]$result1 = [string]$result1 + "SMTP;"
		}
	if ($checkftp)
		{
		[string]$result1 = [string]$result1 + "FTP;"
		}
	if ($checkNNTP)
		{
		[string]$result1 = [string]$result1 + "NNTP;"
		}
	$result1
	}
#ASP check