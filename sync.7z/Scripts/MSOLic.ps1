﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/3/2017 2:21 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Add-PSSnapin Quest.ActiveRoles.ADManagement
Import-Module MSOnline
Import-Module MSOnlineExtended

#$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString)
#$msolcredential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
$msolcredential = Get-Credential

#Get-QADUser -samaccountname jchandle | Set-QADUser -ObjectAttributes @{ cloudsync = "Yammer Enterprise|Microsoft Dynamics CRM Online Professional|Office 365 ProPlus"}


#Connect to the tenant
try
{
	Connect-MSOLService -Credential $msolcredential -ea Stop | Out-Null
}
catch
{
	throw "Failed to connect to O365 tenant!"
}
#Connect to local domain
try
{
	Connect-QADService pimco.imswest.sscims.com -ea Stop | Out-Null
}
catch
{
	throw "Failed to connect to local domain!"
}

#Get enabled cloud users
#$cloudusers = Get-QADUser -LdapFilter "(cloudsync=true)" -SizeLimit 0
$cloudusers = Get-QADUser -LdapFilter "(cloudsync=*)" -SizeLimit 0 -IncludedProperties cloudsync, AccountIsDisabled
#Get all synced users
$msonlineusers = Get-MSOLUser -All

$cloudusers = $cloudusers | where { $_.name -eq "chandler, james" }
#$cloudusers = $cloudusers | where { $_.name -eq "Dao, Neo" }
#Loop through enabled cloud users
foreach ($user in $cloudusers)
{
	#Find the specific user in the loop
	$selecteduser = $msonlineusers | where { $_.userprincipalname -eq $user.email }
	if ($selecteduser)
	{
		#Create a sku list from the cloudsync attribute
		$msonlineskulist = $selecteduser.licenses.accountskuid
		
		#Add product skus
		#$selecteduser.licenses[0].servicestatus
		
		$licenselist = Get-Content -Raw -Path c:\tmp\products2.json | ConvertFrom-Json
		$currentlist = Get-Content -Raw -Path c:\tmp\products2.json | ConvertFrom-Json
		
		
		$fulllicense = ((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -notlike "*-*" }
		$dividedlicense = ((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -like "*-*" }
		
		<#
		Using the JSON license list ($licenselist) as a base,
		enable divided licenses products that match the cloudsync attribute
		#>
		foreach ($lic in $dividedlicense)
		{
			#parent of product
			$parent = $lic.substring(0, 2)
			#product
			$product = $lic.substring(3, ($lic.length - 3))
			#subproducts of parent
			$productlist = ($licenselist | where { $_.licensename -eq $parent }).products
			#Enable the product
			($productlist | where { $_.productname -eq $product }).status = "Enabled"
		}
		
		<#
		Using the JSON license list ($licenselist) as a base,
		enable full licenses (all products) that match the cloudsync attribute on the 
		#>
		foreach ($lic in $fulllicense)
		{
			$productlist = ($licenselist | where { $_.licensename -eq $lic }).products
			#Enable the product
			#($productlist | where { $_.productname -eq "All" }).status = "Enabled"
			foreach ($product in $productlist)
			{
				$product.status = "Enabled"
			}
		}
		
		<#
		Using the JSON license list ($currentlist) as a base,
		enable divided licenses products that match 
		#>
		foreach ($lic in $selecteduser.licenses)
		{
			$parent = $lic
			$parentsku = "PIMCO:" + $lic.accountsku.skupartnumber
			foreach ($enabled in ($parent.servicestatus | where { $_.provisioningStatus -ne "Disabled" }))
			{
				(($currentlist | where { $_.licensesku -eq $parentsku }).products | where { $_.productsku -eq $($enabled.serviceplan.servicename) }).status = "Enabled"
			}
		}
		
		$mismatchflag = @()
		
		#Loop through the sku list and find out if each product sku is enabled or disabled via AD attribute
		$skulist = $licenselist.products.productsku
		foreach ($sku in $skulist)
		{
			switch (($licenselist.products | where { $_.productsku -eq $sku }).status)
			{
				"Enabled" {
					if (($licenselist.products | where { $_.productsku -eq $sku }).status -ne ($currentlist.products | where { $_.productsku -eq $sku }).status)
					{
						$object = "" | select Action, SKU, LicenseName
						$object.Action = "Enable"
						$object.SKU = $sku
						$object.LicenseName = ($licenselist | where { $_.products.productsku -eq $sku }).licensename
						Write-Host "$sku is enabled in Active Directory - Need to enable in O365"
						$mismatchflag += $object
					}
				}
				"Disabled" {
					if (($licenselist.products | where { $_.productsku -eq $sku }).status -ne ($currentlist.products | where { $_.productsku -eq $sku }).status)
					{
						$object = "" | select Action, SKU, LicenseName
						$object.Action = "Disable"
						$object.SKU = $sku
						$object.LicenseName = ($licenselist | where { $_.products.productsku -eq $sku }).licensename
						Write-Host "$sku is not enabled in Active Directory - Need to disable in O365"
						$mismatchflag += $object
					}
				}
			}
		}
		
		#Remove existing licenses if the account is disabled in AD
		if ($user.AccountIsDisabled -eq $true)
		{
			Write-Host "Removing all licenses from $($selecteduser.userprincipalname)"
			$selecteduser | Set-MsolUserLicense -RemoveLicenses
		}
		
		$uniquelicensemismatch = $mismatchflag.licensename | sort -unique
		foreach ($licensename in $uniquelicensemismatch)
		{
			foreach ($selectedlicense in ($licenselist | where { $_.licensename -eq $licensename }))
			{
				$DisabledPlans = [string]($selectedlicense.products | where { $_.status -eq "Disabled" }).productsku -replace (" ", "`", `"")
				$DisabledPlans = "`"" + $DisabledPlans + "`""
				#$selectedlicense.licensesku
				#$DisabledPlans
				#$newMSOL = New-MsolLicenseOptions -AccountSkuId $selectedlicense.licenseSku -DisabledPlans $DisabledPlans
				if ($selecteduser.licenses.accountskuid -contains $($selectedlicense.licenseSku))
				{
					$newMSOL = Invoke-Expression "New-MsolLicenseOptions -AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$selecteduser | Set-MsolUserLicense -Licenseoptions $newMSOL
				}
				else
				{
					$newMSOL = Invoke-Expression "New-MsolLicenseOptions -AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$selecteduser | Set-MsolUserLicense -Licenseoptions $newMSOL -AddLicenses $($selectedlicense.licenseSku)
				}
			}
		}
		
		#If all the products are disabled, remove the top level license
		foreach ($license in $licenselist)
		{
			if ($license.products.status -contains "enabled")
			{ }
			else
			{
				if ($selecteduser.licenses.accountskuid -contains $($license.licensesku))
				{
					Write-Host "Removing $($license.licensesku)"
					$selecteduser | Set-MsolUserLicense -RemoveLicenses $license.licensesku
				}
			}
			
		}
	}
	else
	{
		Write-Warning "Could not find $($user.samaccountname) in O365 users"
	}
}

