﻿Connect-qadservice vms001p4

$array = @()

$ADComputers = get-qadcomputer -sizelimit 0 | select Name, Description, Managedby

foreach ($srv in $ADComputers)
{
    $object = "" | select Name, Description, Managedby, Environment, Sybase
    $object.name = $srv.name
    $object.description = $srv.description
    $object.managedby = ((($srv.managedby).split(",")[1..0] -join (" ") -replace "CN=") -replace "\\").trimstart(" ")
    
    #Get environment
    $checkenv = $srv.name.substring(6,1)
    
    switch ($checkenv)
    {
        "p" {$object.environment = "Production"}
        "b" {$object.environment = "Beta"}
        "d" {$object.environment = "Development"}
        "a" {$object.environment = "Alpha"}
    }
    
    if ((Test-path "\\$($srv.name)\c$") -eq $true)
    {
        if ((Test-Path "\\$($srv.name)\c$\Sybase") -eq $true)
        {
            $object.sybase = "True"
        }
        else 
        {
            $object.sybase = "False"
        }
        $object
        $array += $object
    }
    
}