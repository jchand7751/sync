﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/5/2016 5:00 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

import-module NTFSSecurity -Force
import-module GroupPolicy -Force

$array = @()
$a = get-childitem "\\pimco\sysvol\PIMCO.IMSWEST.SSCIMS.com\Policies"
foreach ($i in $a)
{
	$object = "" | select GPOGuid, Account, AccessRights, IsInherited, GPODisplayName
	$b = (Get-NTFSAccess -Path $i.fullname -Account "NT AUTHORITY\Authenticated Users");
	$object.GPOguid = $i.name;
	$object.account = $b.account.accountname;
	$object.accessrights = $b.accessrights
	$object.IsInherited = $b.isinherited
	$object.GPODisplayName = (Get-GPO -Guid $i.name -Domain pimco.imswest.sscims.com).displayname
	$object
	$array += $object
}

$a = Get-Content c:\temp\thelist.txt
foreach ($i in $a)
{
	Set-GPPermissions -Name $i -PermissionLevel GPORead -TargetName "NT AUTHORITY\Authenticated Users" -Targettype group -Domain Pimco.imswest.sscims.com -WhatIf
}