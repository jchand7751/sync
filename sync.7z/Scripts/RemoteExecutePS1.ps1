﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/11/2013 4:41 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param($comp)

$testcon = Test-Connection $comp -Quiet -Count 1
if ($testcon)
	{
	Copy c:\CheckIISServices.ps1 \\$comp\c$
	Copy c:\cats.bat \\$comp\c$
	$expression1 = "set-executionpolicy -scope CurrentUser bypass -confirm:$false"
	$expression2 = "c:\CheckIISServices.ps1"
	$commandBytes1 = [System.Text.Encoding]::Unicode.GetBytes($expression1)
	$commandBytes2 = [System.Text.Encoding]::Unicode.GetBytes($expression2)

	$encodedCommand1 = [Convert]::ToBase64String($commandBytes1)
	$encodedCommand2 = [Convert]::ToBase64String($commandBytes2)

	.\psexec \\$comp cmd /c "echo . | c:\cats.bat"
	.\psexec \\$comp cmd /c "echo . | powershell -EncodedCommand $encodedCommand2"
	Remove-Item \\$comp\c$\cats.bat -force
	Remove-Item \\$comp\c$\CheckIISServices.ps1 -force
	}