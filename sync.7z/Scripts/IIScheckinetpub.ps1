﻿$array = @()
$a = Get-Content c:\Temp\IISservs.txt
foreach ($i in $a) 
	{
	$object = "" | select Name, PingTest, CTest, InetTest, EInet, URLscan, IIS, ftp, smtp, nntp, asp
	$b = test-connection $i -quiet -count 1
	if ($b -eq $true)
	{
		$c = test-path \\$i\c$
		$d = test-path \\$i\c$\inetpub
		$e = Test-Path \\$i\e$\inetpub
		$f = Test-Path \\$i\c$\windows\system32\inetsrv\URLscan
		$object.name = $i
		$object.Pingtest = $b
		$object.Ctest = $c
		$object.inettest = $d
		$object.EInet = $e
		$object.urlscan = $f
		$object.IIS = (Get-Service -ComputerName $i w3svc).status
		$object.ftp = (Get-Service -ComputerName $i ftpsvc).status
		$object.smtp = (Get-Service -ComputerName $i smtpsvc).status
		$object.nntp = (Get-Service -ComputerName $i nntpsvc).status
		$object.asp = (Get-Service -ComputerName $i aspnet_state).status
		#$object
		$array += $object
	}
	else
	{
		$object.name = $i
		$object.Pingtest = $b
		$object.Ctest = "Offline"
		$object.inettest = "Offline"
		$object.EInet = "Offline"
		$object.urlscan = "Offline"
		$object.IIS = "Offline"
		$object.ftp = "Offline"
		$object.smtp = "Offline"
		$object.nntp = "Offline"
		$object.asp = "Offline"
		#$object
		$array += $object
	}
}
$array | Export-Csv c:\Temp\IIScheck.csv
