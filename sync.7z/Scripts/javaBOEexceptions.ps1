﻿#Change Security level
$javapath = "$env:userprofile\AppData\LocalLow\Sun\Java"
$whoami = ((whoami) -split "\\")[1]
$script:LogPath = "C:\temp\JavaBOEExceptions-$whoami.txt"
$script:counter = 1
$timestamp = (Get-Date -UFormat %Y-%m-%d-%H%M)

#old URLs
#http://businessobjects.pimco.imswest.sscims.com:8080
#http://businessobjects:8080

#Create the log file
if  ((Test-Path $LogPath) -eq $true)
{
	#if ((Get-Content $LogPath | Select-String "Security level verified" -Quiet) -eq $true -and (Get-Content $LogPath | Select-String "Exceptions verified" -Quiet) -eq $true)
	#{
	#	#log file indicates success, skipping
	#	Write-Host "log file indicates success, skipping"
	#	exit
	#}
    if ((Test-Path "$javapath\deployment\security\exception.sites") -and (Test-Path "$javapath\deployment\deployment.properties"))
    {
        if ((Get-Content "$javapath\deployment\security\exception.sites" | select-string "http://businessobjects.pimco.imswest.sscims.com:8080/InfoViewApp/logon.jsp") -and (Get-Content "$javapath\deployment\security\exception.sites" | select-string "http://businessobjects:8080/InfoViewApp/logon.jsp") -and (Get-Content $javapath\deployment\deployment.properties | Select-String "deployment.security.level=MEDIUM"))
        {
            Add-Content -Path $LogPath "$timestamp - It's good!" | Out-Null
            exit
        }
    }
}
else
{
	New-Item -Path $LogPath -ItemType File | Out-Null
	Add-Content -Path $LogPath "$timestamp - Script started" | Out-Null
}

function SetJavaSecurity
{
    if (Test-path "$javapath\deployment")
    {
        Write-host "Found java deployment path"
        Add-Content -Path $LogPath "$timestamp - Found java deployment path"
        #Check for the deployment.properties file
        if (Test-path "$javapath\deployment\deployment.properties")
        {
            if (Get-Content $javapath\deployment\deployment.properties | Select-String "deployment.security.level=MEDIUM")
            {
                Write-host "Java security already set to Medium!"
                Add-Content -Path $LogPath "$timestamp - Java security already set to Medium"
            }
            else
            {
                Write-host "Changing security level"
                Add-Content -Path $LogPath "$timestamp - Changing security level"
                $replacing = Get-Content $javapath\deployment\deployment.properties | select-string "deployment.security.level"
                if ($replacing)
                {
                    $rep = ([string]$replacing).split("=")[1]
                    $delay = Get-Content $javapath\deployment\deployment.properties | foreach {$_ -replace $rep, "MEDIUM"} 
                    try
                    {
                        $delay | set-content $javapath\deployment\deployment.properties -Force
                    }
                    catch
                    {
                        write-warning "Couldn't replace security level"
                        Add-Content -Path $LogPath "$timestamp - Couldn't replace security level"
                    }
                }
                else
                {
                    try
                    {
                        Add-Content -value "deployment.security.level=MEDIUM" -Path "$javapath\deployment\deployment.properties"
                    }
                    catch
                    {
                        write-warning "Couldn't append security level"
                        Add-Content -Path $LogPath "$timestamp - Couldn't append security level"
                    }
                }
            }
        }
    }
    else
    {
        if ($script:counter -le 1)
        {
            write-host "Deployment folder isn't created, starting control panel to generate"
            Add-Content -Path $LogPath "$timestamp - Deployment folder isn't created, starting control panel to generate"
            $javafolders = ls 'C:\Program Files (x86)\Java\jre*'
            if ($javafolders.count -ge 2)
            {
                $jpath = ($javafolders | sort name -Descending)[0].fullname
                ."$jpath\bin\javacpl.exe"
            }
            else
            {
                .'C:\Program Files (x86)\Java\jre*\bin\javacpl.exe'
            }
            $testcounter = 0
            do {$test1 = Test-Path "$javapath\Deployment\deployment.properties" ; $test2 = Test-Path "$javapath\deployment\security" ; sleep -milliseconds 500 ; $testcounter++}
            until ($test1 -eq $true -and $test2 -eq $true -or $testcounter -ge 120)
            Stop-Process -Name javaw | Out-Null
            $script:counter++
            SetJavaSecurity
        }
        else
        {
            write-warning "Exiting because deployment folders aren't creating"
            Add-Content -Path $LogPath "$timestamp - Deployment folders are failing to create, exiting"
            exit
        }

    }
}

function AddJavaExceptions
{
    #Add Java exception
    #Check for security folder
    if (Test-path "$javapath\deployment\security")
    {
        Write-host "Found security folder"
        Add-Content -Path $LogPath "$timestamp - Found security folder"
        #Check for existing exception.sites file
        if (Test-Path "$javapath\deployment\security\exception.sites")
        {
            #Check for the values we need
            if ((Get-Content "$javapath\deployment\security\exception.sites" | select-string "http://businessobjects.pimco.imswest.sscims.com:8080/InfoViewApp/logon.jsp") -and (Get-Content "$javapath\deployment\security\exception.sites" | select-string "http://businessobjects:8080/InfoViewApp/logon.jsp"))
            {
                write-host "Values found already!"
                Add-Content -Path $LogPath "$timestamp - BOE values already added"
            }
            else
            {
                try
                {
                    #Add the needful
                    Write-host "Adding Exceptions"
                    Add-Content -Path $LogPath "$timestamp - Adding exceptions"
                    Add-content -value "http://businessobjects.pimco.imswest.sscims.com:8080/InfoViewApp/logon.jsp" -Path "$javapath\deployment\security\exception.sites"
                    Add-content -value "http://businessobjects:8080/InfoViewApp/logon.jsp" -Path "$javapath\deployment\security\exception.sites"
                }
                catch
                {
                    write-warning "Could not add exceptions"
                    Add-Content -Path $LogPath "$timestamp - Adding exceptions failed"
                }
            }
        }
        else
        {
            Write-host "exception.sites file is missing...creating"
            Add-Content -Path $LogPath "$timestamp - Creating exception.sites file and adding exceptions"
            try
            {
                New-item -ItemType File -Path "$javapath\deployment\security" -Name exception.sites | out-null
                Add-content -value "http://businessobjects.pimco.imswest.sscims.com:8080/InfoViewApp/logon.jsp" -Path "$javapath\deployment\security\exception.sites"
                Add-content -value "http://businessobjects:8080/InfoViewApp/logon.jsp" -Path "$javapath\deployment\security\exception.sites"
            }
            catch
            {
                write-warning "Could not add exceptions"
                Add-Content -Path $LogPath "$timestamp - Adding exceptions failed"
            }
        }
    }
}

function VerifyChanges
{
    if ((Get-Content "$javapath\deployment\security\exception.sites" | select-string "http://businessobjects.pimco.imswest.sscims.com:8080/InfoViewApp/logon.jsp") -and (Get-Content "$javapath\deployment\security\exception.sites" | select-string "http://businessobjects:8080/InfoViewApp/logon.jsp"))
    {
        Add-Content -Path $LogPath "$timestamp - Exceptions verified"
    }
    else
    {
        Add-Content -Path $LogPath "$timestamp - Exceptions verification failed"
    }

    if (Get-Content $javapath\deployment\deployment.properties | Select-String "deployment.security.level=MEDIUM")
    {
        Add-Content -Path $LogPath "$timestamp - Security level verified"
    }
    else
    {
        Add-Content -Path $LogPath "$timestamp - Security level verification failed"
    }
    Add-Content -Path $LogPath "$timestamp - Done"
}

SetJavaSecurity
AddJavaExceptions
VerifyChanges