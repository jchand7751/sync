﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/8/2016 3:22 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($StartDate, $EndDate, $TicketArrayAndTime, $SessionID)

#$startdate = "2016-04-21"
#$enddate = "2016-04-25"
#TicketArrayAndTime Syntax: "IS-1304:1", "IS-1302:3"
if ($SessionID -like "")
{
	$credential = Get-Credential
	$password = $credential.getnetworkcredential().password
	$account = $credential.UserName
	$creds = $account + ":" + $password
}


if (($startdate -match "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]") -ne $true)
{
	throw "Start date is not in the correct format - correct format is 2016-01-25"
}

if (($enddate -match "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]") -ne $true)
{
	throw "End date is not in the correct format - correct format is 2016-01-25"
}

if (([DateTime]$startdate).DayOfWeek -eq "Saturday" -or ([DateTime]$startdate).DayOfWeek -eq "Sunday")
{
	throw "Start date cannot be a weekend day"
}

if (([DateTime]$enddate).DayOfWeek -eq "Saturday" -or ([DateTime]$enddate).DayOfWeek -eq "Sunday")
{
	throw "End date cannot be a weekend day"
}

function addtime
{
	param ($date)
	foreach ($item in $TicketArrayAndTime)
	{
		$ticket = ($item -split ":")[0]
		$time = ([int]($item -split ":")[1] * 60 * 60)
		
		$ticketdate = (get-date ((Get-Date $date).addhours("8")) -format yyyy-MM-dd) + "T15:00:00.000+0000"
		Write-Host "Adding time for ticket $ticket - date $date - hours $($time / 60 / 60)"
		#curl.exe -k https://jira/rest/api/2/issue/$ticket/worklog -u $creds -X POST -H "Content-Type: application/json" -d "{`"`"comment`"`": `"`"Work logged`"`", `"`"started`"`": `"$ticketdate`", `"`"timeSpentSeconds`"`": `"$time`" }"
		
		#$command = "curl.exe -k -b JSESSIONID=$SessionID -H `"Content-Type: application/json`" -X POST https://jira/rest/api/2/issue/$ticket/worklog -d '{`"`"comment`"`": `"`"Work logged`"`", `"`"started`"`": `"`"$ticketdate`"`", `"`"timeSpentSeconds`"`": `"`"$time`"`" }' -s"
		$command = "curl.exe -k -u $creds -H `"Content-Type: application/json`" -X POST https://jira/rest/api/2/issue/$ticket/worklog -d '{`"`"comment`"`": `"`"Work logged`"`", `"`"started`"`": `"`"$ticketdate`"`", `"`"timeSpentSeconds`"`": `"`"$time`"`" }' -s"
		#$command
		Invoke-Expression $command
		#$command = "curl.exe -k -u $creds -H `"Content-Type: application/json`" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{`"`"body`"`": `"`"Attachment: $attachmentlink`"`" }'"
	}
}


$dayscount = ([datetime]$enddate - [datetime]$startdate).days
$date = ([DateTime]$StartDate)


do
{
	if ($date.DayOfWeek -eq "Saturday" -or $date.DayOfWeek -eq "Sunday")
	{
		$date = ([DateTime]$date).adddays("1")
	}
	else
	{
		addtime -date $date
		$date = ([DateTime]$date).adddays("1")
	}
}
until ($date -eq (([DateTime]$EndDate).adddays("1")))

#for ($x = 0; $x -le $dayscount; $x++)
#{
#}

#$startdatetime = ($startdate + " 8:00AM")

#if (([datetime]$startdate).DayOfWeek -ne "Monday")
#{

#}
#"2016-05-18T15:00:00.000+0000"

#curl.exe -k -b JSESSIONID=B20742AAE107FB2DCAAA2A8D55CCF4EB -X GET -H "Content-Type: application/json" https://jira/rest/api/2/issue/IS-938