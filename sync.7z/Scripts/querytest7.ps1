﻿function ConfigButton
{
    $bottompanel.visible = $true
    $bottomhiddenpanel.visible = $true
    $bottomdetailspanel.visible = $false
    <#$configpanel = $bottomhiddenpanel.visible
    switch ($configpanel)
    {
        "True" {$bottomhiddenpanel.visible = $false}
        default {$bottomhiddenpanel.visible = $true}
    }
    #>
}

function DetailsButton
{
    $bottompanel.visible = $true
    $bottomhiddenpanel.visible = $true
    $bottomdetailspanel.visible = $true
    try
    {
        $bottomdetailspanel.Controls.clear()
    }
    catch
    {
        
    }
    <#$detailspanel = $bottomdetailspanel.visible
    switch ($detailspanel)
    {
        "True" {$bottomdetailspanel.visible = $false}
        default {$bottomdetailspanel.visible = $true}
    }
    #>
    $CurrentCell = $datagridview1.SelectedCells.value
    #full row of data for selected cell
    $object = $dataGridView1.SelectedCells.owningrow.DataBoundItem
    write-host $object
    #Dynamic drawing
    #$noteprops = $dataGridView1.SelectedCells.owningrow.DataBoundItem | gm | where {$_.membertype -eq "noteproperty"}
    $noteprops = $script:dataimport | where {$_.id -eq $object.id} | gm | where {$_.membertype -eq "noteproperty"}
    $object = $script:dataimport | where {$_.id -eq $object.id}
    foreach ($type in $noteprops)
    {
        $modifierlabel = New-Object System.Windows.Forms.Label
        $querytextBox = New-Object System.Windows.Forms.TextBox
    }

        #$System_Drawing_Point = New-Object System.Drawing.Point
        #$System_Drawing_Point.X = 427
        #$System_Drawing_Point.Y = 77 + ((($x + 1) * 25) + 30)
        #$System_Drawing_Point.Y = ((($x + 1)) + 5)

    for ($x = 0 ; $x -lt $noteprops.count ; $x++)
    {
        write-host "Creating label $($noteprops.name[$x])"
        $invokepropertylabelarray = @()
        #Create the objects
        $invokepropertylabelarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "label" + " " + "=" + " " + "New-Object System.Windows.Forms.Label" + " " + ";"
        #Set the name
        $invokepropertylabelarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "label" + ".name" + " " + "=" + " " + "'" + ($($noteprops.name)[$x]) + "label" + "'" + " " + ";"
        #Draw
        $System_Drawing_Size = New-Object System.Drawing.Size
        $System_Drawing_Size.Width = (40 + (($noteprops.name)[$x]).length) * 2
        $System_Drawing_Size.Height = 18
        $invokepropertylabelarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "label" + ".Size" + " " + "=" + " " + "`$System_Drawing_Size" + " " + ";"
        $invokepropertylabelarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "label" + ".text" + " " + "=" + " " + "'" + $($noteprops.name)[$x] + "'" + " " + ";"

        if ($lastdrawingpointy)
        {
            #write-host "label hitting Y"
            $System_Drawing_Point = New-Object System.Drawing.Point
            $System_Drawing_Point.X = 400
            $System_Drawing_Point.Y = $lastdrawingpointy + 5
        }
        else
        {
            $System_Drawing_Point = New-Object System.Drawing.Point
            $System_Drawing_Point.X = 400
            $System_Drawing_Point.Y = ((($x + 1)) + 5)
        }
        $invokepropertylabelarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "label" + ".Location" + " " + "=" + " " + "`$System_Drawing_Point" + " " + ";"
        $invokepropertylabelarray += "`$bottomdetailspanel.Controls.Add" + "(" + "$" + "drawing" + ($($noteprops.name)[$x]) + "label" + ")" + " " + ";"
        $stringlabelarray = [string]$invokepropertylabelarray
        invoke-expression $stringlabelarray
        $property = $($noteprops.name)[$x]
        if (($object.$property).contains(","))
        {
            write-host "Creating listbox $($noteprops.name[$x])"
            $objarray = $object.$property.split(",")
            $invokepropertylistboxarray = @()
            $invokepropertylistboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "listbox" + " " + "=" + " " + "New-Object System.Windows.Forms.listbox" + " " + ";"
            $invokepropertylistboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "listbox" + ".name" + " " + "=" + " " + "'" + ($($noteprops.name)[$x]) + "textbox" + "'" + " " + ";"
            $System_Drawing_Size = New-Object System.Drawing.Size
            $System_Drawing_Size.Width = 250
            $System_Drawing_Size.Height = 16 * ($objarray.count + .5)
            $invokepropertylistboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "listbox" + ".Size" + " " + "=" + " " + "`$System_Drawing_Size" + " " + ";"
            foreach ($item in $objarray)
            {
                write-host "Adding binding $item"
                $invokepropertylistboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "listbox" + ".items" + ".add" + "(" + "'" + $item + "'" + ")" + " " + ";" 
            }
            $System_Drawing_Point.X = 527
            $invokepropertylistboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "listbox" + ".Location" + " " + "=" + " " + "`$System_Drawing_Point" + " " + ";"
            $invokepropertylistboxarray += "`$bottomdetailspanel.Controls.Add" + "(" + "$" + "drawing" + ($($noteprops.name)[$x]) + "listbox" + ")" + " " + ";"
            $stringlistboxarray = [string]$invokepropertylistboxarray
            invoke-expression $stringlistboxarray
            $lastdrawingpointy = $system_Drawing_point.y + $System_Drawing_Size.Height
        }
        else
        {
            write-host "Creating textbox $($noteprops.name[$x])"
            $invokepropertytextboxarray = @()
            $invokepropertytextboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "textbox" + " " + "=" + " " + "New-Object System.Windows.Forms.textbox" + " " + ";"
            $invokepropertytextboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "textbox" + ".name" + " " + "=" + " " + "'" + ($($noteprops.name)[$x]) + "textbox" + "'" + " " + ";"
            $System_Drawing_Size = New-Object System.Drawing.Size
            $System_Drawing_Size.Width = 250
            $System_Drawing_Size.Height = 18
            $invokepropertytextboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "textbox" + ".Size" + " " + "=" + " " + "`$System_Drawing_Size" + " " + ";"
            $invokepropertytextboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "textbox" + ".text" + " " + "=" + " " + "'" + $object.$property + "'" + " " + ";"
            $System_Drawing_Point.X = 527
            $invokepropertytextboxarray += "$" + "drawing" + ($($noteprops.name)[$x]) + "textbox" + ".Location" + " " + "=" + " " + "`$System_Drawing_Point" + " " + ";"
            $invokepropertytextboxarray += "`$bottomdetailspanel.Controls.Add" + "(" + "$" + "drawing" + ($($noteprops.name)[$x]) + "textbox" + ")" + " " + ";"
            $stringtextboxarray = [string]$invokepropertytextboxarray
            invoke-expression $stringtextboxarray
            $lastdrawingpointy = $system_Drawing_point.y + $System_Drawing_Size.Height
        }
    }
}

function SearchButton
{
    $bottomhiddenpanel.visible = $false
    $bottomdetailspanel.visible = $false
    $bottompanel.visible = $true

    $checkboxarray = $servernamecheckbox, $columnsgroupBox, $apppoolcredentialcheckBox, $SolarwindscheckBox, $AppDLinkcheckBox, $TypecheckBox, $AppPoolVersioncheckBox, $AppPool32bitEnabledcheckBox, $apppoolnamecheckBox, $bindingscheckBox, $authenticationcheckBox, $PathcheckBox, $logdirectorycheckBox, $siteIDcheckBox, $ServercheckBox, $NamecheckBox, $ParentSiteIDcheckbox, $ParentSiteNamecheckbox
    $selectarray = @()
    foreach ($checkbox in $checkboxarray)
    {
        switch ($checkbox.checked)
        {
            $true {$selectarray += $checkbox.text}
            default {}
        }
    }
    $selectarray += "id"
    write-host [string]$selectarray
    $a = import-csv c:\temp\dbtest1.csv
    $script:dataimport = import-csv c:\temp\dbtest1.csv
    write-host "Search clicked"
    $selectstring = (([string]$selectarray) -replace " ",", ")
    write-host $selectstring
    $querystring = "[array](`$a | where {`$_.$($filtercombobox.selecteditem) $($modifiercombobox.SelectedItem) `"$($querytextbox.text)`"}) | select $selectstring"
    write-host $querystring
    
    $array = New-Object System.Collections.ArrayList
    $datainfo = (invoke-expression $querystring)
    $array.AddRange($dataInfo)
    $DataGridView1.DataSource = $array
}


#Generated Form Function
function GenerateForm {
########################################################################
# Code Generated By: SAPIEN Technologies PrimalForms (Community Edition) v1.0.6.0
# Generated On: 4/13/2015 6:18 PM
# Generated By: jchandle
########################################################################

#region Import the Assemblies
[reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
[reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null
#endregion

#region Generated Form Objects
$iissearchform = New-Object System.Windows.Forms.Form
$bottompanel = New-Object System.Windows.Forms.Panel
$bottomhiddenpanel = New-Object System.Windows.Forms.Panel
$bottomdetailspanel = New-Object System.Windows.Forms.Panel
$typegroupBox = New-Object System.Windows.Forms.GroupBox
$objectstoreportonlabel = New-Object System.Windows.Forms.Label
$ServicesradioButton = New-Object System.Windows.Forms.RadioButton
$sitesappsradioButton = New-Object System.Windows.Forms.RadioButton
$columnsgroupBox = New-Object System.Windows.Forms.GroupBox
$apppoolcredentialcheckBox = New-Object System.Windows.Forms.CheckBox
$SolarwindscheckBox = New-Object System.Windows.Forms.CheckBox
$AppDLinkcheckBox = New-Object System.Windows.Forms.CheckBox
$TypecheckBox = New-Object System.Windows.Forms.CheckBox
$AppPoolVersioncheckBox = New-Object System.Windows.Forms.CheckBox
$AppPool32bitEnabledcheckBox = New-Object System.Windows.Forms.CheckBox
$apppoolnamecheckBox = New-Object System.Windows.Forms.CheckBox
$bindingscheckBox = New-Object System.Windows.Forms.CheckBox
$authenticationcheckBox = New-Object System.Windows.Forms.CheckBox
$PathcheckBox = New-Object System.Windows.Forms.CheckBox
$logdirectorycheckBox = New-Object System.Windows.Forms.CheckBox
$siteIDcheckBox = New-Object System.Windows.Forms.CheckBox
$columnstodisplaylabel = New-Object System.Windows.Forms.Label
$ServercheckBox = New-Object System.Windows.Forms.CheckBox
$NamecheckBox = New-Object System.Windows.Forms.CheckBox
$ParentSiteIDcheckbox = New-Object System.Windows.Forms.CheckBox
$ParentSiteNamecheckbox = New-Object System.Windows.Forms.CheckBox
$dataGridView1 = New-Object System.Windows.Forms.DataGridView
$toppanel = New-Object System.Windows.Forms.Panel
$configbutton = New-Object System.Windows.Forms.Button
$detailsbutton = New-Object System.Windows.Forms.Button
$panel1 = New-Object System.Windows.Forms.Panel
$modifiercombobox = New-Object System.Windows.Forms.ComboBox
$iissearchlabel = New-Object System.Windows.Forms.Label
$selectfilterlabel = New-Object System.Windows.Forms.Label
$searchbutton = New-Object System.Windows.Forms.Button
$modifierlabel = New-Object System.Windows.Forms.Label
$querytextBox = New-Object System.Windows.Forms.TextBox
$querylabel = New-Object System.Windows.Forms.Label
$filtercomboBox = New-Object System.Windows.Forms.ComboBox
$InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState
#endregion Generated Form Objects

#----------------------------------------------
#Generated Event Script Blocks
#----------------------------------------------
#Provide Custom Code for events specified in PrimalForms.
$detailsbutton_OnClick= 
{
#TODO: Place custom script here
    DetailsButton
}

$handler_checkBox4_CheckedChanged= 
{
#TODO: Place custom script here

}

$handler_label1_Click= 
{
#TODO: Place custom script here

}

$searchbutton_OnClick= 
{
#TODO: Place custom script here
    SearchButton
}

$configbutton_OnClick= 
{
#TODO: Place custom script here
    ConfigButton
}

$OnLoadForm_StateCorrection=
{#Correct the initial state of the form to prevent the .Net maximized form issue
	$iissearchform.WindowState = $InitialFormWindowState
}

#----------------------------------------------
#region Generated Form Code
$iissearchform.Text = "IIS Search"
$iissearchform.Name = "iissearchform"
$iissearchform.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1043
$System_Drawing_Size.Height = 567
$iissearchform.ClientSize = $System_Drawing_Size

$bottompanel.Dock = 5
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1043
$System_Drawing_Size.Height = 364
$bottompanel.Size = $System_Drawing_Size

$bottompanel.BackColor = [System.Drawing.Color]::FromArgb(255,192,192,192)
$bottompanel.TabIndex = 9
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 203
$bottompanel.Location = $System_Drawing_Point
$bottompanel.DataBindings.DefaultDataSourceUpdateMode = 0
$bottompanel.Name = "bottompanel"

$iissearchform.Controls.Add($bottompanel)
$bottomhiddenpanel.Dock = 5
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1043
$System_Drawing_Size.Height = 364
$bottomhiddenpanel.Size = $System_Drawing_Size

$bottomhiddenpanel.Visible = $False
$bottomhiddenpanel.TabIndex = 1
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 0
$bottomhiddenpanel.Location = $System_Drawing_Point
$bottomhiddenpanel.DataBindings.DefaultDataSourceUpdateMode = 0
$bottomhiddenpanel.Name = "bottomhiddenpanel"

$bottompanel.Controls.Add($bottomhiddenpanel)
$bottomdetailspanel.Dock = 5
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1043
$System_Drawing_Size.Height = 364
$bottomdetailspanel.Size = $System_Drawing_Size

$bottomdetailspanel.Visible = $False
$bottomdetailspanel.TabIndex = 14
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 0
$bottomdetailspanel.Location = $System_Drawing_Point
$bottomdetailspanel.DataBindings.DefaultDataSourceUpdateMode = 0
$bottomdetailspanel.Name = "bottomdetailspanel"

$bottomhiddenpanel.Controls.Add($bottomdetailspanel)

$typegroupBox.Name = "typegroupBox"

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 165
$System_Drawing_Size.Height = 97
$typegroupBox.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 536
$System_Drawing_Point.Y = 64
$typegroupBox.Location = $System_Drawing_Point
$typegroupBox.TabStop = $False
$typegroupBox.TabIndex = 13
$typegroupBox.DataBindings.DefaultDataSourceUpdateMode = 0

$bottomhiddenpanel.Controls.Add($typegroupBox)
$objectstoreportonlabel.TabIndex = 2
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 127
$System_Drawing_Size.Height = 23
$objectstoreportonlabel.Size = $System_Drawing_Size
$objectstoreportonlabel.Text = "Objects to report on"
$objectstoreportonlabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8.25,1,3,1)

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 22
$System_Drawing_Point.Y = 18
$objectstoreportonlabel.Location = $System_Drawing_Point
$objectstoreportonlabel.DataBindings.DefaultDataSourceUpdateMode = 0
$objectstoreportonlabel.Name = "objectstoreportonlabel"

$typegroupBox.Controls.Add($objectstoreportonlabel)

$ServicesradioButton.TabIndex = 1
$ServicesradioButton.Name = "ServicesradioButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$ServicesradioButton.Size = $System_Drawing_Size
$ServicesradioButton.UseVisualStyleBackColor = $True

$ServicesradioButton.Text = "Services"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 6
$System_Drawing_Point.Y = 65
$ServicesradioButton.Location = $System_Drawing_Point
$ServicesradioButton.DataBindings.DefaultDataSourceUpdateMode = 0

$typegroupBox.Controls.Add($ServicesradioButton)

$sitesappsradioButton.TabIndex = 0
$sitesappsradioButton.Name = "sitesappsradioButton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$sitesappsradioButton.Size = $System_Drawing_Size
$sitesappsradioButton.UseVisualStyleBackColor = $True

$sitesappsradioButton.Text = "Sites/Apps"
$sitesappsradioButton.Checked = $True

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 6
$System_Drawing_Point.Y = 44
$sitesappsradioButton.Location = $System_Drawing_Point
$sitesappsradioButton.DataBindings.DefaultDataSourceUpdateMode = 0
$sitesappsradioButton.TabStop = $True

$typegroupBox.Controls.Add($sitesappsradioButton)


$columnsgroupBox.Name = "columnsgroupBox"

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 427
$System_Drawing_Size.Height = 238
$columnsgroupBox.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 42
$System_Drawing_Point.Y = 33
$columnsgroupBox.Location = $System_Drawing_Point
$columnsgroupBox.TabStop = $False
$columnsgroupBox.TabIndex = 12
$columnsgroupBox.DataBindings.DefaultDataSourceUpdateMode = 0

$bottomhiddenpanel.Controls.Add($columnsgroupBox)

$apppoolcredentialcheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 116
$System_Drawing_Size.Height = 24
$apppoolcredentialcheckBox.Size = $System_Drawing_Size
$apppoolcredentialcheckBox.TabIndex = 16
$apppoolcredentialcheckBox.Text = "AppPoolCredential"
$apppoolcredentialcheckBox.Checked = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 296
$System_Drawing_Point.Y = 135
$apppoolcredentialcheckBox.Location = $System_Drawing_Point
$apppoolcredentialcheckBox.CheckState = 1
$apppoolcredentialcheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$apppoolcredentialcheckBox.Name = "apppoolcredentialcheckBox"


$columnsgroupBox.Controls.Add($apppoolcredentialcheckBox)


$SolarwindscheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$SolarwindscheckBox.Size = $System_Drawing_Size
$SolarwindscheckBox.TabIndex = 15
$SolarwindscheckBox.Text = "SolarwindsLink"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 296
$System_Drawing_Point.Y = 104
$SolarwindscheckBox.Location = $System_Drawing_Point
$SolarwindscheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$SolarwindscheckBox.Name = "SolarwindscheckBox"


$columnsgroupBox.Controls.Add($SolarwindscheckBox)


$AppDLinkcheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$AppDLinkcheckBox.Size = $System_Drawing_Size
$AppDLinkcheckBox.TabIndex = 14
$AppDLinkcheckBox.Text = "AppDLink"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 296
$System_Drawing_Point.Y = 74
$AppDLinkcheckBox.Location = $System_Drawing_Point
$AppDLinkcheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$AppDLinkcheckBox.Name = "AppDLinkcheckBox"


$columnsgroupBox.Controls.Add($AppDLinkcheckBox)


$TypecheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$TypecheckBox.Size = $System_Drawing_Size
$TypecheckBox.TabIndex = 13
$TypecheckBox.Text = "Type"
$TypecheckBox.Checked = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 296
$System_Drawing_Point.Y = 48
$TypecheckBox.Location = $System_Drawing_Point
$TypecheckBox.CheckState = 1
$TypecheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$TypecheckBox.Name = "TypecheckBox"


$columnsgroupBox.Controls.Add($TypecheckBox)


$AppPoolVersioncheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$AppPoolVersioncheckBox.Size = $System_Drawing_Size
$AppPoolVersioncheckBox.TabIndex = 12
$AppPoolVersioncheckBox.Text = "AppPoolVersion"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 151
$System_Drawing_Point.Y = 194
$AppPoolVersioncheckBox.Location = $System_Drawing_Point
$AppPoolVersioncheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$AppPoolVersioncheckBox.Name = "AppPoolVersioncheckBox"


$columnsgroupBox.Controls.Add($AppPoolVersioncheckBox)


$AppPool32bitEnabledcheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 135
$System_Drawing_Size.Height = 24
$AppPool32bitEnabledcheckBox.Size = $System_Drawing_Size
$AppPool32bitEnabledcheckBox.TabIndex = 11
$AppPool32bitEnabledcheckBox.Text = "AppPool32bitEnabled"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 151
$System_Drawing_Point.Y = 164
$AppPool32bitEnabledcheckBox.Location = $System_Drawing_Point
$AppPool32bitEnabledcheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$AppPool32bitEnabledcheckBox.Name = "AppPool32bitEnabledcheckBox"


$columnsgroupBox.Controls.Add($AppPool32bitEnabledcheckBox)


$apppoolnamecheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$apppoolnamecheckBox.Size = $System_Drawing_Size
$apppoolnamecheckBox.TabIndex = 10
$apppoolnamecheckBox.Text = "AppPoolName"
$apppoolnamecheckBox.Checked = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 150
$System_Drawing_Point.Y = 134
$apppoolnamecheckBox.Location = $System_Drawing_Point
$apppoolnamecheckBox.CheckState = 1
$apppoolnamecheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$apppoolnamecheckBox.Name = "apppoolnamecheckBox"


$columnsgroupBox.Controls.Add($apppoolnamecheckBox)


$bindingscheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$bindingscheckBox.Size = $System_Drawing_Size
$bindingscheckBox.TabIndex = 9
$bindingscheckBox.Text = "Bindings"
$bindingscheckBox.Checked = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 150
$System_Drawing_Point.Y = 104
$bindingscheckBox.Location = $System_Drawing_Point
$bindingscheckBox.CheckState = 1
$bindingscheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$bindingscheckBox.Name = "bindingscheckBox"


$columnsgroupBox.Controls.Add($bindingscheckBox)


$authenticationcheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$authenticationcheckBox.Size = $System_Drawing_Size
$authenticationcheckBox.TabIndex = 8
$authenticationcheckBox.Text = "Authentication"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 149
$System_Drawing_Point.Y = 74
$authenticationcheckBox.Location = $System_Drawing_Point
$authenticationcheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$authenticationcheckBox.Name = "authenticationcheckBox"


$columnsgroupBox.Controls.Add($authenticationcheckBox)


$PathcheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$PathcheckBox.Size = $System_Drawing_Size
$PathcheckBox.TabIndex = 7
$PathcheckBox.Text = "Path"
$PathcheckBox.Checked = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 149
$System_Drawing_Point.Y = 48
$PathcheckBox.Location = $System_Drawing_Point
$PathcheckBox.CheckState = 1
$PathcheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$PathcheckBox.Name = "PathcheckBox"


$columnsgroupBox.Controls.Add($PathcheckBox)


$logdirectorycheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$logdirectorycheckBox.Size = $System_Drawing_Size
$logdirectorycheckBox.TabIndex = 6
$logdirectorycheckBox.Text = "Log Directory"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 33
$System_Drawing_Point.Y = 194
$logdirectorycheckBox.Location = $System_Drawing_Point
$logdirectorycheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$logdirectorycheckBox.Name = "logdirectorycheckBox"


$columnsgroupBox.Controls.Add($logdirectorycheckBox)


$siteIDcheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$siteIDcheckBox.Size = $System_Drawing_Size
$siteIDcheckBox.TabIndex = 5
$siteIDcheckBox.Text = "SiteID"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 33
$System_Drawing_Point.Y = 164
$siteIDcheckBox.Location = $System_Drawing_Point
$siteIDcheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$siteIDcheckBox.Name = "siteIDcheckBox"


$columnsgroupBox.Controls.Add($siteIDcheckBox)

$columnstodisplaylabel.TabIndex = 4
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 123
$System_Drawing_Size.Height = 27
$columnstodisplaylabel.Size = $System_Drawing_Size
$columnstodisplaylabel.Text = "Columns to display"
$columnstodisplaylabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",8.25,1,3,1)

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 93
$System_Drawing_Point.Y = 16
$columnstodisplaylabel.Location = $System_Drawing_Point
$columnstodisplaylabel.DataBindings.DefaultDataSourceUpdateMode = 0
$columnstodisplaylabel.Name = "columnstodisplaylabel"

$columnsgroupBox.Controls.Add($columnstodisplaylabel)


$ServercheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$ServercheckBox.Size = $System_Drawing_Size
$ServercheckBox.TabIndex = 3
$ServercheckBox.Text = "Server"
$ServercheckBox.Checked = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 33
$System_Drawing_Point.Y = 48
$ServercheckBox.Location = $System_Drawing_Point
$ServercheckBox.CheckState = 1
$ServercheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$ServercheckBox.Name = "ServercheckBox"

$ServercheckBox.add_CheckedChanged($handler_checkBox4_CheckedChanged)

$columnsgroupBox.Controls.Add($ServercheckBox)


$NamecheckBox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$NamecheckBox.Size = $System_Drawing_Size
$NamecheckBox.TabIndex = 2
$NamecheckBox.Text = "Name"
$NamecheckBox.Checked = $True
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 33
$System_Drawing_Point.Y = 74
$NamecheckBox.Location = $System_Drawing_Point
$NamecheckBox.CheckState = 1
$NamecheckBox.DataBindings.DefaultDataSourceUpdateMode = 0
$NamecheckBox.Name = "NamecheckBox"


$columnsgroupBox.Controls.Add($NamecheckBox)


$ParentSiteIDcheckbox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$ParentSiteIDcheckbox.Size = $System_Drawing_Size
$ParentSiteIDcheckbox.TabIndex = 1
$ParentSiteIDcheckbox.Text = "ParentSiteID"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 33
$System_Drawing_Point.Y = 104
$ParentSiteIDcheckbox.Location = $System_Drawing_Point
$ParentSiteIDcheckbox.DataBindings.DefaultDataSourceUpdateMode = 0
$ParentSiteIDcheckbox.Name = "ParentSiteIDcheckbox"


$columnsgroupBox.Controls.Add($ParentSiteIDcheckbox)


$ParentSiteNamecheckbox.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 104
$System_Drawing_Size.Height = 24
$ParentSiteNamecheckbox.Size = $System_Drawing_Size
$ParentSiteNamecheckbox.TabIndex = 0
$ParentSiteNamecheckbox.Text = "ParentSiteName"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 33
$System_Drawing_Point.Y = 134
$ParentSiteNamecheckbox.Location = $System_Drawing_Point
$ParentSiteNamecheckbox.DataBindings.DefaultDataSourceUpdateMode = 0
$ParentSiteNamecheckbox.Name = "ParentSiteNamecheckbox"


$columnsgroupBox.Controls.Add($ParentSiteNamecheckbox)



$dataGridView1.Name = "dataGridView1"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1043
$System_Drawing_Size.Height = 364
$dataGridView1.Size = $System_Drawing_Size
$dataGridView1.DataBindings.DefaultDataSourceUpdateMode = 0
$dataGridView1.Dock = 5
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 0
$dataGridView1.Location = $System_Drawing_Point
$dataGridView1.TabIndex = 0
$dataGridView1.ReadOnly = $True

$bottompanel.Controls.Add($dataGridView1)


$toppanel.Dock = 1
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1043
$System_Drawing_Size.Height = 203
$toppanel.Size = $System_Drawing_Size

$toppanel.BackColor = [System.Drawing.Color]::FromArgb(255,192,192,192)
$toppanel.TabIndex = 8
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 0
$toppanel.Location = $System_Drawing_Point
$toppanel.DataBindings.DefaultDataSourceUpdateMode = 0
$toppanel.Name = "toppanel"

$iissearchform.Controls.Add($toppanel)
$configbutton.TabIndex = 14
$configbutton.Name = "configbutton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 23
$configbutton.Size = $System_Drawing_Size
$configbutton.UseVisualStyleBackColor = $True

$configbutton.Text = "Config"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 388
$System_Drawing_Point.Y = 161
$configbutton.Location = $System_Drawing_Point
$configbutton.DataBindings.DefaultDataSourceUpdateMode = 0
$configbutton.add_Click($configbutton_OnClick)

$toppanel.Controls.Add($configbutton)

$detailsbutton.TabIndex = 13
$detailsbutton.Name = "detailsbutton"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 23
$detailsbutton.Size = $System_Drawing_Size
$detailsbutton.UseVisualStyleBackColor = $True

$detailsbutton.Text = "Details"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 555
$System_Drawing_Point.Y = 161
$detailsbutton.Location = $System_Drawing_Point
$detailsbutton.DataBindings.DefaultDataSourceUpdateMode = 0
$detailsbutton.add_Click($detailsbutton_OnClick)

$toppanel.Controls.Add($detailsbutton)

$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 1032
$System_Drawing_Size.Height = 289
$panel1.Size = $System_Drawing_Size

$panel1.BackColor = [System.Drawing.Color]::FromArgb(255,255,255,255)
$panel1.TabIndex = 10
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 12
$System_Drawing_Point.Y = 253
$panel1.Location = $System_Drawing_Point
$panel1.DataBindings.DefaultDataSourceUpdateMode = 0
$panel1.Name = "panel1"

$toppanel.Controls.Add($panel1)

$modifiercombobox.FormattingEnabled = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 148
$System_Drawing_Size.Height = 21
$modifiercombobox.Size = $System_Drawing_Size
$modifiercombobox.DataBindings.DefaultDataSourceUpdateMode = 0
$modifiercombobox.Name = "modifiercombobox"
$modifiercombobox.Items.Add("-eq")|Out-Null
$modifiercombobox.Items.Add("-neq")|Out-Null
$modifiercombobox.Items.Add("-like")|Out-Null
$modifiercombobox.Items.Add("-notlike")|Out-Null
$modifiercombobox.RightToLeft = 0
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 98
$modifiercombobox.Location = $System_Drawing_Point
$modifiercombobox.TabIndex = 1

$toppanel.Controls.Add($modifiercombobox)

$iissearchlabel.TabIndex = 5
$iissearchlabel.RightToLeft = 0
$iissearchlabel.TextAlign = 32
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 218
$System_Drawing_Size.Height = 36
$iissearchlabel.Size = $System_Drawing_Size
$iissearchlabel.Text = "IIS Search"
$iissearchlabel.Font = New-Object System.Drawing.Font("Microsoft Sans Serif",20,1,3,1)

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 406
$System_Drawing_Point.Y = 9
$iissearchlabel.Location = $System_Drawing_Point
$iissearchlabel.DataBindings.DefaultDataSourceUpdateMode = 0
$iissearchlabel.UseWaitCursor = $True
$iissearchlabel.Name = "iissearchlabel"

$toppanel.Controls.Add($iissearchlabel)

$selectfilterlabel.TabIndex = 3
$selectfilterlabel.RightToLeft = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 64
$System_Drawing_Size.Height = 21
$selectfilterlabel.Size = $System_Drawing_Size
$selectfilterlabel.Text = "Select Filter"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 391
$System_Drawing_Point.Y = 71
$selectfilterlabel.Location = $System_Drawing_Point
$selectfilterlabel.DataBindings.DefaultDataSourceUpdateMode = 0
$selectfilterlabel.UseWaitCursor = $True
$selectfilterlabel.Name = "selectfilterlabel"
$selectfilterlabel.add_Click($handler_label1_Click)

$toppanel.Controls.Add($selectfilterlabel)

$searchbutton.TabIndex = 0
$searchbutton.Name = "searchbutton"
$searchbutton.RightToLeft = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 23
$searchbutton.Size = $System_Drawing_Size
$searchbutton.UseVisualStyleBackColor = $True

$searchbutton.Text = "Search"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 471
$System_Drawing_Point.Y = 161
$searchbutton.Location = $System_Drawing_Point
$searchbutton.DataBindings.DefaultDataSourceUpdateMode = 0
$searchbutton.add_Click($searchbutton_OnClick)

$toppanel.Controls.Add($searchbutton)

$modifierlabel.TabIndex = 0
$modifierlabel.RightToLeft = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 44
$System_Drawing_Size.Height = 17
$modifierlabel.Size = $System_Drawing_Size
$modifierlabel.Text = "Modifier"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 406
$System_Drawing_Point.Y = 102
$modifierlabel.Location = $System_Drawing_Point
$modifierlabel.DataBindings.DefaultDataSourceUpdateMode = 0
$modifierlabel.UseWaitCursor = $True
$modifierlabel.Name = "modifierlabel"

$toppanel.Controls.Add($modifierlabel)

$querytextBox.RightToLeft = 0
$querytextBox.Cursor = [System.Windows.Forms.Cursors]::Arrow
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 148
$System_Drawing_Size.Height = 20
$querytextBox.Size = $System_Drawing_Size
$querytextBox.DataBindings.DefaultDataSourceUpdateMode = 0
$querytextBox.Name = "querytextBox"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 127
$querytextBox.Location = $System_Drawing_Point
$querytextBox.TabIndex = 2

$toppanel.Controls.Add($querytextBox)

$querylabel.TabIndex = 4
$querylabel.RightToLeft = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 37
$System_Drawing_Size.Height = 18
$querylabel.Size = $System_Drawing_Size
$querylabel.Text = "Query"

$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 414
$System_Drawing_Point.Y = 129
$querylabel.Location = $System_Drawing_Point
$querylabel.DataBindings.DefaultDataSourceUpdateMode = 0
$querylabel.UseWaitCursor = $True
$querylabel.Name = "querylabel"

$toppanel.Controls.Add($querylabel)

$filtercomboBox.Cursor = [System.Windows.Forms.Cursors]::Arrow
$filtercomboBox.FormattingEnabled = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 148
$System_Drawing_Size.Height = 21
$filtercomboBox.Size = $System_Drawing_Size
$filtercomboBox.DataBindings.DefaultDataSourceUpdateMode = 0
$filtercomboBox.Name = "filtercomboBox"
$filtercomboBox.Items.Add("Server")|Out-Null
$filtercomboBox.Items.Add("Bindings")|Out-Null
$filtercomboBox.Items.Add("AppPoolName")|Out-Null
$filtercomboBox.Items.Add("Type")|Out-Null
$filtercomboBox.Items.Add("AppPoolCredential")|Out-Null
$filtercomboBox.Items.Add("AppPoolVersion")|Out-Null
$filtercomboBox.Items.Add("AppPool32bit")|Out-Null
$filtercomboBox.Items.Add("Authentication")|Out-Null
$filtercomboBox.RightToLeft = 0
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 465
$System_Drawing_Point.Y = 68
$filtercomboBox.Location = $System_Drawing_Point
$filtercomboBox.TabIndex = 1

$toppanel.Controls.Add($filtercomboBox)


#endregion Generated Form Code

#Save the initial state of the form
$InitialFormWindowState = $iissearchform.WindowState
#Init the OnLoad event to correct the initial state of the form
$iissearchform.add_Load($OnLoadForm_StateCorrection)
#Show the Form
$iissearchform.ShowDialog()| Out-Null

} #End Function

#Call the Function
GenerateForm
