﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	11/1/2016 11:16 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$OUs = Get-QADObject -Type organizationalunit -SearchRoot "OU=Access Technology,OU=Servers,OU=IA,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"
#$OUs = Get-QADObject -Type organizationalunit -SearchRoot "OU=Citrix,OU=Servers,OU=IA,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"

foreach ($ou in $OUs)
{
	$b = (Get-GPInheritance -Target $OU.dn).gpolinks
	foreach ($i in $b)
	{
		if ((test-path c:\tmp\GPOs\$($ou.name)) -ne $true)
		{
			mkdir c:\tmp\GPOs\$($ou.name)
		}
		get-gpo -Guid $i.gpoid | Get-GPOReport -ReportType HTML | out-file c:\tmp\GPOs\$($ou.name)\$($i.displayname).html
	}
}