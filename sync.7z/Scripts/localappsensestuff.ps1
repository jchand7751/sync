﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/28/2015 12:54 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$computer = "nb-9-1004"
$stringSID = "S-1-5-21-2241961287-1671099396-3952850847-60756"

#Get the base folder random name
$folders = (get-childitem \\$Computer\C$\appsensevirtual\$stringSID -Force -ea 'Stop') | where { $_.psIsContainer -eq $true }

foreach ($folder in $folders)
{
	#Get application name folders
	$apps = (get-childitem $folder.FullName -force) | where { $_.psIsContainer -eq $true }
	foreach ($app in $apps)
	{
		$subfolder = (get-childitem $app.FullName -force) | where { $_.psIsContainer -eq $true }
		foreach ($appsubfolder in $subfolder)
		{
			#Write-Host "Checking $($appsubfolder.fullname)\HarddiskVolume2"
			if (Test-Path "$($appsubfolder.fullname)\HarddiskVolume2")
			{
				$localrootfolder = "$($appsubfolder.fullname)\HarddiskVolume2"
				Get-ChildItem $localrootfolder -force -Recurse
				Write-Host "$($appsubfolder.fullname) has local crap"
			}
		}
	}
}
#\\nb-9-1004\c$\appsensevirtual\S-1-5-21-2241961287-1671099396-3952850847-60756\{ 68872868-8C3E-4692-A7E1-B8FB17DED9D9 }\Office 2010\Device\HarddiskVolume2\Users\Jsipkovi\AppData\Roaming\Microsoft\Signatures

