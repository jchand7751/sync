﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/4/2017 6:53 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$guestcredential = Get-Credential administrator


$2008script = "
	`$servername = hostname
	`$adapter = (gwmi win32_networkadapter | where {`$_.netconnectionid -notlike '' -and `$_.name -notlike 'sonic*'}).netconnectionid
	write-host '-----------------------'
	Write-host 'Setting DNS following on `$servername adapter `$adapter'
	
	netsh interface ipv4 set dnsservers `$adapter static '10.208.20.13'
	netsh interface ipv4 add dnsservers `$adapter 10.208.20.14 index=1
	netsh interface ipv4 add dnsservers `$adapter 10.208.50.13 index=2
	netsh interface ipv4 add dnsservers `$adapter 10.208.50.14 index=3
	"

$2012script = "
	`$servername = hostname
	`$adapter = (Get-NetAdapter).interfacealias
	write-host '-----------------------'
	Write-host 'Setting DNS following on `$servername adapter `$adapter'
	Set-DnsClientServerAddress -InterfaceAlias `$adapter -ServerAddresses (`"10.208.20.13`",`"10.208.20.14`",`"10.208.50.13`",`"10.208.50.14`")
	"
$serverlist = "server1", "server2", "server3"
foreach ($server in $serverlist)
{
	$checkos = (gwmi win32_operatingsystem -comp $server).caption
	if ($checkos -like "Windows server 2008*")
	{
		Invoke-VMScript -ScriptText $2008script -VM $server -GuestCredential $guestcredential -ScriptType Powershell
	}
	if ($checkos -like "Windows server 2012*")
	{
		Invoke-VMScript -ScriptText $2012script -VM $server -GuestCredential $guestcredential -ScriptType Powershell
	}
}