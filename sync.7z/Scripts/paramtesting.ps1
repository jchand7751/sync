﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/30/2017 3:00 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName="1")]
	[switch]$FullSync,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName="2")]
	[switch]$DifferentialSync,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName="3")]
	[string]$User
)
#endregion


$PSBoundParameters.keys