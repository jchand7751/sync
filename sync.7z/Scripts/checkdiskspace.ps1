﻿Function CheckdiskSpace { 
        Param ( $servername )    
$Drives = Get-WmiObject -class win32_logicaldisk -ComputerName "$servername" -Filter "DriveType = 3" | Select @{Name ="Drive";Expression = {$_.DeviceId}} ,@{Name = "Size(Gb)";Expression ={$_.Size/1GB -as [int]}} ,@{Name = "FreeSpace(GB)"; Expression ={$_.Freespace/1Gb -as [int]}} 
$Drives | Select Drive,'Size(Gb)','Freespace(GB)'| Format-Table -AutoSize -Wrap
For($i= 0; $i -lt $Drives.Length ;$i++) 
    { 
       $Percentage= "{0:p}"-f ($($Drives[$i].'Freespace(GB)')/$($Drives[$i].'Size(Gb)'))
          If($Percentage -lt '10.00%') 
                        { 
                    Write-Host "WARNING:Low Disk space on $($Drives[$i].Drive)"
                    Write-Host "Free Disk space on $($Drives[$i].Drive) is $Percentage" 

                            } else  
                             { 
                             Write-Host "Information:Free Disk space on $($Drives[$i].Drive) is $Percentage"
                             } 
            } 

}