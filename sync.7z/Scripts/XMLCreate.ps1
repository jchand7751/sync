﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/9/2015 5:30 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#Get registered services running as a service account
#gwmi win32_service -comp $server | where { $_.startname -like "*pimco*" }

param ($server, $servicename)

#Get the current config file
$ConfigFile = Get-Content "\\$server\C$\programdata\AppDynamics\DotNetAgent\Config\config.xml"
#$ConfigFile = Get-Content "\\$server\C$\programdata\AppDynamics\DotNetAgent\Config\Configtest.xml"
#$configfile = get-content C:\temp\xmlexample.txt

#Change it to XML
$ConfigFile = [xml]$ConfigFile

#Backup the old file
$ConfigFile.Save("\\$server\C$\programdata\AppDynamics\DotNetAgent\Config\configBackup.old")

#Determine if a windows-service node exists
if ($ConfigFile."appdynamics-agent"."app-agents"."windows-services")
{ }
else
{
	#Add a windows-services element
	$addnode = $configfile.createelement("windows-services")
	$configfile."appdynamics-agent"."app-agents".appendchild($addnode)
}
#Put quotes around the service name or it fails horribly
$servicename = ("""$servicename""")
#create an XML node for the service
[xml]$service = "<windows-services>
<windows-service name=$servicename>
<tier name=$servicename/>
</windows-service>
</windows-services>"

#Get the target element from the existing config
$XMLTarget = $ConfigFile."appdynamics-agent"."app-agents".selectSingleNode("windows-services")
#Get the node we want to add
$XMLNewNode = $service."windows-services".selectsinglenode("windows-service")
#Add the node to the target element
$XMLTarget.appendChild($ConfigFile.ImportNode($XMLNewNode, $true))
#Save the new file
$ConfigFile.Save("\\$server\C$\programdata\AppDynamics\DotNetAgent\Config\config.xml")
