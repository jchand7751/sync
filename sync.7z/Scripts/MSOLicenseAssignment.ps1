﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/2/2017 12:03 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		O365 license assignment script.
#>

#region Parameter set
[CmdletBinding()]
Param (
)
#endregion

#region Base variables and environment information
$logfile = "e:\scripts\logs\MSOlicenseassignment.txt"
$undopath = "e:\scripts\msolundo"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
	Import-Module MSOnline -ea 'Stop' | Out-Null
	Import-Module MSOnlineExtended -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays
$PasswordFile = "e:\scripts\kf"
$licensefile = "e:\scripts\license.json"
$msolcredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "s_useradmin@PIMCO.onmicrosoft.com", (Get-Content $PasswordFile | ConvertTo-SecureString)

#endregion

#region Script functions

function ConnectToTenant
{
	#Connect to the tenant
	try
	{
		Connect-MSOLService -Credential $msolcredential -ea Stop | Out-Null
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to connect to the MSOnline tenant" -Throw
	}
}

function GetMSOLUsers
{
	try
	{
		#Get all synced users
		$script:msonlineusers = Get-MSOLUser -All -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Could not query O365 users" -Throw
	}
}

function GetCloudUsers
{
	try
	{
		#Get enabled cloud users
		$script:cloudusers = Get-QADUser -Service pimco.imswest.sscims.com -LdapFilter "(cloudsync=*)" -SizeLimit 0 -IncludedProperties cloudsync, AccountIsDisabled -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Could not query domain users" -Throw
	}
}

function FindUser
{
	param ($user)
	Add-Log -Type 'Information' -Message "Checking for a user that matches userprincipalname $($user.email)"
	try
	{
		#Find the specific user in the loop
		$script:selecteduser = $script:msonlineusers | where { $_.userprincipalname -eq $user.email } -ea 'Stop'
		$script:userFullLicenses = ((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -notlike "*-*" } -ea 'Stop'
		$script:userDividedLicenses = ((($user.cloudsync).split("|")).trimstart(" ")) | where { $_ -like "*-*" } -ea 'Stop'
		if ($script:selecteduser -like "" -or $script:selecteduser.count -ge 2)
		{
			throw "Error"
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to match a user in O365."
		break
	}
	Add-Log -Type 'Information' -Message "Found user"
	
	#Build license files
	try
	{
		$script:licenselist = Get-Content -Raw -Path $licensefile -ea 'Stop' | ConvertFrom-Json -ea 'Stop'
		$script:currentlist = Get-Content -Raw -Path $licensefile -ea 'Stop' | ConvertFrom-Json -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Could not load json license files" -Throw
	}
	
}

function BuildLicenseObjectfromAD
{
	Add-Log -Type 'Information' -Message "Building a license object from AD for $($script:selecteduser.userprincipalname)"
	<#
	Using the JSON license list ($script:licenselist) as a base,
	enable divided licenses products that match the cloudsync attribute
	#>
	foreach ($lic in $script:userDividedLicenses)
	{
		#parent of product
		$parent = $lic.substring(0, ($lic.indexof("-")))
		#product
		$parentlength = ($lic.indexof("-") + 1)
		$productlength = ($lic.length - $parentlength)
		$product = $lic.substring($parentlength, $productlength)
		#$product = $lic.substring(3, ($lic.length - 3))
		#$product
		#subproducts of parent
		$productlist = ($script:licenselist | where { $_.licensename -eq $parent }).products
		#Enable the product
		($productlist | where { $_.productname -eq $product }).status = "Enabled"
		Add-Log -Type 'Information' -Message "Enabling $product"
	}
	
	<#
	Using the JSON license list ($script:licenselist) as a base,
	enable full licenses (all products) that match the cloudsync attribute 
	#>
	foreach ($lic in $script:userFullLicenses)
	{
		$productlist = ($script:licenselist | where { $_.licensename -eq $lic }).products
		#Enable the product
		#($productlist | where { $_.productname -eq "All" }).status = "Enabled"
		foreach ($product in $productlist)
		{
			$product.status = "Enabled"
			Add-Log -Type 'Information' -Message "Enabling $lic"
		}
	}
}

function BuildLicenseObjectfromMSO
{
	Add-Log -Type 'Information' -Message "Building a license object from O365 for $($script:selecteduser.userprincipalname)"
	<#
	Using the JSON license list ($script:currentlist) as a base,
	enable divided licenses products that match 
	#>
	foreach ($lic in $script:selecteduser.licenses)
	{
		$parent = $lic
		$parentsku = "PIMCO:" + $lic.accountsku.skupartnumber
		foreach ($enabled in ($parent.servicestatus | where { $_.provisioningStatus -ne "Disabled" }))
		{
			if ((($script:currentlist | where { $_.licensesku -eq $parentsku }).products | where { $_.productsku -eq $($enabled.serviceplan.servicename) }).status)
			{
				Add-Log -Type 'Information' -Message "Enabling $($enabled.serviceplan.servicename)"
				(($script:currentlist | where { $_.licensesku -eq $parentsku }).products | where { $_.productsku -eq $($enabled.serviceplan.servicename) }).status = "Enabled"
			}
			else
			{
				Add-Log -Type 'Information' -Message "The product $($enabled.serviceplan.servicename) is not available in the license.json - skipping"
			}
		}
	}
}

function BuildActionArray
{
	Add-Log -Type 'Information' -Message "Building the action array based on mismatched licenses"
	$script:mismatchedlicenses = @()
	#Loop through the sku list and find out if each product sku is enabled or disabled via AD attribute
	$skulist = $script:licenselist.products.productsku
	$liclist = $script:licenselist
	
	foreach ($lic in $liclist)
	{
		$specificlicenselist = $script:licenselist | where { $_.licensename -eq $lic.licensename }
		$specificcurrentlist = $script:currentlist | where { $_.licensename -eq $lic.licensename }
		foreach ($sku in $specificlicenselist.products.productsku)
		{
			#$sku
			#Case statement for if this sku is enabled or disabled
			switch (($specificlicenselist.products | where { $_.productsku -eq $sku }).status)
			{
				"Enabled" {
					#Write-Host "$sku is enabled"
					#Check for a mismatch between AD and O365
					if (($specificlicenselist.products | where { $_.productsku -eq $sku }).status -ne ($specificcurrentlist.products | where { $_.productsku -eq $sku }).status)
					{
						#if this product has a dependency, check and make sure that dependency is enabled or will be enabled this round
						#determine if we have a single, multiple dependency, or no dependency
						$dependency = ($specificlicenselist.products | where { $_.productsku -eq $sku }).dependency
						#Write-Host "$Sku dependency check $dependency"
						if ($dependency -ne "None" -and $dependency -notlike $null)
						{
							#Write-Host "$Sku has a dependency"
							$dependcheck = @()
							#Single dependency
							if ($dependency.contains(","))
							{
								$singledependency = ($specificlicenselist.products | where { $_.productsku -eq $sku }).dependency -split ","
								foreach ($dep in $singledependency)
								{
									if (($script:licenselist.products | where { $_.productsku -eq $dep }).status -eq "Enabled")
									{
										$dependcheck += "True"
									}
									else
									{
										$dependcheck += "False"
									}
									if (($script:licenselist.products | where { $_.productsku -eq $dep }).status -eq "Enabled")
									{
										$dependcheck += "True"
									}
									else
									{
										$dependcheck += "False"
									}
								}
							}
							#Multi dependency
							if ($dependency.contains("+"))
							{
								$multipledependency = ($script:licenselist.products | where { $_.productsku -eq $sku }).dependency -split "+"
							}
							
							#Make sure the dependency is met
							#Write-Host "here's dependcheck $dependcheck"
							if (($dependcheck.contains("True")) -eq $true)
							{
								$object = "" | select Action, SKU, LicenseName
								$object.Action = "Enable"
								$object.SKU = $sku
								$object.LicenseName = ($specificlicenselist | where { $_.products.productsku -eq $sku }).licensename
								Add-Log -Type 'Information' -Message "$sku is enabled in Active Directory - dependencies confirmed - Need to enable in O365"
								$script:mismatchedlicenses += $object
							}
							else
							{
								#Disable the SKU because we did not pass the dependency check
								($specificlicenselist.products | where { $_.productsku -eq $sku }).status = "Disabled"
								Add-Log -Type 'Warning' -Message "Can't add $sku which is enabled in Active Directory - Missing dependency"
							}
						}
						else
						{
							$object = "" | select Action, SKU, LicenseName
							$object.Action = "Enable"
							$object.SKU = $sku
							$object.LicenseName = ($specificlicenselist | where { $_.products.productsku -eq $sku }).licensename
							Add-Log -Type 'Information' -Message "$sku is enabled in Active Directory - Need to enable in O365"
							$script:mismatchedlicenses += $object
						}
					}
				}
				"Disabled" {
					#Check for a mismatch between AD and O365
					if (($specificlicenselist.products | where { $_.productsku -eq $sku }).status -ne ($specificcurrentlist.products | where { $_.productsku -eq $sku }).status)
					{
						$object = "" | select Action, SKU, LicenseName
						$object.Action = "Disable"
						$object.SKU = $sku
						$object.LicenseName = ($specificlicenselist | where { $_.products.productsku -eq $sku }).licensename
						Add-Log -Type 'Information' -Message "$sku is not enabled in Active Directory - Need to disable in O365"
						$script:mismatchedlicenses += $object
					}
				}
			}
		}
	}
}


function RemoveLicensesFromDisabledUsers
{
	Add-Log -Type 'Information' -Message "Checking if the user is disabled"
	#Remove existing licenses if the account is disabled in AD
	if ($user.AccountIsDisabled -eq $true)
	{
		try
		{
			Add-Log -Type 'Information' -Message "Removing all licenses from $($script:selecteduser.userprincipalname)"
			$script:selecteduser | Set-MsolUserLicense -RemoveLicenses -ea 'Stop'
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Failed to remove all licenses from $($script:selecteduser.userprincipalname)"
		}
		return
	}
}

function CheckUserLocation
{
	Add-Log -Type 'Information' -Message "Checking user's usage location"
	try
	{
		if ($script:selecteduser.UsageLocation -eq $null)
		{
			Add-Log -Type 'Information' -Message "Setting location to US"
			$script:selecteduser | Set-MsolUser -UsageLocation US -ea 'Stop'
		}
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to set user's usage location, license assignment will fail without this"
	}
}

function SetLicenses
{
	if ($script:mismatchedlicenses)
	{
		Add-Log -Type 'Information' -Message "Backing up action file"
		try
		{
			if ((Test-Path $undopath\$($user.samaccountname) -ea 'Stop') -eq $true)
			{
				#Keep the last 3 change files
				if ((ls $undopath\$($user.samaccountname)).count -ge 3)
				{
					#Remove the oldest file
					(ls $undopath\$($user.samaccountname) | sort lastwritetime -Descending)[-1] | Remove-Item -Force -ea 'Stop'
					$filedate = ((Get-Date).tostring("MM-dd-yyyy-hh-mm-ss"))
					($script:mismatchedlicenses | convertto-json) | Out-File $undopath\$($user.samaccountname)\$($user.samaccountname)-$filedate.json -ea 'Stop'
				}
				else
				{
					$filedate = ((Get-Date).tostring("MM-dd-yyyy-hh-mm-ss"))
					($script:mismatchedlicenses | convertto-json) | Out-File $undopath\$($user.samaccountname)\$($user.samaccountname)-$filedate.json -ea 'Stop'
				}
			}
			else
			{
				#Make an undo directory for the user
				mkdir $undopath\$($user.samaccountname) -ea 'Stop'
				$filedate = ((Get-Date).tostring("MM-dd-yyyy-hh-mm-ss"))
				($script:mismatchedlicenses | convertto-json) | Out-File $undopath\$($user.samaccountname)\$($user.samaccountname)-$filedate.json -ea 'Stop'
			}
		}
		catch
		{
			Add-Log -Type 'Warning' -Message "Action file backup failed"
		}
	}
	$uniquelicensemismatch = $script:mismatchedlicenses.licensename | sort -unique
	foreach ($licensename in $uniquelicensemismatch)
	{
		foreach ($selectedlicense in ($script:licenselist | where { $_.licensename -eq $licensename }))
		{
			$DisabledPlans = [string]($selectedlicense.products | where { $_.status -eq "Disabled" }).productsku -replace (" ", "`", `"")
			$DisabledPlans = "`"" + $DisabledPlans + "`""
			#$selectedlicense.licensesku
			#$DisabledPlans
			#$newMSOL = New-MsolLicenseOptions -AccountSkuId $selectedlicense.licenseSku -DisabledPlans $DisabledPlans
			if ($script:selecteduser.licenses.accountskuid -contains $($selectedlicense.licenseSku))
			{
				try
				{
					Add-Log -Type 'Information' -Message "Adding AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$newMSOL = Invoke-Expression "New-MsolLicenseOptions -AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
					$script:selecteduser | Set-MsolUserLicense -Licenseoptions $newMSOL -ea 'Stop'
				}
				catch
				{
					Add-Log -Type 'Error' -Message "Failed to set licenses on $($script:selecteduser.userprincipalname)"
				}
			}
			else
			{
				try
				{
					if ($DisabledPlans -like '""')
					{
						Add-Log -Type 'Information' -Message "Adding AccountSkuId with add licenses $($selectedlicense.licenseSku)"
						$script:selecteduser | Set-MsolUserLicense -AddLicenses $($selectedlicense.licenseSku) -ea 'Stop'
					}
					else
					{
						Add-Log -Type 'Information' -Message "Adding AccountSkuId with add licenses $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
						$newMSOL = Invoke-Expression "New-MsolLicenseOptions -AccountSkuId $($selectedlicense.licenseSku) -DisabledPlans $DisabledPlans"
						$script:selecteduser | Set-MsolUserLicense -Licenseoptions $newMSOL -AddLicenses $($selectedlicense.licenseSku) -ea 'Stop'
					}
				}
				catch
				{
					Add-Log -Type 'Error' -Message "Failed to set licenses on $($script:selecteduser.userprincipalname)"
				}
			}
		}
	}
	
	#If all the products are disabled, remove the top level license
	Add-Log -Type 'Information' -Message "Checking if top level licenses should be removed"
	foreach ($license in $script:licenselist)
	{
		if ($license.products.status -contains "enabled")
		{ }
		else
		{
			if ($script:selecteduser.licenses.accountskuid -contains $($license.licensesku))
			{
				try
				{
					Add-Log -Type 'Information' -Message "Removing $($license.licensesku)"
					$script:selecteduser | Set-MsolUserLicense -RemoveLicenses $license.licensesku
				}
				catch
				{
					Add-Log -Type 'Error' -Message "Failed to set licenses on $($script:selecteduser.userprincipalname)"
				}
			}
		}
	}
}

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"
ConnectToTenant
GetMSOLUsers
GetCloudUsers
#$script:cloudusers = $script:cloudusers | where { $_.name -eq "chandler, james" -or $_.name -eq "Dao, Neo" -or $_.name -eq "Sipkovich, James" -or $_.name -eq "Loesch, Maria"}
$x = 0
$totalcount = $script:cloudusers.count
#Loop through enabled cloud users
foreach ($user in $script:cloudusers)
{
	$x++
	Add-Log -Type 'Information' -Message "Starting on user $x of $totalcount"
	FindUser $user
	CheckUserLocation
	RemoveLicensesFromDisabledUsers
	BuildLicenseObjectfromAD
	BuildLicenseObjectfromMSO
	BuildActionArray
	SetLicenses
}
Add-Log -Type 'Information' -Message "Script complete"
#endregion