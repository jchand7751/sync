﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/22/2017 6:33 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

do
{
	sleep 120
	$check = [System.Net.DNS]::GetHostEntry('pimco').addresslist.ipaddresstostring
	foreach ($i in $check)
	{
		if ($i -notlike "144.*" -and $i -notlike "10.*")
		{
			write-Warning "Found a host that does not appear to match the server subnets! - $i"
			Send-MailMessage -From no-reply@pimcoDNScheck.com -To james.chandler@pimco.com -Body "Check DNS - pimco appears to be resolving to a non server subnet" -Subject "pimco DNS address in use by a rogue system!" -SmtpServer mailhost
		}
		else
		{
			write-host "Check seems to be good"
		}
	}
	sleep 120
	$check2 = [System.Net.DNS]::GetHostEntry('pimco.imswest.sscims.com').addresslist.ipaddresstostring
	foreach ($i in $check2)
	{
		if ($i -notlike "144.*" -and $i -notlike "10.*")
		{
			write-Warning "Found a host that does not appear to match the server subnets! - $i"
			Send-MailMessage -From no-reply@pimcoDNScheck.com -To james.chandler@pimco.com -Body "Check DNS - pimco.imswest.sscims.com appears to be resolving to a non server subnet" -Subject "pimco.imswest.sscims.com DNS address in use by a rogue system!" -SmtpServer mailhost
		}
		else
		{
			write-host "Check2 seems to be good"
		}
	}
}
until ($a -eq "blah") 