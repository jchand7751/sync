﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/18/2013 11:17 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param ($cluster)
Add-PSSnapin VMware.VimAutomation.Core
<#
$tasks = Get-Task

$taskarray = @()

foreach ($i in $tasks)
	{
	$object = "" | Select Name, Description, State, PercentComplete, StartTime, FinishTime, Initiatedby
	$matchingevent = Get-VIEvent | where {[string]($_.info.task) -eq $i.id}
	$object.name = $i.name
	$object.state = $i.state
	$object.PercentComplete = $i.PercentComplete
	$object.StartTime = $i.StartTime
	$object.FinishTime = $i.FinishTime
	$object.Description = $i.Description
	$object.Initiatedby = $matchingevent.username
	$taskarray += $object
	$object
	}
$taskarray
#>

function VMsonCluster
{
Param ($cluster)
$allclusters = Get-view -viewtype clustercomputeresource

$selectedcluster = $allclusters | where {$_.name -eq $cluster}

$script:array = @()
$vmhosts = Get-view -viewtype hostsystem
$hostlist = $selectedcluster.host

foreach ($i in $hostlist) 
	{
	$selected = get-view $i
	$vmsonhost = $selected.vm
	$clusterinfo = Get-View $selected.parent
	foreach ($vm in $vmsonhost)
		{
		$vmdetails = Get-view $vm
		$object = "" | select Cluster, Hostname, VMname, ID
		$object.cluster = $clusterinfo.name
		$object.hostname = (get-view $i).name
		$object.vmname = $vmdetails.name
		$object.ID = $vmdetails.moref
		#$object
		$script:array += $object
		}
	}
#$script:array
}

function arraysort
{
	$uniquehosts = $script:array | select hostname | get-unique -asstring

	for ($y = 0 ; $y -le $uniquehosts.count ; $y++)
	{
		New-Variable hostvm$y -Value ($script:array | where {$_.hostname -eq $uniquehosts[$y].hostname})
	}

	$CreatedVariableNumber = (Get-Variable hostvm*).count
	
	$script:sortedarray = @()
	#pick the host variable with the most VMs on it
	for ($items = 0; $items -lt 500; $items++)
	{
		for ($x = 0; $x -lt ($CreatedVariableNumber - 1); $x++)
		{
			if ((Get-Variable hostvm$x).value[$items]) 
			{
				$script:sortedarray += ((Get-Variable hostvm$x).value[$items])
			}
		}
}	
	
	
}

VMsonCluster $cluster
arraysort

$runcounter = 0
$jobtracker = @()
$jobfinishtracker = 0
$finisharray = @()
$script:whoami = whoami
cls
$script:sortedarray
($script:array).count
($script:sortedarray).count
Read-Host "stop"
foreach ($vm in $script:sortedarray)
	{
	
	$b = $script:sortedarray.count
	
	$runcounter++
	While ($(Get-Task | where {$_.state -eq "Running" -and $_.name -eq "RelocateVM_task" -and $_.extensiondata.info.reason.username -eq $script:whoami}).count -ge "3")
        { 
        $totalrunningJobs = ($(Get-Task | where {$_.state -eq "Running" -and $_.name -eq "RelocateVM_task" -and $_.extensiondata.info.reason.username -eq $script:whoami})).count
        $totalthreadedJobs =  $jobtracker.count
        $totalcompleteJobs = $jobfinishtracker
        $totalnotfinishedjobs = ($b - $totalthreadedjobs) 
        Write-Progress -id 0 -Activity "Moving VMs" -Status "Max threads open, waiting for threads to close" -CurrentOperation "$totalnotfinishedjobs threads left - $totalrunningjobs threads open" -PercentComplete ($totalcompleteJobs / $b * 100) 
        #foreach ($runjob in $jobtracker)
		#	{
		#	Write-Progress -ParentId 1 -Activity "Active task $runjob" -Status "VM Move" -CurrentOperation "Moving VM" -PercentComplete ((Get-Task -Id $runjob).percentcomplete)
		#	}
		
		$activecounter = 1
		for ($o=1; $o -lt $jobtracker.count; $o++) 
			{
			$jname = (((get-task -id $jobtracker[$o]).extensiondata).info).entityname
			$checkactive = Get-Task -Id $jobtracker[$o]
			if ($checkactive -and $checkactive.state -eq "running")
				{
				Write-Progress -ParentId ($activecounter - 1) -Id ($activecounter + 1) -Activity "Active task $jname" -Status "VM Move" -CurrentOperation "Moving VM" -PercentComplete ((Get-Task -Id $jobtracker[$o]).percentcomplete)
				$activecounter++
				}
			}
		sleep 3
		
		}
	############# JOB TO BE RUN HERE #############
	$datastoretopick = ((Get-VMHost -Name $script:sortedarray[0].hostname | Get-Datastore -Name NewPimco* | where {$_.extensiondata.summary.freespace} | sort -Property FreeSpaceGB -Descending)[0]).name
	#only new SAN
	#ignore DCs?
	if ($datastoretopick)
		{}
		else
			{
			Write-Warning "Storage not found, exiting"
			Exit
			}
	$starttask = get-vm -Name $vm.vmname | move-vm -Datastore $datastoretopick -RunAsync #-WhatIf
	$jobtracker += $starttask.id
	
	foreach ($item in $jobtracker)
		{
		$object = "" | select Jobname, Status
		$object.jobname = $item
		$check = Get-Task -Id $item
		$object.status = $check.state
		if ($check.state -eq "Success" -or $check.state -eq "Failure" -and ($finisharray | where {$_.jobname -eq $item}) -eq $null)
			{
			$jobfinishtracker++
			$finisharray += $object
			}
		}
	}   
#While ($(Get-Task | where {$_.state -eq "Running" -and $_.name -eq "RelocateVM_task"}).count -gt 0 -or ($(Get-Task | where {$_.state -eq "Running" -and $_.name -eq "RelocateVM_task"}.count -ne $null)))
While (((Get-Task | where {$_.state -eq "Running" -and $_.name -eq "RelocateVM_task" -and $_.extensiondata.info.reason.username -eq $script:whoami}).count) -gt "0")
	{
	$b = $script:array.count
	$rJobs = ($(Get-Task | where {$_.state -eq "Running" -and $_.name -eq "RelocateVM_task" -and $_.extensiondata.info.reason.username -eq $script:whoami})).count
    Write-Progress -Activity "Finishing last threads" -Status "Waiting for remaining moves" -CurrentOperation "$rJobs left" -PercentComplete (($b - $rJobs) / $b * 100) 
	}

