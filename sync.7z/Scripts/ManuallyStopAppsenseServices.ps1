﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/3/2016 2:15 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

"NB-18-1196", "NB-18-1183", "NB-18-1181-1", "NB-18-1185-1", "NB-20-1049", "NB-18-1182", "NB-18-1184", "NB-18-1221", "VMW7NB-P-DEV037", "NB-18-1224", "NB-18-1225", "NB-18-1222-1", "NB-18-1223", "NB-18-1220"


foreach ($computer in $computers)
{
	foreach ($service in $AppsenseServices)
	{
		try
		{
			Write-host "Changing startup to disabled on $service"
			#Add-Content -Path $logfile "$(executiontime) - Changing startup to disabled on $service"
			$returncode = (gwmi win32_service -filter "Name=$service" -comp $computer).changestartmode("Disabled")
			#$command = "cmd /c sc //$computer config $service start= disabled"
			#$returncode = Invoke-Expression $command
			if ($returncode.returnvalue -ne 0)
			{
				throw "Failed to change start mode on $service"
			}
		}
		Catch
		{
			#Write-Warning "Failed to stop $service"
			write-host "Failed to change startup to disabled on $service"
		}
	}
	$AppsenseServices = "'AppSense Watchdog Service'", "'Appsense Client Communications Agent'", "'AppSense EmCoreService'"
	foreach ($service in $AppsenseServices)
	{
		try
		{
			#Write-Verbose "Stopping $service"
			write-host "Stopping $service"
			(gwmi win32_service -filter "Name=$service" -ComputerName $computer).StopService() | Out-Null
		}
		Catch
		{
			Write-Warning "Failed to stop $service"
			#Add-Content -Path $logfile "$(executiontime) - Failed to stop $service"
		}
	}
}