﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/16/2017 12:03 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	CloudsyncAttributePopulation
	===========================================================================
	.DESCRIPTION
		Set the cloudsync AD attribute for users that are members of cloud groups (O365-*)
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '1')]
	[switch]$FullSync,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '2')]
	[switch]$DifferentialSync,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '3')]
	[string]$User
)
#endregion

#region Base variables and environment information
$logfile = "e:\scripts\logs\cloudsyncattribute.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays
#Differential group sync location
$differentialsynclocation = "e:\scripts\groupdata\"

#Array for cloud users
$script:cloudsyncusers = @()

#endregion

#region Script functions
function GetCloudGroups
{
	try
	{
		#Get all of the cloud groups
		$script:cloudsyncgroups = Get-QADGroup "O365-*" -Service pimco.imswest.sscims.com -ea 'Stop' -DontUseDefaultIncludedProperties -IncludedProperties AllMembers
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to get cloud groups" -Throw
	}
	$count = $($script:cloudsyncgroups).count
	Add-Log -Type 'Information' -Message "Found $count cloud groups"
	foreach ($group in $script:cloudsyncgroups)
	{
		try
		{
			if (Test-Path $differentialsynclocation\$($group.name).txt)
			{
				Remove-Item $differentialsynclocation\$($group.name).txt -Force -ea 'Stop'
				$group.allmembers | Out-File $differentialsynclocation\$($group.name).txt -Force -ea 'Stop'
			}
			else
			{
				$group.allmembers | Out-File $differentialsynclocation\$($group.name).txt -Force -ea 'Stop'
			}
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Failed to create group file data, please ensure the following path exists: $($differentialsynclocation)" -Throw
		}
	}
}

function GetCloudUsers
{
	#Get all of the users in the cloud groups
	$script:cloudsyncusers = $script:cloudsyncgroups.allmembers
	#Just get a unique list of cloud users
	$script:cloudsyncusers = $script:cloudsyncusers | select -Unique
	$count = $($script:cloudsyncusers).count
	Add-Log -Type 'Information' -Message "Found $count cloud users"
}

$setattributescriptblock = {
	<#
	Loop through the cloud users find the cloud groups they are a member of, strip off the first characters of the group name (O365) and build the array that contains their
	samaccountname, email, and cloudsyncvalue
	#>
	param ($User)
	
	function executiontime
	{
		get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
	}
	
	function Add-Log
	{
		param (
			[ValidateSet('Information', 'Warning', 'Error')]
			$Type,
			$Message,
			$EventId,
			$EventSource,
			[switch]$Throw
		)
		Write-Verbose "$(executiontime) - $type : $message"
		Add-Content -Path $logfile "$(executiontime) - $type : $message"
		if ($EventId -ne $null -and $EventSource -ne $null)
		{
			Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
		}
		switch ($throw)
		{
			$true { throw "$type : $message" }
			$false { }
			default { }
		}
	}
	Add-PSSnapin Quest.ActiveRoles.ADManagement | Out-Null
	$logfile = "e:\scripts\logs\cloudsyncattribute.txt"
	$script:useractionarray = @()

	$object = "" | select samaccountname, cloudsyncvalue, cloudsyncattribute, DN, Result
	$object.DN = $user
	
	$o365groups = @()
	try
	{
		$userlookup = ([ADSI]"LDAP://$user")
		if (!$userlookup.samaccountname)
		{
			throw "Failed to lookup user"
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to query $(((([string]($object.dn -split ', ')[0..1] -replace 'CN=') -replace '\\ ', ', ') -split ',', 3)[0..1] -join ',')"
		break
	}
	Add-Log -Type 'Information' -Message "Processing user - $($userlookup.samaccountname) - set attribute"
	$object.samaccountname = $userlookup.samaccountname
	$o365groups += $userlookup.memberof | foreach {
		try
		{
			$groupdn = $_
			$groupdncleanup = $groupdn -replace "/","\/"
			$group = ([ADSI]"LDAP://$groupdncleanup")
			if (!$group.name)
			{
				throw "Failed to lookup group"
			}
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Failed to query $groupdn - $($group.name)"
			break
		}
		if ($group.name -like "o365-*")
		{
			[string]$group.name
		}
	}
	$o365groups = $o365groups | sort
	foreach ($group in $o365groups)
	{
		$attributename = ($group -replace "O365-")
		$object.cloudsyncvalue = ($object.cloudsyncvalue + $attributename + "|")
	}
	if ($object.cloudsyncvalue)
	{
		$object.cloudsyncvalue = ((($object.cloudsyncvalue).trimstart("")).trimend("|"))
	}
	#$object.cloudsyncattribute = [string](([ADSI]"LDAP://$($object.dn)").cloudsync)
	$object.cloudsyncattribute = [string]$userlookup.cloudsync
	if ($object.cloudsyncvalue -ne $object.cloudsyncattribute)
	{
		#Add-Log -Type 'Information' -Message "Mismatch on cloudsync attributes for '$(((([string]($object.dn -split ', ')[0..1] -replace 'CN=') -replace '\\ ', ', ') -split ',', 3)[0..1] -join ",")' - '$($object.cloudsyncvalue)'"
		Add-Log -Type 'Information' -Message "Mismatch on cloudsync attributes for '$($userlookup.samaccountname)' - '$($object.cloudsyncvalue)'"
		try
		{
			Set-QADUser -Identity $object.dn -Service pimco.imswest.sscims.com -ObjectAttributes @{ cloudsync = $object.cloudsyncvalue } -ea Stop | Out-Null
			$object.result = "User set successfully"
		}
		catch
		{
			$object.result = "Failed to do set"
			Add-Log -Type 'Error' -Message "Failed to set cloudsync attribute for $($userlookup.samaccountname)"
			Add-Log -Type 'Error' -Message $error[0]
		}
	}
	else
	{
		Add-Log -Type 'Information' -Message "Attribute for $($userlookup.samaccountname) is already set"
		$object.result = "No updates needed"
	}
	$object
}

function ClearDisabledUsersAttributes
{
	Add-Log -Type 'Information' -Message "Starting to clear attributes from disabled users"
	#Clear cloudsync values from disabled users and users that are no longer a member of any O365- groups
	try
	{
		$disabledusers = Get-QADUser -Service pimco.imswest.sscims.com -Disabled -IncludedProperties cloudsync -DontUseDefaultIncludedProperties -sizelimit 0 | where { $_.cloudsync -ne $null }
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to query Active Directory"
	}
	
	$disabledusers | foreach {
		if (($_ | Get-QADMemberOf -Name "O365-*" -Service pimco.imswest.sscims.com -ea 'Stop' -DontUseDefaultIncludedProperties) -eq $null)
		{
			Add-Log -Type 'Information' -Message "$($_.samaccountname) has a cloudsync attribute of $($_.cloudsync) but the account is disabled, setting cloudsync value to null"
			try
			{
				Set-QADUser -Service pimco.imswest.sscims.com -Identity $_.samaccountname -ObjectAttributes @{ cloudsync = "" } -ea Stop | Out-Null
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to clear attribute!"
			}
		}
	}
}

function RunSpace
{
	$RunspaceTotal = $RunspaceCollection.count
	$CompletionCount = 0
	$Resultsarray = @()
	While ($RunspaceCollection)
	{
		Foreach ($Runspace in $RunspaceCollection.ToArray())
		{
			If ($Runspace.Runspace.IsCompleted)
			{
				#write-host "Run space finished"
				if ($Runspace.Powershell.HadErrors -eq $true)
				{
					$runspace.powershell.streams.error
				}
				#write the data
				$resultsarray += $Runspace.PowerShell.EndInvoke($Runspace.Runspace)
				#See the data
				#$Runspace.PowerShell.EndInvoke($Runspace.Runspace)
				#close the session
				$Runspace.PowerShell.Dispose()
				#$runspace.powershell
				$RunspaceCollection.Remove($Runspace)
				$CompletionCount++
				Write-Progress -Activity "Runspace in progress" -Status "Processing threads" -CurrentOperation "Remaining threads: $($RunspaceTotal - $Completioncount) - $('{0:N0}' -f $($Completioncount/$RunspaceTotal * 100))% Complete" -PercentComplete "$($Completioncount/$RunspaceTotal * 100)"
			}
			else
			{
				sleep 5
				Write-Progress -Activity "Runspace in progress" -Status "Processing threads" -CurrentOperation "Remaining threads: $($RunspaceTotal - $Completioncount) - $('{0:N0}' -f $($Completioncount/$RunspaceTotal * 100))% Complete" -PercentComplete "$($Completioncount/$RunspaceTotal * 100)"
			}
		}
	}
	foreach ($result in $Resultsarray)
	{
		Add-Log -Type 'Information' -Message "User: $($result.samaccountname)"
		if ($result.result -eq "No updates needed")
		{
			Add-Log -Type 'Information' -Message "Result: $($result.result)"
		}
		else
		{
			Add-Log -Type 'Information' -Message "Old Attribute: $($result.cloudsyncattribute)"
			Add-Log -Type 'Information' -Message "New Attribute: $($result.cloudsyncvalue)"
			Add-Log -Type 'Information' -Message "Result: $($result.result)"
		}
	}
}

function GetCloudUsersDifferential
{
	#Run only against the users that changed since the last full sync
	try
	{
		#Get the o365 groups from the last full sync
		$knowngroups = Get-ChildItem $differentialsynclocation -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Can't read previous group membership, do a full sync or check permissions" -Throw
	}
	foreach ($group in $knowngroups)
	{
		try
		{
			#foreach last sync group get the previous members and compare to current group membership, if a change is detected process the account
			$lastsyncmembers = Get-Content $differentialsynclocation\$($group.name)
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Can't read previous group membership, do a full sync or check permissions" -Throw
		}
		try
		{
			$currentmembers = (Get-QADGroup -Service Pimco.imswest.sscims.com -Name $group.BaseName -ea Stop).members
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Can't find $($group.basename) in AD"
		}
		foreach ($member in $currentmembers)
		{
			if ($lastsyncmembers -notcontains $member)
			{
				#A member has been added to this group since the last full sync
				Add-Log -Type 'Information' -Message "$member has been added as a member of $($group.BaseName)"
				$script:cloudsyncusers += $member
			}
		}
		
		foreach ($member in $lastsyncmembers)
		{
			if ($currentmembers -notcontains $member)
			{
				#A member has been removed from this group since the last full sync
				Add-Log -Type 'Information' -Message "$member is no longer a member of $($group.BaseName)"
				$script:cloudsyncusers += $member
			}
		}
	}
	
	$script:cloudsyncusers = $script:cloudsyncusers | select -Unique
	$count = $($script:cloudsyncusers).count
	Add-Log -Type 'Information' -Message "Found $count cloud users"
}

$clearattributesscriptblock = {
	param ($User)
	
	function executiontime
	{
		get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
	}
	
	function Add-Log
	{
		param (
			[ValidateSet('Information', 'Warning', 'Error')]
			$Type,
			$Message,
			$EventId,
			$EventSource,
			[switch]$Throw
		)
		Write-Verbose "$(executiontime) - $type : $message"
		Add-Content -Path $logfile "$(executiontime) - $type : $message"
		if ($EventId -ne $null -and $EventSource -ne $null)
		{
			Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
		}
		switch ($throw)
		{
			$true { throw "$type : $message" }
			$false { }
			default { }
		}
	}
	Add-PSSnapin Quest.ActiveRoles.ADManagement | Out-Null
	$logfile = "e:\scripts\logs\cloudsyncattribute.txt"
	$script:useractionarray = @()
	
	$object = "" | select samaccountname, cloudsyncvalue, cloudsyncattribute, DN, Result
	$object.DN = $user
	
	$o365groups = @()
	try
	{
		$userlookup = ([ADSI]"LDAP://$user")
		if (!$userlookup.samaccountname)
		{
			throw "Failed to lookup user"
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to query $(((([string]($object.dn -split ', ')[0..1] -replace 'CN=') -replace '\\ ', ', ') -split ',', 3)[0..1] -join ',')"
		break
	}
	Add-Log -Type 'Information' -Message "Processing user - $($userlookup.samaccountname) - clear attribute"
	$object.samaccountname = $userlookup.samaccountname
	$o365groups += $userlookup.memberof | foreach {
		try
		{
			$groupdn = $_
			$groupdncleanup = $groupdn -replace "/", "\/"
			$group = ([ADSI]"LDAP://$groupdncleanup")
			if (!$group.name)
			{
				throw "Failed to lookup group"
			}
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Failed to query $groupdn - $($group.name)"
			break
		}
		if ($group.name -like "o365-*")
		{
			[string]$group.name
		}
	}
	$o365groups = $o365groups | sort
	if ($o365groups -eq $null)
	{
		Add-Log -Type 'Information' -Message "$($userlookup.samaccountname) has a cloudsync attribute of $($userlookup.cloudsync) but is no longer a member of any AD groups, setting cloudsync value to null"
		try
		{
			Set-QADUser -Service pimco.imswest.sscims.com -Identity $user -ObjectAttributes @{ cloudsync = "" } -ea Stop | Out-Null
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Failed to clear attribute for $($userlookup.samaccountname)!"
		}
	}
	else
	{
		Add-Log -Type 'Information' -Message "$($userlookup.samaccountname) has a cloudsync attribute of $($userlookup.cloudsync) and is a member of at least one group"
	}
	
}

function RunspaceSetup-SetAttribute
{
	Add-Log -Type 'Information' -Message "Starting runspace setup - set attribute"
	$RunspaceCollection = @()
	$RunspacePool = [RunspaceFactory]::CreateRunspacePool(1, 100)
	$RunspacePool.Open()
	
	foreach ($user in $script:cloudsyncusers)
	{
		#Create a PowerShell object to run the runspace, add the script and argument.
		$Powershell = [PowerShell]::Create().AddScript($setattributescriptblock).AddArgument($User)
		#Specify runspace to use
		$Powershell.RunspacePool = $RunspacePool
		
		#Create Runspace collection
		[Collections.Arraylist]$RunspaceCollection += New-Object -TypeName PSObject -Property @{
			Runspace = $PowerShell.BeginInvoke()
			PowerShell = $PowerShell
		}
	}
	Runspace
}

function RunspaceSetup-ClearAttribute
{
	Add-Log -Type 'Information' -Message "Starting runspace setup - clear attribute"
	$RunspaceCollection = @()
	$RunspacePool = [RunspaceFactory]::CreateRunspacePool(1, 100)
	$RunspacePool.Open()
	try
	{
		$formercloudusers = Get-QADUser -Service pimco.imswest.sscims.com -LdapFilter "(cloudsync=*)" -SizeLimit 0 -IncludedProperties cloudsync -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to query AD for cloud users" -Throw
	}
	foreach ($user in $formercloudusers.dn)
	{
		#Create a PowerShell object to run the runspace, add the script and argument.
		$Powershell = [PowerShell]::Create().AddScript($clearattributesscriptblock).AddArgument($User)
		#Specify runspace to use
		$Powershell.RunspacePool = $RunspacePool
		
		#Create Runspace collection
		[Collections.Arraylist]$RunspaceCollection += New-Object -TypeName PSObject -Property @{
			Runspace = $PowerShell.BeginInvoke()
			PowerShell = $PowerShell
		}
	}
	Runspace
}

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"
switch ($PsBoundParameters.keys)
{
	"User" {
		try
		{
			$script:cloudsyncusers += (Get-QADUser -Service pimco.imswest.sscims.com -SamAccountName $User -ea 'Stop').dn
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Couldn't find user $user" -Throw
		}
		RunspaceSetup-SetAttribute
	}
	"FullSync" {
		GetCloudGroups
		GetCloudUsers
		RunspaceSetup-SetAttribute
		RunspaceSetup-ClearAttribute
		ClearDisabledUsersAttributes
	}
	"DifferentialSync" {
		GetCloudUsersDifferential
		RunspaceSetup-SetAttribute
	}
}
Add-Log -Type 'Information' -Message "Script complete"
#endregion