﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/4/2015 9:09 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($floor)

Add-PSSnapin Quest.ActiveRoles.ADManagement
Get-QADComputer -ComputerName nb-$floor* -sizelimit 0 | select name
$object = "" | select Computer, UEV, Appsense, LoggedInUser

Test-Connection -ComputerName $computer -Count 1 -Quiet
$object.Appsense =
try
{
	$object.Appsense = (Get-Service -ComputerName $computer -Name "AppSense Client Communications Agent" -ea 'Stop').status
}
catch
{
	$object.Appsense = "Not installed"
}
try
{
	$object.UEV = (Get-Service -ComputerName $computer -Name UevAgentService -ea 'Stop').status
}
catch
{
	$object.UEV = "Not installed"	
}
(gwmi Win32_ComputerSystem -ComputerName $computer).username
