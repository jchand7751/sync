﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	11/7/2016 4:21 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#$jobs = Get-CliqrJob

##VMware VMs that should be terminated but failed for whatever reason

$vmview = get-view -ViewType virtualmachine -ErrorAction 'Stop'

$array = @();
foreach ($i in $vmview)
{
	$object = "" | select VMname, JobID, Owner, externalID
	$object.vmname = ((($i.config.annotation) -split "\n" | where { $_ -like "*vmname*" })).split("=")[1]
	$object.JobID = ((($i.config.annotation) -split "\n" | where { $_ -like "*job_id*" })).split("=")[1]
	$object.Owner = ((($i.config.annotation) -split "\n" | where { $_ -like "*owner*" })).split("=")[1]
	$object.ExternalID = ((($i.config.annotation) -split "\n" | where { $_ -like "*externalid*" })).split("=")[1]
	$array += $object
}

$array2 = @()
$array | foreach {
	$object = "" | select JobID, JobStatus, Message, VMs
	$a = Get-CliqrJobDetails -JobID $_.jobid
	if ($a.status -notlike "jobrunning" -and $_.jobid -notlike "")
	{
		write-host "check $($_.jobid) - $($a.status) - $($a.statusMsg) - $($a.virtualmachines.id)"
		$object.JobId = $_.jobid
		$object.Jobstatus = $a.status
		$object.Message = $a.statusMsg
		$object.VMs = [string]$a.virtualmachines.id
		$object
		$array2 += $object
	}
}



#foreach ($i in $array)
#{
#	$i | where { $_.jobid -like $jobs.deploymentinfo.deploymentid	}
#}