﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/21/2015 3:07 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#Daily build
Add-PSSnapin Quest.ActiveRoles.ADManagement
$serverarray = Get-QADComputer -OSName "Windows Server 2008*" -SizeLimit 0 | select name

$RunspaceCollection = @()
$RunspacePool = [RunspaceFactory]::CreateRunspacePool(1, 40)
$RunspacePool.Open()

$scriptblock = { param ($server); write-verbose "starting script"; \\naspmhome\technology\Chandler_James\Private\Appsense\scripts\IISDetails.ps1 $server }

foreach ($Server in $serverarray)
{
	
	#Create a PowerShell object to run add the script and argument.
	$Powershell = [PowerShell]::Create().AddScript($ScriptBlock).AddArgument($($Server.name))
	#Specify runspace to use
	$Powershell.RunspacePool = $RunspacePool
	
	#Create Runspace collection
	[Collections.Arraylist]$RunspaceCollection += New-Object -TypeName PSObject -Property @{
		Runspace = $PowerShell.BeginInvoke()
		PowerShell = $PowerShell
	}
}

$RunspaceTotal = $RunspaceCollection.count
$CompletionCount = 0
$Resultsarray = @()
while ($RunspaceCollection)
{
	foreach ($Runspace in $RunspaceCollection.ToArray())
	{
		if ($Runspace.Runspace.IsCompleted)
		{
			#write-host "Run space finished"
			if ($Runspace.Powershell.HadErrors -eq $true)
			{
				$runspace.powershell.streams.error
			}
			#write the data
			$resultsarray += $Runspace.PowerShell.EndInvoke($Runspace.Runspace)
			$Runspace.PowerShell.EndInvoke($Runspace.Runspace)
			#close the session
			$Runspace.PowerShell.Dispose()
			#$runspace.powershell
			$RunspaceCollection.Remove($Runspace)
			$CompletionCount++
			Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
			Write-host "Total count: $RunspaceTotal"
			write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
		}
		else
		{
			sleep 5
			write-host "Run space not done"
			Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
			Write-host "Total count: $RunspaceTotal"
			write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
		}
	}
}

$array = $Resultsarray

for ($x = 0; $x -lt $array.count; $x++)
{
	$array[$x] | Add-Member noteproperty -Name id -Value ($x + 1)
}

#$array
$array | Export-Csv c:\temp\dbtest1.csv