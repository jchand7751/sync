﻿$failurearray = @() 
$goodarray = @()
$a = import-csv c:\temp\forumrules2.csv

foreach ($i in $a) 
{
    $b = $i.name.replace(",",", ")
    if (get-qaduser -name $b) 
    {
    $goodarray += $b
    } 
    else 
    {
        #write-warning "Did not find user with name $b"
        #$object = "" | select Name, Revised
        $failurearray += $b
    }
}

$failurearray2 = @()
foreach ($i in $failurearray) 
{
    $c = (($i.split(" ")[0..1] -join " ") + "*")
    if (get-qaduser -name $c) 
    {
        write-host "$c seems to exist"
        if ((get-qaduser -name $c).count -eq 1)
        {
            $goodarray += $c
        }
        else
        {
            Write-Warning "$c is getting too many hits"
            $failurearray2 += $i
        }
    }
    else
    {
        write-warning "Still can't find an account for $i"
        $failurearray2 += $i
    }
}

$failurearray3 = @()

foreach ($i in $failurearray2) 
{
    if (((get-qaduser (($i.split(",")[0]).split(" ")[0])).name).count -eq 1)
    {
        $name = (get-qaduser (($i.split(",")[0]).split(" ")[0])).name
        write-host "I think $name seems to work for $i"
        $goodarray += $name
    }
    else
    {
        write-warning "STILL don't have a name for $i"
        $failurearray3 += $i
    }
}

foreach ($i 