﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/30/2015 2:18 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		UEV Migration Script.
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 1)]
	[string]$Computer,
	
	[Parameter(Mandatory = $true, Position = 2)]
	[string]$Username
)
Write-Verbose "Starting script"
#param ($Computer, $username)

#Set Variables
$whoami = whoami
$logfile = "C:\temp\UEVMigration-$username-$computer.txt"

#Functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function getadminusers
{
	Param ($computer)
	$testcon = Test-Connection $computer -Quiet -Count 1
	$script:array = @()
	if ($testcon)
	{
		try
		{
			$LocalAdmin = ([ADSI]"WinNT://$Computer/Administrators")
		}
		catch
		{
			Write-Warning "Failed to access local admins group"
			Add-Content -Path $logfile "$(executiontime) - Failed to access local admins group"
		}
		$UserNames = @($LocalAdmin.psbase.Invoke("Members"))
		$UserList = $Usernames | foreach { $_.gettype().invokemember("Name", 'GetProperty', $null, $_, $null) }
		$parentlist = $UserNames | foreach { $_.gettype().invokemember("parent", 'GetProperty', $null, $_, $null) }
		for ($x = 0; $x -lt ($UserList.count); $x++)
		{
			$object = "" | select Computer, User
			$object.computer = $computer
			$object.user = ((($parentlist[$x] -replace "WinNT://") -replace "IMSWEST/") -replace "PIMCO/") + "\" + $UserList[$x]
			#$object
			$script:array += $object
		}
	}
	else
	{
		$object = "" | select Computer, User
		$object.user = "Offline"
		$object.computer = $computer
		#$object
		$script:array += $object
		Write-Warning "Failed to access local admins group"
		Add-Content -Path $logfile "$(executiontime) - Failed to access local admins group"
	}
	if ($script:array)
	{
		$script:array | select *

	}
	else
	{
		Write-Warning "Failed to access local admins group"
		Add-Content -Path $logfile "$(executiontime) - Failed to access local admins group"
	}
}

#Setup this PC

#Copy the FBR dll and executable
Write-Verbose "Setting up this PC"
if (Test-Path c:\temp\FBRInterface.dll)
{ }
else
{
	Copy-Item \\nasshare\share\test\FBRInterface.dll c:\temp
}
if (Test-Path c:\temp\FBRTool.exe)
{ }
else
{
	Copy-Item \\nasshare\share\test\FBRTool.exe c:\temp
}
if (Test-Path c:\temp\EmFsLibrary.dll)
{ }
else
{
	Copy-Item \\nasshare\share\test\EmFsLibrary.dll c:\temp
}

try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Quest snap-in not installed!"
	throw "Quest snap-in not installed"
	#exit 1
}

#Create log file
Write-Verbose "Creating log file"
New-Item -Type File $logfile -Force | Out-Null
Add-Content -Path $logfile "$(executiontime) - Starting script - Running as $whoami"

#Connect to Pimco
try
{
	Write-Verbose "Connecting to Pimco AD"
	Add-Content -Path $logfile "$(executiontime) - Connecting to Pimco AD"
	Connect-QADService vms001p6 -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to connect to Pimco AD"
	Add-Content -Path $logfile "$(executiontime) - Failed to connect to Pimco AD"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	throw "Failed to connect to Pimco AD"
	#exit 1
}

#Get user's current groups
try
{
	Write-Verbose "Looking up user and adding current appsense groups to log file"
	Add-Content -Path $logfile "$(executiontime) - Looking up user and adding current appsense groups to log file"
	$currentgroups = Get-QADUser -SamAccountName $username -ea 'Stop' | Get-QADMemberOf -Indirect -Name "*appsen*" -ea 'Stop'
	foreach ($i in $currentgroups.name) { $stringgroups = $stringgroups + $i + ", " }
	Add-Content -Path $logfile "$(executiontime) - Current Appsense Groups: $stringgroups"
}
catch
{
	Write-Warning "Failed to lookup specified user"
	Add-Content -Path $logfile "$(executiontime) - Failed to lookup specified user"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	throw "Failed to lookup specified user"
	#exit 1
}

#Make sure user's PC is up
try
{
	Write-Verbose "Looking for specified PC"
	Add-Content -Path $logfile "$(executiontime) - Looking for specified PC"
	Test-Connection -ComputerName $Computer -count 1 -ea Stop | Out-Null
}
catch
{
	Write-Warning "PC appears to be offline"
	Add-Content -Path $logfile "$(executiontime) - PC appears to be offline"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	throw "PC appears to be offline"
	#exit 1
}

#Make sure UEV is installed already
try
{
	Write-Verbose "Checking PC for the UEV agent"
	Add-Content -Path $logfile "$(executiontime) - Checking PC for the UEV agent"
	Get-Service -ComputerName $Computer -Name "UevAgentService" -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to find UEV agent - please install via Bigfix or manually"
	Add-Content -Path $logfile "$(executiontime) - Failed to find UEV agent"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	throw "Failed to find UEV agent"
	#exit 1
}

#One time state check
$appsensecurrentstatus = (gwmi win32_service -filter "Name='Appsense Client Communications Agent'" -ComputerName $Computer).state
Add-Content -Path $logfile "$(executiontime) - Appsense Client Communications Agent is currently $appsensecurrentstatus"

#Stop and disable appsense services
$AppsenseServices = "'Appsense Client Communications Agent'", "'AppSense EmCoreService'", "'AppSense Watchdog Service'"
foreach ($service in $AppsenseServices)
{
	try
	{
		Write-Verbose "Stopping $service"
		Add-Content -Path $logfile "$(executiontime) - Stopping $service"
		(gwmi win32_service -filter "Name=$service" -ComputerName $computer).StopService() | Out-Null
	}
	Catch
	{
		Write-Warning "Failed to stop $service"
		Add-Content -Path $logfile "$(executiontime) - Failed to stop $service"
	}
}

foreach ($service in $AppsenseServices)
{
	try
	{
		Write-Verbose "Disabling $service"
		Add-Content -Path $logfile "$(executiontime) - Disabling $service"
		(gwmi win32_service -filter "Name=$service" -ComputerName $computer).Changestartmode("Disabled") | Out-Null
	}
	Catch
	{
		Write-Warning "Failed to disable $service"
		Add-Content -Path $logfile "$(executiontime) - Failed to disable $service"
	}
}

$qaduser = Get-QADUser -SamAccountName $Username
#Remove user from Appsense groups
$AppsenseGroups = "AppSense-Test", "AppSense Migrated", "Appsense Personalized Users", "AppSense No Office", "AppSense Base User Group 2", "_AppSenseNYAll", "AppSense New Migraton Mode ON", "AppSense Web Interface Users", "AppsenseMigration7_12_13", "AppSense Base User Group 3"
foreach ($group in $AppsenseGroups)
{
	try
	{
		Write-Verbose "Removing user from $group"
		Add-Content -Path $logfile "$(executiontime) - Removing user from $group"
		
		Get-QADGroup $group | Remove-QADGroupMember -Member $qaduser -ea 'Stop' | Out-Null
	}
	catch
	{
		Write-Warning "Failed to remove user from $group"
		Add-Content -Path $logfile "$(executiontime) - Failed to remove user from $group"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		throw "Failed to remove user from $group"
		#exit 1
	}
}

#Add user and PC to UEV group
try
{
	Write-Verbose "Adding user to UEV_Users group"
	Add-Content -Path $logfile "$(executiontime) - Adding user to UEV_Users group"
	Get-QADGroup "UEV_Users" | Add-QADGroupMember -Member $qaduser -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to remove user from $group"
	Add-Content -Path $logfile "$(executiontime) - Failed to add user to UEV_Users group"
}

try
{
	Write-Verbose "Adding computer to UEV_Computers group"
	Add-Content -Path $logfile "$(executiontime) - Adding computer to UEV_Computers group"
	$compname = $computer + "$"
	Get-QADGroup "UEV_Computers" | Add-QADGroupMember -Member $compname -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to add computer to UEV_Computers group"
	Add-Content -Path $logfile "$(executiontime) - Failed to add computer to UEV_Computers group"
}

#Export appsense registry function
function ExportAppsenseRegistry
{
	param ($Computer, $Username)
	
	c:
	cd\
	cd temp
	
	#Get current user's SID
	$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$Username))"
	$searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com'
	#$searcher.SearchRoot = 'LDAP://imswest.sscims.com'
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Looking up $Username in Pimco AD"
		Write-Verbose "Looking up $Username in Pimco AD"
		$user = $searcher.FindOne().GetDirectoryEntry()
	}
	catch
	{
		Write-Warning "Failed to find $Username in Pimco AD"
		Add-Content -Path $logfile "$(executiontime) - Failed to find $Username in Pimco AD"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		throw "Failed to find $Username in Pimco AD"
		#exit 1
	}
	
	function confirmprompt
	{
		if ($user)
		{
			Add-Content -Path $logfile "$(executiontime) - Confirming user"
			Write-Verbose "Confirming user"
			$confirmuser = Read-Host "Please confirm $($user.name) (y/n)"
		}
		switch ($confirmuser)
		{
			"y" { Add-Content -Path $logfile "$(executiontime) - User confirmed" }
			"n" {
				Write-Warning "User name was not confirmed"
				Add-Content -Path $logfile "$(executiontime) - User $($user.name) was not confirmed"
				Add-Content -Path $logfile "$(executiontime) - Script finished"
				exit 1
			}
			default { Write-Warning "Please select Y or N"; confirmprompt }
		}
	}
	
	#confirmprompt
	Add-Content -Path $logfile "$(executiontime) - Confirming user"
	Write-Verbose "Confirming user"
	if ($user.name -eq $qaduser.name)
	{
		
	}
	else
	{
		Write-Warning "User name was not confirmed"
		Add-Content -Path $logfile "$(executiontime) - User $($user.name) was not confirmed"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		throw "User $($user.name) was not confirmed"
		#exit 1
	}
	
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Finding user's SID value"
		Write-Verbose "Finding user's SID value"
		$binarySID = $user.ObjectSid.Value
		$script:stringsid = (New-Object System.Security.Principal.SecurityIdentifier($binarySID, 0)).Value
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to find user's SID"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		throw "Failed to find user's SID"
		#exit 1
	}
	#get the random Appsense folder string name
	#ps2....
	#$folders = (get-childitem C:\appsensevirtual\$script:stringsid -attributes Directory -force)
	try
	{
		Add-Content -Path $logfile "$(executiontime) - Checking for an Appsense folder for the user under \\$Computer\C$\appsensevirtual\$script:stringsid"
		Write-Verbose "Checking for an Appsense folder for the user under \\$Computer\C$\appsensevirtual\$script:stringsid"
		$folders = (get-childitem \\$Computer\C$\appsensevirtual\$script:stringsid -Force -ea 'Stop') | where { $_.psIsContainer -eq $true }
	}
	catch
	{
		Write-Warning "Failed to find an Appsense folder for the user"
		Add-Content -Path $logfile "$(executiontime) - Failed to find an Appsense folder for the user"
		Add-Content -Path $logfile "$(executiontime) - Script finished"
		throw "Failed to find an Appsense folder for the user"
		#exit 1
	}
	#powershell 2.0 friendly...
	try
	{
		Write-Verbose "Creating a local folder for c:\temp\AppsenseRegistry\$username"
		Add-Content -Path $logfile "$(executiontime) - Creating a local folder for c:\temp\AppsenseRegistry\$username"
		mkdir c:\temp\AppsenseRegistry\$username -Force | Out-Null
	}
	catch
	{
		Write-Warning "Failed to create a folder for $username"
		Add-Content -Path $logfile "$(executiontime) - Failed to create a folder for $username"
	}
	#should just be one of these but just in case...
	foreach ($folder in $folders)
	{
		#Get all the personalized app folders
		#$apps = (get-childitem $folder.FullName -attributes Directory -force)
		$apps = (get-childitem $folder.FullName -force) | where { $_.psIsContainer -eq $true }
		foreach ($app in $apps)
		{
			#$app.name
			if ($($app.Name) -eq "Dsktp")
			{
				$fbrpath = $app.FullName + "\registry\SessionData\registry.fbr"
				$filename = ($app.name).replace(" ", "") + "SessionData.reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
				$fbrpath = $app.FullName + "\registry\GlobalShared\registry.fbr"
				$filename = ($app.name).replace(" ", "") + "GlobalShared.reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
				$fbrpath = $app.FullName + "\registry\GlobalShared\iconsettings.fbr"
				$filename = ($app.name).replace(" ", "") + "GlobalSharedIconsettings.reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
			}
			else
			{
				#give us some nice file names and get rid of spaces because the fbrtool is picky
				$fbrpath = $app.FullName + "\registry\settings.fbr"
				$filename = ($app.name).replace(" ", "") + ".reg"
				#generate the needful
				.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$USERNAME\$filename /parentpath=HKCU
			}
			
		}
	}
}

ExportAppsenseRegistry -Computer $computer -Username $username

#Create a folder for the user in their c:\temp
try
{
	Write-Verbose "Creating a folder on remote PC for c:\temp\$username"
	Add-Content -Path $logfile "$(executiontime) - Creating a folder on remote PC for c:\temp\$username"
	mkdir \\$computer\c$\temp\$username -ea 'Stop' -Force | Out-Null
}
catch
{
	Write-Warning "Failed to create folder \\$computer\c$\temp\$username"
	Add-Content -Path $logfile "$(executiontime) - Failed to create folder \\$computer\c$\temp\$username"
}

try
{
	Write-Verbose "Copying registry files to remote PC"
	Add-Content -Path $logfile "$(executiontime) - Copying registry files to remote PC"
	Copy-Item c:\temp\AppsenseRegistry\$username\* \\$computer\c$\temp\$username -ea 'Stop'
}
catch
{
	Write-Warning "Failed to copy Appsense registry files to \\$computer\c$\temp\$username"
	Add-Content -Path $logfile "$(executiontime) - Failed to copy Appsense registry files to \\$computer\c$\temp\$username"
}

#Get Outlook signatures

try
{
	Add-Content -Path $logfile "$(executiontime) - Checking for an Appsense folder for the user under \\$Computer\C$\appsensevirtual\$script:stringsid"
	Write-Verbose "Checking for an Appsense folder for the user under \\$Computer\C$\appsensevirtual\$script:stringsid"
	$folders = (get-childitem \\$Computer\C$\appsensevirtual\$script:stringsid -Force -ea 'Stop') | where { $_.psIsContainer -eq $true }
}
catch
{
	Write-Warning "Failed to find an Appsense folder for the user"
	Add-Content -Path $logfile "$(executiontime) - Failed to find an Appsense folder for the user"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	throw "Failed to find an Appsense folder for the user"
	#exit 1
}

#Start Remote Registry service
try
{
	Write-Verbose "Starting remote registry on remote PC"
	Add-Content -Path $logfile "$(executiontime) - Starting remote registry on remote PC"
	(gwmi win32_service -filter "Name='remoteregistry'" -ComputerName $computer).StartService() | Out-Null
}
catch
{
	Write-Warning "Failed to start remote registry on $computer"
	Add-Content -Path $logfile "$(executiontime) - Failed to start remote registry on $computer"
	#throw "Failed to start UevAgentService on $Computer"
	#exit 1
}


#(get-childitem \\$Computer\C$\appsensevirtual\$script:stringsid)
#C:\appsensevirtual\S-1-5-21-2241961287-1671099396-3952850847-23212\{ 98354999-6E6C-4C6E-81A2-1CB017E466B4 }\Office 2010\Device\HarddiskVolume2\Users\h410726\AppData\Roaming\Microsoft\Signatures

if ($appsensecurrentstatus -eq "Running")
{
	Add-Content -Path $logfile "$(executiontime) - Starting Outlook signature migration"
	foreach ($folder in $folders)
	{
		Add-Content -Path $logfile "$(executiontime) - Checking sub folder $($folder.fullname)"
		#Get all the personalized app folders
		#$apps = (get-childitem $folder.FullName -attributes Directory -force)
		$apps = (get-childitem $folder.FullName -force) | where { $_.psIsContainer -eq $true }
		foreach ($app in $apps)
		{
			#$app.name
			Add-Content -Path $logfile "$(executiontime) - Checking sub sub folder: $($app.name)"
			if ($($app.Name) -eq "Office 2010")
			{
				$signaturelocation = ($app.fullname + "\device\harddiskvolume2\users\$username\appdata\roaming\microsoft\Signatures")
				Add-Content -Path $logfile "$(executiontime) - Signature location is: $signaturelocation"
				#Test-Path $app.fullname\Device\HarddiskVolume2\Users\h410726\AppData\Roaming\Microsoft\Signatures
				if (Test-Path ($app.fullname + "\device\harddiskvolume2\users\$username\appdata\roaming\microsoft\Signatures"))
				{
					#HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList
					$Reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $computer)
					$RegKey = $Reg.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProfileList\$script:stringsid")
					#$RegKey.GetValue("ProfileImagePath")
					$fulluserprofilepath = "\\" + $Computer + "\" + ($RegKey.GetValue("ProfileImagePath") -replace (":", "$"))
					$fullsigpath = $fulluserprofilepath + "\appdata\roaming\microsoft\Signatures"
					Add-Content -Path $logfile "$(executiontime) - Local signature path is: $fullsigpath"
					if (Test-Path $fullsigpath)
					{
						Write-Verbose "Renaming existing signature path at $($fullsigpath)"
						Add-Content -Path $logfile "$(executiontime) - Renaming existing signature path at $($fullsigpath)"
						Rename-Item $fullsigpath ($fullsigpath + "OLD") -Force
						Copy-Item ($app.fullname + "\device\harddiskvolume2\users\$username\appdata\roaming\microsoft\Signatures") $fullsigpath -Recurse -Force
						$pathforlog = ($app.fullname + "\device\harddiskvolume2\users\$username\appdata\roaming\microsoft\Signatures")
						Write-Verbose "Copying signature from $($pathforlog) to $($fullsigpath)"
						Add-Content -Path $logfile "$(executiontime) - Copying signature from $($pathforlog) to $($fullsigpath)"
					}
					else
					{
						$pathforlog = ($app.fullname + "\device\harddiskvolume2\users\$username\appdata\roaming\microsoft\Signatures")
						Write-Verbose "Copying signature from $($pathforlog) to $($fullsigpath)"
						Add-Content -Path $logfile "$(executiontime) - Copying signature from $($pathforlog) to $($fullsigpath)"
						Copy-Item ($app.fullname + "\device\harddiskvolume2\users\$username\appdata\roaming\microsoft\Signatures") $fullsigpath -Recurse -Force
					}
				}
			}
		}
	}
	
	#Get the wallpaper
	$Reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('Users', $computer)
	$RegKey = $Reg.OpenSubKey("$script:stringsid\\Control Panel\\Desktop")
	$wallpaperpath = $RegKey.GetValue("Wallpaper")
	if (Test-Path $wallpaperpath)
	{
		
	}
}

#Enable UEV service
try
{
	Write-Verbose "Changing start type of UEV service on remote PC"
	Add-Content -Path $logfile "$(executiontime) - Changing start type of UEV service on remote PC"
	(gwmi win32_service -filter "Name='UevAgentService'" -ComputerName $computer).ChangeStartMode("Automatic") | Out-Null
}
catch
{
	Write-Warning "Failed to change start type of UevAgentService on $computer"
	Add-Content -Path $logfile "$(executiontime) - Failed to change start type of UevAgentService on $computer"
}

#Start UEV service
try
{
	Write-Verbose "Starting UEV on remote PC"
	Add-Content -Path $logfile "$(executiontime) - Starting UEV on remote PC"
	(gwmi win32_service -filter "Name='UevAgentService'" -ComputerName $computer).StartService() | Out-Null
}
catch
{
	Write-Warning "Failed to start UevAgentService on $computer"
	Add-Content -Path $logfile "$(executiontime) - Failed to start UevAgentService on $computer"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	throw "Failed to start UevAgentService on $Computer"
	#exit 1
}

#Check and see if user is an admin
#$checkforuser = getadminusers $computer | where { $_.user -like "Pimco\$username" }
#$checkforuser

#if ($($checkforuser).user -like "PIMCO\$username")
#{
#Get our XML
$xml = Get-Content \\nasshare\share\test\UEVAutomation\runonceregimporttask.xml
$xml = $xml -replace "%LogonDomain%\\%LogonUser%", "pimco\$username"
$xml | Out-File c:\temp\runonceregimport-$username.xml -force
try
{
	#if the user is already an admin create this task on their PC
	Write-Verbose "Creating a task on remote PC"
	Add-Content -Path $logfile "$(executiontime) - Creating a task on remote PC"
	schtasks /Create /S $computer /XML c:\temp\runonceregimport-$username.xml /TN "Run Once Reg Import" /F
}
catch
{
	Write-Warning "Failed to create the scheduled task on $computer"
	Add-Content -Path $logfile "$(executiontime) - Failed to create the scheduled task on $computer"
	Add-Content -Path $logfile "$(executiontime) - Script finished"
	throw "Failed to create the scheduled task on $Computer"
	#exit 1
}
#}
<#Non admin is randomly working now?!?
else
{
	#Get our XML
	$xml = Get-Content \\nasshare\share\test\UEVAutomation\runonceregimporttask.xml
	$xml = $xml -replace "%LogonDomain%\\%LogonUser%", "pimco\$username"
	$xml | Out-File c:\temp\runonceregimport.xml
	try
	{
		#if they are not an admin create this task that will remove them from admins after the script executes
		Write-Verbose "Creating a task on remote PC"
		Add-Content -Path $logfile "$(executiontime) - Creating a task on remote PC"
		schtasks /Create /S $computer /XML c:\temp\runonceregimport.xml /TN "Run Once Reg Import"
	}
	catch
	{
		Write-Warning "Failed to create the scheduled task on $computer"
		Add-Content -Path $logfile "$(executiontime) - Failed to create the scheduled task on $computer"
	}
	
	#Make user an admin so they can import registry at next relog
	try
	{
		Write-Verbose "Adding $username to local admins on $computer"
		Add-Content -Path $logfile "$(executiontime) - Adding $username to local admins on $computer"
		([ADSI]"WinNT://$computer/Administrators,group").Add("WinNT://Pimco/$username") | Out-Null
	}
	catch
	{
		Write-Warning "Failed to add $username to local admins on $computer"
		Add-Content -Path $logfile "$(executiontime) - Failed to add $username to local admins on $computer"
	}
}
#>

#Copy the import script to the target
try
{
	Write-Verbose "Copying reg file script to remote"
	Add-Content -Path $logfile "$(executiontime) - Copying reg file script to remote"
	Copy-Item \\nasshare\share\test\UEVAutomation\importregfiles.ps1 \\$computer\c$\temp -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to copy import registry script to \\$computer\c$\temp"
	Add-Content -Path $logfile "$(executiontime) - Failed to copy import registry script to \\$computer\c$\temp"
}

#Done
Write-Verbose "Done!"
Add-Content -Path $logfile "$(executiontime) - Script finished"
