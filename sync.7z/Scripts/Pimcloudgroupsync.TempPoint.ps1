﻿
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[switch]$WhatIf
)
#endregion

#region Base variables and environment information
$logfile = "c:\scripts\logging\PimcloudGroupSync.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module ModuleName -ea 'Stop' | Out-Null
	Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

#endregion

#region Main
$pimcocredential = get-credential "pimco\jchandle"
$corecredential = get-credential "core\admjchandler"

$password = Get-Content c:\scripts\secure1.p | ConvertTo-SecureString
$pimcocredential = New-Object System.Management.Automation.PSCredential pimco\s_jiraauto, $password
$password = Get-Content c:\scripts\secure2.p | ConvertTo-SecureString
$corecredential = New-Object System.Management.Automation.PSCredential pimco\s_jiraauto, $password

Connect-QADService pimco.imswest.sscims.com -Credential $pimcocredential
$Groups = Get-QADGroup pimcloud-* | where { $_.name -like "*sandbox*" }
foreach ($i in $Groups)
{
	
	$currentpimcogroupmembers = @()
	$currentpimcogroupmembers += (Get-QADGroup $i.name -Service pimco.imswest.sscims.com | get-qadgroupmember -Service pimco.imswest.sscims.com -SizeLimit 0).samaccountname
	$currentpimcogroupmembers
	Connect-QADService core.pimcocloud.net -Credential $corecredential | Out-Null
	$currentcoregroupmembers = @()
	$currentcoregroupmembers += (Get-QADGroup $i.name -Service core.pimcocloud.net | get-qadgroupmember -Service core.pimcocloud.net -SizeLimit 0).samaccountname
	$currentcoregroupmembers
	$comparison = compare $currentpimcogroupmembers $currentcoregroupmembers
	if ($comparison)
	{
		#need to add is <=
		foreach ($usertobeadded in ($comparison | where { $_.sideindicator -eq "<=" }))
		{
			Write-Host "Adding $($usertobeadded.inputobject)"
			Get-QADUser -SamAccountName "$($usertobeadded.inputobject)" -Service pimco.imswest.sscims.com -Credential $pimcocredential | Add-QADGroupMember $i.name -Service core.pimcocloud.net -Credential $corecredential
		}
		#need to remove is =>
		foreach ($usertoberemoved in ($comparison | where { $_.sideindicator -eq "=>" }))
		{
			Write-Host "Removing $($usertoberemoved.inputobject)"
			#Remove-QADGroupMember $i.name "$($usertoberemoved.inputobject)" -Service core.pimcocloud.net -Credential $corecredential
			Get-QADUser -SamAccountName "$($usertoberemoved.inputobject)" -Service pimco.imswest.sscims.com -Credential $pimcocredential | Remove-QADGroupMember $i.name -Service core.pimcocloud.net -Credential $corecredential
		}
	}
	else
	{
		Write-Host "No changes needed to $($i.name)"
	}
}

#endregion