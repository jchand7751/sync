﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/2/2015 6:07 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#Run Chef deprovision to get password and remove node from Chef
chef-client -r "recipe[pimco-windows-deprovision]"

$hostname = hostname

$User = "core\svc_adaccess"
#From Chef
$PasswordFile = "C:\temp\remoteFiles\cleanupScript\Password.txt"
$KeyFile = "C:\temp\remoteFiles\cleanupScript\AES.key"
$key = Get-Content $KeyFile
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, (Get-Content $PasswordFile | ConvertTo-SecureString -Key $key)

$password = "#{pwd}" | ConvertTo-SecureString -AsPlainText -Force;
$credential = New-Object System.Management.Automation.PSCredential "#{account}", $password;


### Need invoke rights for svc_adaccess ###
Invoke-Command localhost {
	$hostname = hostname
	#$hostname = "CLV035PW-2C03D3"
	$searcher = [adsisearcher]'LDAP://core.pimcocloud.net'
	$searcher.filter = "name=$hostname"
	$result = $searcher.FindOne()
	$adsidelete = [adsi]("$($result.path)")
	try { $adsidelete.deletetree() }
	catch { Write-Warning "Failed to delete" }
} -Credential $Credential -Authentication 'Credssp'
