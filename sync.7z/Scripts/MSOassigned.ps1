﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/20/2017 3:59 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
Connect-MsolService
$array = @()
$users = get-msoluser -All

foreach ($user in $users)
{
	$object = "" | select Email, Samaccountname, City, E3, CRM
	$object.Email = $user.userprincipalname
	$object.City = $user.city
	$aduser = Get-QADUser -Email $user.userprincipalname -DontUseDefaultIncludedProperties -IncludedProperties samaccountname
	$object.samaccountname = $aduser.samaccountname
	if ($user.licenses.accountskuid -contains "PIMCO:ENTERPRISEPACK")
	{
		$object.E3 = "Yes"
	}
	else
	{
		$object.E3 = "No"
	}
	
	if ($user.licenses.accountskuid -contains "PIMCO:DYN365_ENTERPRISE_PLAN1")
	{
		$object.CRM = "Yes"
	}
	else
	{
		$object.CRM = "No"
	}
	
	$array += $object
}
$array