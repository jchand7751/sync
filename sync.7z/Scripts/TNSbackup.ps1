﻿
Add-PSSnapin Quest.ActiveRoles.ADManagement

Connect-QADService vms001p5
$servers = Get-QADComputer -SearchRoot "OU=Windows,OU=Servers,OU=IA,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com"
foreach ($server in $servers.name)
{
	Write-Host "Checking $server ..."
	if ((Test-Connection -ComputerName $server -Quiet -Count 1) -eq $true)
	{
		if ((Test-Path \\$server\C$\Oracle\product\11.2.0\client32\Network\Admin\tnsnames.ora) -eq $true)
		{
			copy-item \\$server\C$\Oracle\product\11.2.0\client32\Network\Admin\tnsnames.ora \\$server\C$\Oracle\product\11.2.0\client32\Network\Admin\tnsnamesBackup8-5 -Force
		}
		else
		{
			Write-Warning "Didn't find a tnsnames.ora in client32"	
		}
		
		if ((Test-Path \\$server\C$\Oracle\product\11.2.0\client64\Network\Admin\tnsnames.ora) -eq $true)
		{
			copy-item \\$server\C$\Oracle\product\11.2.0\client64\Network\Admin\tnsnames.ora \\$server\C$\\Oracle\product\11.2.0\client64\Network\Admin\tnsnamesBackup8-5 -Force
		}
		else
		{
			Write-Warning "Didn't find a tnsnames.ora in client64"
		}
	}
	else
	{
		Write-Warning "$server is offline"
	}
}