﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   11/1/2013 5:33 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
#Param ($Computer, $User)
Param(
   [Parameter(Mandatory=$true,Position=0)]
   [string]$Computer,

   [Parameter(Mandatory=$true,Position=1)]
   [string]$Domain,

 [Parameter(Mandatory=$true,Position=2)]
   [string]$User
)


#$Computer = Read-Host "Computer"
#$Domain = Read-Host "Domain"
#$User = Read-Host "User/Group"
([ADSI]"WinNT://$computer/Administrators,group").Add("WinNT://$domain/$user")