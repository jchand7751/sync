﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/6/2017 9:24 AM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>



function Test-TCPSocket
{
	param ([string]$RemoteHost, [int]$Port)
	New-Object System.Net.Sockets.TCPClient($RemoteHost, $Port)
}

function Test-UDPSocket
{
	param ([string]$RemoteHost, [int]$Port)
	New-Object System.Net.Sockets.UdpClient($RemoteHost, $Port)
}

$a = nslookup pimco.imswest.sscims.com
foreach ($i in ($a[4..($a.count)])) { $cleanip = ($i -replace ("addresses:  ")).trimstart(""); [ADSI]"LDAP://$cleanip" }

function LDAPTest
{
	param ($domain = "pimco.imswest.sscims.com")
	try
	{
		#$domainlookup = nslookup $domain
		$domainlookup = [System.Net.Dns]::GetHostAddresses($domain)
		#foreach ($dc in $domainlookup[4..($domainlookup.count -2)])
		foreach ($dc in $domainlookup)
		{
			#$cleanip = ($dc -replace ("addresses:  ")).trimstart("")
			$cleanip = $dc
			$LDAPtest = [ADSI]"LDAP://$cleanip"
			if ($LDAPtest.distinguishedname)
			{
				Write-Host "Successful LDAP lookup on $cleanip"
			}
			else
			{
				Write-Warning "Failed to LDAP lookup on $cleanip"
			}
		}
	}
	catch
	{
		Write-Warning "Failed to look up $domain"
	}
}



function LDAPTest
{
	param ($domain = "pimco.imswest.sscims.com")
	try
	{
		$domainlookup = [System.Net.Dns]::GetHostAddresses($domain)
		foreach ($dc in $domainlookup)
		{
			$LDAPtest = [ADSI]"LDAP://$dc"
			if ($LDAPtest.distinguishedname)
			{
				Write-Host "Successful LDAP lookup on $dc"
			}
			else
			{
				Write-Warning "Failed to LDAP lookup on $dc"
			}
		}
	}
	catch
	{
		Write-Warning "Failed to look up $domain"
	}
}