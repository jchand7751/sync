﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/23/2015 3:30 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
function Get-Handles
{
	param ($server, $file)
	
	try
	{
		$path = Split-Path $file
		Test-Path ("\\" + $server + "\" + ($path -replace ":", "$")) -ea 'Stop'
	}
	catch
	{
		Throw "Path not found"
	}
	#Make sure handle is on the server
	if (Test-Path \\$server\e$\tools\handle.exe)
	{ }
	else
	{
		Throw "Handle is not installed"
	}
	#Invoke handle remotely and capture the results
	try
	{
		$handleresults = invoke-command $server { e:\tools\handle.exe $args -accepteula } -Args $path -ErrorAction Stop
	}
	catch
	{
		Throw "Server invoking is not configured"
	}
	#Put the handle results into an object and then add it into an array
	$handlecount = ($handleresults.count)
	if ($handleresults[5] -eq "No matching handles found.")
	{
		Write-Host "No matching handles found."
	}
	else
	{
		$array = @()
		foreach ($line in $handleresults[5..$handlecount])
		{
			$object = "" | select Name, PID, Type, File
			$linecount = ((($line -split " pid: ") -split "type: ") -split " ").count
			$object.name = (((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[0]
			$object.pid = (((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[1]
			$object.type = (((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[2]
			$object.file = [string]((((($line -split " pid: ") -split "type: ") -split " ") | where { $_ -notlike "" })[4..$linecount])
			#$object
			if ($object.name -ne "System")
			{
				$array += $object	
			}
		}
		#$array
		if ($file)
		{
			$array | where { $_.file -eq $file } | foreach ($_) { Write-Host "$file is being held open by process $($_.pid) with name $($_.name)" }	
		}
	}
}

Get-ProcHandles -server vma001b042 -path "e:\services\puma_optimization"
Get-ProcHandles -server vma001d029 -path "E:\Program Files\Markit Group\MarkitEDM"
Get-ProcHandles -server vma001d029 -path "E:\" -file "E:\Program Files\Markit Group\MarkitEDM\CADIS.WebService.Data.dll"