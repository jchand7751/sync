﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/19/2015 6:31 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


Add-PSSnapin Quest.ActiveRoles.ADManagement

$script:array = @()
$toplevel = Get-QADUser -Name "Yu, Cheng" -IncludedProperties directreports, employeetype | select name, samaccountname, employeetype, directreports, manager
#$toplevel = Get-QADUser -Name "nguyen, larry" -IncludedProperties directreports, employeetype | select name, samaccountname, employeetype, directreports
#$toplevel = Get-QADUser -Name "hooper, daniel" -IncludedProperties directreports, employeetype | select name, samaccountname, employeetype, directreports

$object = "" | select Name, LoginID, EmployeeType, DirectReports, Manager, Level
$object.name = $toplevel.name
$object.LoginID = $toplevel.samaccountname
$object.EmployeeType = $toplevel.employeetype
$object.DirectReports = $toplevel.directreports
$object.Manager = (Get-QADUser $toplevel.manager).name
$object.Level = 1
$array += $object

function getnextlevel
{
	param ($nextleveluser)
	#$script:level++
	#foreach ($user in $nextleveluser.directreports)
	#{
		Write-Host "Next level $($nextleveluser.name) - $level"
		$currentlevel = Get-QADUser -SamAccountName ($nextleveluser.samaccountname) -IncludedProperties directreports, employeetype | select name, samaccountname, employeetype, directreports, manager, Level
		
		$object = "" | select Name, LoginID, EmployeeType, DirectReports, Manager, Level
		$object.name = $currentlevel.name
		$object.LoginID = $currentlevel.samaccountname
		$object.EmployeeType = $currentlevel.employeetype
		$object.DirectReports = $currentlevel.directreports
		$object.Manager = (Get-QADUser $currentlevel.manager).name
		$object.Level = $script:level
		#$object
		$script:array += $object
		if ($object.directreports)
		{
			$script:level++
			foreach ($subuser in $object.directreports)
			{
				$subuser = Get-QADUser $subuser -IncludedProperties directreports, employeetype | select name, samaccountname, employeetype, directreports, Level
				getnextlevel $subuser
			}
			$script:level--
		}
	#}
}

foreach ($secondleveluser in $toplevel.directreports)
{
	Write-Host "2nd level $secondleveluser"
	$script:level = 2
	$secondleveluser = Get-QADUser $secondleveluser -IncludedProperties directreports, employeetype | select name, samaccountname, employeetype, directreports, Level
	#if ($secondleveluser.directreports)
	#{
		getnextlevel $secondleveluser
	#}
}

$array