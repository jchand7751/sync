﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/23/2015 4:11 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($Computer)
$logpath = "\\nasshare\share\Pimlib\logs"

if (Test-Connection -ComputerName $computer -Count 1 -Quiet)
{
	$Getitems = Get-childitem \\$computer\c$\scratch\pimlib_fun*
	foreach ($item in $Getitems)
	{
		copy-item $item.fullname $logpath -force 
	}
		#(gwmi -win32_computersystem -computer $computer).username
}