﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	8/11/2017 3:45 PM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
foreach ($i in $a)
{
	if ((Get-QADUser -Email $i.email) -notlike "")
	{
		(Get-QADUser -Email $i.email).samaccountname
	}
	else
	{
		Write-Host "not found"
	}
}

$a = Import-Csv crmonboard500.csv
foreach ($i in $a)
{
	if ($i.samaccountname -eq "not found")
	{
		if ((Get-QADUser -Name $i.Name) -notlike "")
		{
			(Get-QADUser -Name $i.Name).samaccountname
		}
		else
		{
			Write-Host "not found"
		}
	}
	else
	{
		$i.samaccountname
	}
}

$a = Import-Csv c:\tmp\crmonboard500.csv
foreach ($i in $a)
{
	$user = Get-QADUser -SamAccountName $i.samaccountname
	if ($user)
	{
		if (($user | Get-QADMemberOf -Name vpn-*) -notlike "")
		{
			$user | get-qadmemberof -Name vpn-* | foreach { Remove-QADGroupMember -Member $user -Identity $_.name }
		}
		$user | Add-qadmemberof -Group "O365-E3-ProPlus" | Out-Null
		$user | Add-qadmemberof -Group "O365-E3-Sharepoint Online" | Out-Null
		$user | Add-qadmemberof -Group "O365-Dynamics 365 Enterprise-Dynamics 365" | Out-Null
		$user | Add-qadmemberof -Group "VPN-O365-CRM" | Out-Null
		$user | Add-qadmemberof -Group "O365-CRM-Prod" | Out-Null
	}
}