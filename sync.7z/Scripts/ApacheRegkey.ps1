﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/17/2013 11:11 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param($computer)

Import-Module PSRemoteRegistry

$testconnection = Test-Connection $computer -Quiet -Count 1
switch($testconnection)
	{
	"true"  {
			$keys = Get-RegKey -computer $computer -key Software | where {$_.key -like "*apac*"}
			}
	"false" {
			$keys = $null
			}
	}

$object = "" | Select Computer, Keys
$object.Computer = $computer
if ($keys)
	{
	foreach ($i in $keys) 
		{
		$object.keys += $i.key + "," 
		}
	}
	else
		{
		$object.keys = "No Apache keys found"
		}

$object