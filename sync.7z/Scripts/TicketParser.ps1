﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/1/2016 10:46 AM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename: 		TicketParser.PS1    	
	===========================================================================
	.DESCRIPTION
		Ticket Parser.
#>

#Get all the tickets
$tickets = Get-ChildItem e:\jira
$jsonticketarray = @()

if ($tickets)
{ }
else
{ exit }

#Jsonify all the tickets in an array
foreach ($ticket in $tickets)
{
	$jsonticket = ConvertFrom-Json (Get-Content $ticket.FullName)
	$jsonticketarray += $jsonticket
}

#Parse the ticket array, take action, remove the ticket from the jira folder
$count = 0
foreach ($jsonticket in $jsonticketarray)
{
	Write-Host "Ticket type is: $($jsonticket.issue.fields.customfield_11400)"
	#Custom field that contains the project/issuetype
	switch ($jsonticket.issue.fields.customfield_11400)
	{
		"is/active-directory-group-report-api" { Remove-Item $tickets[$count].FullName; E:\scripts\JiraADReport\JiraADReport.ps1 -jsonticket $jsonticket }
		"is/cloud-user-onboarding" { Remove-Item $tickets[$count].FullName; E:\scripts\CliqrSelfProvisioning\CliqrSelfProvisioning.ps1 -jsonticket $jsonticket }
	}
	$count++
}