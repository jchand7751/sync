﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/14/2016 6:27 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($jsonticket)
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop'
	Connect-QADService Pimco.imswest.sscims.com -ea 'Stop'
}
catch
{
	Write-Warning "Failed to load environment"
	exit
}

#Jira credential
$password = Get-Content c:\secure\secure.p | ConvertTo-SecureString
$credential = New-Object System.Management.Automation.PSCredential pimco\s_jiraauto, $password
$password = $credential.getnetworkcredential().password
$account = "s_jiraauto"
$creds = $account + ":" + $password

#Cliqr credential
$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"

#Issue ID
$issueid = $jsonticket.issue.key

#Selected clouds
$selectedclouds = $jsonticket.issue.fields.customfield_12601.value

$cloudarray = @()
switch ($selectedclouds)
{
	"Sandbox" { $selectedclouds = $cloudarray += 1 }
	"Dev" { $selectedclouds = $cloudarray += 2 }
	"Beta" { $selectedclouds = $cloudarray += 3 }
	"Pre-prod" { $selectedclouds = $cloudarray += 4 }
	"prod" { $selectedclouds = $cloudarray += 5 }
}

#Requestor
$requestor = $jsonticket.user.name
Write-Host "Requester is $requestor"

try
{
	$user = Get-QADUser -SamAccountName $requestor -ea 'Stop'
	if ($user)
	{ }
	else
	{
		throw "Missing user"	
	}
}
catch
{
	Write-Warning "User not found"
	exit
}
try
{
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" } -ea 'Stop'
	$cliqrusers = $cliqrusers | ConvertFrom-Json -ea 'Stop'
}
catch
{
	Write-Warning "Cliqr User query failed"
	exit
}

#Check for an existing Cliqr user
if (($cliqrusers | where { $_.externalid -eq $requestor }) -like $null)
{
	#User wasn't found in the Cliqr user lookup, create a new account
	#Stage new User with Activation profile (using AD variables)
	Write-Host "Creating a new user"
	Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/" -d "{ `"`"firstName`"`": `"`"$($user.firstname)`"`", `"`"lastName`"`": `"`"$($user.lastname)`"`", `"`"password`"`": `"`"===redacted===`"`", `"`"emailAddr`"`": `"`"$($user.email)`"`", `"`"companyName`"`": `"`"$($user.department)`"`", `"`"phoneNumber`"`": `"`"`"`", `"`"externalId`"`": `"`"$($user.samaccountname)`"`", `"`"tenantId`"`": 1, `"`"activationProfileId`"`": 8 } " } -ea 'Stop'
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" } -ea 'Stop'
	foreach ($cloud in $selectedclouds)
	{
		Write-Host "Adding user to cloud $cloud"
		Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/$($selectedcliqruser).id" -d "{ `"`"action`"`": `"`"MANAGE_CLOUDS`"`", `"`"manageCloudsData`"`": { `"`"activateRegions`"`": [ { `"`"regionId`"`": `"`"$cloud`"`" } ], `"`"storageSize`"`": 0 } } " } -ea 'Stop'
	}
}
else
{
	$selectedcliqruser = ($cliqrusers | where { $_.externalid -eq $requestor })
	#Add user to selected clouds
	foreach ($cloud in $selectedclouds)
	{
		Write-Host "Adding user to cloud $cloud"
		Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/$($selectedcliqruser).id" -d "{ `"`"action`"`": `"`"MANAGE_CLOUDS`"`", `"`"manageCloudsData`"`": { `"`"activateRegions`"`": [ { `"`"regionId`"`": `"`"$cloud`"`" } ], `"`"storageSize`"`": 0 } } " } -ea 'Stop'
	}
}

#Verify
try
{
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0&detail=true" } -ea 'Stop'
	$cliqrusers = $cliqrusers | ConvertFrom-Json -ea 'Stop'
}
catch
{
	Write-Warning "Cliqr User query failed"
	exit
}

$usersregions = ($cliqrusers.users | where { $_.externalid -eq $requestor }).detail.regions

$checkregionarray = @()
foreach ($region in $selectedclouds)
{
	$checkregionarray += ($usersregions -contains $region)
}

if ($checkregionarray -contains $false)
{
	Write-Warning "Environment add failed"
}
else
{
	Write-Host "Environment add successful"	
}