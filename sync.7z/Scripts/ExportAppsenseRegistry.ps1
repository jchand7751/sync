﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/16/2015 2:24 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
c:
cd\
cd \temp
#Copy the FBR dll and executable
Copy-Item \\nasshare\share\test\FBRInterface.dll c:\temp\
Copy-Item \\nasshare\share\test\FBRTool.exe c:\temp\
Copy-Item \\nasshare\share\test\EmFsLibrary.dll c:\temp\
#Get current user's SID
$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$env:username))"
$user = $searcher.FindOne().GetDirectoryEntry()
$binarySID = $user.ObjectSid.Value
$stringSID = (New-Object System.Security.Principal.SecurityIdentifier($binarySID, 0)).Value
#get the random Appsense folder string name
#ps2....
#$folders = (get-childitem C:\appsensevirtual\$stringSID -attributes Directory -force)
$folders = (get-childitem C:\appsensevirtual\$stringSID -Force) | where { $_.psIsContainer -eq $true }
#powershell 2.0 friendly...
mkdir c:\temp\AppsenseRegistry\$env:username
#should just be one of these but just in case...
foreach ($folder in $folders)
{
	#Get all the personalized app folders
	#$apps = (get-childitem $folder.FullName -attributes Directory -force)
	$apps = (get-childitem $folder.FullName -force) | where { $_.psIsContainer -eq $true }
	foreach ($app in $apps)
	{
		#give us some nice file names and get rid of spaces because the fbrtool is picky
		$fbrpath = $app.FullName + "\registry\settings.fbr"
		$filename = ($app.name).replace(" ", "") + ".txt"
		#generate the needful
		.\FBRTool.exe $fbrpath /exportfile /regfile=c:\temp\AppsenseRegistry\$env:USERNAME\$filename /parentpath=HKCU
	}
}