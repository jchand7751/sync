﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/16/2015 2:07 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($Environment)
Add-PSSnapin Quest.ActiveRoles.ADManagement
$resultarray = @()

#$servers = Get-QADComputer -OSName "Windows Server 2008*" -SizeLimit 0
$servers = @()
#$servers += Get-QADComputer ina001b019
#$servers += Get-QADComputer ina001b012
#$servers += Get-QADComputer vma001d030
#$servers += Get-QADComputer ina001b013
#$servers += Get-QADComputer INE001P11

switch ($Environment)
{
	"dev-beta" {
		$servers += Get-QADComputer INA001D* -SizeLimit 0
		$servers += Get-QADComputer VMA001D* -SizeLimit 0
		$servers += Get-QADComputer INH001D* -SizeLimit 0
		$servers += Get-QADComputer VMH001D* -SizeLimit 0
		$servers += Get-QADComputer VMA001B* -SizeLimit 0
		$servers += Get-QADComputer INA001B* -SizeLimit 0
		$servers += Get-QADComputer INH001B* -SizeLimit 0
		$servers += Get-QADComputer VMH001B* -SizeLimit 0
	}
	"prod" {
		$servers += Get-QADComputer INA001P* -SizeLimit 0
		$servers += Get-QADComputer VMA001P* -SizeLimit 0
		$servers += Get-QADComputer INH001P* -SizeLimit 0
		$servers += Get-QADComputer VMH001P* -SizeLimit 0
	}
}

foreach ($server in $servers)
{
	$object = "" | select Servername, Status, Applications
	$object.Servername = $server.name
	if ((Test-Connection -ComputerName $server.name -Count 1 -Quiet) -eq $true)
	{
		$object.Status = "Online"
		
		#Make sure we have access
		if ((Test-Path \\$($server.name)\c$ -ea 'SilentlyContinue') -eq $true)
		{
		}
		else
		{
			$object.Status = "No access to server"
			$resultarray += $object
			continue
		}
			
		#run
		$results = \\nasshare\share\PimcoIIS_InstallPackage\Tools\PSTool\PsInfo.exe -s Applications \\$($server.name)
		
		sleep 1
		
		#Find adobe
		$results = $results | where { $_ -like "Adobe*" }
		
		#gather the results
		$newresult = @()
		foreach ($result in $results)
		{
			$length = ($result.length) + 1
			$newresult += ($result).padright($length, ",")
		}
		$object.applications = [string]($newresult)
		#$object
		$resultarray += $object
	}
	else
	{
		$object.Status = "Offline"
		$resultarray += $object
		continue
	}
}
#$resultarray
$resultarray | Export-Csv c:\temp\AdobeApplicationsReport.csv -Force
$body = [string]($resultarray | ConvertTo-Html)
Send-MailMessage -To "James.chandler@pimco.com", "virgil.gherghel@pimco.com" -From scripttest@pimconull.net -SmtpServer mailhost -BodyAsHtml -Body $body -Subject "Adobe Finder"
