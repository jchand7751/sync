﻿C:
cd C:\vagrant\vms\boinc\
.\Vagrant.exe up


