﻿Add-PSsnapin swissnapin
$swis = connect-swis vma001p087 -credential (get-credential)
#Query IIS Details
$array = @()
foreach ($i in $a) 
{
    $array += .\IISDetails.ps1 $i.name
}
#Query Solarwinds DB Details

#Query AppDynamics
$applications = curl --user queryaccount@customer1:Pimco123 http://prodpmappdyn2:8090/controller/rest/applications?output=JSON
#Convert to object
$applications = $applications | out-string | ConvertFrom-Json
$appdarray = @()
foreach ($app in $applications)
{
	$tiersinapplication = curl --user queryaccount@customer1:Pimco123 http://prodpmappdyn2:8090/controller/rest/applications/$($app.name)/tiers?output=JSON
	$tiersinapplication = $tiersinapplication | out-string | ConvertFrom-Json
	$tiersinapplication  |  Add-Member -NotePropertyName Application -NotePropertyValue $($app.name)
	$tiersinapplication  |  Add-Member -NotePropertyName AppID -NotePropertyValue $($app.id)
	Foreach ($tier in $tiersinapplication)
	{
		$nodesrunningthistier = curl --user queryaccount@customer1:Pimco123 http://prodpmappdyn2:8090/controller/rest/applications/$($app.name)/tiers/$($tier.id)/nodes?output=JSON
		$nodesrunningthistier = $nodesrunningthistier | out-string | ConvertFrom-Json
		$tier | Add-Member -notepropertyname nodes -notepropertyvalue ([string]$($nodesrunningthistier.machinename))
		$tier
		$appdarray += $tier
	}
	#$array += $tiersinapplication
}

#Get Department?
#Link to Tier

#smash together into giant CSV

#Add some appd
foreach ($thing in $array)
{
    if ($thing.parentsitename)
    {
        $wut = ($thing.parentsitename + "/" + $thing.name)
        #write-host $wut
        $result = $appdarray | where {$_.name -like $wut}
        if ($result)
        {
            $thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue "https://appd/controller/#/location=APP_COMPONENT_MANAGER&timeRange=last_12_hours.BEFORE_NOW.-1.-1.720&application=$($result.appid)&component=$($result.id)&dashboardMode=force"
        }
        else
        {
            $thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue ""
        }
   }
   else
   {
        $wut = ($thing.name)
        #write-host $wut
        $result = $appdarray | where {$_.name -eq $wut}
        if ($result)
        {
            $thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue "https://appd/controller/#/location=APP_COMPONENT_MANAGER&timeRange=last_12_hours.BEFORE_NOW.-1.-1.720&application=$($result.appid)&component=$($result.id)&dashboardMode=force"
            #"https://appd/controller/#/location=APP_COMPONENT_MANAGER&timeRange=last_12_hours.BEFORE_NOW.-1.-1.720&application=$($result.appid)&component=$($result.id)&dashboardMode=force"
        }
        else
        {
            $thing | Add-Member -NotePropertyName AppDLink -NotePropertyValue ""
        }
    }
}


#Add solarwinds

#Get server owners
$swarray = get-swisdata $swis "SELECT Caption, NodeID From ORION.NODES"
foreach ($thing in $array)
{
    $querynode = $swarray | where {$_.caption -like $($thing.server)}
    if ($querynode)
    {

        $thing | Add-Member -NotePropertyName SolarwindsLink -NotePropertyValue "http://solarwinds/Orion/NetPerfMon/NodeDetails.aspx?NetObject=N:$($querynode.nodeid)"
    }
    else
    {
        $thing | Add-Member -NotePropertyName SolarwindsLink -NotePropertyValue ""
    }
}

#future
#Vip curl no header get servers in pools
#connection strings from web.config
#services
#CM deployment info

$array | export-csv c:\temp\smasheddb.csv