﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/8/2015 3:31 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$computername = hostname

$logfile = "C:\temp\RegRun-$env:username-$computername.txt"
New-Item -Type File $logfile -Force

function executiontime 
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

Add-Content -Path $logfile "$(executiontime) - Script started"
$regfiles = Get-ChildItem -Path c:\temp\$env:username

foreach ($file in $regfiles)
{
	Add-Content -Path $logfile "$(executiontime) - Renaming $($file.FullName) to $($file.BaseName).reg"
	Rename-Item $file.FullName ($file.BaseName + ".reg")
}

$updatedregfiles = Get-ChildItem -Path c:\temp\$env:username
foreach ($file in $updatedregfiles)
{
	Add-Content -Path $logfile "$(executiontime) - Importing reg file $($file.FullName)"
	regedit /S $file.FullName
}
Add-Content -Path $logfile "$(executiontime) - Script finished"