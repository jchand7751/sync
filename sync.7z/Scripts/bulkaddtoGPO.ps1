﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/5/2016 11:03 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Import-Module grouppolicy
$a = get-content C:\temp\sybaseuse.txt
$b = get-content C:\temp\sybasecomp.txt

foreach ($i in $b)
{
	$i
	Set-GPPermissions -Name "TEST - SybaseCheckNB" -TargetName $i -TargetType Computer -PermissionLevel GpoApply -server vms001p4
}


foreach ($i in $a)
{
	$i
	Set-GPPermissions -Name "TEST - SybaseCheckNB" -TargetName $i -TargetType User -PermissionLevel GpoApply -server vms001p4
}