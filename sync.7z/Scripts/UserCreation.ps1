﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   8/14/2013 4:50 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================


Add-PSSnapin Quest.ActiveRoles.ADManagement
$a = Import-Csv C:\Temp\testaccountsv2.csv
foreach ($i in $a)
	{
	if ($i.enabled -eq "No")
		{
		if ($i.manager)
			{
			$manager = Get-QADUser -SamAccountName $i.manager
			$testname = ($i.sn + "," + " " + $i.givenname)
			New-QADUser -SamAccountName $i.samaccountname `
			-Name $testname `
			-DisplayName $testname `
			-upn $i.userprincipalname `
			-mail $i.mail `
			-givenName $i.givenname `
			-sn $i.sn `
			-Initials $i.initials `
			-Manager $manager.dn `
			-l $i.l  `
			-physicalDeliveryOfficeName $i.physicaldeliveryofficename `
			-Title $i.title `
			-st $i.st `
			-Department $i.department  `
			-Company $i.company  `
			-StreetAddress $i.streetaddress `
			-PostalCode $i.postalcode `
			-UserPassword $i.password `
			-ParentContainer $i.parentcontainer `
			-objectattributes @{employeetype=$i.employeetype ; middlename=$i.middlename ; c=$i.c ; extensionattribute1=$i.extensionattribute1 ; extensionattribute3=$i.extensionattribute3 ; extensionattribute5=$i.extensionattribute5} `
			#-whatif
			#-facsimileTelephoneNumber $i.facsimiletelephonenumber `
			#-telephoneNumber $i.telephonenumber `
			#-mobile $i.mobile `
			# extensionattribute2=$i.extensionattribute2 ;
			# accountexpires=$i.accountexpires ;
			# -middlename $i.middlename `
			#-c $i.c  `
			}
			else
				{
				$testname = ($i.sn + "," + " " + $i.givenname)
				New-QADUser -SamAccountName $i.samaccountname `
				-Name $testname `
				-DisplayName $testname `
				-upn $i.userprincipalname `
				-mail $i.mail `
				-givenName $i.givenname `
				-sn $i.sn `
				-Initials $i.initials `
				-l $i.l  `
				-physicalDeliveryOfficeName $i.physicaldeliveryofficename `
				-Title $i.title `
				-st $i.st `
				-Department $i.department  `
				-Company $i.company  `
				-StreetAddress $i.streetaddress `
				-PostalCode $i.postalcode `
				-UserPassword $i.password `
				-ParentContainer $i.parentcontainer `
				-objectattributes @{employeetype=$i.employeetype ; middlename=$i.middlename ; c=$i.c ; extensionattribute1=$i.extensionattribute1 ; extensionattribute3=$i.extensionattribute3 ; extensionattribute5=$i.extensionattribute5} `
				#-whatif
				# -facsimileTelephoneNumber $i.facsimiletelephonenumber `
				# -telephoneNumber $i.telephonenumber `
				# -mobile $i.mobile `
				# extensionattribute2=$i.extensionattribute2 ; 
				# accountexpires=$i.accountexpires ;
				# -middlename $i.middlename `
				#-c $i.c  `
				}
		}
	else
		{
		if ($i.manager)
			{
			$manager = Get-QADUser -SamAccountName $i.manager
			$testname = ($i.sn + "," + " " + $i.givenname)
			New-QADUser -SamAccountName $i.samaccountname `
			-Name $testname `
			-DisplayName $testname `
			-upn $i.userprincipalname `
			-mail $i.mail `
			-givenName $i.givenname `
			-sn $i.sn `
			-Initials $i.initials `
			-Manager $manager.dn `
			-l $i.l  `
			-physicalDeliveryOfficeName $i.physicaldeliveryofficename `
			-Title $i.title `
			-st $i.st `
			-Department $i.department  `
			-Company $i.company  `
			-StreetAddress $i.streetaddress `
			-PostalCode $i.postalcode `
			-UserPassword $i.password `
			-ParentContainer $i.parentcontainer `
			-objectattributes @{employeetype=$i.employeetype ; middlename=$i.middlename ; c=$i.c ; extensionattribute1=$i.extensionattribute1 ; extensionattribute3=$i.extensionattribute3 ; extensionattribute5=$i.extensionattribute5} `
			#-whatif
			# -facsimileTelephoneNumber $i.facsimiletelephonenumber `
			# -telephoneNumber $i.telephonenumber `
			# -mobile $i.mobile `
			# accountexpires=$i.accountexpires ;
			# -middlename $i.middlename `
			# extensionattribute2=$i.extensionattribute2 ; 
			#-c $i.c  `
			}
			else
				{
				$testname = ($i.sn + "," + " " + $i.givenname)
				New-QADUser -SamAccountName $i.samaccountname `
				-Name $testname `
				-DisplayName $testname `
				-upn $i.userprincipalname `
				-mail $i.mail `
				-givenName $i.givenname `
				-sn $i.sn `
				-Initials $i.initials `
				-l $i.l  `
				-physicalDeliveryOfficeName $i.physicaldeliveryofficename `
				-Title $i.title `
				-st $i.st `
				-Department $i.department  `
				-Company $i.company  `
				-StreetAddress $i.streetaddress `
				-PostalCode $i.postalcode `
				-UserPassword $i.password `
				-ParentContainer $i.parentcontainer `
				-objectattributes @{employeetype=$i.employeetype ; middlename=$i.middlename ; c=$i.c ; extensionattribute1=$i.extensionattribute1 ; extensionattribute3=$i.extensionattribute3 ; extensionattribute5=$i.extensionattribute5} `
				#-whatif
				# accountexpires=$i.accountexpires ;
				# -facsimileTelephoneNumber $i.facsimiletelephonenumber `
				# -telephoneNumber $i.telephonenumber `
				# -mobile $i.mobile `
				# -middlename $i.middlename `
				# extensionattribute2=$i.extensionattribute2 ; 
				#-c $i.c  `
				}
		}
	if ($i.accountexpires)
			{
			$accountexpires = ([datetime]"01/01/2014").touniversaltime()
			Get-QADUser -SamAccountName $i.samaccountname | Set-QADUser -AccountExpires $accountexpires -whatif
			}
		if ($i.enabled -eq "No")
			{
			Get-QADUser -SamAccountName $i.samaccountname | Disable-QADUser -whatif
			}
	}