﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/23/2015 3:12 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


Create PROCEDURE usp_insertsw
	 	  @Caption nvarchar(max) = NULL,
		  @Department nvarchar(max) = NULL,
		  @Environment nvarchar(max)= NULL,
		  @LastBoot nvarchar(max)= NULL,
		  @NodeID nvarchar(max)= NULL,
		  @NumberofCores nvarchar(max)= NULL,
		  @TotalCapacity nvarchar(max)= NULL
	as
INSERT INTO SWTable (Caption, Department, Environment, LastBoot, NodeID, NumberofCores, TotalCapacity)
SELECT @Caption, @Department, @Environment, @LastBoot, @NodeID, @NumberofCores, @TotalCapacity


Create PROCEDURE usp_insertiis
		  @Server nvarchar(max) = NULL,
		  @Name nvarchar(max) = NULL,
		  @ParentSiteID nvarchar(max) = NULL,
		  @ParentSiteName nvarchar(max) = NULL,
		  @SiteID nvarchar(max) = NULL,
		  @LogDirectory nvarchar(max) = NULL,
		  @Path nvarchar(max) = NULL,
		  @Authentication nvarchar(max) = NULL,
		  @Bindings nvarchar(max) = NULL,
		  @AppPoolName nvarchar(max) = NULL,
		  @AppPool32bitenabled nvarchar(max) = NULL,
		  @AppPoolCredential nvarchar(max) = NULL,
		  @AppPoolVersion nvarchar(max) = NULL,
		  @Type nvarchar(max) = NULL,
		  @Webconfig nvarchar(max) = NULL,
		  @Id nvarchar(max) = NULL,
		  @IISpath nvarchar(max) = NULL
	as
INSERT INTO IISTable (Server, Name, ParentSiteID, ParentSiteName, SiteID, LogDirectory, Path, Authentication, Bindings, AppPoolName, AppPool32bitenabled, AppPoolCredential, AppPoolVersion, Type, Webconfig, Id, IISpath)
SELECT @Server, @Name, @ParentSiteID, @ParentSiteName, @SiteID, @LogDirectory, @Path, @Authentication, @Bindings, @AppPoolName, @AppPool32bitenabled, @AppPoolCredential, @AppPoolVersion, @Type, @Webconfig, @Id, @IISpath