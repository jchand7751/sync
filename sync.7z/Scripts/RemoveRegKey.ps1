﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/19/2016 2:45 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($value)

#Get-ItemProperty -Path "HKCU:\Software\Microsoft\Office\14.0\Excel\Add-in Manager"
#Get-ItemProperty -Path "HKCU:\Software\Microsoft\Office\14.0\Excel\Add-in Manager" | Remove-Item
Get-ItemProperty -Path "HKCU:\Software\Microsoft\Office\14.0\Excel\Add-in Manager" | Export-Csv c:\temp\AddinManagerKey.csv
Get-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options | Export-Csv c:\temp\ExcelOptionsKey.csv

if ($value)
{
	#Delete Appsense OPEN value
	Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options -Name $value
	#Delete Appsense Addin Manager value
	Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Office\14.0\Excel\Add-in Manager" -Name $value
}

#Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options -Name OPEN1
#Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options -Name OPEN2
#Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options -Name OPEN3
#Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options -Name OPEN4
#Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options -Name OPEN5
#Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\14.0\Excel\Options -Name OPEN6

#$Username = ((gwmi win32_computersystem -comp $computername).username -split "pimco\\")[1]
#$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$Username))"
#$searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com'
#$user = $searcher.FindOne().GetDirectoryEntry()
#$binarySID = $user.ObjectSid.Value
#$stringSID = (New-Object System.Security.Principal.SecurityIdentifier($binarySID, 0)).Value

#Get-ItemProperty -Path Microsoft.Powershell.Core\Registry::HKEY_Users\$stringSID\Software\Microsoft\Office\14.0\Excel\Options | Export-Csv c:\temp\installedaddins.csv