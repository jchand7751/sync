﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/27/2016 11:06 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$Computer,

	[Parameter(Mandatory = $true, Position = 1)]
	[string]$stringvalues
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\AddinInstall-$Computer.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
Add-Log -Type 'Information' -Message "Starting script"
#endregion

#region Load modules and snapins
try
{
	Import-module \\nasshare\share\test\PSRemoteRegistry -ea 'Stop' | Out-Null
	#Import-module PSRemoteRegistry -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins $Error[0]" -Throw
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

#endregion

#region Main

if ((Test-Connection -ComputerName $Computer -Count 1 -Quiet) -ne $true)
{
	Add-Log -Type 'Error' -Message "$Computer is offline" -Throw
}

if (((Get-Service -ComputerName $Computer -Name RemoteRegistry).status) -ne "Running")
{
	try
	{
		(gwmi win32_service -ComputerName $Computer -Filter "name='remoteregistry'").StartService()
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to start remote registry service" -Throw
	}
}

try
{
	$getuser = ((gwmi win32_computersystem -comp $Computer -ea 'Stop').username)
}
catch
{
	Add-Log -Type 'Error' -Message "Could not get user" -Throw
}

if ($getuser)
{ }
else
{
	Add-Log -Type 'Error' -Message "Could not get user" -Throw
}

$Domain = ($getuser -split ("\\"))[0]
$Username = ($getuser -split ("\\"))[1]

$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$Username))"
switch ($Domain)
{
	"PIMCO" { $searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com' }
	"IMSWEST" { $searcher.SearchRoot = 'LDAP://imswest.sscims.com' }
	default { Add-Log -Type 'Error' -Message "Domain did not match Pimco or IMSWEST" -Throw }
}
$user = $searcher.FindOne().GetDirectoryEntry()
if ($user)
{ }
else
{
	Add-Log -Type 'Error' -Message "Couldn't find user" -Throw
}
$binarySID = $user.ObjectSid.Value
$stringSID = (New-Object System.Security.Principal.SecurityIdentifier($binarySID, 0)).Value
$stringarray = ($stringvalues -split ",")
foreach ($value in $stringarray)
{
	if (Get-RegString -Computer $Computer -Hive Users -Key $stringSID\Software\Microsoft\Office\14.0\Excel\Options -Value OPEN -ea 'SilentlyContinue')
	{
		for ($x = 1; $x -lt 50; $x++)
		{
			try
			{
				$valuecheck = Get-RegString -Computer $Computer -Hive Users -Key $stringSID\Software\Microsoft\Office\14.0\Excel\Options -Value OPEN$x -ea 'Stop'
				if ($valuecheck.data -eq $value)
				{
					Add-Log -Type 'Error' -Message "Found an existing reg string matching $value - OPEN$x"
					exit
				}
			}
			catch
			{
				Add-Log -Type 'Information' -Message "Value OPEN$x is available"
				try
				{
					Add-Log -Type 'Information' -Message "Set-RegString -Computer $Computer -Hive Users -Key $stringSID\Software\Microsoft\Office\14.0\Excel\Options -Value OPEN$x -Data $value -ErrorAction 'Stop' -Confirm:$false"
					Set-RegString -Computer $Computer -Hive Users -Key $stringSID\Software\Microsoft\Office\14.0\Excel\Options -Value OPEN$x -Data $value -ErrorAction 'Stop' -Confirm:$false
					break
				}
				catch
				{
					Add-Log -Type 'Error' -Message "Set Regstring failed" -Throw
				}
			}
		}
	}
	else
	{
		Add-Log -Type 'Information' -Message "Value OPEN is available"
		try
		{
			Add-Log -Type 'Information' -Message "Set-RegString -Computer $Computer -Hive Users -Key $stringSID\Software\Microsoft\Office\14.0\Excel\Options -Value OPEN -Data $value -ErrorAction 'Stop' -Confirm:$false"
			Set-RegString -Computer $Computer -Hive Users -Key $stringSID\Software\Microsoft\Office\14.0\Excel\Options -Value OPEN -Data $value -ErrorAction 'Stop' -Confirm:$false
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Set Regstring failed" -Throw
		}
	}
}
Add-Log -Type 'Information' -Message "Script finished"
#endregion