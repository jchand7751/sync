﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/3/2016 4:43 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


get-qadgroup "*technology managers 2" | get-qadgroupmember -sizelimit 0 | select Name, Department, @{Name = "Manager"; Expression = { (get-qaduser $_.manager).name } } | export-csv c:\temp\TechnologyMangers2.csv