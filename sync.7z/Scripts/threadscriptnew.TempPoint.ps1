﻿$hosts = "vmh001d036","vmh001d038","vmh001d026","vmh001d027"

#$CSV = "C:\temp\vappdata.csv"
    #$hosts = @()
    #$a = get-content $CSV
    $serverarray = $null
    $serverarray = @()

    #$a = $a -replace(";",",")
    #$blah = '"name","serverame","blank1","blank2","protocol","port","path" ' + $a

$RunspaceCollection = @()
$RunspacePool = [RunspaceFactory]::CreateRunspacePool(1,40)
$RunspacePool.Open()

$scriptblock = {param ($computer) ; write-verbose "starting script" ; \\naspmhome\technology\Chandler_James\Private\Appsense\scripts\IISDetails.ps1 $computer}

<#$scriptblock = {
Param(
        $Computer
        )
         
        Try{
            Get-WinEvent -ComputerName $Computer -MaxEvents 10 -ErrorAction Stop
        }
        Catch{
            write-warning "caught this"
            Write-Warning $_
        }      
     }
#>

Foreach($Computer in $hosts)
{
    
    #Create a PowerShell object to run add the script and argument.
    $Powershell = [PowerShell]::Create().AddScript($ScriptBlock).AddArgument($Computer)
    #Specify runspace to use
    $Powershell.RunspacePool = $RunspacePool
    
    #Create Runspace collection
    [Collections.Arraylist]$RunspaceCollection += New-Object -TypeName PSObject -Property @{
    Runspace = $PowerShell.BeginInvoke()
    PowerShell = $PowerShell  
    } 
}

$RunspaceTotal = $RunspaceCollection.count
$CompletionCount = 0
$Resultsarray = @()
While($RunspaceCollection)
{
    Foreach($Runspace in $RunspaceCollection.ToArray())
    {
        If($Runspace.Runspace.IsCompleted)
        {
            #write-host "Run space finished"
            if ($Runspace.Powershell.HadErrors -eq $true)
            {
                $runspace.powershell.streams.error
            }
            #write the data
            $resultsarray += $Runspace.PowerShell.EndInvoke($Runspace.Runspace)
            $Runspace.PowerShell.EndInvoke($Runspace.Runspace)
            #close the session
            $Runspace.PowerShell.Dispose()
            #$runspace.powershell
            $RunspaceCollection.Remove($Runspace)
            $CompletionCount++
            Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
            Write-host "Total count: $RunspaceTotal"
            write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
        }
        else
        {
            sleep 5
            write-host "Run space not done"
            Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
            Write-host "Total count: $RunspaceTotal"
            write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
        }
    }
}
$Resultsarray | export-csv c:\temp\theseresults.csv