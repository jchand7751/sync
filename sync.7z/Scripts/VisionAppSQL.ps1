﻿$SQLQ = "
with Parent_table 
as ( 
SELECT a.[id],ServerName,b.ParentItemId
  FROM [visionapp].[dbo].[vRDConnections] A
 INNER JOIN  [visionapp].[dbo].[vRDIndexTable] B
 ON A.Id = B.Id
) 

select d.*,c.* from Parent_table d
inner join (
SELECT a.[id],a.Name,b.ParentItemId
  FROM [visionapp].[dbo].[vRDFolders] A
 INNER JOIN  [visionapp].[dbo].[vRDIndexTable] B
 ON A.Id = B.Id ) c 
 on d.ParentItemId = c.Id
 "


function Get-SQL
{
##Passing the servername
param(
  [string]$ServerName,
  $applicationid
)

 ## SQL connection and getting selected results 
 $SqlConnection = New-Object System.Data.SqlClient.SqlConnection
#$SqlConnection.ConnectionString = "Server=$servername;Database=master ;Integrated Security=True"
$SqlConnection.ConnectionString = "Server=$servername,5150;Database=visionapp ;Integrated Security=True"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SQLQ
$SqlCmd.Connection = $SqlConnection
$SqlCmd.CommandTimeout = 0
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet) | out-null  #to get rid of output
$sqlconnection.close()
$allperm=@() 


##selecting each row from the sql ouput and inserting into each particular row
$dataset.tables[0]
}

$SQLQ = "SELECT Id,Name FROM [visionapp].[dbo].vRDFolders"

$folderset
$serverset

$newarray = @()
foreach ($i in $serverset)
{
    $object = "" | select id, ServerName, ParentItemId, id1, Name, ParentItemId1, ParentFolder, ParentParentFolder
    $object.id = $i.id
    $object.servername = $i.servername
    $object.id1 = $i.id1
    $object.name = $i.name
    $object.parentitemid1 = $i.parentitemid1 
    $object.parentfolder = ($folderset | where {$_.id -eq $i.parentitemid1}).name
    $object.parentparentfolder = ($folderset | where {$_.id -eq $i.parentfolder}).name
    $newarray += $object
}





SELECT Id,Name FROM [visionapp].[dbo].vRDFolders
