﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/2/2015 4:58 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$Basepath64 = "W:\pm\vendor\boost\win64\"
$Currentversion64 = "1_57_0"
$Basepath32 = "W:\pm\vendor\boost\win32\"
$Currentversion32 = "1_57_0"
if (Test-Path ($Basepath64 + $Currentversion64))
{
	robocopy ($Basepath64 + $Currentversion64) C:\pimco\vendors\boost\win64\$CurrentVersion64 /MIR /R:5 /W:5 /MT:16
}
if (Test-Path ($Basepath32 + $Currentversion32))
{
	robocopy ($Basepath32 + $Currentversion32) C:\pimco\vendors\boost\win32\$CurrentVersion32 /MIR /R:5 /W:5 /MT:16
}