﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/29/2016 2:22 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

function test123 {
	
	Get-process
}

function test456
{
	
	Get-childitem
}

Write-Host "ran this"