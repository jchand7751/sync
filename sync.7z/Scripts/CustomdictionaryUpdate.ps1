﻿$dictionaryname = "CUSTOMBDS1.dic"
$dictionaryshared = "\\nasshare\share\test\CUSTOMBDS1.dic"
$dictionarylocalpath = "c:\temp"
$dictionarylocal = "c:\temp\CUSTOMBDS1.dic"
$whoami = ((whoami) -split "\\")[1]
$script:LogPath = "C:\temp\crmdictionary-$whoami.txt"
$timestamp = (Get-Date -UFormat %Y-%m-%d-%H%M)

#Create the log file
if  ((Test-Path $LogPath) -eq $true)
{Add-Content -Path $LogPath "$timestamp - Script started" | Out-Null}
else
{
	New-Item -Path $LogPath -ItemType File | Out-Null
	Add-Content -Path $LogPath "$timestamp - Script started" | Out-Null
}
#Start Word COM Object
try
{
    $word = New-Object -comobject word.application
}
catch
{
    Write-Warning "Failed to start Word Com object, exiting!"
    Add-Content -Path $LogPath "$timestamp - Failed to start Word Com object, exiting!"
    exit
}
#Try to find the shared dictionary added locally
$dictionaryobject = $word.customdictionaries | where {$_.name -eq $dictionaryname}
if ($dictionaryobject)
{
    #Shared dictionary appears to be added, checking for latest version
    $dictionarysharedwritetime = (Get-Item $dictionaryshared).LastWriteTime
    $dictionarylocalwritetime = (Get-Item ($dictionaryobject.path + "\" + $dictionaryobject.name)).LastWriteTime
    if ($dictionarysharedwritetime -ne $dictionarylocalwritetime)
    {
        Write-Warning "Dictionary versions don't match, copying new file"
        Add-Content -Path $LogPath "$timestamp - Dictionary versions don't match, copying new file"
        #Mismatch on the write times, replace the local
        try
        {
            Copy-Item $dictionaryshared $dictionarylocalpath -Force
        }
        catch
        {
            Write-Warning "Dictionary failed to copy!"
            Add-Content -Path $LogPath "$timestamp - Dictionary failed to copy!"
        }
    }
    else
    {
        Write-Warning "Dictionary versions match"
        Add-Content -Path $LogPath "$timestamp - Dictionary versions match"
    }
}
else
{
    Write-Warning "Dictionary not found, copying new file"
    Add-Content -Path $LogPath "$timestamp - Dictionary not found, copying new file"
    #Copy the shared dictionary local
    try
    {
        Copy-Item $dictionaryshared $dictionarylocalpath -Force
    }
    catch
    {
        Write-Warning "Dictionary failed to copy!"
        Add-Content -Path $LogPath "$timestamp - Dictionary failed to copy!"
    }
    if (Get-Item $dictionarylocal)
    {
        #If the dictionary made it over add it into Word
        try
        {
            $word.customdictionaries.add($dictionarylocal)
        }
        catch
        {
            Write-Warning "Failed to add the local dictionary to Word!"
            Add-Content -Path $LogPath "$timestamp - Failed to add the local dictionary to Word!"
        }
    }
    else
    {
        Write-Warning "Dictionary failed to copy!"
        Add-Content -Path $LogPath "$timestamp - Dictionary failed to copy!"
    }
}
Add-Content -Path $LogPath "$timestamp - Script finished" | Out-Null