﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/22/2015 3:19 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
#good example
#http://www.infinitec.de/post/2011/07/25/How-to-get-the-number-of-unread-mails-from-multiple-mailboxes-using-the-EWS-Managed-API-and-PowerShell.aspx
#Exchange web services
param($emailaddress, $foldername)
#Import the module
try
{
	Import-Module -Name "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll"
}
catch
{
	Write-Warning "Module not installed, exiting"
}
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP2)
$service.usedefaultcredentials = $true
$service.Url= new-object Uri("https://owa-lb.pimco.imswest.sscims.com/EWS/Exchange.asmx")
$mailbox = New-Object Microsoft.Exchange.WebServices.Data.Mailbox($emailAddress)
$folderId = New-Object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox, $mailbox)
$folder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service, $folderId)
$folder.unreadcount