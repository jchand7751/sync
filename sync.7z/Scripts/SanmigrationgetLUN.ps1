<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.57
	 Created on:   	6/2/2014 12:09 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$object =
$csv = Import-Csv c:\temp\PIMCO-NB-SourceOne-RAWLuns.csv
$vmhost = "inv0b1rw4.pimco.imswest.sscims.com"
$canon = $i."raw lun ID"; ([string]($canon[10..($canon.length - 12)])) -replace " "

foreach ($i in ($csv | where { $_.raw -eq "TRUE" }))
{
	$object = "" | select VMname, canonicalname, runtimename
	$canon = $i."raw lun ID"
	$canon = (([string]($canon[10..($canon.length - 13)])) -replace " ")
	$canon = "naa." + $canon
	#$canon
	$info = get-scsilun -vmhost $vmhost -canonicalname $canon
	$object.vmname = $i.VM
	$object.canonicalname = $canon
	$object.runtimename = $info.runtimename
	$object
}


