﻿#Generic CM script to invoke Powershell and allow credential passing through CredSSP
param(
  [string]$ServerList,
  [string]$Env,
  [string]$Script_Path,
  [string]$Password,
  #Application Specific 
  [string]$EDMCmdPath,
  [string]$Path,
  [string]$LogLocation,
  [string]$DBHOST,
  [string]$DBServer,
  [string]$FileName
)

Write-Host ""
Write-Host "Env          = $Env"
Write-Host "ServerList   = $ServerList"
Write-Host ""

#Take the comma separated servers from the params and turn it into an array
$ServerArr = $ServerList.split(",")

#Need to do something with Env?

#Build the Credential, exit out if it fails since the whole thing will hang
try
{
    $securepassword = $password | ConvertTo-SecureString -AsPlainText -force;
    $credential = New-Object System.Management.Automation.PSCredential "pimco\svc_pimcocm",$securepassword -ea Stop
    #$credential = New-Object System.Management.Automation.PSCredential "pimco\jchandle",$securepassword -ea Stop
}
catch
{
    $errMessage = "ERR: $Server - " + $_.Exception.ToString()
    Write-Host $errMessage
    exit 1
}

foreach ($Server in $ServerArr)
{
    Try
    {
        #Create the script block, this is the exact syntax that will be executed from the Invoke-Command
        $Scriptblock = "$Script_Path -DBHost $DBHost -DBServer $DBServer"
        Write-host ""
        Write-host "Executing the following on $Server`: $scriptblock"
        Write-host ""
        #Run the command on the server in the array
        Invoke-Command -ComputerName $Server -ScriptBlock{Invoke-Expression $args[0]} -argumentlist $ScriptBlock -Credential $Credential -Authentication CredSSP -ea Stop
        #."E:\Program Files\Markit Group\MarkitEDM\CADISImportExport.exe" /action:Import /type:DBParameters /server:VMD001B050 /db:EDM /integrated:Yes /newonly:No /groups:Overwrite /filename:e:\batch\edmimport\markitDBParam.xml
    }
    Catch [System.Exception]
    {
        $errMessage = "ERR: $Server - " + $_.Exception.ToString()
        Write-Host $errMessage
        exit 1
    }
}        
exit 0
