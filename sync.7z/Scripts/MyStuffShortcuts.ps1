﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   8/8/2013 2:58 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

Function CheckforQuest
{
$testsnapin = Get-PSSnapin | where {$_.name -like "Quest.ActiveRoles.ADManagement"}
if ($testsnapin)
    {}
    else
        {
        Add-PSSnapin "Quest.ActiveRoles.ADManagement"
        }
}

Function Getusers
{
Connect-qadservice pimco.imswest.sscims.com | Out-null
$script:Users = Get-QADGroup MyStuff-Test | Get-QADGroupmember
}

Function ShortcutCheck
{
Param ($Userobject)

$logfile = "C:\MyStuffLogFile.txt"

$Testpath = Test-Path "$($Userobject.homedirectory)\Private\My Stuff"
If ($Testpath)
	{}
	Else
		{
        Write-warning "This user account does not have permissions to access the My Stuff folder for $($Userobject.name) or the folder does not exist!"
        Exit
        }

$UsersList = Get-ChildItem "$($Userobject.homedirectory)\Private\My Stuff"
$usersarray = @()
foreach ($i in $UsersList)
	{
	$tempobject = "" | select Name, Path, Arguments
	$tempobject.name = $i.Name
	###Shortcut Link Section###
	$checkendswith1 = ($i.Name).EndsWith(".lnk")
	switch ($checkendswith1)
		{
		"True" {$path = $i.FullName ; $LinkObject = New-Object -COM WScript.Shell ; $LinkDetails = $LinkObject.createShortcut($Path) ; $tempobject.path = $LinkDetails.TargetPath ; $tempobject.arguments = $LinkDetails.arguments}
		}

	###URL Link Section###
	$checkendswith2 = ($i.Name).EndsWith(".url")
	$path = $i.FullName
	if ((Get-Content $path | Select-String "url=").count -ge 2)
		{
		switch ($checkendswith2)
			{
			"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")[1]) -replace "URL=" ; $tempobject.path = $LinkDetails}
			}
		$usersarray += $tempobject 
		}
		else
			{
			switch ($checkendswith2)
				{
				"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")) -replace "URL=" ; $tempobject.path = $LinkDetails}
				}
			$usersarray += $tempobject 
			}
	}
Write-host "Users Shortcuts:"
$usersarray
Write-Host "-------------------------------------"
Write-host ""
###Comparison Objects###
#$templatelist = Get-ChildItem "\\pimco\dfspimco\share\My Stuff - Template"
$templatelist = Get-ChildItem "\\pimco\dfspimco\share\My Stuff - Test" -exclude NewShortcuts
$templatearray = @()
foreach ($i in $templatelist)
	{
	$tempobject = "" | select Name, Path, Arguments
	$tempobject.name = $i.name
	
	$checkendswith1 = ($i.Name).EndsWith(".lnk")
	switch ($checkendswith1)
		{
		"True" {$path = $i.FullName ; $LinkObject = New-Object -COM WScript.Shell ; $LinkDetails = $LinkObject.createShortcut($Path) ; $tempobject.path = $LinkDetails.targetpath ; $tempobject.arguments = $LinkDetails.arguments}
		}
	
	$checkendswith2 = ($i.Name).EndsWith(".url")
	$path = $i.FullName
	if ((Get-Content $path | Select-String "url=").count -ge 2)
		{
		switch ($checkendswith2)
			{
			"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")[1]) -replace "URL=" ; $tempobject.path = $LinkDetails}
			}
		$templatearray += $tempobject 
		}
		else
			{
			switch ($checkendswith2)
				{
				"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")) -replace "URL=" ; $tempobject.path = $LinkDetails}
				}
			$templatearray += $tempobject 
			}
	}
Write-host "Template Shortcuts:"
Write-host ""
$templatearray
Write-Host "-------------------------------------"
Write-host ""
foreach ($i in $usersarray)
	{
	$matches = $templatearray | where {$_.name -eq $i.name}
    if ($matches)
        {
	    if ($matches.path -eq $i.path -and $matches.arguments -eq $i.arguments)
		  {
		  Write-Host "$($i.name) matches, skipping"
		  }
		  else
	        {
			Write-Host "$($i.name) does NOT match, replacing shortcut"
			#Copy "\\pimco\dfspimco\share\My Stuff - Template\$($i.name)" "$($i.homedirectory)\Private\My Stuff" -whatif
			Copy "\\pimco\dfspimco\share\My Stuff - Test\$($i.name)" "$($UserObject.homedirectory)\Private\My Stuff"
			}
        }    
	}	
}

Function AddNewShortcuts
{
Param ($Userobject)
$logfile = "C:\MyStuffLogFile.txt"

$Testpath = Test-Path "$($Userobject.homedirectory)\Private\My Stuff"
If ($Testpath)
	{}
	Else
		{
        Write-warning "This user account does not have permissions to access the My Stuff folder for $($Userobject.name) or the folder does not exist!"
        Exit
        }

$UsersList = Get-ChildItem "$($Userobject.homedirectory)\Private\My Stuff"
$usersarray = @()
foreach ($i in $UsersList)
	{
	$tempobject = "" | select Name, Path, Arguments
	$tempobject.name = $i.Name
	###Shortcut Link Section###
	$checkendswith1 = ($i.Name).EndsWith(".lnk")
	switch ($checkendswith1)
		{
		"True" {$path = $i.FullName ; $LinkObject = New-Object -COM WScript.Shell ; $LinkDetails = $LinkObject.createShortcut($Path) ; $tempobject.path = $LinkDetails.TargetPath ; $tempobject.arguments = $LinkDetails.arguments}
		}

	###URL Link Section###
	$checkendswith2 = ($i.Name).EndsWith(".url")
	$path = $i.FullName
	if ((Get-Content $path | Select-String "url=").count -ge 2)
		{
		switch ($checkendswith2)
			{
			"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")[1]) -replace "URL=" ; $tempobject.path = $LinkDetails}
			}
		$usersarray += $tempobject 
		}
		else
			{
			switch ($checkendswith2)
				{
				"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")) -replace "URL=" ; $tempobject.path = $LinkDetails}
				}
			$usersarray += $tempobject 
			}
	}
Write-Host "-------------------------------------"
Write-host ""
###Comparison Objects###
#$templatelist = Get-ChildItem "\\pimco\dfspimco\share\My Stuff - Template"
$templatelist = Get-ChildItem "\\pimco\dfspimco\share\My Stuff - Test\NewShortcuts"
$templatearray = @()
if ($templatelist.count)
    {
    foreach ($i in $templatelist)
    	{
    	$tempobject = "" | select Name, Path, Arguments
    	$tempobject.name = $i.name
    	
    	$checkendswith1 = ($i.Name).EndsWith(".lnk")
    	switch ($checkendswith1)
    		{
    		"True" {$path = $i.FullName ; $LinkObject = New-Object -COM WScript.Shell ; $LinkDetails = $LinkObject.createShortcut($Path) ; $tempobject.path = $LinkDetails.targetpath ; $tempobject.arguments = $LinkDetails.arguments}
    		}
    	
    	$checkendswith2 = ($i.Name).EndsWith(".url")
    	$path = $i.FullName
    	if ((Get-Content $path | Select-String "url=").count -ge 2)
    		{
    		switch ($checkendswith2)
    			{
    			"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")[1]) -replace "URL=" ; $tempobject.path = $LinkDetails}
    			}
    		$templatearray += $tempobject 
    		}
    		else
    			{
    			switch ($checkendswith2)
    				{
    				"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")) -replace "URL=" ; $tempobject.path = $LinkDetails}
    				}
    			$templatearray += $tempobject 
    			}
        }
    }    
    else
        {
        $i = $templatelist
        $tempobject = "" | select Name, Path, Arguments
    	$tempobject.name = $i.name
    	
    	$checkendswith1 = ($i.Name).EndsWith(".lnk")
    	switch ($checkendswith1)
    		{
    		"True" {$path = $i.FullName ; $LinkObject = New-Object -COM WScript.Shell ; $LinkDetails = $LinkObject.createShortcut($Path) ; $tempobject.path = $LinkDetails.targetpath ; $tempobject.arguments = $LinkDetails.arguments}
    		}
    	
    	$checkendswith2 = ($i.Name).EndsWith(".url")
    	$path = $i.FullName
    	if ((Get-Content $path | Select-String "url=").count -ge 2)
    		{
    		switch ($checkendswith2)
    			{
    			"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")[1]) -replace "URL=" ; $tempobject.path = $LinkDetails}
    			}
    		$templatearray += $tempobject 
    		}
    		else
    			{
    			switch ($checkendswith2)
    				{
    				"True" {$path = $i.FullName ; $LinkDetails = ([string](get-content $path | select-string "url=")) -replace "URL=" ; $tempobject.path = $LinkDetails}
    				}
    			$templatearray += $tempobject 
    			}
        }
    Write-host "New Shortcuts:"
    Write-host ""
    $templatearray
    Write-Host "-------------------------------------"
    Write-host ""
    foreach ($i in $templatearray)
    	{
    	$matches = $Usersarray | where {$_.name -eq $i.name}
    	if ($matches)
    		{
    		Write-Host "$($i.name) has been added already, skipping"
    		}
    		else
    			{
    			Write-Host "$($i.name) is a new shortcut, adding it..."
    			#Copy "\\pimco\dfspimco\share\My Stuff - Template\$($i.name)" "$($i.homedirectory)\Private\My Stuff" -whatif
    			Copy "\\pimco\dfspimco\share\My Stuff - Test\NewShortcuts\$($i.name)" "$($UserObject.homedirectory)\Private\My Stuff"
    			}	
    	}	
}

CheckforQuest
$testsnapin = Get-PSSnapin | where {$_.name -like "Quest.ActiveRoles.ADManagement"}
if ($testsnapin)
    {}
    else
        {
        Write-Warning "Quest module not running! Exiting..."
        Exit
        }
GetUsers
Foreach ($i in $script:Users)
    {
    ShortcutCheck $i
    AddNewShortcuts $i
    }        


