﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/9/2015 2:39 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	CliqrStagingVMMove.ps1
	===========================================================================
	.DESCRIPTION
		Move VMs from Staging datastore clusters into production datastore cluster.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Tiername
)
#endregion

#region Base variables and environment information
$logfile = "e:\logs\CliqrStagingVMMove.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin VMware.VimAutomation.Core -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw -EventSource Pimcloud -EventId 75
}
#endregion

#region Create variables and arrays
$stagingdatastoreclusters = "Cliqr-Image-VMStaging", "csv035brnzc001_dsc002-STAGE", "csv035goldc001_dsc002-STAGE"

#endregion

#region Script functions

#endregion

#region Main
Add-Log -Message "Starting script" -Type 'Information' -EventSource Pimcloud -EventId 60
#Connect to VCenter
try
{
	Connect-VIServer vma035gw080.core.pimcocloud.net -ea 'Stop' -Force | Out-Null
}
catch
{
	Add-Log -Message "Failed to connect to VCenter" -Type 'Error' -Throw -EventSource Pimcloud -EventId 73
}

#Get VMs in Staging Datastores
$vms = @()
try
{
	#Get all the VMs on our staging clusters
	#$vms = Get-DatastoreCluster -Name csv035brnzc001_dsc002-STAGE -ea 'Stop' | Get-VM -Name clv*
	foreach ($datastorecluster in $stagingdatastoreclusters)
	{
		$vms += Get-DatastoreCluster -Name $datastorecluster -ea 'Stop' | Get-VM -Name clv*
	}
}
catch
{
	Add-Log -Message "Failed to query $datastorecluster" -Type 'Error' -Throw -EventSource Pimcloud -EventId 74
}

#Move VMs
if ($vms)
{
	foreach ($vm in $vms)
	{
		try
		{
			Add-Log -Message "Attempting to move $($vm.name)" -Type 'Information'
			#Find the cluster this VM lives in
			$parentcluster = Get-View -Id (Get-View -Id $vm.vmhostid).parent
			#Find the datastore cluster for this cluster that isn't named *stage* or *staging*
			$dscluster = ((get-view (get-view $parentcluster.datastore).parent).summary | where { $_.name -notlike "*staging*" -and $_.name -notlike "*Stage*" })
			if ($dscluster.count -gt 1)
			{
				#If we have more than one datastore clusters available pick the one with the most free space
				$vm | Move-VM -Datastore ($dscluster | sort freespace)[0].name -ea 'Stop' -RunAsync #-WhatIf
			}
			else
			{
				#If we have just one datastore cluster, send it over
				$vm | Move-VM -Datastore $dscluster.name -ea 'Stop' -RunAsync #-WhatIf
			}
		}
		catch
		{
			Add-Log -Message "Unable to move $($vm.name)" -Type 'Warning'
			$moveerror = $true
		}
	}
}
else
{
	Add-Log -Message "No VMs to move" -Type 'Information'
}
if ($moveerror -eq $true)
{
	Add-Log -Message "Failed to move vm(s), check log for details" -Type 'Error' -EventSource Pimcloud -EventId 76
}
Add-Log -Message "Script finished" -Type 'Information' -EventSource Pimcloud -EventId 61
#endregion
