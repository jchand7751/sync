﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/8/2017 1:50 PM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$vms = "clv035pw-520dc8", "clv035pw-a23e16", "clv035pw-a39fe2", "clv035pw-c49074", "clv035pw-fe9662", "clv035pw-14a243", "clv0h5pw-5aeb58", "clv0h5pw-738909", "clv0h5pw-0a23c6", "clv0h5pw-c9f24a", "clv0h5pw-d0cb9f"
foreach ($i in $vms)
{
	invoke-command $i {
		cmd /c echo rescan | diskpart
		$size = (Get-PartitionSupportedSize -DiskNumber 1 -PartitionNumber 2)
		Resize-Partition -DiskNumber 1 -PartitionNumber 2 -Size $size.SizeMax
	}	
}