﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/30/2016 4:24 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$GroupName
)

#endregion

#region Base variables and environment information
$logfile = "c:\temp\CliqrGroupSync.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions
function Get-CliqrGroup
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		$Name,
		[Parameter(Mandatory = $false, Position = 0)]
		$ID
	)
	#Connection variables
	$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
	$url = "10.155.5.112"
	
	$groups = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups?size=0" -s
	[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
	$jsonserial = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
	$jsonserial.MaxJsonLength = 500000000
	$groups = $jsonserial.DeserializeObject($groups)
	
	if ($Name)
	{
		$selectedgroup = ($groups.groups | where { $_.name -like $name })
		if ($selectedgroup -notlike $null)
		{
			$selectedgroup
		}
	}
	
	if ($ID)
	{
		$selectedgroup = ($groups.groups | where { $_.id -eq $ID })
		if ($selectedgroup -notlike $null)
		{
			$selectedgroup
		}
	}
	
	if ($Name -like $null -and $ID -like $null)
	{
		$groups.groups
	}
}
#endregion

#region Main
Add-Log -Message "Starting script"

try
{
	#Get all the AD managed Cliqr groups
	$ADGroups = Get-QADGroup -Name "Pimcloud*" -ManagedBy "CN=s_pimcldpr,OU=ServiceAccounts,OU=IA,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com" -DontUseDefaultIncludedProperties -IncludedProperties Samaccountname -SizeLimit 0
}
catch
{
	Add-Log -Message "Couldn't get AD" -Throw
}

try
{
	#Get all the AD managed Cliqr groups
	$ADGroups = Get-QADGroup -Name "Pimcloud*" -ManagedBy "CN=s_pimcldpr,OU=ServiceAccounts,OU=IA,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=com" -DontUseDefaultIncludedProperties -IncludedProperties Samaccountname -SizeLimit 0
}
catch
{
	Add-Log -Message "Couldn't get AD" -Throw
}
foreach ($group in $ADGroups)
{
	Add-Log -Message "Cleaning up group $($group.samaccountname)"
	#Get the group via Cliqr API
	$specgroup = Get-CliqrGroup -Name $group.samaccountname
	#$specgroup.users.externalid
	if ($specgroup -like "")
	{
		Add-Log -Message "Couldn't get Cliqr group members" -Throw
	}
	try
	{
		#AD group members
		$ADgroupmembers = ($group | Get-QADGroupMember -DontUseDefaultIncludedProperties -IncludedProperties Samaccountname -SizeLimit 0).samaccountname
	}
	catch
	{
		Add-Log -Message "Couldn't get AD group members" -Throw
	}
	#Cliqr group members
	$Cliqrgroupmembers = ($specgroup).users.externalId
	#AD vs Cliqr group members
	$compare = compare $cliqrgroupmembers $adgroupmembers
	#Just the users that should not be in Cliqr
	$badCliqrUsers = ($compare | where { $_.sideindicator -eq "<=" }).inputobject
	
	if ($badCliqrUsers)
	{
		Add-Log -Message "Attempting to remove the following users: $([string]$badCliqrUsers)"
		#Commented items are for native ConvertFrom-Json - others are assuming .net json conversion library
		
		#Create the expression to remove users
		#$expression = "(`$specgroup | ConvertFrom-Json).users | where { `$_.externalid -ne " + '"' + (([string]$badcliqrusers) -replace " ", '" -and $$_.externalid -ne "') + '"}'
		$expression = "(`$specgroup).users | where { `$_.externalId -ne " + '"' + (([string]$badcliqrusers) -replace " ", '" -and $$_.externalId -ne "') + '"}'
		$users = Invoke-Expression $expression
		#$specgroupobject = ($specgroup | ConvertFrom-Json)
		#$specgroupobject = $specgroup
		
		#Update the object with users only found in AD
		##foreach ($i in $specgroupobject.keys) { if ($i -like "users") { $specgroupobject[$i] = $users } }
		#$specgroupobject | add-member -Name users -Value $users -MemberType noteproperty -force
		
		#Create a json object and kill all the extra space
		##$object = $specgroupobject | ConvertTo-Json -Compress
		if ($users.id.count -eq 1)
		{
			$userarray = @()
			$userarray += $users
			$script:users = $userarray
		}
		else
		{
			$script:users = $users
		}
		$specgroup
		
		$specgroup.remove("users")
		$specgroup.add("users", $script:users)
		$object = $specgroup | ConvertTo-Json -Compress
		#$object
		
		$specgroup
		#[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
		#$jsonserial1 = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
		#$jsonserial1.MaxJsonLength = 500000000
		#$object = $jsonserial1.Serialize($specgroup)
		
						
		
		#Convert any blank arrays using [] or Cliqr won't accept them
		$object = $object -replace 'perms":""', 'perms":[]'
		#Send the file in ascii format
		$object | out-file c:\tmp\filename.json -Encoding ascii
		#Modify the group via Cliqr API
		$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
		$url = "10.155.5.112"
		curl.exe -k -X PUT -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups/$($specgroup.id)" -d "@c:\tmp\filename.json" -s
		Add-Log -Message "Removal complete"
	}
	elseif ($ADgroupmembers -like $null)
	{
		Add-Log -Message "Removing all users from group"
		#$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
		#$url = "10.155.5.112"
		#curl.exe -k -X GET -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups/94" -s
		$specgroup = Get-CliqrGroup -Name $group.samaccountname
		#$specgroupobject = $specgroup
		#$users = @()
		#foreach ($i in $specgroupobject.keys) { if ($i -like "users") { $specgroupobject[$i] = @() } }
		
		#foreach ($i in $specgroupobject.keys) { if ($i -like "users") { $specgroupobject.remove($i) } }
		#$specgroupobject.remove("users")
		#$specgroupobject.add("users", @())
		#$object = $specgroupobject | ConvertTo-Json -Compress
		$specgroup.remove("users")
		$specgroup.add("users", @())
		#$object = $specgroup | ConvertTo-Json -Compress
		#$object
		
		
		[void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")
		$jsonserial1 = New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer
		$jsonserial1.MaxJsonLength = 500000000
		$object = $jsonserial1.Serialize($specgroup)
		#$object
		
		#Convert any blank arrays using [] or Cliqr won't accept them
		$object = $object -replace 'perms":""', 'perms":[]'
		#Send the file in ascii format
		$object | out-file c:\tmp\filename.json -Encoding ascii
		#Modify the group via Cliqr API
		$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
		$url = "10.155.5.112"
		curl.exe -k -X PUT -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/tenants/1/groups/$($specgroup.id)" -d "@c:\tmp\filename.json" -s
		Add-Log -Message "Removal complete"
	}
	else
	{
		Add-Log -Message "No group mismatch detected for $($group.samaccountname)"
	}
}

#endregion
