﻿$a = ls
$array = @()
foreach ($i in $a)
{
    $array += import-csv $i.FullName
}

foreach ($i in $array)
{
    $d = [datetime]$i.date
    $i | add-member -MemberType NoteProperty -name sorttime -Value $d -Force
}

$finalarray = foreach ($name in $uniquename) {($array | where {$_."user name" -eq $name."user name"} | sort sorttime -Descending)[0] }