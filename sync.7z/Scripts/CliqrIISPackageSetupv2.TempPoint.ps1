﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/26/2016 1:24 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   	CliqrIISPackageSetup.ps1  	
	===========================================================================
	.DESCRIPTION
		IIS Setup Script.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\CliqrIISPackageSetup.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$server = hostname
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
$reposource = "http://10.155.5.63:8080/"
$whoami = whoami

#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
	Import-Module WebAdministration -ea 'Stop' | Out-Null
	Import-Module NetTCPIP -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

#endregion

#region Main
Add-Log -Type Information -Message "Starting IIS package setup script"
agentSendLogMessage "$(executiontime) - Starting IIS package setup script"
LoadCliqrEnvVariables


#Download Carbon for Service permission change
Start-BitsTransfer -Source http://10.155.5.63:8080/Carbon.dll -destination c:\temp\installed\ -ProxyUsage NoProxy


$packagezips = (ls e:\apps -Filter *.zip).basename
$expandedpackages = @()
foreach ($pkg in $packagezips)
{
	$expandedpackages += (ls E:\apps\ -Recurse -Directory) | where { $_.fullname -like "*$pkg" }
}

#Find Pimco IIS apps from expanded zips
$iisapps = @()
$expandeddirectory = (ls $expandedpackages.parent.fullname -Directory) | sort -Unique
foreach ($pkg in $expandeddirectory)
{
	if ((ls "$($pkg.parent.fullname)\$($pkg.name)" -Directory -Filter "client") -or (ls "$($pkg.parent.fullname)\$($pkg.name)" -Directory -Filter "wcf") -or (ls "$($pkg.parent.fullname)\$($pkg.name)" -Directory -Filter "site"))
	{
		$iisapps += "$($pkg.parent.fullname)\$($pkg.name)"
	}
}

#Find Pimco windows services from expanded zips
$winservices = @()
$expandeddirectory = (ls $expandedpackages -Directory) | sort -Unique
foreach ($pkg in $expandeddirectory)
{
	if ((ls "$($pkg.parent.fullname)\$($pkg.name)" -Directory -Filter "service"))
	{
		$winservices += "$($pkg.parent.fullname)\$($pkg.name)"
	}
}

#Build out the inetpub structure
foreach ($pimcoapp in $iisapps)
{
	if ((Test-Path $pimcoapp\client) -eq $true)
	{
		try
		{
			Add-Log -Type Information -Message "Found Pimco application client $pimcoapp"
			agentSendLogMessage "$(executiontime) - Found Pimco application client $pimcoapp"
			Copy-Item $pimcoapp\client\* e:\inetpub\ -Recurse
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to copy data to inetpub - $($Error[0])"
			agentSendLogMessage "$(executiontime) - Failed to copy data to inetpub"
		}
	}
	
	if ((Test-Path $pimcoapp\wcf) -eq $true)
	{
		try
		{
			Add-Log -Type Information -Message "Found Pimco application wcf $pimcoapp"
			agentSendLogMessage "$(executiontime) - Found Pimco application wcf $pimcoapp"
			Copy-Item $pimcoapp\wcf\* e:\inetpub\ -Recurse
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to copy data to inetpub - $($Error[0])"
			agentSendLogMessage "$(executiontime) - Failed to copy data to inetpub"
		}
	}
	
	if ((Test-Path $pimcoapp\site) -eq $true)
	{
		try
		{
			Add-Log -Type Information -Message "Found Pimco application site $pimcoapp"
			agentSendLogMessage "$(executiontime) - Found Pimco application site $pimcoapp"
			Copy-Item $pimcoapp\site\* e:\inetpub\ -Recurse
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to copy data to inetpub - $($Error[0])"
			agentSendLogMessage "$(executiontime) - Failed to copy data to inetpub"
		}
	}
}

#Build out the windows service structure
foreach ($pimcoservice in $winservices)
{
	if ((Test-Path $pimcoservice\service) -eq $true)
	{
		try
		{
			Add-Log -Type Information -Message "Found Pimco service $pimcoservice"
			agentSendLogMessage "$(executiontime) - Found Pimco service $pimcoservice"
			Copy-Item $pimcoservice\service\* e:\services\ -Recurse
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to copy data to e:\services - $($Error[0])"
			agentSendLogMessage "$(executiontime) - Failed to copy data to e:\services"
		}
	}
}

#stop IIS to prevent locks
iisreset /stop

$structure = ls e:\inetpub -Exclude healthcheck
#$apppools = ls "env:" | where { $_.name -like "site*" }


#Get credentials
Import-Module cyberarkmoduletest
#fix cyberark
function GetCreds
{
	Add-Log -Type 'Information' -Message "Starting credential loop"
	try
	{
		Connect-CyberArk -credentialfileuser "svc_iisadmin" -credentialfile "C:\pimcloud\cliqr-scripts\windows\utils\data\iisadmin.dat" -credentialkey "C:\pimcloud\cliqr-scripts\windows\utils\data\iisadmin.k"
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to get authentication token"
	}
	if ($env:CliqrDepEnvName -eq "prod" -or $env:CliqrDepEnvName -eq "preprod")
	{
		if ($env:prod_svc_acct)
		{
			$script:service_account_fqdn = $env:prod_svc_acct
		}
	}
	else
	{
		if ($env:svc_acct)
		{
			$script:service_account_fqdn = $env:svc_acct
		}
	}
	
	$script:service_account = ($script:service_account_fqdn -split '\\')[-1]
	try
	{
		$accountid = (Get-CyberArkAccount -Accountname $script:service_account_fqdn -Safe "PIMCO_TechInfra").id
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to query account from cyberark"
	}
	
	if ($accountid)
	{
		try
		{
			$script:service_password = Get-CyberArkCredential -Accountid $accountid
		}
		catch
		{
			Add-Log -Type 'Warning' -Message "Failed to pull credentials for $accountid from cyberark"
		}
	}
	else
	{
		Add-Log -Type 'Warning' -Message "Failed to find an account ID for the specified service account: $script:service_account_fqdn"
	}
}

#Get creds loop
$credloop = 0
do { sleep 5; GetCreds; $credloop++; $credloop }
until ($script:service_password -notlike $Null -or $credloop -ge 10)

#prevent account lockout
if ($script:service_password -like $null)
{
	$script:service_account = $null
	$script:service_account_fqdn = $null
}

#create app pools
foreach ($i in $structure.name)
{
	try
	{
		New-WebAppPool -Name $i
		$GetPool = Get-Item "iis:\AppPools\$($i)"
		if ($env:CliqrDepEnvName -eq "prod" -or $env:CliqrDepEnvName -eq "preprod")
		{
			$GetPool.processmodel.username = $env:serviceaccount
			$GetPool.processmodel.Password = $env:serviceaccountpassword -replace "\\\$", "$"
			$GetPool.processmodel.identityType = "SpecificUser"
			$GetPool | Set-Item
			#Restart-WebAppPool -Name $i
		}
		else
		{
			$GetPool.processmodel.username = $env:nonprodserviceaccount
			$GetPool.processmodel.Password = $env:nonprodserviceaccountpassword -replace "\\\$", "$"
			$GetPool.processmodel.identityType = "SpecificUser"
			$GetPool | Set-Item
			#Restart-WebAppPool -Name $i
		}
	}
	catch
	{
		Add-Log -Type Information -Message "Failed to create app pool for $i - $($Error[0])"
		agentSendLogMessage "$(executiontime) - Failed to create app pool for $i"
	}
}

$sites = ($structure | where { $_.name -notlike "*wcf" -and $_.Name -notlike "*api" }).name
$apps = ($structure | where { $_.name -like "*wcf" -or $_.Name -like "*api" }).name

$iisarray = @()

foreach ($site in $sites)
{
	$object = "" | select Name, Parent, Authentication
	$object.name = $site
	$object.parent = "None"
	$object.authentication = $env:iisauthentication
	$iisarray += $object
}

if ($sites -like $null)
{
	$object = "" | select Name, Parent, Authentication
	$object.name = "root"
	$object.parent = "None"
	$object.authentication = $env:iisauthentication
	$iisarray += $object
	mkdir e:\inetpub\root
}

foreach ($app in $apps)
{
	$object = "" | select Name, Parent, Authentication
	$object.name = $app
	$object.parent = ($iisarray | where { $_.parent -like "none" }).name
	#$object.authentication = ($iisarray | where { $_.name -like $sites }).authentication
	$object.authentication = $env:iisauthentication
	$iisarray += $object
}

foreach ($iisobject in $iisarray)
{
	if ($iisobject.parent -eq "none")
	{
		Add-Log -Type Information -Message "Creating root site $($iisobject.name)"
		agentSendLogMessage "$(executiontime) - Creating root site $($iisobject.name)"
		try
		{
			if ($iisobject.name -eq "root")
			{
				New-WebAppPool -Name $iisobject.name
			}
			New-Website -Name $iisobject.name -ApplicationPool $iisobject.name -physicalpath "e:\inetpub\$($iisobject.name)" -HostHeader "*" -Port 80 | Out-Null
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to create root site $($iisobject.name)"
			agentSendLogMessage "$(executiontime) - Failed to create root site $($iisobject.name)"
		}
		try
		{
			#site bindings
			Add-Log -Type Information -Message "Creating bindings"
			agentSendLogMessage "$(executiontime) - Creating bindings"
			#New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-sandbox.core.pimcocloud.net")
			#New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-dev")
			#New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-dev.core.pimcocloud.net")
			#New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-beta")
			#New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-beta.core.pimcocloud.net")
			#New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-prod")
			New-WebBinding $iisobject.name -IPAddress "*" -Port 8703 -HostHeader "*"
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to create bindings"
			agentSendLogMessage "$(executiontime) - Failed to create bindings"
		}
		
		if ($iisobject.authentication -eq "Kerberos")
		{
			try
			{
				#use app pool credentials
				Add-Log -Type Information -Message "Setting app pool to use specified credentials"
				agentSendLogMessage "$(executiontime) - Setting app pool to use specified credentials"
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location $iisobject.name -value true
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to set app pool to use credentials"
				agentSendLogMessage "$(executiontime) - Failed to set app pool to use credentials"
			}
		}
		
		if ($iisobject.authentication -eq "NTLM" -or $iisobject.authentication -eq "Kerberos")
		{
			try
			{
				Add-Log -Type Information -Message "Enabling Windows authentication"
				agentSendLogMessage "$(executiontime) - Enabling Windows authentication"
				#Enable windows auth
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $iisobject.name -value true
				#disable anonymous
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $iisobject.name -value false
				#use app pool credentials
				Add-Log -Type Information -Message "Setting app pool to use specified credentials"
				agentSendLogMessage "$(executiontime) - Setting app pool to use specified credentials"
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location $iisobject.name -value true
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to enable Windows authentication"
				agentSendLogMessage "$(executiontime) - Failed to enable Windows authentication"
			}
		}
		if ($iisobject.authentication -eq "Anonymous")
		{
			try
			{
				Add-Log -Type Information -Message "Enabling Anonymous authentication"
				agentSendLogMessage "$(executiontime) - Enabling Anonymous authentication"
				#Enable windows auth
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $iisobject.name -value false
				#disable anonymous
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $iisobject.name -value true
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to enable Anonymous authentication"
				agentSendLogMessage "$(executiontime) - Failed to enable Anonymous authentication"
			}
		}
	}
	else
	{
		try
		{
			Add-Log -Type Information -Message "Creating vApp $($iisobject.name)"
			agentSendLogMessage "$(executiontime) - Creating vApp $($iisobject.name)"
			New-WebApplication -name $iisobject.name -Site $iisobject.parent -PhysicalPath "e:\inetpub\$($iisobject.name)" -ApplicationPool $iisobject.name -Force
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to create vApp $($iisobject.name)"
			agentSendLogMessage "$(executiontime) - Failed to create vApp $($iisobject.name)"
		}
		
		if ($iisobject.authentication -eq "Kerberos")
		{
			try
			{
				#use app pool credentials
				Add-Log -Type Information -Message "Setting app pool to use specified credentials"
				agentSendLogMessage "$(executiontime) - Setting app pool to use specified credentials"
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location "$($iisobject.parent)/$($iisobject.name)" -value true
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to set app pool to use credentials"
				agentSendLogMessage "$(executiontime) - Failed to set app pool to use credentials"
			}
		}
		
		if ($iisobject.authentication -eq "NTLM" -or $iisobject.authentication -eq "Kerberos")
		{
			try
			{
				Add-Log -Type Information -Message "Enabling Windows authentication"
				agentSendLogMessage "$(executiontime) - Enabling Windows authentication"
				#Enable windows auth
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value true
				#disable anonymous
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value false
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to enable Windows authentication"
				agentSendLogMessage "$(executiontime) - Failed to enable Windows authentication"
			}
		}
		if ($iisobject.authentication -eq "Anonymous")
		{
			try
			{
				Add-Log -Type Information -Message "Enabling Anonymous authentication"
				agentSendLogMessage "$(executiontime) - Enabling Anonymous authentication"
				#Enable windows auth
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value false
				#disable anonymous
				Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value true
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to enable Anonymous authentication"
				agentSendLogMessage "$(executiontime) - Failed to enable Anonymous authentication"
			}
		}
	}
}

#Register any windows services
$directories = ls e:\services -Directory
foreach ($dir in $directories)
{
	foreach ($exe in (ls $dir.fullname -filter *.exe))
	{
		C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /servicename=$($dir.name) /i $exe.fullname
	}
}

#change service account
try
{
	$serviceaccount = ($env:serviceaccount -split '\\')[-1]
	([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$serviceaccount") | Out-Null
}
catch
{
	#Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	#agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
}

#grant rights to logon as a service
$Identity = $env:serviceaccount
$privilege = "SeServiceLogonRight"
$CarbonDllPath = "C:\temp\installed\Carbon.dll"
[Reflection.Assembly]::LoadFile($CarbonDllPath)
[Carbon.Lsa]::GrantPrivileges($Identity, $privilege)

#Change service account on windows services
$Service = gwmi win32_service | where { $_.pathname -like ('"' + $exe.fullname + '"') }
$Service.Change($Null, $Null, $Null, $Null, $Null, $Null, $env:serviceaccount, $env:serviceaccountpassword, $Null, $Null, $Null)
#$Service.StartService()

#add healthcheck site
$ipaddress = (Get-NetIPAddress -AddressFamily ipv4 -InterfaceAlias "ethernet*").ipaddress
mkdir e:\inetpub\healthcheck
Start-BitsTransfer -Source http://10.155.5.63:8080/probe.htm -destination e:\inetpub\healthcheck -ProxyUsage NoProxy
New-WebAppPool -Name healthcheck
New-Website -Name healthcheck -ApplicationPool healthcheck -physicalpath "e:\inetpub\healthcheck" -HostHeader $ipaddress -Port 8701 | Out-Null
#New-WebBinding healthcheck -IPAddress $ipaddress -Port 8700 -HostHeader $ipaddress

#add HTTP response headers
$Hostname = hostname
C:\windows\System32\inetsrv\appcmd.exe set config -section:system.webServer/httpProtocol /-"customHeaders.[name='X-ServerName']"
C:\windows\System32\inetsrv\appcmd.exe set config -section:system.webServer/httpProtocol /+"customHeaders.[name='X-ServerName',value=`'$HostName`']"

#iisreset
iisreset /start

agentSendLogMessage "$(executiontime) - IIS Package setup complete"
Add-Log -Type Information -Message "IIS Package setup complete"
#endregion