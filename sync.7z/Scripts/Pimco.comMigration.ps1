﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	11/14/2016 12:42 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$VMName,
	[Parameter(Mandatory = $true, Position = 1)]
	[string]$ListPath
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\IOMigration-$VMName.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$password = "P@ssword8" | ConvertTo-SecureString -AsPlainText -Force
$guestcredential = New-Object System.Management.Automation.PSCredential "administrator", $password
#$guestcredential = Get-Credential
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	#Import-module ModuleName -ea 'Stop' | Out-Null
	#Add-PSSnapin VMware.VimAutomation.Core | Out-Null
	#Add-PSSnapin VMware.VimAutomation.Vds | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

Function ConnecttoVCenter
{
	Param ($Vcenter, $VCenterCredential)
	
	if ($Vcenter)
	{
		if ($defaultviservers)
		{
			Disconnect-VIServer * -Confirm:$false
			Connect-VIServer $vcenter -Credential $VCenterCredential
		}
		else
		{
			Connect-VIServer $vcenter -Credential $VCenterCredential
		}
	}
	else
	{
		Write-Warning "No VCenter specified!"
		exit
	}
}

function ShutdownVMs
{
	foreach ($vm in $script:vminfoarray)
	{
		Write-Host "Shutting down $($vm.vmname)"
		Get-VM -Id $vm.vmid | Shutdown-VMGuest -Confirm:$false -ErrorAction SilentlyContinue #-WhatIf
	}
}

function UnRegisterVMs
{
	if ($script:vminfoarrayoriginalstate)
	{
		foreach ($unregvm in $script:vminfoarrayoriginalstate)
		{
			write-host "Unregistering VM $($vmunreg.name)"
			$vmunreg = Get-View $unregvm.vmid
			$vmunreg.unregistervm()
		}
	}
	else
	{
		Write-Warning "Original state variable is missing"
		exit
	}
}

function Register-VMX
{
	param ($entityName = $null, $dsNames = $null, $template = $false, $ignore = $null, $checkNFS = $false, $whatif = $false)
	
	function Get-Usage
	{
		Write-Host "Parameters incorrect" -ForegroundColor red
		Write-Host "Register-VMX -entityName  -dsNames [,...]"
		Write-Host "entityName   : a cluster-, datacenter or ESX hostname (not together with -dsNames)"
		Write-Host "dsNames      : one or more datastorename names (not together with -entityName)"
		Write-Host "ignore       : names of folders that shouldn't be checked"
		Write-Host "template     : register guests ($false)or templates ($true) - default : $false"
		Write-Host "checkNFS     : include NFS datastores - default : $false"
		Write-Host "whatif       : when $true will only list and not execute - default : $false"
	}
	
	if (($entityName -ne $null -and $dsNames -ne $null) -or ($entityName -eq $null -and $dsNames -eq $null))
	{
		Get-Usage
		break
	}
	
	if ($dsNames -eq $null)
	{
		switch ((Get-Inventory -Name $entityName).GetType().Name.Replace("Wrapper", ""))
		{
			"Cluster"{
				#$dsNames = Get-Cluster -Name $entityName | Get-VMHost | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | % {$_.Name}
				Write-Warning "Option not supported"
				Exit
			}
			"Datacenter"{
				#$dsNames = Get-Datacenter -Name $entityName | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | % {$_.Name}
				Write-Warning "Option not supported"
				Exit
			}
			"VMHost"{
				#$dsNames = Get-VMHost -Name $entityName | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | % {$_.Name}
				Write-Warning "Option not supported"
				Exit
			}
			Default
			{
				Get-Usage
				exit
			}
		}
	}
	else
	{
		$dsNames = Get-Datastore -Name $dsNames | where { $_.Type -eq "VMFS" -or $checkNFS } | Select -Unique | % { $_.Name }
	}
	
	$dsNames = $dsNames | Sort-Object
	$pattern = "*.vmx"
	if ($template)
	{
		$pattern = "*.vmtx"
	}
	
	foreach ($dsName in $dsNames)
	{
		Write-Host "Checking: " -NoNewline; Write-Host -ForegroundColor yellow $dsname
		$ds = Get-Datastore $dsName | Select -Unique | Get-View
		$dsBrowser = Get-View $ds.Browser
		$dc = Get-View $ds.Parent
		while ($dc.MoRef.Type -ne "Datacenter")
		{
			$dc = Get-View $dc.Parent
		}
		$tgtfolder = Get-View $dc.VmFolder
		$esx = Get-View $ds.Host[0].Key
		$pool = Get-View (Get-View $esx.Parent).ResourcePool
		
		$vms = @()
		foreach ($vmImpl in $ds.Vm)
		{
			$vm = Get-View $vmImpl
			$vms += $vm.Config.Files.VmPathName
		}
		$datastorepath = "[" + $ds.Name + "]"
		
		$searchspec = New-Object VMware.Vim.HostDatastoreBrowserSearchSpec
		$searchspec.MatchPattern = $pattern
		
		$taskMoRef = $dsBrowser.SearchDatastoreSubFolders_Task($datastorePath, $searchSpec)
		
		$task = Get-View $taskMoRef
		while ("running", "queued" -contains $task.Info.State)
		{
			$task.UpdateViewData("Info.State")
		}
		$task.UpdateViewData("Info.Result")
		foreach ($folder in $task.Info.Result)
		{
			if (!($ignore -and (&{ $res = $false; $folder.FolderPath.Split("]")[1].Trim(" /").Split("/") | %{ $res = $res -or ($ignore -contains $_) }; $res })))
			{
				$found = $FALSE
				if ($folder.file -ne $null)
				{
					foreach ($vmx in $vms)
					{
						if (($folder.FolderPath + $folder.File[0].Path) -eq $vmx)
						{
							$found = $TRUE
						}
					}
					if (-not $found)
					{
						if ($folder.FolderPath[-1] -ne "/") { $folder.FolderPath += "/" }
						$vmx = $folder.FolderPath + $folder.File[0].Path
						if ($template)
						{
							$params = @($vmx, $null, $true, $null, $esx.MoRef)
						}
						else
						{
							$params = @($vmx, $null, $false, $pool.MoRef, $null)
						}
						if (!$whatif)
						{
							if ($folder.folderpath -like "*snapshot*")
							{
								if ($($folder.file[0]).path -eq ($VMName + ".vmx"))
								{
									#Write-Host "Bypassing $($folder.file[0].Path) because it's in the snapshot directory"
								}
								else
								{
									#Write-Host "`t" $vmx "not found"
								}
							}
							else
							{
								if ($($folder.file[0]).path -eq ($VMName + ".vmx"))
								{
									$taskMoRef = $tgtfolder.GetType().GetMethod("RegisterVM_Task").Invoke($tgtfolder, $params)
									Write-Host "`t" $vmx "registered" -ForegroundColor 'Green'
								}
								else
								{
									#Write-Host "`t" $vmx "not found"
								}
							}
						}
						else
						{
							if ($folder.folderpath -like "*snapshot*")
							{
								if ($($folder.file[0]).path -eq ($VMName + ".vmx"))
								{
									#Write-Host "Bypassing $($folder.file[0].Path) because it's in the snapshot directory"
								}
								else
								{
									#Write-Host "`t" $vmx "not found"
								}
							}
							else
							{
								if ($($folder.file[0]).path -eq ($VMName + ".vmx"))
								{
									Write-Host "`t" $vmx "registered" -NoNewline -ForegroundColor 'Green'; Write-Host " ==> What If" -ForegroundColor 'Green'
								}
								else
								{
									#Write-Host "`t" $vmx "not found"
								}
							}
						}
					}
				}
			}
		}
		Write-Host "The specified VM has been registered or was not found, check logs for details"
	}
}

function registerVM
{
	#get all clusters
	$clusters = get-view -ViewType clustercomputeresource
	
	#get the non mgmt cluster
	$script:cluster = $clusters | where { $_.name -notlike "*mgmt*" }
	
	#Exclude local datastores
	$script:datastores = (get-view $script:cluster.datastore) | where { $_.summary.multiplehostaccess -eq $true }
	foreach ($datastore in $script:datastores)
	{
		Register-VMX -dsNames $datastore.name -checkNFS:$true #-whatif:$true
	}
}

function powerVMbackon
{
	#Trigger the question?
	$script:VM | Start-VM -ea 'SilentlyContinue'
	
	try
	{
		$movedit = ($script:VM | Get-VMQuestion).options[1]
		$script:VM | Get-VMQuestion | Set-VMQuestion -Option $movedit -confirm:$false
	}
	catch
	{
		Write-Warning "Failed to answer VM question - this can be ignored"
	}
	
	$script:VM | Start-VM -ea 'SilentlyContinue'
	Write-Host "Waiting 5min for VMware tools to start"
	Wait-Tools -VM $script:VM -TimeoutSeconds 300 -ea 'SilentlyContinue'
	Write-Host "Done"
}

function SelectNIC
{
	Param ($VM)
	$script:nics = gwmi win32_networkadapter -computer $VM | where { $_.adaptertype -like "ethernet 802.3" }
	$script:selected = $script:nics | where { $_.servicename -like "e1000" -or $_.name -like "Vmware*" }
	$script:localarea = $script:selected.netconnectionID
}

function SetNetwork2008
{
	$script = "
	switch ($($script:selectedVM.subnet))
	{
	'27' {`$SubnetMask = '255.255.255.224'}
	'26' {`$SubnetMask = '255.255.255.192'}
	'25' {`$SubnetMask = '255.255.255.128'}
	'24' {`$SubnetMask = '255.255.255.0'}
	}
	
	`$adapter = (gwmi win32_networkadapter | where {`$_.netconnectionid -notlike '' -and `$_.name -notlike 'sonic*'}).netconnectionid
	`$IPAddress = $($script:selectedVM.ip)
	`$Gateway = $($script:selectedVM.gateway)
	#`$SubnetMask = $($script:selectedVM.subnet)
	#`$SubnetMask = '255.255.255.192'
	
	write-host '-----------------------'
	Write-host 'Setting the following:'
	Write-host 'Adapter: ' `$Adapter
	Write-host 'IP(s): ' `$IPAddress
	Write-host 'Subnetmask: ' `$SubnetMask
	Write-host 'Gateway: ' `$Gateway
	write-host '-----------------------'
	c:

	`$testformultipleips = if (`$IPAddress -like '*,*') {`$true}

	if (`$testformultipleips -eq `$true)
	{
		`$IPAddressarray = `$IPAddress -split ', '
		`$numberofIPs = `$IPAddressarray.count
		netsh interface ipv4 set address `$adapter static `$IPaddressarray[0] `$subnetMask `$Gateway 1
		for (`$x=1; `$x -lt `$numberofIPs; `$x++) 
		{
			netsh interface ipv4 add address `$adapter `$ipaddressarray[`$x] `$subnetmask
		}
	}
	else
	{
		netsh interface ipv4 set address `$adapter static `$IPaddress `$subnetMask `$Gateway 1
	}
	netsh interface ipv4 set dnsservers `$adapter static '10.208.20.13'
	netsh interface ipv4 add dnsservers `$adapter 10.208.20.14 index=1
	netsh interface ipv4 add dnsservers `$adapter 10.208.50.13 index=2
	netsh interface ipv4 add dnsservers `$adapter 10.208.50.14 index=3
	
	gwmi win32_networkadapterconfiguration | Invoke-WMIMethod -Name SetDNSDomain -Argumentlist 'us1.1corp.org'
	ipconfig /registerdns
	"
	
	$script
	Invoke-VMScript -ScriptText $script -VM $script:VM -GuestCredential $guestcredential -ScriptType Powershell
	
	
	#netsh interface 6to4 set state disabled
	
	#$AdapterNetworkSettings = "[wmiclass] win32_networkadapterconfiguration"
	#$array = ((import-csv C:\$vm-networkinfo.csv).dnsdomainsuffixsearchorder)
	#$AdapterNetworkSettings.SetDNSSuffixSearchOrder($array)
	
	#Get-WMIObject Win32_NetworkAdapterConfiguration | Invoke-WmiMethod -name SetDNSDomain -Argumentlist 'us1.1corp.org'
	
	#Invoke-VMScript -ScriptText $script -VM $script:VM -GuestCredential $guestcredential -ScriptType Powershell
}

function reattachRAW
{
	$rawidentifiers = import-csv c:\sanmigration\$cluster-rawmappings.csv | where { $_.rawmappedto -notlike $null }
	foreach ($hostsystem in $script:selectedcluster.host[0])
	{
		$lunhost = Get-VMHost -id $hostsystem
		foreach ($rawdev in $rawidentifiers)
		{
			$vm = $rawdev.rawmappedto
			$identifier = $rawdev.identifier
			$lun = $rawdev.lun
			#$disktype = $rawdev.disktype
			$disktype = "RawVirtual"
			Write-host "Mapping lun $lun with identifier $identifier to $vm"
			$deviceName = ($lunhost | Get-ScsiLun | Where { $_.CanonicalName -eq $identifier }).ConsoleDeviceName
			New-HardDisk -VM $vm -DiskType $disktype -DeviceName $deviceName #-whatif
		}
	}
}

function removeRAWs
{
	if ($script:selectedcluster)
	{
		foreach ($hostsystem in $selectedcluster.host)
		{
			$vmsonhost = (Get-View $hostsystem).vm
			foreach ($vm in $vmsonhost)
			{
				$vmstat = Get-View $vm
				$RawVirtualdisks = get-vm -id $vmstat.moref | get-harddisk -DiskType RawVirtual
				$RawPhysicaldisks = get-vm -id $vmstat.moref | get-harddisk -DiskType RawPhysical
				if ($RawVirtualDisks)
				{
					foreach ($disk in $RawVirtualdisks)
					{
						write-host "Removing RawVirtual disk $($disk.name) from VM $($disk.parent)"
						$disk | Remove-harddisk #-whatif
					}
				}
				if ($RawPhysicalDisks)
				{
					foreach ($disk in $RawPhysicaldisks)
					{
						write-host "Removing RawPhysical disk $($disk.name) from VM $($disk.parent)"
						$disk | Remove-harddisk #-whatif
					}
				}
			}
		}
	}
	else
	{
		Write-Warning "Selected cluster not found"
		exit
	}
}

function GetVM
{
	param ($vmname)
	try
	{
		$script:VM = Get-VM -Name $vmname -ea 'Stop'
	}
	catch
	{
		Add-Log -Message "Failed to find VM - exiting" -Type 'Error' -Throw
	}
}

function ReadList
{
	try
	{
		$script:selectedVM = Import-Csv $listpath -ea 'Stop' | where { $_.name -eq $VMName } -ea 'Stop'
		if ((($script:selectedVM.name).count) -gt 1 -or (($script:selectedVM.name).count) -eq 0)
		{
			throw "count mismatch"
		}
	}
	catch
	{
		Write-Warning "Failed to find $VMName from the list"
	}
}

function UpdateVMVersion
{
	try
	{
		Set-VM -VM $VMName -Version v11 -Confirm:$false -ea 'Stop'
	}
	catch
	{
		Write-Warning "Failed to update VM to version 11"	
	}
}

function AddNic
{
	param ($portgroup)
	try
	{
		$pg = Get-VDPortgroup -Name $portgroup -ea 'Stop'
		$script:VM | New-NetworkAdapter -Type vmxnet3 -Portgroup $pg -StartConnected -Confirm:$false -ea 'Stop'
	}
	catch
	{
		Write-Warning "Failed to add vnic"
	}
}

function ExecuteChangeIPScript
{
	$script = '"%programfiles%\Common Files\Microsoft Shared\MSInfo\msinfo32.exe" /report "%tmp%\inforeport"'
	Invoke-VMScript -ScriptText $script -VM $script:VM -GuestCredential $guestcredential -ScriptType Powershell
	
}

function SetNetwork2012
{
	$script = "
	`$adapter = (Get-NetAdapter).interfacealias
	`$IPAddress = $($script:selectedVM.ip)
	`$Gateway = $($script:selectedVM.gateway)
	`$SubnetMask = $($script:selectedVM.subnet)
	Remove-NetIPAddress -InterfaceAlias `$adapter -confirm:`$false
	New-NetIPAddress -InterfaceAlias `$adapter -AddressFamily IPv4 -IPAddress `$IPAddress -PrefixLength `$SubnetMask -DefaultGateway `$gateway
	Set-DnsClientServerAddress -InterfaceAlias `$adapter -ServerAddresses (`"10.208.20.13`",`"10.208.20.14`",`"10.208.50.13`",`"10.208.50.14`")
	Set-DNSClient -InterfaceAlias `$adapter -ConnectionSpecificSuffix `"us1.1corp.org`"
	#Set-DnsClientGlobalSetting -SuffixSearchList $Suffix
	ipconfig /registerDNS
	"
	$script
	#Delete default route?
	#route delete 0.0.0.0
	Invoke-VMScript -ScriptText $script -VM $script:VM -GuestCredential $guestcredential -ScriptType Powershell
}

function GetOS
{
	$invoke = Invoke-VMScript -ScriptText "(gwmi win32_operatingsystem).caption" -VM $script:VM -GuestCredential $guestcredential -ScriptType Powershell
	$vmresult = $invoke.tostring()
	$script:OS = $vmresult.trim("")
}

function RestartGuest
{
	$script:VM | Restart-VMGuest -ea 'Stop'
	
}

function UpdateVmwareTools
{
	Write-Host "Forcing auto update of VMware tools"
	try
	{
		Update-Tools -VM $script:vm
	}
	catch
	{
		Write-Warning "Failed to update VMware tools"
	}
}

function AddUsers
{
	Invoke-VMScript -ScriptText "([ADSI]"WinNT://localhost/Administrators, group").Add("WinNT://pimco.imswest.sscims.com/iis-admin") | Out-Null " -VM $VM -GuestCredential $guestcredential -ScriptType Powershell
}
#endregion

#region Main

#Verify App shutdown?

#Connect to VCenter
ConnecttoVCenter -Vcenter 10.155.142.8 -VCenterCredential (Get-Credential)
#AGI Vcenter
#ConnecttoVCenter -Vcenter 10.155.142.8 -VCenterCredential Get-Credential

#region AGI Steps
#Lookup VM in parameter
#GetVM -vmname $VMName

#Check has a physical RAW device - Nope everything is virtual

#shutdown VM?

#If Physical shutdown and re-attach as virtual

#Vmotion or Clone to NFS datastore USE TOP BOX (gui) TO CHANGE RAW DISK TO VIRTUAL

#Unregister VM
#endregion

#Read the VM info from the spreadsheet
ReadList

#Clean up the variables so they work
$script:selectedVM.ip = "`"$($script:selectedvm.ip)`""
$script:selectedVM.gateway = "`"$($script:selectedvm.gateway)`""
$script:selectedVM.subnet = $($script:selectedvm.subnet).trimstart("/")
$script:selectedVM.subnet = "`"$($script:selectedvm.subnet)`""
$script:selectedVM

#Reregister VM
RegisterVM

sleep 5

#Get VM as an object
GetVM $vmname

$script:VM

#Update VM hardware type
UpdateVMVersion

#Add network adapter
#AddNic -portgroup "pimcloud-nj-production|Production|Production"
AddNic -portgroup $($script:selectedVM.pg)

#Power on and wait for vmware tools to be up
powerVMbackon

#Pause to make sure everything is gravy
Read-Host "Check VM - press enter when VM tools is running (it might auto update)"

#Update VMware tools
UpdateVmwareTools

Write-Host "Waiting for VMware tools to start back up"
Wait-Tools -VM $script:VM -TimeoutSeconds 300 -ea 'SilentlyContinue'
Write-Host "Done"

#Pause to make sure everything is gravy
Read-Host "Check VM - press enter when VM tools is running (tools update should be complete)"

#Determine OS
GetOS

#Change IP address
Write-Host "Setting IP(s)"
if ($script:OS -like "*Windows Server 2012*")
{ SetNetwork2012 }
if ($script:OS -like "*Windows Server 2008*")
{ SetNetwork2008 }
Write-Host "Done"

#reboot for new drivers?
Write-Host "Doing one last reboot"
RestartGuest
Wait-Tools -VM $script:VM -TimeoutSeconds 300 -ea 'SilentlyContinue'
Write-Host "Done"

#add user to admin

#App owner verify

#endregion