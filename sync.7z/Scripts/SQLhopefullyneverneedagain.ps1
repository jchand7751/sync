﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/2/2013 11:34 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================


 $b = $array | where {$_.sqltest -eq "True"}
 foreach ($i in $b)
    {
    $object = "" | select name, sqltest       
    $testforsql = get-service -comp $i.name | where {$_.name -like "MSSQL$*"}       
    $object.name = $i.name
    if ($testforsql)
        {
        $object.sqltest = $testforsql.displayname
        }
        else
            {
            $object.sqltest = "False"
            }
        $object
        $array1 += $object       
        }
        
 $b = $array | where {$_.sqltest -eq "True"}
 foreach ($i in $b)
    {
    $object = "" | select name, sqltest       
    $testforsql = get-service -comp $i | where {$_.name -eq "MSSQLSERVER"}       
    $object.name = $i
    if ($testforsql)
        {
        $object.sqltest = $testforsql.displayname
        }
        else
            {
            $object.sqltest = "False"
            }
        $object
        $array3 += $object       
        }       