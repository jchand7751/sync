﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/12/2017 9:36 AM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
foreach ($computer in $b)
{
	Invoke-Command $computer {
		$services = Get-Service "*dask*"
		foreach ($i in $services)
		{
			cmd /c sc sdset "$($i.name)"  "D:(A;; CCLCSWRPWPDTLOCRRC;;; SY)(A;; CCDCLCSWRPWPDTLOCRSDRCWDWO;;; BA)(A;; CCLCSWLOCRRC;;; IU)(A;; CCLCSWLOCRRC;;; SU)(A;; CCDCLCSWRPWPDTLOCRSDRCWDWO;;; RD)S:(AU; FA; CCDCLCSWRPWPDTLOCRSDRCWDWO;;; WD)"
		}
	}
}