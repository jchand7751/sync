﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/14/2017 10:31 AM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

function Connect-CyberArk
{
	param ($environment)
	try
	{
		#$request = curl.exe -H "Accept: application/json" -H "Content-Type:application/json" https://exv035tw-cpma1/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -d "@jsonpw" -s
		$credential = Get-Credential
		#$expression = "curl.exe -H `"Accept: application/json`" -H `"Content-Type:application`/json`" https://10.155.60.21/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -s -d --% `"`{`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`"`}`""
		$expression = "c:\temp\curl.exe -H `"Accept: application/json`" -H `"Content-Type:application`/json`" https://10.155.60.21/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -i -k -s -d --% `"`{`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`"`}`""
		
		$Request = Invoke-Expression $expression
		if ($request[0] -ne "HTTP/1.1 200 OK")
		{ throw "Failed to query Cyberark" }
		else
		{
		}
	}
	catch
	{
		Write-Warning "Caught Exception"
	}
	$script:Authcode = ($Request[-1] | convertfrom-json).CyberArkLogonResult
}

function Lookup-CyberArkAccount
{
	param ($Accountname, $safe)
	
	$request = c:\temp\curl.exe -H "Accept:application/json" -H "Authorization: $script:Authcode" https://10.155.60.21/PasswordVault/WebServices/PIMServices.svc/Accounts?keywords=$accountname`&safe=PIMCO_TechInfra -k -s -i
	#$request[-1]
	if ($request[0] -ne "HTTP/1.1 200 OK")
	{
		$request[1]
		throw "Failed to query Cyberark"
	}
	else
	{
		#$request
		if (($request[-1] | convertfrom-json).count -ne 0)
		{
			$result = ($Request[-1] | convertfrom-json).accounts.properties
			$object = "" | select ID, Safe, Folder, Name, UserName, PolicyID, LogonDomain, Address, DeviceType
			$object.ID = ($request[-1] | ConvertFrom-Json).accounts.accountid
			$object.Safe = $result[0].value
			$object.Folder = $result[1].value
			$object.Name = $result[2].value
			$object.UserName = $result[3].value
			$object.PolicyID = $result[4].value
			$object.LogonDomain = $result[5].value
			$object.Address = $result[6].value
			$object.DeviceType = $result[7].value
			$object
		}
		else
		{
			Write-Warning "Could not find an account matching $Accountname"
		}
	}
}

function Get-CyberArkCredential
{
	param ($Accountid)
	
	$request = c:\temp\Curl.exe -H "Accept:application/json" -H "Authorization: $script:Authcode" https://10.155.60.21/PasswordVault/WebServices/PIMServices.svc/Accounts/$accountid/Credentials -k -s -i
	if ($request[0] -ne "HTTP/1.1 200 OK")
	{ throw "Failed to query Cyberark" }
	else
	{
		#$result = ($Request | convertfrom-json).CyberArkLogonResult
		$result = $request[-1]
		$result
	}
}
