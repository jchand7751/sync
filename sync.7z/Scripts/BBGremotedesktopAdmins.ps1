﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   8/27/2013 11:49 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
function getadminusers
{
	Param ($computer)
	$testcon = Test-Connection $computer -Quiet -Count 1
	$script:array = @()
	if ($testcon)
	{
		$LocalAdmin = ([ADSI]"WinNT://$Computer/Administrators")
		$UserNames = @($LocalAdmin.psbase.Invoke("Members"))
		$UserList = $Usernames | foreach { $_.gettype().invokemember("Name", 'GetProperty', $null, $_, $null) }
		$parentlist = $UserNames | foreach { $_.gettype().invokemember("parent", 'GetProperty', $null, $_, $null) }
		for ($x = 0; $x -lt ($UserList.count); $x++)
		{
			$object = "" | select Computer, User
			$object.computer = $computer
			$object.user = ((($parentlist[$x] -replace "WinNT://") -replace "IMSWEST/") -replace "PIMCO/") + "\" + $UserList[$x]
			#$object
			$script:array += $object
		}
	}
	else
	{
		$object = "" | select Computer, User
		$object.user = "Offline"
		$object.computer = $computer
		#$object
		$script:array += $object
	}
	$script:array | select *

}

function getRDPusers
{
	Param ($computer)
	$testcon = Test-Connection $computer -Quiet -Count 1
	$script:array = @()
	if ($testcon)
	{
		$LocalAdmin = ([ADSI]"WinNT://$Computer/Remote Desktop Users")
		$UserNames = @($LocalAdmin.psbase.Invoke("Members"))
		$UserList = $Usernames | foreach { $_.gettype().invokemember("Name", 'GetProperty', $null, $_, $null) }
		$parentlist = $UserNames | foreach { $_.gettype().invokemember("parent", 'GetProperty', $null, $_, $null) }
		if ($UserList.count -ge 2)
		{
			for ($x = 0; $x -lt ($UserList.count); $x++)
			{
				$object = "" | select Computer, User
				$object.computer = $computer
				$object.user = ((($parentlist[$x] -replace "WinNT://") -replace "IMSWEST/") -replace "PIMCO/") + "\" + $UserList[$x]
				#$object
				$script:array += $object
			}
		}
		else
		{
			$object = "" | select Computer, User
			$object.computer = $computer
			$object.user = ((($parentlist -replace "WinNT://") -replace "IMSWEST/") -replace "PIMCO/") + "\" + $UserList
			#$object
			$script:array += $object
		}
	}
	else
	{
		$object = "" | select Computer, User
		$object.user = "Offline"
		$object.computer = $computer
		#$object
		$script:array += $object
	}
	$script:array | select *

}

$bbgarray = @()
foreach ($i in $a)
{
	$object = "" | select Computer, User, RDPAccess, AdminAccess, Status
	$object.computer = $i.computername
	$object.user = $i.username
	if (Test-Connection -ComputerName $i.computername -Quiet -Count 1)
	{
		$object.status = "Online"
	}
	else
	{
		$object.status = "Offline"
		$object.RDPaccess = "N/A"
		$object.Adminaccess = "N/A"
		$bbgarray += $object
		$object
		continue
	}
	#Write-Host "got here"
	if (getrdpusers -computer $i.computername | where { $_.user -eq "pimco\$($i.username)" })
	{
		$object.RDPaccess = "True"
	}
	else
	{
		$object.RDPaccess = "False"
	}
	
	if (getadminusers -computer $i.computername | where { $_.user -eq "pimco\$($i.username)" })
	{
		$object.Adminaccess = "True"
	}
	else
	{
		$object.Adminaccess = "False"
	}
	$object
	$bbgarray += $object
}