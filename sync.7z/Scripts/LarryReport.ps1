﻿#$a = get-content "h:\private\appsense\smarts-20141216v2.txt"
$a = get-content "c:\temp\smartusers.txt"
$array = @()
foreach ($i in $a) 
{
    $objectblah = "" | select LoginName, DateAccess, Program
    $objectblah.LoginName = $i.split("")[0]
    $objectblah.DateAccess = ($i.split("") | where {$_ -notlike ""})[3]
    $objectblah.Program = ($i.split("") | where {$_ -notlike ""})[4]

    $object = "" | select LoginID, LastName, FirstName, Title, Department, Manager, Office, DateAccess, Program
    $testforuser = get-qaduser -samaccountname $objectblah.loginname
    if ($testforuser)
    {
       $object.LastName = $testforuser.lastname
       $object.FirstName = $testforuser.firstname
       $object.LoginID = $testforuser.samaccountname
       $object.Title = $testforuser.title
       $object.Department = $testforuser.department
       $object.Office = $testforuser.city
       $object.DateAccess = $objectblah.DateAccess
       $object.Program = $objectblah.program

       try
       {
            $TestManager = (get-qaduser ($testforuser.manager)).name
            $object.Manager = $TestManager
       }
       Catch
       {
        $object.Manager = "Manager not found"
       }
       $array += $object
    }
    else
    {
        $object.LastName = "User not found"
        $object.FirstName = "User not found"
        $object.LoginID = $objectblah.loginname
        $object.Title = "User not found"
        $object.Department = "User not found"
        $object.Office = "User not found"
        $object.DateAccess = "User not found"
        $object.Program = "User not found"
        $array += $object
    }
    $object
}
$array | export-csv c:\temp\larryreport1.csv