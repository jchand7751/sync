﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/2/2015 6:07 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#Run Chef deprovision to get password and remove node from Chef
chef-client -r "recipe[pimco-windows-deprovision]"

$hostname = hostname

$User = "core\svc_adaccess"
#From Chef
$PasswordFile = "C:\temp\remoteFiles\cleanupScript\Password.txt"
$KeyFile = "C:\temp\remoteFiles\cleanupScript\AES.key"
$key = Get-Content $KeyFile
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, (Get-Content $PasswordFile | ConvertTo-SecureString -Key $key)

$password = "#{pwd}" | ConvertTo-SecureString -AsPlainText -Force;
$credential = New-Object System.Management.Automation.PSCredential "#{account}", $password;


$searcher = [adsisearcher][adsi]"DC=core,DC=pimcocloud,DC=net"

#Create $oldcomp however you like then use it as input for the ADSI searcher

$searcher.filter = "(cn=$oldcomp)"

#Search Active Directory for the current location of the computer object

$searchparm = $searcher.FindOne()

#Assign $deleteoldcomp to the found path

$deleteoldcomp = $searchparm.path

#Assign the ADSI object to a variable

$delcomp = [adsi]("$deleteoldcomp")

try { $delcomp.deletetree() }
catch { }