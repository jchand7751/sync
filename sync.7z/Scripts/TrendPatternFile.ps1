﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	8/6/2015 11:02 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
$count = $comps.count
$array = @()
do
{
	$number = Get-Random $count
	try
	{
		$array += (get-item "\\$($comps[$number].name)\c$\Program Files (x86)\Trend Micro\OfficeScan Client\BF.ptn" -ea Stop) | select name, lastwritetime
	}
	catch
	{
		$x--
	}
	$x++
}
until
(
	$x -ge 40	
)



$comps = Get-QADComputer -OSName "Windows 7*" -SizeLimit 0
#$comps = $comps | where { $_.name -like "NB-*" }
$array = @()
$x = 0
$limit = $comps.count 
foreach ($i in $comps)
{
	$x++
	Write-Host "$x of $limit"
	Write-Host "Trying host $($i.name)"
	$object = "" | select PC, File, LastWriteTime
	if (Test-Connection $i.name -Count 1 -Quiet)
	{
		try
		{
			$result = (get-item "\\$($i.name)\c$\Program Files (x86)\Trend Micro\OfficeScan Client\BF.ptn" -ea Stop)
			$object.PC = ($result.fullname -split ("\\"))[2]
			$object.file = $result.name
			$object.lastwritetime = $result.lastwritetime
			$object
			$array += $object
		}
		catch
		{
		}
	}
}
