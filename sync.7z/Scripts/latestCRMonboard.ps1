﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/16/2017 2:12 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
<#
CRM + Yammer user
O365-E3-Yammer
O365-E3-ProPlus
O365-E3-Sharepoint Online
O365-CRM Online
VPN-O365-CRM

Yammer user
O365-E3-Yammer
O365-E3-ProPlus
VPN-Email-ADFS

ProPlus User (No CRM, No Yammer)
O365-E3-ProPlus
VPN-Email-ADFS

CRM only
O365-E3-ProPLus
O365-E3-Sharepoint Online
O365-CRM Online
VPN-O365-CRM
#>

#Add-PSSnapin Quest.ActiveRoles.ADManagement
$users = Import-Csv c:\tmp\crm\crmonboardfinal2.csv
foreach ($i in $users)
{
	$user = $null
	if ($i.CRMUSER -eq "True")
	{
		$usertype = "CRM User"
	}
	
	if ($i.CRMUser -eq "False")
	{
		$usertype = "Business User"
	}
	
	try
	{
		$user = Get-QADUser -SamAccountName $i.samaccountname -ea stop
	}
	catch
	{
		Write-Warning "Can't find $($i.samaccountname)"
	}
	switch ($usertype)
	{
		"CRM User" {
			Write-Host "$($i.samaccountname) is a CRM User"
			$user | Add-qadmemberof -Group "O365-E3-Yammer" | Out-Null
			$user | Add-qadmemberof -Group "O365-E3-ProPlus" | Out-Null
			$user | Add-qadmemberof -Group "O365-E3-Sharepoint Online" | Out-Null
			$user | Add-qadmemberof -Group "O365-Dynamics 365 Enterprise-Dynamics 365" | Out-Null
			$user | Add-qadmemberof -Group "VPN-O365-CRM" | Out-Null
		}
		"Business User" {
			Write-Host "$($i.samaccountname) is a Business user"
			$user | Add-qadmemberof -Group "O365-E3-ProPlus" | Out-Null
			$user | Add-qadmemberof -Group "VPN-Email-ADFS" | Out-Null
		}
	}
}