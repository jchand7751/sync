﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.57
	 Created on:   	6/9/2014 11:25 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$NBPCs = get-qadcomputer -searchroot "OU=Workstations - Regular,OU=AppsenseWorkstations,OU=Windows 7,OU=NB Workstations,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=COM" -SizeLimit 0
$NBtraders = get-qadcomputer -searchroot "OU=Workstations - Traders,OU=AppsenseWorkstations,OU=Windows 7,OU=NB Workstations,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=COM" -SizeLimit 0
$DEPCs = get-qadcomputer -searchroot "OU=Workstations - Regular,OU=AppsenseWorkstations,OU=Windows 7,OU=Computers,OU=Site-DE,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=COM" -SizeLimit 0

#PC array
$array = @()

#Get all NB PCs
foreach ($comp in ($nbpcs | where { $_.name -like "nb*" })) { $object = "" | select PCname, User; $object.pcname = $comp.name; $object.user = (gwmi win32_computersystem -comp $comp.name).username; $object; $array += $object }
foreach ($comp in $nbtraders) { $object = "" | select PCname, User; $object.pcname = $comp.name; $object.user = (gwmi win32_computersystem -comp $comp.name).username; $object; $array += $object }
foreach ($comp in $depcs) { $object = "" | select PCname, User; $object.pcname = $comp.name; $object.user = (gwmi win32_computersystem -comp $comp.name).username; $object; $array += $object }

#Get all flag users
$userarray = get-qadgroup "flagstartup users" | get-qadgroupmember

#Result array for checking flag log file
$array2 = @()

#Result array for matched users with PC name
$array3 = @()

#Get only the PCs that flag users are logged into
foreach ($comp in $array)
{
	#$comp
	foreach ($logonname in $userarray)
	{
		#$logonname.samaccountname
		$comp | where { $_.user -like "pimco\$($logonname.samaccountname)" }
		#write-host "pimco\$($logonname.samaccountname)"}
		$checkmatch = $comp | where { $_.user -like "pimco\($logonname.samaccountname)" }
		If ($checkmatch)
		{
			#$logonname
			$checkmatch
			#$checkmatch += $array3
			$array3 += $checkmatch
		}
	}
	
}

#Check array3 PCs for the flag log file, get it's contents put it in array2
foreach ($comp in $array3)
{
	$object = "" | select PCname, fileexists, content
	
	$pathtest = test-path \\$comp.pcname\c$\temp\flagappstartuptask.txt
	if ($pathtest -eq $true)
	{
		$object.fileexists = "True"
		$content = get-content \\$comp.pcname\c$\temp\flagappstartuptask.txt
		$object.content = $content
		$object
		$array2 += $object
	}
	else
	{
		$object.fileexists = "False"
		$object.content = "N/A"
		$object
		$array2 += $object
	}
}