﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/1/2013 4:42 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param ($ViewObject, $Vcenter)

Add-PSSnapin VMware.VimAutomation.Core | Out-Null
Add-PSSnapin Quest.ActiveRoles.ADManagement | Out-Null

Connect-VIServer $VCenter | Out-Null

$i = Get-View $ViewObject

$script:VMObject = "" | Select Name, Cluster, Description, GuestOS, size, OldestEventinSecurityLog, LastPimcoLogonTime, LastPimcoLogonAccount, Managedby
$script:VMObject.name = $i.name
$script:VMObject.Cluster = (Get-View (Get-View $i.runtime.host).parent).name
$script:VMObject.GuestOS = $i.guest.guestfullname
$disks = Get-HardDisk -VM $i.name -disktype flat
$size = $null
foreach ($d in $disks)
    {
    $size = $size + $d.capacityGB
    }
$script:VMObject.size = [string]$size + " GB"

if ($script:VMObject.guestOS -like "*2003*")
	{
	$events = Get-WinEvent -ComputerName $i.name -LogName 'Security' -FilterXPath 'Event[System[EventID=528] and EventData[Data[@Name="TargetDomainName"]="PIMCO" and Data[@Name="LogonType"]="10"]]' -MaxEvents 1
	$oldevent = Get-WinEvent -ComputerName $i.name -LogName security -Oldest -MaxEvents 1
	if ($oldevent)
		{
		$script:VMObject.OldestEventinSecuritylog = $oldevent.timecreated
		}
	$x = $i.name
	New-Item -Type file c:\Temp\tempfile-$x.txt | Out-Null
	$events.message | Out-File c:\Temp\tempfile-$x.txt -Append
	$cleanevents = Get-Content c:\Temp\tempfile-$x.txt
	Remove-Item c:\Temp\tempfile-$x.txt -force
	$cleanevents = $cleanevents | Select-String "Account Name:"
	$Allcleanevents = $cleanevents[1]
	$tempobject = "" | select TimeCreated, Account
	$tempobject.timecreated = $events.timecreated
	$tempobject.account = ($allcleanevents -replace "Account Name:") -replace '\s+', ''
	}
	else
		{
		$events = Get-WinEvent -ComputerName $i.name -LogName 'Security' -FilterXPath 'Event[System[EventID=4624] and EventData[Data[@Name="TargetDomainName"]="PIMCO" and Data[@Name="LogonType"]="10"]]' -MaxEvents 1
		$oldevent = Get-WinEvent -ComputerName $i.name -LogName security -Oldest -MaxEvents 1
		if ($oldevent)
			{
			$script:VMObject.OldestEventinSecuritylog = $oldevent.timecreated
			}
		$x = $i.name
		New-Item -Type file c:\Temp\tempfile-$x.txt | Out-Null
		$events.message | Out-File c:\Temp\tempfile-$x.txt -Append
		$cleanevents = Get-Content c:\Temp\tempfile-$x.txt
		Remove-Item c:\Temp\tempfile-$x.txt -force
		$cleanevents = $cleanevents | Select-String "Account Name:"
		$Allcleanevents = $cleanevents[1]
		$tempobject = "" | select TimeCreated, Account
		$tempobject.timecreated = $events.timecreated
		$tempobject.account = ($allcleanevents -replace "Account Name:") -replace '\s+', ''
		}	

function ADstats
{
Param ($vmname)
$fqdn = (nslookup $vmname 144.77.70.195 | select-string name) -replace "Name:    "
$name = $fqdn.split(".")[0]
$domainname = $fqdn -replace ($name + ".")
$compstats = "" | select-object name, description, managedby, domain, parentcontainer, OS
connect-qadservice -service 'vms001p4.pimco.imswest.sscims.com:389' | out-null
$ADstats = Get-qadcomputer -name $name
$compstats.name = $name
$compstats.description = if ($ADstats.description) {$ADstats.description} else {"None set"}
$compstats.managedby = if ($ADstats.managedby) {(Get-qaduser $ADstats.managedby).name} else {"None set"}
$compstats.domain = $domainname
$compstats.parentcontainer = $adstats.parentcontainer
$compstats.OS = $adstats.OSName
$compstats		
}	

$ADinfo = ADstats $i.name

$script:VMObject.description = $ADinfo.description
$script:VMObject.managedby = $ADinfo.managedby

#single events

$tp = Test-Connection $i.name
if ($tp)
	{
	if ($script:VMObject.GuestOS -like "*Windows Server*")
		{
		if ($tempobject.timecreated)
			{
			$script:VMObject.LastPimcoLogonTime = $tempobject.timecreated
			$script:VMObject.LastPimcoLogonAccount = $tempobject.account
			}
			else
				{
				$script:VMObject.LastPimcoLogonTime = "No recent logon"
				$script:VMObject.LastPimcoLogonAccount = "No recent logon"
				}
		}
		else
			{
			$script:VMObject.LastPimcoLogonTime = "N/A"
			$script:VMObject.LastPimcoLogonAccount = "N/A"
			}
	}
	else
		{
		$script:VMObject.LastPimcoLogonTime = "Offline"
		$script:VMObject.LastPimcoLogonAccount = "Offline"
		}
$script:VMObject | select *	