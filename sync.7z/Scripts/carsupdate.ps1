﻿function executiontime {get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"}

function logfilesetup
{
    $script:logfile = "C:\temp\CARSUpdate.txt"
    if ((Test-Path $script:logfile) -ne $true)
    {
        New-Item -ItemType file $script:logfile | out-null
    }
}

function checkforcurrentversion
{
    #Check for current version

    Write-Host "Checking for old version"
    Add-Content "$(executiontime) - Checking for old version" -Path $script:logfile
    if (Test-Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\3BCF948E1258340C649A46485FC4853B6FF993FB)
    {
        Write-Host "Found old version registry path"
        Add-Content "$(executiontime) - Found old version registry path" -Path $script:logfile
    }
    else
    {
        write-warning "Old version does not appear to be installed"
        Add-Content "$(executiontime) - Old version does not appear to be installed" -Path $script:logfile

        #Check for new version
        if (Test-Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\C83E9432994079C9FAB9EE96FCE0412066A49D65)
        {
            Write-Host "New version already installed, exiting"
            Add-Content "$(executiontime) - New version already installed, exiting" -Path $script:logfile
            exit
        }
        else
        {
            Write-Host "New version not found, exiting"
            Add-Content "$(executiontime) - New version not found, exiting"
            exit
        }
    }
}

function uninstallcurrentversion
{
    #Uninstall current version
    try
    {
        Write-host "Attempting to uninstall current version"
        Add-Content "$(executiontime) - Attempting to uninstall current version" -Path $script:logfile
        ."c:\Program Files\Common Files\Microsoft Shared\VSTO\10.0\VSTOInstaller.exe" /Uninstall file:///W:/pimprod/client_facing_tech/cars/addins/word_research/bin/Pimco.AM.Research.ResearchRibbon.vsto /silent
    }
    catch
    {
        Write-warning "Error found during old version uninstall"
        Add-Content "$(executiontime) - Error found during old version uninstall" -Path $script:logfile
    }
    $count = 0
    #wait for that to finish
    do 
    {
        $a = get-process -name vstoinstaller -ea silentlycontinue
        write-host "Waiting for vstoinstaller process"
        Add-Content "$(executiontime) - Waiting for vstoinstaller process" -Path $script:logfile
        sleep 1
        $count++
    } 
    until 
    (
        $a -eq $null -or $count -ge 30
    )
}

function verifyuninstall
{
    #Make sure the uninstall worked
    if (Test-Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\3BCF948E1258340C649A46485FC4853B6FF993FB)
    {
        write-warning "Uninstall of old version failed"
        Add-Content "$(executiontime) - Uninstall of old version failed" -Path $script:logfile
        exit
    }
    else
    {
        Add-Content "$(executiontime) - Uninstall of old version succeeded" -Path $script:logfile
    }
}

function dllcachecleanup
{
    #dll cache cleanup thing
    rundll32 dfshim CleanOnlineAppCache
    #let it do whatever its going to do
    sleep 10
}

function installnewversion
{
    Write-host "Starting new version install"
    Add-Content "$(executiontime) - Starting new version install" -Path $script:logfile
    #Install the new version
    ."c:\Program Files\Common Files\Microsoft Shared\VSTO\10.0\VSTOInstaller.exe" /install file:///W:/pimdev/client_facing_tech/am/cars/crs_word/bin/Pimco.AM.Research.ResearchRibbon.vsto /s
    $count = 0
    #Let the install finish
    do 
    {
        $a = get-process -name vstoinstaller -ea silentlycontinue
        write-host "Waiting for vstoinstaller process"
        Add-Content "$(executiontime) - Waiting for vstoinstaller process" -Path $script:logfile
        sleep 1
        $count++
    } 
    until 
    (
        $a -eq $null -or $count -ge 30
    )
}

function installnewversionexe
{
    Write-host "Starting new version install"
    Add-Content "$(executiontime) - Starting new version install" -Path $script:logfile
    ."W:\pimdev\client_facing_tech\am\cars\crs_word\bin\CRSWordRibbon.exe"
    #guess a time for the thing to finish
    sleep 60
    #clean up the stupid message
    gwmi win32_process | where {$_.name -eq "VSTOInstaller.exe"} | foreach {$_.terminate()}
}

function verifynewinstall
{
    #Verify the install
    if (Test-Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\C83E9432994079C9FAB9EE96FCE0412066A49D65)
    {
        write-host "New version installed successfully"
        Add-Content "$(executiontime) - New version installed successfully" -Path $script:logfile
    }
    else
    {
        write-warning "New version install failed"
        Add-Content "$(executiontime) - New version install failed" -Path $script:logfile
    }
}

function disablecurrentplugin
{
    $word = New-Object -com word.application
    ($word.comaddins | where {$_.progId -eq "Pimco.AM.Research.ResearchRibbon"}).Connect = $false
    $word.quit()
}

function checkword
{
    $word = New-Object -com word.application
    ($word.comaddins | where {$_.progId -eq "Pimco.AM.Research.ResearchRibbon"})
    $word.quit()
}

### Main ###
logfilesetup
disablecurrentplugin
checkforcurrentversion
uninstallcurrentversion
verifyuninstall
dllcachecleanup
installnewversionexe
verifynewinstall

