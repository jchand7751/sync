﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/8/2016 2:45 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Sync group membership between "CM Institutional - Associates & IPs" and "CM Institutional - Associates & IPs - Security"
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
Connect-QADService pimco
$cmusers = get-qadgroup "CM Institutional - Associates & IPs" | get-qadgroupmember | where { $_.type -eq "user" }
$cmsecusers = get-qadgroup "CM Institutional - Associates & IPs - security" | get-qadgroupmember | where { $_.type -eq "user" }
if ($cmsecusers.samaccountname -ne $cmusers.samaccountname)
{
	foreach ($user in $cmusers.samaccountname)
	{
		Get-QADUser -SamAccountName $user | Add-QADMemberOf -Group "CM Institutional - Associates & IPs - security"
	}
}
else
{
		
}