﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/21/2017 10:33 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
$array = @()

$users = $a
foreach ($user in $users)
{
	$user = get-msoluser -userprincipalname $user
	$object = "" | select Email, E3, CRM, Yammer
	$object.Email = $user.userprincipalname
	if ($user.licenses.accountskuid -contains "PIMCO:ENTERPRISEPACK")
	{
		$object.E3 = "Yes"
	}
	else
	{
		$object.E3 = "No"
	}
	
	if ($user.licenses.accountskuid -contains "PIMCO:CRMSTANDARD")
	{
		$object.CRM = "Yes"
	}
	else
	{
		$object.CRM = "No"
	}
	
	if (($user.licenses.servicestatus | where { $_.serviceplan.servicename -eq "YAMMER_ENTERPRISE" }).provisioningstatus -eq "Success")
	{
		$object.Yammer = "Yes"
	}
	else
	{
		$object.Yammer = "No"
	}
	
	$array += $object
}
$array


$user = Get-QADUser "stairs, ben"
$user = Get-QADUser "hsieh, joe"
$user = Get-QADUser "tuttle, alena"
$user = Get-QADUser "kyle, brian"
