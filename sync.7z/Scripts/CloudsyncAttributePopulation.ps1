﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/16/2017 12:03 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	CloudsyncAttributePopulation
	===========================================================================
	.DESCRIPTION
		Set the cloudsync AD attribute for users that are members of cloud groups (O365-*)
#>

#region Base variables and environment information
$logfile = "e:\scripts\logs\cloudsyncattribute.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#Array for cloud users
$script:cloudsyncusers = @()

#Array with User cloudsync values
$script:useractionarray = @()

#endregion

#region Script functions

function SetAttributes
{
	#Compare the cloudsync value from the array to the users current cloudsync value, if it doesn't match, set the new value
	foreach ($action in $script:useractionarray)
	{
		if ($action.cloudsyncvalue -ne ($script:cloudsyncusers | where { $_.samaccountname -eq $action.samaccountname }).cloudsync)
		{
			Add-Log -Type 'Information' -Message "Mismatch on cloudsync attributes for $($action.samaccountname) setting - '$($action.cloudsyncvalue)'"
			try
			{
				Set-QADUser -Identity $action.samaccountname -Service pimco.imswest.sscims.com -ObjectAttributes @{ cloudsync = $action.cloudsyncvalue } -ea Stop | Out-Null
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set cloudsync attribute for $($action.samaccountname)"
			}
		}
		else
		{
			Add-Log -Type 'Information' -Message "Attribute for $($action.samaccountname) is already set"
		}
	}
}

function GetCloudGroups
{
	try
	{
		#Get all of the cloud groups
		$script:cloudsyncgroups = Get-QADGroup O365* -Service pimco.imswest.sscims.com -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to get cloud groups" -Throw
	}
	$count = $($script:cloudsyncgroups).count
	Add-Log -Type 'Information' -Message "Found $count cloud groups"
}

function GetCloudUsers
{
	#Get all of the users in the cloud groups
	foreach ($group in $script:cloudsyncgroups)
	{
		$script:cloudsyncusers += $group | Get-QADGroupMember -Service pimco.imswest.sscims.com -SizeLimit 0 -ea 'Stop' -IncludedProperties "Cloudsync"
	}
	
	#Just get a unique list of cloud users
	$script:cloudsyncusers = $script:cloudsyncusers | select -Unique
	#$script:cloudsyncusers = $script:cloudsyncusers | where { $_.name -eq "Loesch, Maria" } | select -Unique
	$count = $($script:cloudsyncusers).count
	Add-Log -Type 'Information' -Message "Found $count cloud users"
}

function PopulateActionArray
{
	<#
	Loop through the cloud users find the cloud groups they are a member of, strip off the first characters of the group name (O365) and build the array that contains their
	samaccountname, email, and cloudsyncvalue
	#>
	foreach ($user in $script:cloudsyncusers)
	{
		Add-Log -Type 'Information' -Message "Processing user: $($user.samaccountname)"
		$object = "" | select SamaccountName, email, cloudsyncvalue
		foreach ($group in $script:cloudsyncgroups)
		{
			if (Get-QADGroupMember $group -Service pimco.imswest.sscims.com -LdapFilter "(samaccountname=$($user.samaccountname))")
			{
				#Create the attributes for each user
				$attributename = $group.name -replace "O365-"
				$object.samaccountname = $user.samaccountname
				$object.email = $user.email
				$object.cloudsyncvalue = $object.cloudsyncvalue + $attributename + "|"
				Add-Log -Type 'Information' -Message "$($user.samaccountname) is a member of $attributename - Adding to execution list"
			}
		}
		#Clean up the trailing data
		$object.cloudsyncvalue = (($object.cloudsyncvalue).trimstart("")).trimend("|")
		$script:useractionarray += $object
	}
}

function ClearAttributes
{
	try
	{
		$formercloudusers = Get-QADUser -Service pimco.imswest.sscims.com -LdapFilter "(cloudsync=*)" -SizeLimit 0 -IncludedProperties cloudsync, AccountIsDisabled -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to query Active Directory"
	}
	$formercloudusers | foreach {
		if (($_ | Get-QADMemberOf -Name "O365*" -Service pimco.imswest.sscims.com -ea 'Stop') -eq $null)
		{
			Add-Log -Type 'Information' -Message "$($_.samaccountname) has a cloudsync attribute of $($_.cloudsync) but is no longer a member of any AD groups, setting cloudsync value to null"
			try
			{
				Set-QADUser -Service pimco.imswest.sscims.com -Identity $_.samaccountname -ObjectAttributes @{ cloudsync = "" } -ea Stop | Out-Null
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to clear attribute!"
			}
		}
	}
}

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"
GetCloudGroups
GetCloudUsers
PopulateActionArray
SetAttributes
ClearAttributes
Add-Log -Type 'Information' -Message "Script complete"
#endregion