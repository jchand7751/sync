﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	11/9/2016 1:16 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


$AllPCs = get-qadcomputer -OSName "Windows 7*" -sizelimit 0
$missingUEV = $AllPCs | where { ($_ | Get-QADMemberOf -Name "UEV_Computers").name -like "" } | select Name
$missingUEV | export-csv c:\temp\PCsNotinUEVComputersGroup.csv


$AllUsers = get-qaduser –includedproperties ExtensionAttribute5 -sizelimit 0 | where { $_.extensionattribute5 –eq “u” }
$missingUEV = $Allusers | where { ($_ | Get-QADMemberOf -Name "UEV_Users").samaccountname -like "" } | select Name, SamAccountName, office, l
$missingUEV | export-csv c:\temp\UsersNotinUEVComputersGroup.csv
