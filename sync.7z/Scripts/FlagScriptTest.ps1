﻿Param ($function)

#Define common variables for functions
$Script:UserName = $env:username
$Script:ComputerName = $env:computername

function StartAppLoop
{
    #Loop counter so the function doesnt run indefinitely
    $script:StartAppLoopCounter++
    #Start the process and save the object so we can look at the process ID later
    $App_pid = [diagnostics.process]::start($apploc)
    Write-Verbose "Attemping $appname start"
    Add-Content -Path $logfile "$(executiontime) Attemping $appname start"
    #Waiting for rundll to end, count to 60 it should finish instantly
    $proccounter = 0
    do {$proccounter++ ; sleep 1} until (!(get-process -id $App_pid.id -ea 0) -or $proccounter -ge 60)

    #Get the Click once processes running on the box, one of these should be the parent process for flag
    #Once the click once process and flag are found break out of the loop, otherwise give it some time and then retry the loop
    $counter = 0
    do
    {
        sleep 2
        $counter++
        $ClickOnceProcesses = gwmi win32_process | where {$_.name -eq "dfsvc.exe"}
        foreach ($proc in $clickOnceProcesses)
        { 
            $script:checkformatch = gwmi win32_process | where {$_.parentprocessid -eq $proc.processid -and $_.name -eq $appexecutable}
            write-verbose "Checking for $appname with parent ID $($proc.processid)"
            Add-Content -Path $logfile "$(executiontime) Checking for $appname with parent ID $($proc.processid)"
            if ($script:checkformatch)
            {
                $Match = "true"
                Add-Content -Path $logfile "$(executiontime) $appname started!"
                Write-Verbose "$appname started!"
                break
            }
        }
        sleep 3
   }
    until
    ($Match -eq "true" -or $counter -ge 18)

    if ($counter -ge 18)
    {
        Add-Content -Path $logfile "$(executiontime) $appname failed to start, retrying entire process"
        Write-Verbose "$appname failed to start, retrying entire process"
        if ($script:StartAppLoopCounter -le 2)
        {
            StartAppLoop
        }
    }

}

function AppExecution
{
    #Define variables
    $apploc = "W:\pimprod\tlc\trading\flag\client\bin\FLAG.application"
    $logfile = "C:\Temp\FlagFiles\FlagAppStartupLog.txt"
    $appexecutable = "flag.exe"
    $appname = "FLAG"
    function executiontime {get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"}
    $retrycount = 10
    $script:StartAppLoopCounter = 0
    
    #Start application and monitor that it started loop
    StartAppLoop

    #Check the log file path to see if it exists, if it does, log the info, otherwise create it and log the info
    if ((Test-path $logfile) -eq $true)
    {
        Add-Content -Path $logfile "$(executiontime) $Script:UserName $Script:ComputerName $appname finished"
    }
    else
    {
        New-Item -Path $logfile -itemtype file
        Add-Content -Path $logfile "$(executiontime) $Script:UserName $Script:ComputerName $appname finished"
    }

}

Function SendEmail
{
    Param ($EmailFrom, $EmailTo, $EmailSubject, $EmailBody)
	# Send E-mail message
	$Message = New-Object Net.Mail.MailMessage($EmailFrom, $EmailTo, $EmailSubject, $EmailBody)
	$SMTPClient = New-Object Net.Mail.SmtpClient("mailhost.pimco.com", 25)
	#$SMTPClient.EnableSsl = $true
	#$SMTPClient.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
	$SMTPClient.Send($Message)

}

function CheckNetworkPath
{
	#Define variables for the script
	$driveletter = "w:"
	$timeoutcounter = 0
	$timeoutmax = 180
	$LogPath = "C:\temp\FlagFiles\FlagAppStartupTask.txt"
	$timestamp = (Get-Date -UFormat %Y-%m-%d-%H%M)
    $appname = “FLAG”
    $executiontime = get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
    $EmailFrom = "NoReply_Flag_Notification@Pimco.com"
	$EmailTo = "james.chandler@pimco.com"
    $EmailSubject = "Flag could not start for user $Script:UserName" 
    $EmailBody = "$driveletter drive did not mount for $Script:UserName on $Script:ComputerName within $timeoutmax seconds of login."

	
	#Create the log file
	if ((Test-Path $LogPath) -eq $true)
	{
		#Remove-Item $LogPath -Force | Out-Null
		#New-Item -Path $LogPath -ItemType File | Out-Null
		Add-Content -Path $LogPath "$executiontime $Script:UserName on $Script:ComputerName - Task started" | Out-Null
	}
	else
	{
		Add-Content -Path $LogPath "$executiontime $Script:UserName on $Script:ComputerName - Task started" | Out-Null
	}
	
	#Loop a check every 1 second for the $driveletter specified until it reaches the timeout maximum
	do
	{
		$testpath = Test-Path -Path $driveletter
		sleep 1
		$timeoutcounter++
		#Display timeout counter and testpath results for testing
		#$timeoutcounter
		#$testpath
	}
	until ($testpath -eq $true -or $timeoutcounter -ge $timeoutmax)
	
	#if the drive letter is not mapped within the timeout maximum send an email to $emailfrom and add an event to the log file
	if ($timeoutcounter -ge $timeoutmax)
	{
		Add-Content -Path $LogPath "$executiontime $Script:UserName $Script:ComputerName - $driveletter did not mount within $timeoutmax seconds" | Out-Null
        SendEmail $EmailFrom $EmailTo $EmailSubject $EmailBody
	}
	else
	{
		#Add log entry that Flag is starting successfully, launch the Copy/App execution via the original batchfile
		Add-Content -Path $LogPath "$executiontime $Script:UserName $Script:ComputerName - $driveletter was found, starting $appname" | Out-Null
		#\\pimco.imswest.sscims.com\NETLOGON\Batch\FlagAppStartupV2.bat
        #Start application
        AppExecution
	}
}

Function MonitorApp
{
    #Define variables
    $wait_time = 600   #POLLING INTERVAL
    $num_times = 2     #NO OF TIMES TO CHECK ON ANY GIVEN DAY.
    $appname = “FLAG”
    #$MyProcCMD = "\\pimco.imswest.sscims.com\netlogon\Batch\FlagAppStartupV2.bat" #<-- cmd to start proc   
    #$process = gps "FLAG" -ea 0
    $counter = 0
    $lastCheckDate = Get-Date -format d
    $EmailFrom = "NoReply_Flag_Notification@Pimco.com"
    $EmailTo = "tony.incontro@pimco.com,Vinodkumar.Kadambalithaya@pimco.com,james.chandler@pimco.com"
    $EmailSubject = "$appname Restarted"
    $EmailBody = "$appname Applicaton Re-started for $Script:UserName on $Script:ComputerName"

    while ($true)
    {
        start-sleep -s $wait_time
        $currentdate = Get-Date  -format d
        if ($currentdate -ne $lastCheckDate)
        { 
            $counter = 0
        }
            $lastCheckDate = $currentdate
            if ($counter -lt $num_times)
            {
                $process = gps $appname -ea 0 
                if (!$process) 
                {
                    $counter++
                    #$wmi = ([wmiclass]"win32_process").Create($MyProcCMD) #process has stopped - start it
                    AppExecution
                    SendEmail $EmailFrom $EmailTo $EmailSubject $EmailBody
                }
            }          
    }
}

Switch ($function)
{
    "Start-App" {CheckNetworkPath}
    "Monitor-App" {MonitorApp}
}
