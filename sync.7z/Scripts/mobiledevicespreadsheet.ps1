﻿
$finalarray = @()
foreach ($i in $array) 
{
    $object = "" | select Name, Title, Office, Department, DeviceType, LookupStatus
    
    #try to find user
    if ($i.name)
    {
        if (Get-qaduser -name $i.name)
        {
            $object.lookupstatus = "Success"
            $lookup = (Get-qaduser -name $i.name)
            $count = $lookup.count
            $object.name = $lookup.name
            $object.Title = $lookup.title
            $object.department = $lookup.department
            $object.devicetype = $i.devicetype
            $object.office = $lookup.l
            if ($lookup.count -gt 1)
            {
                $object.lookupstatus = "Multiple"
                $object.name = $i.Name
                $object.Title = ""
                $object.department = ""
                $object.devicetype = $i.devicetype
                $object.office = ""
            }
        }
        else
        {
            $object.lookupstatus = "Failed"
            $object.name = $i.name
            $object.Title = ""
            $object.department = ""
            $object.devicetype = $i.devicetype
            $object.office = ""
        }
    }
    else
    {
        if (Get-qaduser -samaccountname $i."user id")
        {
            $object.lookupstatus = "Success"
                $lookup = (Get-qaduser -samaccountname $i."user id")
                $count = $lookup.count
                $object.name = $lookup.name
                $object.Title = $lookup.title
                $object.department = $lookup.department
                $object.devicetype = $i.devicetype
                $object.office = $lookup.l
                if ($lookup.count -gt 1)
                {
                    $object.lookupstatus = "Multiple"
                    $object.name = $i."user id"
                    $object.Title = ""
                    $object.department = ""
                    $object.devicetype = $i.devicetype
                    $object.office = ""
                }
            }
        else
            {
                $object.lookupstatus = "Failed"
                $object.name = $i."user ID"
                $object.Title = ""
                $object.department = ""
                $object.devicetype = $i.devicetype
                $object.office = ""
            }
    }
    $object
    $finalarray += $object
}