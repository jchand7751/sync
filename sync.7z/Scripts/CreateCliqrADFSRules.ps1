﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/10/2016 3:50 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
$groups = Get-QADGroup -Parent "OU=pimcloud,OU=Applications,OU=Groups,OU=Operations,OU=Users,OU=CORP,DC=PIMCO,DC=IMSWEST,DC=SSCIMS,DC=COM"

foreach ($i in $groups)
{
	Add-Content c:\temp\cliqrrules.txt ''
	Add-Content c:\temp\cliqrrules.txt "@RuleTemplate = `"EmitGroupClaims`""
	Add-Content c:\temp\cliqrrules.txt "@RuleName = `"Group Lookup: $($i.name)`""
	Add-Content c:\temp\cliqrrules.txt "c:[Type == `"http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid`", Value == `"$($i.sid)`", Issuer == `"AD AUTHORITY`"] => issue(Type = `"http://schemas.xmlsoap.org/claims/Group`", Value = `"$($i.name)`", Issuer = c.Issuer, OriginalIssuer = c.OriginalIssuer, ValueType = c.ValueType);"
}

foreach ($i in $groups)
{
	Add-Content c:\temp\cliqrrules.txt ''
	Add-Content c:\temp\cliqrrules.txt "@RuleTemplate = `"EmitGroupClaims`""
	Add-Content c:\temp\cliqrrules.txt "@RuleName = `"Group Lookup: $($i.name) to Role (Activation)`""
	Add-Content c:\temp\cliqrrules.txt "c:[Type == `"http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid`", Value == `"$($i.sid)`", Issuer == `"AD AUTHORITY`"] => issue(Type = `"http://schemas.microsoft.com/ws/2008/06/identity/claims/role`", Value = `"$($i.name)`", Issuer = c.Issuer, OriginalIssuer = c.OriginalIssuer, ValueType = c.ValueType);"
}