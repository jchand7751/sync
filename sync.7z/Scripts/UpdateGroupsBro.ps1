﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/5/2017 12:32 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement

#Run from Core
$credential = get-credential
Connect-QADService pimco.imswest.sscims.com #-Credential $credential
get-qadgroup pimcloud-* | foreach {
	$groupname = $_.name
	Connect-QADService core.pimcocloud.net
	New-QADGroup -Name $_.name -DisplayName $_.name -GroupName $_.name -GroupType security -GroupScope DomainLocal -parentcontainer "OU=onboarding,OU=sec_groups,OU=itops,DC=core,DC=pimcocloud,DC=net"
}

#Run from Pimco
$pimcocredential = get-credential "pimco\jchandle"
$corecredential = get-credential "core\admjchandler"

Connect-QADService pimco.imswest.sscims.com -Credential $pimcocredential
$Groups = Get-QADGroup pimcloud-* | where { $_.name -like "*sandbox*" }
foreach ($i in $Groups)
{
	
	$currentpimcogroupmembers = @()
	$currentpimcogroupmembers += (Get-QADGroup $i.name -Service pimco.imswest.sscims.com | get-qadgroupmember -Service pimco.imswest.sscims.com -SizeLimit 0).samaccountname
	$currentpimcogroupmembers
	Connect-QADService core.pimcocloud.net -Credential $corecredential | Out-Null
	$currentcoregroupmembers = @()
	$currentcoregroupmembers += (Get-QADGroup $i.name -Service core.pimcocloud.net | get-qadgroupmember -Service core.pimcocloud.net -SizeLimit 0).samaccountname
	$currentcoregroupmembers
	$comparison = compare $currentpimcogroupmembers $currentcoregroupmembers
	if ($comparison)
	{
		#need to add is <=
		foreach ($usertobeadded in ($comparison | where { $_.sideindicator -eq "<=" }))
		{
			Write-Host "Adding $($usertobeadded.inputobject)"
			Get-QADUser -SamAccountName "$($usertobeadded.inputobject)" -Service pimco.imswest.sscims.com -Credential $pimcocredential | Add-QADGroupMember $i.name -Service core.pimcocloud.net -Credential $corecredential
		}
		#need to remove is =>
		foreach ($usertoberemoved in ($comparison | where { $_.sideindicator -eq "=>" }))
		{
			Write-Host "Removing $($usertoberemoved.inputobject)"
			#Remove-QADGroupMember $i.name "$($usertoberemoved.inputobject)" -Service core.pimcocloud.net -Credential $corecredential
			Get-QADUser -SamAccountName "$($usertoberemoved.inputobject)" -Service pimco.imswest.sscims.com -Credential $pimcocredential | Remove-QADGroupMember $i.name -Service core.pimcocloud.net -Credential $corecredential
		}
	}
	else
	{
		Write-Host "No changes needed to $($i.name)"
	}
}
