﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.57
	 Created on:   	6/4/2014 3:06 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
[CmdletBinding()]
Param
(
	[Parameter(Mandatory = $true, Position = 1, ParameterSetName = 'Location1')]
	[string]$csvpath
)

#Variables
$logfile = "C:\temp\ADAttributeImport.txt"

#Functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

if (Test-Path $logfile)
{ }
else
{
	New-Item -Type File $logfile | Out-Null
}

Add-Content -Path $logfile "$(executiontime) - Starting Script"
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop'
}
catch
{
	Write-Warning "Failed to load required modules"
	Add-Content -Path $logfile "$(executiontime) - Failed to connect to the domain"
	exit
}

try
{
	Connect-QADService vms001p7.pimco.imswest.sscims.com -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "Failed to connect to the domain"
	Add-Content -Path $logfile "$(executiontime) - Failed to connect to the domain"
	exit
}

if ((Test-Path $csvpath) -eq $true)
{
	Write-Verbose "Found CSV, starting import"
}
else
{
	throw "Could not find specified CSV"
}

$importcsv = Import-Csv $CSVpath
if ($importcsv)
{
	foreach ($user in $importcsv)
	{
		$usercheck = Get-QADUser -SamAccountName $user.login_id
		if ($usercheck)
		{
			Write-Verbose "Setting streetaddress attribute on account $($usercheck.samaccountname) to $($user.streetaddress)"
			Add-Content -Path $logfile "$(executiontime) - Setting streetaddress attribute on account $($usercheck.samaccountname) to $($user.streetaddress)"
			$usercheck | Set-QADUser -ObjectAttributes @{ "streetaddress" = $($user.streetaddress) } -WhatIf | Out-Null
			Write-Verbose "Setting postaladdress attribute on account $($usercheck.samaccountname) to $($user.postaladdress)"
			Add-Content -Path $logfile "$(executiontime) - Setting postaladdress attribute on account $($usercheck.samaccountname) to $($user.postaladdress)"
			$usercheck | Set-QADUser -ObjectAttributes @{ "postaladdress" = $($user.postaladdress) } -WhatIf | Out-Null
		}
		else
		{
			Write-Warning "User `"$($user.login_id)`" was not found in AD"
			Add-Content -Path $logfile "$(executiontime) - User `"$($user.login_id)`" was not found in AD"
		}
	}
}
else
{
	Write-Warning "CSV file was not found"
	Add-Content -Path $logfile "$(executiontime) - CSV file was not found"
}
#Remove the snapin to resolve the try catch at the start on the next run
Remove-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop'
Add-Content -Path $logfile "$(executiontime) - Done"