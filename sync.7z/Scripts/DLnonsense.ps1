﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/9/2016 3:42 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin Quest.ActiveRoles.ADManagement
$dls = "AmPC", "EPC", "EM FORUM", "APC"

foreach ($i in $dls)
{
	Get-QADGroup $i | Get-QADGroupMember -Indirect -IncludedProperties l, co, proxyaddresses | select Name, PrimaryEmail, @{
		Name = "PimcoEmail"; Expression = { (([string](get-qaduser $_.samaccountname -IncludedProperties proxyaddresses | foreach { $_.proxyaddresses -like "*@pimco.com" } | where { $_ -like "smtp:*" })) -replace "smtp:") }
	}, @{ Name = "Manager"; Expression = { (get-qaduser $_.manager).name } }, Title, l, co, city
}


$ampc = Get-QADGroup "amPC" | Get-QADGroupMember -Indirect -IncludedProperties l, co, proxyaddresses | select Name, Email, @{ Name = "PimcoEmail"; Expression = { (([string](get-qaduser $_.samaccountname -IncludedProperties proxyaddresses | foreach { $_.proxyaddresses -like "*@pimco.com" } | where { $_ -like "smtp:*" })) -replace "smtp:") } }, @{ Name = "Manager"; Expression = { (get-qaduser $_.manager).name } }, Title, l, co, city

$epc = Get-QADGroup "EPC" | Get-QADGroupMember -Indirect -IncludedProperties l, co, proxyaddresses | select Name, Email, @{ Name = "PimcoEmail"; Expression = { (([string](get-qaduser $_.samaccountname -IncludedProperties proxyaddresses | foreach { $_.proxyaddresses -like "*@pimco.com" } | where { $_ -like "smtp:*" })) -replace "smtp:") } }, @{ Name = "Manager"; Expression = { (get-qaduser $_.manager).name } }, Title, l, co, city

$emforum = Get-QADGroup "EM FORUM" | Get-QADGroupMember -Indirect -IncludedProperties l, co, proxyaddresses | select Name, Email, @{ Name = "PimcoEmail"; Expression = { (([string](get-qaduser $_.samaccountname -IncludedProperties proxyaddresses | foreach { $_.proxyaddresses -like "*@pimco.com" } | where { $_ -like "smtp:*" })) -replace "smtp:") } }, @{ Name = "Manager"; Expression = { (get-qaduser $_.manager).name } }, Title, l, co, city

$apc = Get-QADGroup "APC" | Get-QADGroupMember -Indirect -IncludedProperties l, co, proxyaddresses | select Name, Email, @{ Name = "PimcoEmail"; Expression = { (([string](get-qaduser $_.samaccountname -IncludedProperties proxyaddresses | foreach { $_.proxyaddresses -like "*@pimco.com" } | where { $_ -like "smtp:*" })) -replace "smtp:") } }, @{ Name = "Manager"; Expression = { (get-qaduser $_.manager).name } }, Title, l, co, city