﻿
#Variables
<#
$env:apppath
$env:CliqrDepEnvName
$filename
$env:serviceaccount
$env:serviceaccountpassword
$env:site
$env:iisappname
#>

#Import Modules
Import-module BitsTransfer
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

$cliqrvariableslocation = "C:\temp\userenv.ps1"
.$cliqrvariableslocation

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

if ($env:CliqrDepEnvName -like "sandbox")
{
	$filename = ($env:apppath -split "/")[-3] + "-" + ($env:apppath -split "/")[-2] + "-" + "DEV" + ".zip"
}
else
{
	$filename = ($env:apppath -split "/")[-3] + "-" + ($env:apppath -split "/")[-2] + "-" + (($env:CliqrDepEnvName).toupper()) + ".zip"
}

Start-BitsTransfer -Source ($env:apppath + "/" + $filename) -destination e:\ -ProxyUsage NoProxy
Start-BitsTransfer -Source http://10.155.5.63:8080/Carbon.dll -destination c:\temp\installed\ -ProxyUsage NoProxy

sleep 10

#$filename = ($env:appzipfile -split "/")[-1]
Expand-ZIPFile E:\$filename -destination e:

Import-Module WebAdministration
$structure = ls e:\inetpub
#$apppools = ls "env:" | where { $_.name -like "site*" }

#create app pools
foreach ($i in $structure.name)
{
	New-WebAppPool -Name $i.value
	
	$GetPool = Get-Item "iis:\AppPools\$($i.value)"
	$GetPool.processmodel.username = $env:serviceaccount
	$GetPool.processmodel.Password = $env:serviceaccountpassword
	$GetPool.processmodel.identityType = "SpecificUser"
	$GetPool | Set-Item
	Restart-WebAppPool -Name $i.value
}

$sites = ($structure | where { $_.name -notlike "*client*" }).name
$apps = ($structure | where { $_.name -like "*wcf*" }).name

$iisarray = @()

foreach ($site in $sites)
{
	$object = "" | select Name, Parent, Authentication
	$object.name = $site
	$object.parent = "None"
	$object.authentication = "Kerberos"
	$iisarray += $object
}

foreach ($app in $apps)
{
	$object = "" | select Name, Parent, Authentication
	$object.name = $app
	$object.parent = $sites.name
	$object.authentication = $sites.authentication
	$iisarray += $object
}

foreach ($iisobject in $iisarray)
{
	if ($iisobject.parent -eq "none")
	{
		#Write-Host "$($site.name) is a root site"
		New-Website -Name $iisobject.name -ApplicationPool $iisobject.name -physicalpath "e:\inetpub\$($iisobject.name)" -HostHeader ($env:iisAppName + "-sandbox") -Port 8700 | Out-Null
		#site bindings
		New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-sandbox.core.pimcocloud.net")
		New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-dev")
		New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-dev.core.pimcocloud.net")
		New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-beta")
		New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-beta.core.pimcocloud.net")
		New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-prod")
		New-WebBinding $iisobject.name -IPAddress "*" -Port 8700 -HostHeader ($env:iisAppName + "-prod.core.pimcocloud.net")
		#use app pool credentials
		Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location $iisobject.name -value true
		
		if ($iisobject.authentication -eq "NTLM" -or $iisobject.authentication -eq "Kerberos")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $iisobject.name -value true
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $iisobject.name -value false
		}
		if ($iisobject.authentication -eq "Anonymous")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location $iisobject.name -value false
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location $iisobject.name -value true
		}
	}
	else
	{
		#Write-Host "$($site.name) is an app"
		New-WebApplication -name $iisobject.name -Site $iisobject.parent -PhysicalPath "e:\inetpub\$($iisobject.name)" -ApplicationPool $iisobject.name -Force
		
		#use app pool credentials
		Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name useAppPoolCredentials -location "$($iisobject.parent)/$($iisobject.name)" -value true
		
		if ($iisobject.authentication -eq "NTLM" -or $iisobject.authentication -eq "Kerberos")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value true
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value false
		}
		if ($iisobject.authentication -eq "Anonymous")
		{
			#Enable windows auth
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/windowsAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value false
			#disable anonymous
			Set-WebConfigurationProperty -filter /system.WebServer/security/authentication/AnonymousAuthentication -name enabled -location "$($iisobject.parent)/$($iisobject.name)" -value true
		}
	}
}

#Register any windows services
$directories = ls e:\services -Directory
foreach ($dir in $directories)
{
	foreach ($exe in (ls $dir.fullname -filter *.exe))
	{
		C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /servicename=$($dir.name) /i $exe.fullname
	}
}

#change service account
try
{
	$serviceaccount = ($env:serviceaccount -split '\\')[-1]
	([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$serviceaccount") | Out-Null
}
catch
{
	#Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	#agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
}

#grant rights to logon as a service
$Identity = $env:serviceaccount
$privilege = "SeServiceLogonRight"
$CarbonDllPath = "C:\temp\installed\Carbon.dll"
[Reflection.Assembly]::LoadFile($CarbonDllPath)
[Carbon.Lsa]::GrantPrivileges($Identity, $privilege)

#Change service account on windows services
$Service = gwmi win32_service | where { $_.pathname -like ('"' + $exe.fullname + '"') }
$Service.Change($Null, $Null, $Null, $Null, $Null, $Null, $env:serviceaccount, $env:serviceaccountpassword, $Null, $Null, $Null)
$Service.StartService()

#add healthcheck site
mkdir e:\inetpub\healthcheck
Start-BitsTransfer -Source http://10.155.5.63:8080/probe.htm -destination e:\inetpub\healthcheck -ProxyUsage NoProxy
New-WebAppPool -Name healthcheck
New-Website -Name healthcheck -ApplicationPool healthcheck -physicalpath "e:\inetpub\healthcheck" -Port 8700 | Out-Null

#add HTTP response headers
$Hostname = hostname
C:\windows\System32\inetsrv\appcmd.exe set config -section:system.webServer/httpProtocol /-"customHeaders.[name='X-ServerName']"
C:\windows\System32\inetsrv\appcmd.exe set config -section:system.webServer/httpProtocol /+"customHeaders.[name='X-ServerName',value=`'$HostName`']"

iisreset


