﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/22/2017 6:31 PM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Create a folder in a mailbox with a homepage URL.
#>

#Import the module
try
{
	Import-Module -Name "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll"
}
catch
{
	Write-Warning "Module not installed, exiting"
}

$foldername = "PIMCO eVault1"
#$emailaddress = "blah@pimco.com"

#Create the Exchange service API object to connect to the mailbox
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP2)

#Get credentials - for manual use only
$Cred = Get-Credential

#Encrypt credentials to disk and create a credential object
#$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString)
#$cred = New-Object System.Management.Automation.PSCredential "pimco\svc_accountwithaccesstoimpersonate mailboxes", $password

#Enable impersonation
#$service.ImpersonatedUserId = new-object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress, $emailaddress);

#Set the credentials
$service.Credentials = new-object Microsoft.Exchange.WebServices.Data.WebCredentials($($cred.getnetworkcredential().username), $($cred.getnetworkcredential().password), $($cred.getnetworkcredential().domain))

#CAS URL
$service.Url = new-object Uri("https://owa-lb.pimco.imswest.sscims.com/EWS/Exchange.asmx")

#Byte encoding of evault URL
$evaultURL = [byte[]](2,0,0,0,1,0,0,0,33,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,46,0,0,0,104,0,116,0,116,0,112,0,115,0,58,0,47,0,47,0,100,0,115,0,109,0,97,0,105,0,108,0,46,0,112,0,105,0,109,0,99,0,111,0,46,0,99,0,111,0,109,0,47,0,115,0,115,0,101,0,97,0,114,0,99,0,104,0,47,0,0,0)

#Extended property for homepage of folder
$ExchExtendedProperty = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(14047, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Binary)

#Create an exchange folder object against the service object
$oFolder = new-object Microsoft.Exchange.WebServices.Data.Folder($service)

#Set the name
$oFolder.DisplayName = $foldername

#Set the extended value
$ofolder.SetExtendedProperty($ExchExtendedProperty, $evaultURL)

#Save the folder under the inbox
$oFolder.Save([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox)