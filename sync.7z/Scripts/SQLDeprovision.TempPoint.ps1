﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	9/15/2016 6:44 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   SQLdeprovision.ps1  	
	===========================================================================
	.DESCRIPTION
		Cliqr SQL deprovision script.
#>

. "c:\Program Files\osmosix\service\utils\agent_util.ps1"
sleep 5

function Executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force
	}
}

function SQLdeprovisionScript
{
	$logfile = "C:\temp\SQLDeproLog.txt"
	$server = hostname
	$key = 203, 117, 112, 91, 119, 165, 146, 173, 140, 253, 20, 134, 174, 241, 213, 16
	$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString -Key $key)
	$credential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
	
	CreateLogFile
	Add-Content -Path $logfile "$(executiontime) - Starting SQL deprovision script"
	agentSendLogMessage "$(executiontime) - Starting SQL deprovision script"
	Add-Content -Path $logfile "$(executiontime) - Giving svc_adaccess temporary admin access to create SPNs"
	agentSendLogMessage "$(executiontime) - Giving svc_adaccess temporary admin access to create SPNs"
	try
	{
		([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://core.pimcocloud.net/svc_adaccess") | Out-Null
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to add svc_adaccess to local admins group"
		agentSendLogMessage "$(executiontime) - Failed to add svc_adaccess to local admins group"
	}
	Add-Content -Path $logfile "$(executiontime) - Removing SPNs"
	agentSendLogMessage "$(executiontime) - Removing SPNs"
	
	$session = New-PSSession localhost -Credential $credential -Authentication Credssp
	
	$spnarray = @()
	$spnarray += "MSSQLSvc/$server"
	$spnarray += "MSSQLSvc/$server.core.pimcocloud.net"
	$spnarray += "MSSQLSvc/$server`:1433"
	$spnarray += "MSSQLSvc/$server.core.pimcocloud.net:1433"
	
	$user = Invoke-Command -Session $session { [ADSI]"LDAP://CN=svc-sqladmin,OU=svc_accounts,OU=itops,DC=core,DC=pimcocloud,DC=net" }
	
	if ($user.samaccountname)
	{ }
	else
	{
		Add-Content -Path $logfile "$(executiontime) - Couldn't get user account"
		agentSendLogMessage "$(executiontime) - Couldn't get user account"
	}
	
	$currentSPNs = $user.serviceprincipalname
	
	#Remove SPN
	foreach ($spn in $spnarray)
	{
		#sleep 10
		Add-Content -Path $logfile "$(executiontime) - Removing SPN $spn"
		agentSendLogMessage "$(executiontime) - Removing SPN $spn"
		#Invoke-Command -Session $session {setspn -d $args CORE\svc-sqladmin} -ArgumentList $spn
		
		if (($currentSPNs -contains $spn) -eq $true)
		{
			#$currentSPNs += $spn
			$currentSPNs = $currentSPNs | Where { $_ –ne $spn }
		}
		else
		{
			Add-Content -Path $logfile "$(executiontime) - SPN doesn't exist"
			agentSendLogMessage "$(executiontime) - SPN doesn't exist"
		}
	}
	
	foreach ($i in $currentSPNs)
	{
		Add-Content -Path $logfile "$(executiontime) - SPN to be set $i"
		agentSendLogMessage "$(executiontime) - SPN to be set $i"
	}
	
	Add-Content -Path $logfile "$(executiontime) - Bulk settings SPNs"
	agentSendLogMessage "$(executiontime) - Bulk settings SPNs"
	
	Invoke-Command -Session $session {
		$user = [ADSI]"LDAP://CN=svc-sqladmin,OU=svc_accounts,OU=itops,DC=core,DC=pimcocloud,DC=net"
		$user.put("serviceprincipalname", $args)
		$user.setinfo()
	} -ArgumentList $currentSPNs
	
	sleep 30
	$foundspn = (Invoke-Command -Session $session { setspn -L core\svc-sqladmin })
	
	#Verify SPN
	
	foreach ($spn in $spnarray)
	{
		$found = $false
		foreach ($fspn in $foundspn)
		{
			if ($fspn.trimstart("") -eq $spn)
			{
				$found = $true
				break
			}
		}
		switch ($found)
		{
			"$true" { Add-Content -Path $logfile "$(executiontime) - SPN was found: $spn"; agentSendLogMessage "$(executiontime) - SPN was found: $spn"; $script:spnerror = $true }
			"$false" { }
		}
		Add-Content -Path $logfile "$(executiontime) - SPN successfully removed: $spn"
		agentSendLogMessage "$(executiontime) - SPN successfully removed: $spn"
	}
    <#
    try
    {
	    ([ADSI]"WinNT://localhost/Administrators,group").Remove("WinNT://core.pimcocloud.net/svc_adaccess") | Out-Null
    }
    catch
    {
        Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	    agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
    }
    #>
}

agentSendLogMessage "Starting deprovision"
SQLdeprovisionScript

Add-Content -Path $logfile "Node deprovisioned"
agentSendLogMessage "Deprovision complete"