﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/6/2016 8:48 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$tech = get-qadcomputer nb -SizeLimit 0
$tech += get-qadcomputer nb -SizeLimit 0

$tech = get-qadcomputer -osname "Windows 7*" -SizeLimit 0
New-Item -Type file -Path "c:\temp\ae2results.txt"
$file = "c:\temp\ae2results.txt"

foreach ($i in $tech)
{
	if (Test-Connection -ComputerName $($i.name) -Count 1 -Quiet)
	{
		if (ls \\$($i.name)\c$\temp\ae2setup.txt -ea 'SilentlyContinue')
		{
			#write-host "$($i.name) has logs"
			$username = (gwmi Win32_ComputerSystem -comp $i.name -ea 'SilentlyContinue').username
			Add-Content "AE2 script executed on: $username  - $($i.name)" -Path $file
			#cat \\$($i.name)\c$\temp\ae2setup.txt
		}
	}
}


### codesearch deploy ###

$a = "vma001p038", "vma001p039", "vma001p089"
foreach ($i in $a) { new-item -type directory -Path \\$i\e$\inetpub\codesearch-rewrite }

msdeploy -verb:sync -source:apphostconfig="codesearch-rewrite" -dest:apphostconfig="codesearch-rewrite", computername=vma001p038 -enableLink:AppPoolExtension -disableLink:ContentExtension

foreach ($i in $a) { cp e:\inetpub\codesearch-rewrite\web.config \\$i\e$\inetpub\codesearch-rewrite -whatif }

#remove bindings from old site pimco-rewrite-redirect
