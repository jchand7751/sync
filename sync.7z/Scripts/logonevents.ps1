﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/29/2015 10:26 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
function Get-LogonEvents
{
	param ($Computer = "localhost", $Days = 2)
	if ((Test-Connection -ComputerName $Computer -Count 1 -Quiet) -ne $true)
	{
		throw "$Computer is offline"
	}
	$oldestsecurityevent = get-winevent -LogName Security -Oldest -MaxEvents 1 -ComputerName $Computer
	#$Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[EventData[Data[@Name='LogonType'] and (Data='7') or (Data='2') or (Data='11') or (Data='10')]] and *[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624)]]</Select></Query></QueryList>" -Computername $computer
	$today = get-Date
	$cleanstart = $today.adddays(- $days)
	$datestart = Get-Date $cleanstart -UFormat "%Y-%m-%d"
	$uglydatestring = "TimeCreated[@SystemTime&gt;='$($datestart)T08:00:01.000Z'"
	try
	{
		$Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[EventData[Data[@Name='LogonType'] and (Data = '7') or (Data = '2') or (Data = '11') or (Data = '10')]] and *[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624) and $($uglydatestring)]]]</Select></Query></QueryList>" -Computername $computer -ea 'Stop'
	}
	catch
	{
		Throw "No logons found on $Computer for the past $days days. Oldest event $($oldestsecurityevent.timecreated)"
	}
	foreach ($event in $Events)
	{
		#$event
		$object = "" | select User, Computer, LogonType, Date, Time, OldestEventDate
		$object.oldesteventdate = ($oldestsecurityevent.timecreated).toshortdatestring()
		$object.date = ($event.timecreated).toshortdatestring()
		$object.time = ($event.timecreated).toshorttimestring()
		$object.computer = $event.properties[11].value
		$object.user = $event.properties[5].value
		$logontype = $event.properties[8].value
		switch ($logontype)
		{
			"11" { $object.logontype = "Cached login" }
			"10" { $object.logontype = "Remote login" }
			"7" { $object.logontype = "Unlock" }
			"2" { $object.logontype = "Local login" }
			"3" { $object.logontype = "Network login" }
		}
		$object
	}
}
Get-LogonEvents