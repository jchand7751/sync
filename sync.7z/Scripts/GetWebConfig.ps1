﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/13/2016 10:35 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
Import-Module WebAdministration
cd iis:\sites\
cd root
$webarray = (ls) | foreach { $_.pspath -replace "WebAdministration::\\\\VMH001D020\\Sites\\root\\" }
#$webarray = @()
#$webarray = ""
foreach ($item in $webarray)
{
	$object = "" | select Location, AnonymousAuthEnabled, WindowsAuthEnabled, UseAppPoolCredentials
	$object.Location = $item
	$object.AnonymousAuthEnabled = (Get-WebConfigurationProperty -PSPath "MACHINE/WEBROOT/APPHOST/root" -filter /system.WebServer/security/authentication/AnonymousAuthentication -location $item -Name Enabled).value
	$object.WindowsAuthEnabled = (Get-WebConfigurationProperty -PSPath "MACHINE/WEBROOT/APPHOST/root"  -filter /system.WebServer/security/authentication/windowsAuthentication -location $item -Name Enabled).value
	$object.UseAppPoolCredentials = (Get-WebConfigurationProperty -PSPath "MACHINE/WEBROOT/APPHOST/root"  -filter /system.WebServer/security/authentication/windowsAuthentication -location $item -Name useAppPoolCredentials).value
	$object
}


Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -location 'root/bulletinboardapi' -filter "system.webServer/security/authentication/anonymousAuthentication" -name "enabled" -value "True"
Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST/healthcheck' -filter "system.webServer/security/authentication/anonymousAuthentication" -name "enabled" -value "False"
