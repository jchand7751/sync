﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/10/2016 12:15 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Get-GPPermissions -Name "TEST - SybaseCheckNB" -All | foreach { Set-GPPermissions -Name "TEST - SybaseCheckNB" -PermissionLevel none -TargetName $_.trustee.name -TargetType computer; write-host "setting $($_.trustee.name) to none" }

Get-GPPermissions -Name "TEST - SybaseCheckNB" -All |

foreach ($i in $a)
{
	if ($i.trustee.sidtype -eq "Unknown")
	{
		Set-GPPermissions -Name "Applocker" -PermissionLevel none  -TargetType computer -whatif
	}
}