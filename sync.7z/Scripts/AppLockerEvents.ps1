﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	8/26/2015 3:34 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($computer)
Add-PSSnapin Quest.ActiveRoles.ADManagement
$array = @()
$events = Get-WinEvent -LogName "Microsoft-Windows-AppLocker/EXE and DLL" -comp $computer | select timecreated, userid, machinename, message
foreach ($event in $events)
{
	$object = "" | select TimeCreated, LoginName, Name, Title, Department, PC, ApplicationPath
	
	$objSID = New-Object System.Security.Principal.SecurityIdentifier($event.userid)
	$objUser = $objSID.Translate([System.Security.Principal.NTAccount])
	$object.loginname = $objUser.Value
	$eventmessagecleanup = ($event.message -replace " was allowed to run but would have been prevented from running if the AppLocker policy were enforced.", "")
	$eventmessagecleanup = $eventmessagecleanup -replace " was allowed to run."
	$object.ApplicationPath = $eventmessagecleanup
	$object.PC = $event.machinename
	$object.timecreated = $event.timecreated
	
	if ($script:ADdetails.samaccountname -eq ($object.loginname -split "\\")[1])
	{ }
	else
	{
		$script:ADdetails = Get-QADUser $object.loginname
	}
	$object.Name = $script:ADdetails.name
	$object.Title = $script:ADdetails.title
	$object.department = $script:ADdetails.department
	
	#$object
	
	if ($object.loginname -notlike "NT AUTHORITY\SYSTEM")
	{
		$array += $object	
	}
}
$array | Export-Csv c:\temp\applockerevents-$computer.csv