﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   1/10/2014 11:15 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

Add-PSSnapin Quest.ActiveRoles.ADManagement
Function logstamp {
Get-Date -UFormat %Y%m%d%H%M
}

function Log {
	param([string]$filename,[string]$text)
	if ($filename)
	{
		Out-File $filename -append -noclobber -inputobject "$(Invoke-Expression logstamp) - $text" -encoding ASCII
	}
}


Function LoggingSetup
{
	if ($CurrentExecutingPath.ToLower().contains("beta"))
	{
		$Script:CurrentScriptEnvironment = "Beta"
	}	
		elseif ($CurrentExecutingPath.ToLower().contains("development"))
		{
			$Script:CurrentScriptEnvironment = "Development"
		}
		elseif ($CurrentExecutingPath.ToLower().contains("production"))
		{
			$Script:CurrentScriptEnvironment = "Production"
		}
		else
		{
			$Script:CurrentScriptEnvironment = "Undetermined"
		}
	
	if ((Test-Path "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\") -eq $true)
	{
		Write-Host "Logging folder found, creating file"
		$Script:Logpath = "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\$($CurrentScriptName -replace '.ps1')-$script:executiontime.log"
		if ((Test-Path $Script:Logpath) -eq $true)
		{
			for ($x = 1 ; $checkit -eq $true ; $x++)
			{
				if (Test-Path ($script:Logpath + "-" + $x) -eq $true)
				{
					$checkit = $false
				}
				else
				{
					$checkit = $true
					$script:Logpath = $script:Logpath + "-" + $x
				}
			}
			
			$x = 0
			do {$script:Logpath = ($script:Logpath).trimend("-$x.log") ; $x++ ; $script:Logpath = ($script:Logpath).trimend(".log") + "-" + "$x.log"}
			until ((Test-Path $script:Logpath) -eq $false)
		}
		else
		{
			New-Item -Type File $Script:Logpath -ErrorAction Stop
		}
	}
	else
	{
		Write-Warning "No logging path found, script will NOT be logged"
		$Script:Logpath = $null
	}
}

function ExampleofLogging
{
	Connect-QADService imswest.sscims.com | out-string -Stream | foreach ($_) {Log $script:Logpath $_}
	Get-QADUser -SamAccountName z548410 | ft -AutoSize | out-string -Stream | foreach ($_) {Log $script:Logpath $_}
	Log $script:Logpath "Getting User"
}



#Define environment information
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$Script:ExecutionTime = logstamp
LoggingSetup
Write-Host ""
Write-Host ""
Write-Host "Full Script Path: "$FullScriptPath
Write-Host "Current Script Name: "$currentScriptName
Write-Host "Current Executing Path: "$currentExecutingPath
Write-Host "Current Script Environment: "$CurrentScriptEnvironment
Write-Host "Script Execution Date/Time: "$script:ExecutionTime
Write-Host "Script Logpath: "$script:Logpath
Write-Host ""
Write-Host "-------------------------------------------------------------------------------------"
Write-Host ""
Write-Host ""
ExampleofLogging


