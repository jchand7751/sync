﻿#=======================================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.28
# Created on:   1/23/2014 3:12 PM
# Created by:   Bryan Johnson
# Organization: State Street
# Filename:     StorageReport.ps1
# Parameters:
#				-VIServer <string[]>
#						Specifies the vCenter server to Connect to. Default is all
#						vCenter servers.
#
#				-ClusterFreeSpace <int[]>
#						Specifies the available free space filter for a single datastore
#						in a cluster. Default value is 400GB
#
# 				-PercentFree <int[]>
# 						Specifies the free space filter for local and shared datastores.
# 						Default value is 20%
#
# 				-OutputPath <string[]>
# 						Specifies the script output path. Default is C:\temp
#=======================================================================================

[CmdletBinding()]
param (
	   	[parameter(Position=0,
		HelpMessage=’VirtualCenter server to Connect to’)]
		[string]$VIServer = "all",
		
		[parameter(Position=1,
		HelpMessage=’Clusters with X free space on a single datastore’)]
		[int]$ClusterFreeSpace= "400",

		[parameter(Position=2,
		HelpMessage=’Datastores below X percent’)]
		[int]$PercentFree= "20",

		[parameter(Position=3,
		HelpMessage=’Output location’)]
		[string]$OutputPath = "C:\temp"
)

Function logstamp 
{
	#returns a padded timestamp string like 200705231132
	$now=Get-Date
	$yr=$now.Year.ToString()
	$mo=$now.Month.ToString()
	$dy=$now.Day.ToString()
	$hr=$now.Hour.ToString()
	$mi=$now.Minute.ToString()
	
	if ($mo.length -lt 2) {
	$mo="0"+$mo #pad single digit months with leading zero
	}
	
	if ($dy.length -lt 2) {
	$dy="0"+$dy #pad single digit day with leading zero
	}
	
	if ($hr.length -lt 2) {
	$hr="0"+$hr #pad single digit hour with leading zero
	}
	
	if ($mi.length -lt 2) {
	$mi="0"+$mi #pad single digit minute with leading zero
	}
	
	write-output $yr$mo$dy$hr$mi
}

function Log 
{
	param([string]$filename,[string]$text)
	if ($filename)
	{
		Out-File $filename -append -noclobber -inputobject "$(Invoke-Expression logstamp) - $text" -encoding ASCII
	}
}

Function LoggingSetup
{
	if ($CurrentExecutingPath.indexof("Beta") -ne -1)
	{
		$Script:CurrentScriptEnvironment = "Beta"
	}	
		elseif ($CurrentExecutingPath.indexof("Experimental") -ne -1)
		{
			$Script:CurrentScriptEnvironment = "Experimental"
		}
		elseif ($CurrentExecutingPath.indexof("Production") -ne -1)
		{
			$Script:CurrentScriptEnvironment = "Production"
		}
		else
		{
			$Script:CurrentScriptEnvironment = "Undetermined"
		}
	
	if ((Test-Path "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\") -eq $true)
	{
		Write-Host "Logging folder found, creating file"
		$Script:Logpath = "$(-join $currentExecutingPath[0..((-join ($currentExecutingPath[0..($currentExecutingPath.LastIndexOf("\") -1)])).lastindexof("\") - 1)])\Logging\$($CurrentScriptName -replace '.ps1')-$script:executiontime.log"
		New-Item -Type File $Script:Logpath -ErrorAction Stop
	}
	else
	{
		Write-Warning "No logging path found, script will NOT be logged"
		$Script:Logpath = $null
	}
}

function TestSnapin
{
	# Check for Vmware snapin
	Log $script:Logpath "Check for Vmware snap-in"
	$testsnapin = Get-PSSnapin | where {$_.name -like "VMware*"}
	if ($testsnapin)
	{
		Log $script:Logpath "Vmware snap-in already added"
	}
	    else
		{
			Add-PSSnapin VMware.VimAutomation.Core
			Log $script:Logpath "Vmware snap-in added"
	    }
}

function ConnectVIServer
{
	# Connect to the vCenter server specified by the VIServer parameter and retrieve all clusters.
	switch ($VIServer) 
	{
		"ina041pv" 
		{
			if ($DefaultVIServer)
			{
				Disconnect-VIServer * -Force -Confirm:$false
			}
			Log $script:Logpath "Connecting to the vCenter server $VIServer"
			connect-viserver ina041pv | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
			$Clusters = Get-View -viewtype ClusterComputeResource
			foreach ($Cluster in $Clusters)
			{
				Report $Cluster
			}		
		}
		"ina000pv" 
		{
			if ($DefaultVIServer)
			{
				Disconnect-VIServer * -Force -Confirm:$false
			}
			Log $script:Logpath "Connecting to the vCenter server $VIServer"
			connect-viserver ina000pv | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
			$Clusters = Get-View -viewtype ClusterComputeResource
			foreach ($Cluster in $Clusters)
			{
				Report $Cluster
			}
		}
		"vma000v51vc" 
		{
			if ($DefaultVIServer)
			{
				Disconnect-VIServer * -Force -Confirm:$false
			}
			Log $script:Logpath "Connecting to the vCenter server $VIServer"
			connect-viserver vma000v51vc | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
			$Clusters = Get-View -viewtype ClusterComputeResource
			foreach ($Cluster in $Clusters)
			{
				Report $Cluster
			}
		}
		"vma0b0v51vc" 
		{
			if ($DefaultVIServer)
			{
				Disconnect-VIServer * -Force -Confirm:$false
			}
			Log $script:Logpath "Connecting to the vCenter server $VIServer"
			connect-viserver vma0b0v51vc | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
			$Clusters = Get-View -viewtype ClusterComputeResource
			foreach ($Cluster in $Clusters)
			{
				Report $Cluster
			}
		}
		"ina0z0pv" 
		{
			if ($DefaultVIServer)
			{
				Disconnect-VIServer * -Force -Confirm:$false
			}
			Log $script:Logpath "Connecting to the vCenter server $VIServer"
			connect-viserver ina0z0pv | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
			$Clusters = Get-View -viewtype ClusterComputeResource
			foreach ($Cluster in $Clusters)
			{
				Report $Cluster
			}
		}
		"all" 
		{
			$VIServers = "ina000pv", "vma000v51vc", "vma0b0v51vc", "ina041pv"
			foreach ($VIServer in $VIServers) 
			{
				Log $script:Logpath "Connecting to the vCenter server $VIServer"
				if ($DefaultVIServer)
				{
					Disconnect-VIServer * -Force -Confirm:$false
				}
				connect-viserver $VIServer | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
				$Clusters = Get-View -viewtype ClusterComputeResource
				foreach ($Cluster in $Clusters)
					{
						Report $Cluster
					}
			}
		}
		default 
		{
			$VIServers = "ina000pv", "vma000v51vc", "vma0b0v51vc", "ina041pv"
			foreach ($server in $VIServers) 
			{
				Log $script:Logpath "Connecting to the vCenter server $VIServer"
				if ($DefaultVIServer)
				{
					Disconnect-VIServer * -Force -Confirm:$false
				}
				connect-viserver $server | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
				$Clusters = Get-View -viewtype ClusterComputeResource
					foreach ($global:Cluster in $Clusters)
					{
						Report $Cluster
					}
			}
		}
	}
}

function Report 
{
	# For each cluster determine  all datastores and split them into local and shared.
	Param ($Cluster)
	$clustername = $cluster.name
	Log $script:Logpath "Determining local and shared datastores in cluster $clustername"
	$datastores = $Cluster.datastore
	$script:sdatastores = @()
	$script:localdatastores = @()
	
	foreach ($db in $datastores) 
	{
		if (((get-view $db).host).count -gt 1)
		{
			$script:sdatastores += $db
		}
		else
		{
			$script:localdatastores += $db
		}
	}
	Log $script:Logpath "Collecting local datastore details for cluster $clustername"
	LocalDatastores $localdatastores
	Log $script:Logpath "Collecting shared datastore details for cluster $clustername"
	SharedDatastores $sdatastores
}

function SharedDatastores
{
	# Determine shared datastore details
	Param($sdatastores)
	foreach ($i in $sdatastores)
    {
		$object = "" | select Cluster, Datastore, SizeGB, FreeSpace, FreeSpaceGB, Percentfree
		$object.Cluster = $Cluster.name
	    $object.Datastore = (Get-view $i).name
		[decimal]$object.FreeSpaceGB = ("{0:N0}" -f (((Get-view $i).summary).freespace/1GB))
		$SizetoCheck = (((Get-view $i).summary).freespace/((Get-view $i).summary).capacity)
		$object.SizeGB = ("{0:N0}" -f (((Get-view $i).summary).capacity/1GB))
		$DatastorePercentage = ("{0:P1}" -f $SizetoCheck)
		$object.FreeSpace = $datastorepercentage
		[decimal]$object.Percentfree = ("{0:N1}" -f ($SizetoCheck *100))
		$script:reportshared += $object | select Cluster, Datastore, SizeGB, FreeSpaceGB, FreeSpace, Percentfree
	}
}

function LocalDatastores
{
	# Determine local datastore details
	Param($localdatastores)
	foreach ($i in $localdatastores)
    {
		$object = "" | select Cluster, Host, Datastore, SizeGB, FreeSpace, FreeSpaceGB, Percentfree
		$object.Cluster = $Cluster.name
	    $object.Datastore = (Get-view $i).name
		[decimal]$object.FreeSpaceGB = ("{0:N0}" -f (((Get-view $i).summary).freespace/1GB))
		$esxhost = (Get-view $i).host | foreach{$_.key}
		$object.Host = (Get-View $esxhost).name
		$SizetoCheck = (((Get-view $i).summary).freespace/((Get-view $i).summary).capacity)
		$object.SizeGB = ("{0:N0}" -f (((Get-view $i).summary).capacity/1GB))
		$DatastorePercentage = ("{0:P1}" -f $SizetoCheck)
		$object.FreeSpace = $datastorepercentage
		[decimal]$object.Percentfree = ("{0:N1}" -f ($SizetoCheck *100))
		$script:reportlocal += $object | select Cluster, Host, Datastore, SizeGB, FreeSpaceGB, FreeSpace, Percentfree
	}
}

function ClusterSpace 
{
	# Determine clusters with less than the space specified by the -ClusterFreeSpace parameter on a single datastore. Default value is 400GB
	Param ($ClusterFreeSpace)
	Log $script:Logpath "Determining clusters with less than $percentfree % free space on a single datastore."
	$clusterspacelt = $script:reportshared | where{[int]$_.freespacegb -le $ClusterFreeSpace} 
	$clusterspacegt = $script:reportshared | where{[int]$_.freespacegb -gt $ClusterFreeSpace -and $_.datastore -notlike "*Websense*"} 
	$clusterspacelt = $clusterspacelt | select -uniq cluster
	$clusterspacegt = $clusterspacegt | select -uniq cluster
	$lessthan = @()
	$graterthan = @()
	foreach ($i in $clusterspacelt)
	    {
	    $lessthan += $i.cluster
	}
	foreach ($i in $clusterspacegt)
	    {
	    $graterthan += $i.cluster
	}
	$compare = Compare-Object $lessthan $graterthan
	$clusterspace = @()
	foreach ($i in $compare)
	    {
	    if ($i.sideindicator -eq "<=")
	        {
	        $clusterspace += $i.inputobject
	        }
	    }
	[array]$criticalclusters = Get-Content $outputpath\CriticalClusters.txt
	$comparecritical = Compare-Object $criticalclusters $clusterspace -IncludeEqual
	$criticalclusterspace = @()
	foreach ($i in $comparecritical)
	    {
	    if ($i.sideindicator -eq "==")
	        {
	        $criticalclusterspace += $i.inputobject
	        }
	    }
	$object = "" | select Cluster
	$script:clusterspacelt400 = @()
	foreach ($i in $criticalclusterspace ) {
		$object.cluster = $i
		$script:clusterspacelt400 += $object | select Cluster
	}
}

function StorageRequest
{
	# Determining if a storage request was sent in the last 7 days
	param($clusters)
	foreach ($cluster in $clusters)
	{
		[string]$clustername = $cluster.cluster
		Log $script:Logpath "Determining if a storage request was sent in the last 7 days for cluster $clustername."
		if (Test-Path ("\\vma000p014\e$\Scripts\StorageReport\StorageRequests\Storage_Request_$clustername"+"_Auto.xls"))
		{
			$file = Get-Item ("\\vma000p014\e$\Scripts\StorageReport\StorageRequests\Storage_Request_$clustername"+"_Auto.xls")
			if ($file.LastWriteTime -lt (get-date).adddays(-7))
			{
				EmailStorageRequest $clustername
			}
			Else
			{
				$filedate = ($file.LastWriteTime).ToShortDateString()
				$script:clusterspacelt400 | Where{$_.cluster -eq "$clustername"} | Add-Member -MemberType 'NoteProperty' -Name "StorageRequested" -Value "$filedate"
				Log $script:Logpath "Last storage request for cluster $clustername was sent on $filedate"
			}
		}
		else 
		{
			EmailStorageRequest $clustername
		}
	}
}

function EmailStorageRequest
{
	# Create and email storage requests
	param ($clustername)
	Log $script:Logpath "Create and email storage request for $clustername."
	$date = (get-date).ToShortDateString()
	if ($VIServer -eq "all")
	{
		Connect-VIServer "ina000pv", "vma000v51vc", "vma0b0v51vc", "ina041pv"  | out-string -Stream | foreach{ $_ | Log $script:Logpath $_}
	}
	$esx_hostname = ((Get-Cluster $clustername | get-vmhost)[0]).name
	$lun = Get-ScsiLun -VmHost $esx_hostname | foreach{$_.runtimename}
	$luns = @()
	foreach ($i in $lun)
	{
		$lunid = ($i -split ":")[3] -replace "L"
		$luns += [int]$lunid
	}
	$previous = 0
	$luns2 = $luns | sort | select -Unique
	foreach ($id in $luns2)
	{
		if ($id.CompareTo($previous+1).Equals(1))
		{
			$new_lunid = $previous+1
			break # no need to search anymore
		}
		$previous = $id
	}
	if (!$new_lunid)
	{
		$new_lunid = $id+1
	}
					
	$xl = New-Object -ComObject Excel.Application
	$xl.DisplayAlerts = $false
	$xl.Visible = $false
	$wb = $xl.WorkBooks.Open("\\vma000p014\e$\Scripts\StorageReport\Storage_Request_$clustername.xls")
	$ws = $wb.WorkSheets.item(1)
	$ws.Cells.Item(4,3) = $date
	$ws.Cells.Item(32,3) = $new_lunid
	$wb.SaveAs("\\vma000p014\e$\Scripts\StorageReport\StorageRequests\Storage_Request_$clustername"+"_Auto.xls")
	$xl.Quit()
	[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl) | out-null
	
	Start-Sleep -Seconds 5
	$body = "Please process the attached storage request. This is to maintain available storage for growth in the $clustername cluster."
	$from = "ITMicrosoftServerTeam-DL@statestreet.com"
	#$to = "ITMicrosoftServerTeam-DL@statestreet.com"
	$to = "bryan.johnson@statestreet.com"
	#$cc = "ITMicrosoftServerTeam-DL@statestreet.com"
	$subject = "Storage Request - $clustername"
	$attachment = ("\\vma000p014\e$\Scripts\StorageReport\StorageRequests\Storage_Request_$clustername"+"_Auto.xls")
	Send-MailMessage -From $from -To $to -Cc $cc -smtpserver "mailhost.pimco.com" -Subject $subject -Body "$Body" -Attachments $attachment
	Log $script:Logpath "Storage Request for $clustername sent To: $to, Cc: $cc"
	$script:clusterspacelt400 | Where{$_.cluster -eq "$clustername"} | Add-Member -MemberType 'NoteProperty' -Name "StorageRequested" -Value "$date"
}

function EmailReport
{
	# Filter the local and shared datastore reports by the value of the -Percentfree parameter and email the report. Default value is 20%
	Param($ClusterFreeSpace, $Percentfree)
	Log $script:Logpath "Build and email the alert report"
	$style = "<style>"
	$style = $style + "BODY{background-color:white;}"
	$style = $style + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
	$style = $style + "TH{border-width: 1px;padding:3px;border-style: solid;border-color: black;background-color:#58ACFA}"
	$style = $style + "TD{border-width: 1px;padding:3px;border-style: solid;border-color: black;background-color:White}"
	$style = $style + "</style>"

	$space = "<H2>Clusters with less than " + $ClusterFreeSpace + "GB storage on a single datastore:</H2>"
	$space2 = $script:clusterspacelt400 | sort Cluster | select Cluster, StorageRequested | ConvertTo-Html -Fragment
	$title = "<H2>Local datastores with less than " + $Percentfree + "% free space:</H2>" 
	$table = $script:reportlocal | sort Percentfree | where{[decimal]$_.Percentfree -lt $Percentfree} | select Cluster, Host, Datastore, SizeGB, FreeSpaceGB, FreeSpace | ConvertTo-Html -Fragment
	$title2 = "<H2>NFS/SAN datastores with less than " + $Percentfree + "% free space:</H2>" 
	$table2 = $script:reportshared | sort Percentfree | where{[decimal]$_.Percentfree -lt $Percentfree}  | select Cluster, Datastore, SizeGB, FreeSpaceGB, FreeSpace | ConvertTo-Html -Fragment
		
	$style | Out-File $outputpath\report.htm
	ConvertTo-Html -Body "$space $space2 $title $table $title2 $table2" |  Out-File $outputpath\report.htm -Append
	
	$body = Get-Content $outputpath\report.htm
	$from = "StorageAlertReport@IMSWest-Vmware.com"
	$to = "ITMicrosoftServerTeam-DL@statestreet.com"
	#$to = "bryan.johnson@statestreet.com"
	$subject = "VMware Storage Alert Report"
	Send-MailMessage -From $from -To $to -smtpserver "mailhost.pimco.com" -Subject $subject -Body "$Body" -BodyAsHtml 
	Log $script:Logpath "Report sent to $to"
}

#Define environment information
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$Script:ExecutionTime = logstamp
LoggingSetup
Write-Host ""
Write-Host ""
Write-Host "Full Script Path: "$FullScriptPath
Write-Host "Current Script Name: "$currentScriptName
Write-Host "Current Executing Path: "$currentExecutingPath
Write-Host "Current Script Environment: "$CurrentScriptEnvironment
Write-Host "Script Execution Date/Time: "$script:ExecutionTime
Write-Host "Script Logpath: "$script:Logpath
Write-Host ""
Write-Host "-------------------------------------------------------------------------------------"
Write-Host ""
Write-Host ""

#Start of script
Log $script:Logpath "VIServer = $VIServer"
Log $script:Logpath "ClusterFreeSpace = $ClusterFreeSpace"
Log $script:Logpath "PercentFree = $PercentFree"
Log $script:Logpath "OutputPath = $OutputPath"
$script:reportlocal = @()
$script:reportshared = @()	
TestSnapin
ConnectVIServer $VIServer
ClusterSpace $ClusterFreeSpace
#StorageRequest $script:clusterspacelt400
EmailReport $ClusterFreeSpace $Percentfree
$script:reportlocal | Export-Csv $outputpath\reportlocal.csv
$script:reportshared | Export-Csv $outputpath\reportshared.csv
$script:clusterspacelt400 | Export-Csv $outputpath\clusterspacelt400.csv
Log $script:Logpath "Export datastore details to $outputpath"
Log $script:Logpath "Script complete"
Log $script:Logpath "Error details..."
$error | out-string -Stream | foreach ($_) {Log $script:Logpath $_}
