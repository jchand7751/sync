﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   1/10/2014 11:15 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================


#Define environment information
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
if ($CurrentExecutingPath.indexof("Beta") -ne -1)
	{
	$CurrentScriptEnvironment = "Beta"
	}
	elseif ($CurrentExecutingPath.indexof("Experimental") -ne -1)
		{
		$CurrentScriptEnvironment = "Experimental"
		}
	elseif ($CurrentExecutingPath.indexof("Production") -ne -1)
		{
		$CurrentScriptEnvironment = "Production"
		}

#Test-Path \\nasprod\Systems\Common\IT\Technology Operations\Microsoft Server Team\Powershell\Scripts\Beta	
$fullPathIncFileName
$currentScriptName
$currentExecutingPath
$CurrentScriptEnvironment
#}

Write-Host "Log test"
#logging