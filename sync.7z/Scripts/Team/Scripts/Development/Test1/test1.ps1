﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   1/14/2014 10:21 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Write-Host "Test script - Experimental, no parameters"