# dot-source all function files
Get-ChildItem -Path $PSScriptRoot\*.ps1 | Foreach-Object{ . $_.FullName }

# Export all commands in BaseModule folder
Export-ModuleMember -Function @(Get-Command -Module $ExecutionContext.SessionState.Module)