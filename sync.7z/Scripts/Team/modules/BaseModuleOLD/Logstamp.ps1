﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   2/13/2014 10:29 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Function logstamp 
{
	Get-Date -UFormat %Y%m%d%H%M
}
