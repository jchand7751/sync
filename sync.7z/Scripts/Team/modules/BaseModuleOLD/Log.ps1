﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   2/13/2014 10:28 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
function Log {
	param([string]$filename,[string]$text)
	if ($filename)
	{
		Out-File $filename -append -noclobber -inputobject "$(Invoke-Expression logstamp) - $text" -encoding ASCII
	}
}