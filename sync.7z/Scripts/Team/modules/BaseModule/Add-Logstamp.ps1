﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   2/13/2014 10:29 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Function logstamp 
{
	[CmdletBinding()]
	Param
	(
   		[Parameter(Mandatory=$false,Position=1,ParameterSetName='Location1')]
		[switch]$Script,
		[Parameter(Mandatory=$false,Position=1,ParameterSetName='Location1')]
		[switch]$File
	)
	if ($File)
	{
		switch ($File)
		{
			default {Get-Date -UFormat %Y-%m-%d-%H%M}
		}
	}
	
	if ($script)
	{
		switch ($script)
		{
			default {Get-Date -format hh:mm:ss}
		}
	}
}
