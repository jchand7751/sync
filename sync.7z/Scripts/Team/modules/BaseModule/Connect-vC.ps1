﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.48
	 Created on:   	4/1/2014 12:35 PM
	 Created by:   	Dean Rose 
	 Organization: 	State Street IMS 
	 Filename:     	Connect-vC.ps1
	===========================================================================
	.DESCRIPTION
		This cmdlet connects the user to the specified vCenter server in a powershell/powerCLI session.
#>
	Function Connect-vC {
	Param(
	[Parameter(Mandatory=$true,ValueFromPipeline=$true,Position=0,HelpMessage="vCenter that ESX host is managed by")]
	[string[]]$vCenter="ina000pv.imswest.sscims.com"
	)
	
		if ($vCenter) {
			if ($defaultviservers) {
				Disconnect-VIServer * -Confirm:$false
				Connect-VIServer $vCenter
			} else {
				Connect-VIServer $vCenter
			}
		} else {
			Write-Warning "vCenter NOT specified!"
			exit
		}
	}
