﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   2/13/2014 10:28 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
function Log {
	param([string]$text)
	if ($global:Logpath -and $text)
	{
		Out-File $global:logpath -append -noclobber -inputobject "$(Invoke-Expression (logstamp -Script)) - $text" -encoding ASCII
	}
}