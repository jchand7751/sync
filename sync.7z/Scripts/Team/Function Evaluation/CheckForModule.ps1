function CheckForModule
{
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1,ParameterSetName='Location1')]
		[string]$ModuleName
	)
	$ModuleList = Get-Module -list
	$TestModule = $ModuleList | where {$_.name -eq $ModuleName}
	if ($TestModule)
	{
		$ModuleRunning = Get-Module -Name $ModuleName
		if ($ModuleRunning)
		{
			Log "$ModuleName is already loaded"
		}
		else
		{
			Import-Module -Name $ModuleName	
			Log "$ModuleName has been loaded"
		}
	}
	else
	{
		Write-Warning "The required module $modulename is not installed"
		Log "$ModuleName is not installed"
		exit
	}
}