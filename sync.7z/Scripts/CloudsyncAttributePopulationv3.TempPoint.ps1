﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	2/16/2017 12:03 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	CloudsyncAttributePopulation
	===========================================================================
	.DESCRIPTION
		Set the cloudsync AD attribute for users that are members of cloud groups (O365-*)
#>

#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '1')]
	[switch]$FullSync,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '2')]
	[switch]$DifferentialSync,
	
	[Parameter(Mandatory = $false, Position = 0, ParameterSetName = '3')]
	[string]$User
)
#endregion

#region Base variables and environment information
$logfile = "e:\scripts\logs\cloudsyncattribute.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays
#Differential group sync location
$differentialsynclocation = "e:\scripts\groupdata\"

#Array for cloud users
$script:cloudsyncusers = @()

#Array with User cloudsync values
$script:useractionarray = @()

#endregion

#region Script functions

function SetAttributes
{
	#Compare the cloudsync value from the array to the users current cloudsync value, if it doesn't match, set the new value
	foreach ($action in $script:useractionarray)
	{
		if ($action.cloudsyncvalue -ne ([ADSI]"LDAP://$($script:cloudsyncusers | where { $_ -eq $action.dn })").cloudsync)
		{
			Add-Log -Type 'Information' -Message "Mismatch on cloudsync attributes for $(([string]($action.dn -split ', ')[0..1] -replace 'CN=') -replace '\\ ', ', ') setting - '$($action.cloudsyncvalue)'"
			try
			{
				Set-QADUser -Identity $action.dn -Service pimco.imswest.sscims.com -ObjectAttributes @{ cloudsync = $action.cloudsyncvalue } -ea Stop | Out-Null
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set cloudsync attribute for $($action.dn)"
			}
		}
		else
		{
			Add-Log -Type 'Information' -Message "Attribute for $(([string]($action.dn -split ', ')[0..1] -replace 'CN=') -replace '\\ ', ', ') is already set"
		}
	}
}

function GetCloudGroups
{
	try
	{
		#Get all of the cloud groups
		$script:cloudsyncgroups = Get-QADGroup O365-* -Service pimco.imswest.sscims.com -ea 'Stop' -DontUseDefaultIncludedProperties -IncludedProperties AllMembers
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to get cloud groups" -Throw
	}
	$count = $($script:cloudsyncgroups).count
	Add-Log -Type 'Information' -Message "Found $count cloud groups"
	foreach ($group in $script:cloudsyncgroups)
	{
		if (Test-Path $differentialsynclocation\$($group.name).txt)
		{
			Remove-Item $differentialsynclocation\$($group.name).txt -Force
			$group.allmembers | Out-File $differentialsynclocation\$($group.name).txt -Force
		}
		else
		{
			$group.allmembers | Out-File $differentialsynclocation\$($group.name).txt -Force
		}
	}
}

function GetCloudUsers
{
	#Get all of the users in the cloud groups
	$script:cloudsyncusers = $script:cloudsyncgroups.allmembers
	#Just get a unique list of cloud users
	$script:cloudsyncusers = $script:cloudsyncusers | select -Unique
	$count = $($script:cloudsyncusers).count
	Add-Log -Type 'Information' -Message "Found $count cloud users"
}

function LookupAndSetCloudsync
{
	<#
	Loop through the cloud users find the cloud groups they are a member of, strip off the first characters of the group name (O365) and build the array that contains their
	samaccountname, email, and cloudsyncvalue
	#>
	$script:useractionarray = @()
	foreach ($user in $script:cloudsyncusers)
	{
		Add-Log -Type 'Information' -Message "Processing user $user"
		$object = "" | select cloudsyncvalue, DN
		#$user = Get-QADUser $user -DontUseDefaultIncludedProperties
		$object.DN = $user
		<#
		([ADSI]"LDAP://$user").memberof | foreach
		{
			$group = ([ADSI]"LDAP://$_")
			if ($group.name -like "o365-*")
			{
				$attributename = [string]($group.name -replace "O365-")
				#$object.samaccountname = $user.samaccountname
				#$object.email = $user.email
				if ($attributename)
				{
					$object.cloudsyncvalue = ($object.cloudsyncvalue + $attributename + "|")
				}
			}
		}
		#>
		$o365groups = @()
		$o365groups += ([ADSI]"LDAP://$user").memberof | foreach {
			$group = ([ADSI]"LDAP://$_")
			if ($group.name -like "o365-*")
			{
				[string]$group.name
			}
		}
		$o365groups = $o365groups | sort
		foreach ($group in $o365groups)
		{
			$attributename = ($group -replace "O365-")
			$object.cloudsyncvalue = ($object.cloudsyncvalue + $attributename + "|")
		}
		
		$object.cloudsyncvalue = ((($object.cloudsyncvalue).trimstart("")).trimend("|"))
		#$script:useractionarray += $object

		if ($object.cloudsyncvalue -ne ([ADSI]"LDAP://$($script:cloudsyncusers | where { $_ -eq $object.dn })").cloudsync)
		{
			Add-Log -Type 'Information' -Message "Mismatch on cloudsync attributes for $(([string]($object.dn -split ', ')[0..1] -replace 'CN=') -replace '\\ ', ', ') setting - '$($action.cloudsyncvalue)'"
			try
			{
				Set-QADUser -Identity $object.dn -Service pimco.imswest.sscims.com -ObjectAttributes @{ cloudsync = $object.cloudsyncvalue } -ea Stop | Out-Null
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to set cloudsync attribute for $($object.dn)"
			}
		}
		else
		{
			Add-Log -Type 'Information' -Message "Attribute for $(([string]($object.dn -split ', ')[0..1] -replace 'CN=') -replace '\\ ', ', ') is already set"
		}
	}
}

function ClearAttributes
{
	#Clear cloudsync values from disabled users and users that are no longer a member of any O365- groups
	try
	{
		$disabledusers = Get-QADUser -Service pimco.imswest.sscims.com -Disabled -IncludedProperties cloudsync -DontUseDefaultIncludedProperties -sizelimit 0
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to query Active Directory"
	}
	
	$disabledusers | foreach {
		if (($_ | Get-QADMemberOf -Name "O365-*" -Service pimco.imswest.sscims.com -ea 'Stop' -DontUseDefaultIncludedProperties) -eq $null -and $_.cloudsync -ne $null)
		{
			Add-Log -Type 'Information' -Message "$($_.samaccountname) has a cloudsync attribute of $($_.cloudsync) but is no longer a member of any AD groups, setting cloudsync value to null"
			try
			{
				Set-QADUser -Service pimco.imswest.sscims.com -Identity $_.samaccountname -ObjectAttributes @{ cloudsync = "" } -ea Stop | Out-Null
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to clear attribute!"
			}
		}
	}
	
	try
	{
		$formercloudusers = Get-QADUser -Service pimco.imswest.sscims.com -LdapFilter "(cloudsync=*)" -SizeLimit 0 -IncludedProperties cloudsync -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to query Active Directory"
	}
	
	$formercloudusers | foreach {
		if (($_ | Get-QADMemberOf -Name "O365-*" -Service pimco.imswest.sscims.com -ea 'Stop' -DontUseDefaultIncludedProperties) -eq $null -and $_.cloudsync -ne $null)
		{
			Add-Log -Type 'Information' -Message "$($_.samaccountname) has a cloudsync attribute of $($_.cloudsync) but is no longer a member of any AD groups, setting cloudsync value to null"
			try
			{
				Set-QADUser -Service pimco.imswest.sscims.com -Identity $_.samaccountname -ObjectAttributes @{ cloudsync = "" } -ea Stop | Out-Null
			}
			catch
			{
				Add-Log -Type 'Error' -Message "Failed to clear attribute!"
			}
		}
	}
}

function GetCloudUsersDifferential
{
	#Run only against the users that changed since the last full sync
	try
	{
		#Get the o365 groups from the last full sync
		$knowngroups = Get-ChildItem $differentialsynclocation -ea 'Stop'
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Can't read previous group membership, do a full sync or check permissions" -Throw
	}
	foreach ($group in $knowngroups)
	{
		try
		{
			#foreach last sync group get the previous members and compare to current group membership, if a change is detected process the account
			$lastsyncmembers = Get-Content $differentialsynclocation\$($group.name)
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Can't read previous group membership, do a full sync or check permissions" -Throw
		}
		try
		{
			$currentmembers = (Get-QADGroup -Service Pimco.imswest.sscims.com -Name $group.BaseName -ea Stop).members
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Can't find $($group.basename) in AD"
		}
		foreach ($member in $currentmembers)
		{
			if ($lastsyncmembers -notcontains $member)
			{
				#A member has been added to this group since the last full sync
				Add-Log -Type 'Information' -Message "$member has been added as a member of $($group.BaseName)"
				$script:cloudsyncusers += $member
			}
		}
		
		foreach ($member in $lastsyncmembers)
		{
			if ($currentmembers -notcontains $member)
			{
				#A member has been removed from this group since the last full sync
				Add-Log -Type 'Information' -Message "$member is no longer a member of $($group.BaseName)"
				$script:cloudsyncusers += $member
			}
		}
	}
	
	$script:cloudsyncusers = $script:cloudsyncusers | select -Unique
	$count = $($script:cloudsyncusers).count
	Add-Log -Type 'Information' -Message "Found $count cloud users"
}

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting script"
switch ($PsBoundParameters.keys)
{
	"User" {
		try
		{
			$script:cloudsyncusers += (Get-QADUser -Service pimco.imswest.sscims.com -SamAccountName $User -ea 'Stop').dn
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Couldn't find user $user" -Throw
		}
		PopulateActionArray
		SetAttributes
	}
	"FullSync" {
		GetCloudGroups
		GetCloudUsers
		PopulateActionArray
		SetAttributes
		ClearAttributes
	}
	"DifferentialSync" {
		GetCloudUsersDifferential
		PopulateActionArray
		SetAttributes
	}
}
Add-Log -Type 'Information' -Message "Script complete"
#endregion