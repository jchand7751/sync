﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/22/2017 6:31 PM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


#Import the module
try
{
	Import-Module -Name "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll"
}
catch
{
	Write-Warning "Module not installed, exiting"
}


$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP2)

#Get credentials
$Cred = Get-Credential

#Set the credentials
$service.Credentials = new-object Microsoft.Exchange.WebServices.Data.WebCredentials($($cred.getnetworkcredential().username), $($cred.getnetworkcredential().password), $($cred.getnetworkcredential().domain))

#$a = (($firesult | where { $_.displayname -eq "Yammer" }).extendedproperties)[5].value

$byte = [byte[]](2,0,0,0,1,0,0,0,33,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,46,0,0,0,104,0,116,0,116,0,112,0,115,0,58,0,47,0,47,0,100,0,115,0,109,0,97,0,105,0,108,0,46,0,112,0,105,0,109,0,99,0,111,0,46,0,99,0,111,0,109,0,47,0,115,0,115,0,101,0,97,0,114,0,99,0,104,0,47,0,0,0)

$foldername = "dinner3"

$Exch2 = new-object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(14047, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Binary)
$oFolder = new-object Microsoft.Exchange.WebServices.Data.Folder($service)
$oFolder.DisplayName = $FolderName
$ofolder.SetExtendedProperty($exch2, $byte)
$oFolder.Save([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::msgfolderroot)