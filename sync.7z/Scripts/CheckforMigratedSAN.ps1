﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.26
# Created on:   12/10/2013 2:14 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

Add-PSSnapin VMware.VimAutomation.Core

function buildinfoloop
{
Param ($allhosts)
foreach ($vmhost in $allhosts)
	{
	$c = (get-view $vmhost.configmanager.storagesystem).storagedeviceinfo.multipathinfo.lun | foreach {$_.path} | foreach {$_.transport.portworldwidename}
	$d =  $c | where {$_ -notlike ""}
	$d = $d | foreach {"{0:X0}" -f $_}
	$temparray = @()
	foreach ($i in $d) 
		{
		$checkforexisting = $temparray | where {$_ -eq $i}
		if ($checkforexisting) 
			{} 
			else 
				{
				$temparray += $i
				} 
		}
	$object = "" | select Cluster, Hostname, TargetWWNPaths
	$object.hostname = $vmhost.name
	$object.Cluster = (Get-View $vmhost.parent).name
	$object.TargetWWNPaths = [string]$temparray
	$object
	$script:finishedarray += $object
	}
}


$script:finishedarray = @()
$vcenters = "ina000pv", "vma000v51vc"
foreach ($vc in $vcenters)
	{
	Disconnect-VIServer * -Confirm:$false -Force
	Connect-VIServer $vc
	$allhosts = Get-View -viewtype hostsystem
	buildinfoloop $allhosts
	}
$script:finishedarray | Export-Csv c:\Temp\CheckForClusterSANMigration.csv

