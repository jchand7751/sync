﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/18/2017 5:27 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/notblah asdfa


$json | foreach { consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/$_.psobject.properties.name $_.psobject.properties.value }

$json

$properties = $json.psobject.properties.name
$id = $json.id
foreach ($property in $properties)
{
	$typenames = ($json.($property)).psobject.typenames
	$basetype = ($json.($property)).gettype().name
	#if (($typenames -contains "System.Array") -eq $true -or ($typenames -contains "System.Management.Automation.PSCustomObject") -eq $true)
	if ($basetype -eq "PSCustomObject")
	{
		### 2nd loop ###
		$topprop = $property
		$json2 = $json.$property
		$json2 = $json2 | ConvertTo-Json
		$json2 = $json2 | convertfrom-json
		$properties = $json2.psobject.properties.name
		foreach ($property in $properties)
		{
			$typenames = ($json2.($property)).psobject.typenames
			$basetype = ($json2.($property)).gettype().name
			#if (($typenames -contains "System.Array") -eq $true -or ($typenames -contains "System.Management.Automation.PSCustomObject") -eq $true)
			if ($basetype -eq "PSCustomObject")
			{
				### 3rd loop ###
				$nextprop = $property
				$json3 = $json2.$property
				$json3 = $json3 | ConvertTo-Json
				$json3 = $json3 | convertfrom-json
				$properties = $json3.psobject.properties.name
				foreach ($property in $properties)
				{
					$typenames = ($json3.($property)).psobject.typenames
					$basetype = ($json3.($property)).gettype().name
					#if (($typenames -contains "System.Array") -eq $true -or ($typenames -contains "System.Management.Automation.PSCustomObject") -eq $true)
					if ($basetype -eq "PSCustomObmect")
					{
						### 4th loop ###
						$nextnextprop = $property
						$json4 = $json3.$property
						$json4 = $json4 | ConvertTo-Json
						$json4 = $json4 | convertfrom-json
						$properties = $json4.psobject.properties.name
						foreach ($property in $properties)
						{
							$typenames = ($json4.($property)).psobject.typenames
							$basetype = ($json4.($property)).gettype().name
							#if (($typenames -contains "System.Array") -eq $true -or ($typenames -contains "System.Management.Automation.PSCustomObject") -eq $true)
							if ($basetype -eq "PSCustomObject")
							{
								### 5th loop ###
								$nextnextnextprop = $property
								$json5 = $json4.$property
								$json5 = $json5 | ConvertTo-Json
								$json5 = $json5 | convertfrom-json
								$properties = $json5.psobject.properties.name
								foreach ($property in $properties)
								{
									$typenames = ($json5.($property)).psobject.typenames
									$basetype = ($json5.($property)).gettype().name
									#if (($typenames -contains "System.Array") -eq $true -or ($typenames -contains "System.Management.Automation.PSCustomObject") -eq $true)
									if ($basetype -eq "PSCustomObject")
									{
										
									}
									else
									{
										Write-Host "Setting v1/cliqr/jobs/$id/$topprop/$nextprop/$nextnextprop/$nextnextnextprop/$property $($json5.$property)"
										consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$topprop/$nextprop/$nextnextprop/$nextnextnextprop/$property $json5.$property
									}
								}
								###############
							}
							else
							{
								Write-Host "Setting v1/cliqr/jobs/$id/$topprop/$nextprop/$nextnextprop/$property $($json4.$property)"
								consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$topprop/$nextprop/$nextnextprop/$property $json4.$property
							}
						}
						###############
					}
					else
					{
						Write-Host "Setting v1/cliqr/jobs/$id/$topprop/$nextprop/$property $($json3.$property)"
						consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$topprop/$nextprop/$property $json3.$property
					}
				}
				###############
			}
			else
			{
				Write-Host "Setting v1/cliqr/jobs/$id/$topprop/$property $($json2.$property)"
				consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$topprop/$property $json2.$property
			}
		}
		###############
	}
	elseif ($basetype -eq "Object[]")
	{
		$topprop = $property
		$json2 = $json.$property
		$json2 = $json2 | ConvertTo-Json
		$json2 = $json2 | convertfrom-json
		$properties = ($json2 | gm | where { $_.membertype -eq "noteproperty" }).name
		if (($json2.count) -gt 1)
		{
			for ($x = 0; $x -le ($json2.count); $x++)
			{
				foreach ($property in $properties)
				{
					$typenames = ($json2.($property[$x])).psobject.typenames
					$basetype = ($json2.($property[$x])).gettype().name
					#if (($typenames -contains "System.Array") -eq $true -or ($typenames -contains "System.Management.Automation.PSCustomObject") -eq $true)
					if ($basetype -eq "PSCustomObject")
					{
						### 3rd loop ###
						$nextprop = $property
						$json3 = $json2.$property[$x]
						$json3 = $json3 | ConvertTo-Json
						$json3 = $json3 | convertfrom-json
						$properties = $json3.psobject.properties.name
					}
					else
					{
						$multitopprop = $topprop + $x
						Write-Host "Setting v1/cliqr/jobs/$id/$multitopprop/$property $($json2.$property[$x])"
						consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$multitopprop/$property $json2.$property[$x]
					}
				}
			}
		}
		else
		{
			foreach ($property in $properties)
			{
				$typenames = ($json2.($property)).psobject.typenames
				$basetype = ($json2.($property)).gettype().name
				#if (($typenames -contains "System.Array") -eq $true -or ($typenames -contains "System.Management.Automation.PSCustomObject") -eq $true)
				if ($basetype -eq "PSCustomObject")
				{
					### 3rd loop ###
					$nextprop = $property
					$json3 = $json2.$property
					$json3 = $json3 | ConvertTo-Json
					$json3 = $json3 | convertfrom-json
					$properties = $json3.psobject.properties.name
				}
				else
				{
					Write-Host "Setting v1/cliqr/jobs/$id/$topprop/$property $($json2.$property)"
					consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$topprop/$property $json2.$property
				}
			}
		}
	}
	else
	{
		Write-Host "Setting v1/cliqr/jobs/$id/$property $($json.$property)"
		consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$property $json.$property
	}
}

$properties = $json.psobject.properties.name
$id = $json.id
foreach ($property in $properties)
{
	$currentpath = ""
	Loop $json $property $currentpath
}


function Loop
{
	param ($object, $property, $currentpath)
	#$object
	#$property
	$basetype = ($object.($property)).gettype().name
	if ($basetype -eq "PSCustomObject")
	{
		$object2 = $object.$property
		$object2 = $object2 | ConvertTo-Json
		$object2 = $object2 | convertfrom-json
		$properties = $object2.psobject.properties.name
		
		if ($currentpath -notlike "")
		{
			$currentpath = $currentpath + "/" + $property
		}
		else
		{
			$currentpath = $property
		}
		foreach ($property in $properties)
		{
			Loop $object2 $property $currentpath
		}
	}
	elseif ($basetype -eq "Object[]")
	{
		$object2 = $object.$property
		$object2 = $object2 | ConvertTo-Json
		$object2 = $object2 | convertfrom-json
		$properties = ($object2 | gm | where { $_.membertype -eq "noteproperty" }).name
		#hash table
		if ([string]$properties -eq "name value")
		{
			foreach ($item in $object2)
			{
				Write-Host "Setting v1/cliqr/jobs/$id/$currentpath/$($item.name) $($item.value)"
				consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$currentpath/$($item.name) $($item.value)
			}
		}
		else
		{
			if (($object2.count) -gt 1)
			{
				if ($currentpath -notlike "")
				{
					$currentpath = $currentpath + "/" + $property
				}
				else
				{
					$currentpath = $property
				}	
				for ($x = 0; $x -lt ($object2.count); $x++)
				{
					foreach ($property in $properties)
					{
						$property
						#Write-Host "On a multi object $($object2[$x]) $property $($currentpath + $x)"
						$specifiedobject = $object2[$x]
						Loop $specifiedobject $property $($currentpath + $x)
					}
				}
			}
			else
			{
				if ($currentpath -notlike "")
				{
					$currentpath = $currentpath + "/" + $property
				}
				else
				{
					$currentpath = $property
				}
				foreach ($property in $properties)
				{
					Loop $object2 $property $currentpath
				}
			}
		}
	}
	else
	{
		if ($currentpath -notlike "")
		{
			Write-Host "Setting v1/cliqr/jobs/$id/$currentpath/$property $($object.$property)"
			consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$currentpath/$property $object.$property
		}
		else
		{
			Write-Host "Setting v1/cliqr/jobs/$id/$property $($object.$property)"
			consulate --api-host pimcloudcmdb --api-port 80 kv set v1/cliqr/jobs/$id/$property $object.$property
		}
	}
}