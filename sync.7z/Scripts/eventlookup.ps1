﻿$Results = @()
$Computers = "C:\temp\Test.txt" ## Path of the server list as a input File
$ComputerList = Get-Content $Computers
#$Computer
ForEach ($Computer in $ComputerList)
{
	$oldestsecurityevent = get-winevent -LogName Security -Oldest -MaxEvents 1
	#$Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[EventData[Data[@Name='LogonType'] and (Data='7') or (Data='2') or (Data='11') or (Data='10')]] and *[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624)]]</Select></Query></QueryList>" -Computername $computer
	$today = get-Date
	$cleanstart = $today.adddays(-8)
	$datestart = Get-Date $cleanstart -UFormat "%Y-%m-%d"
	$uglydatestring = "TimeCreated[@SystemTime&gt;='$($datestart)T08:00:01.000Z'"
	$Events = Get-WinEvent -filterxml "<QueryList><Query Id='0' Path='Security'><Select Path='Security'>*[EventData[Data[@Name='LogonType'] and (Data = '7') or (Data = '2') or (Data = '11') or (Data = '10')]] and *[System[Provider[@Name='Microsoft-Windows-Security-Auditing'] and (EventID=4624) and $($uglydatestring)]]]</Select></Query></QueryList>" -Computername $computer
	foreach ($event in $Events)
	{
		$object = "" | select User, Computer, LogonType, Date, PCIPAddress, HostName
		$object.PCIPAddress = $event.properties[18].value
		$object.date = ($event.timecreated).toshortdatestring()
		$object.computer = $event.properties[11].value
		$object.user = $event.properties[5].value
		$logontype = $event.properties[8].value
		# $logontype = $env:clientname
		$HostName = [System.Net.Dns]::GetHostByAddress($event.properties[18].value).HostName
		##### got the host name as   nb-7-1230.pimco.imswest.sscims.com
		## but not able to add the column in CSV file for it
		$object.hostname = $hostname
		Write-Host $hostName
		
		
		switch ($logontype)
		{
			"11" { $object.logontype = "Cached login" }
			"10" { $object.logontype = "Remote login" }
			"7" { $object.logontype = "Unlock" }
			"2" { $object.logontype = "Local login" }
			"3" { $object.logontype = "Network login" }
		}
		$Results += $object
	}
	
}
$results
#$Results | export-csv C:\Users\anath\Desktop\Jim\LastLogOn\Test------.csv
#End