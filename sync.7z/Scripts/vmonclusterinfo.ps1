﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.23
# Created on:   10/24/2013 10:47 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Param ($cluster)
$allclusters = Get-view -viewtype clustercomputeresource

$selectedcluster = $allclusters | where {$_.name -eq $cluster}
Add-PSSnapin VMware.VimAutomation.Core
$array = @()
$credentialsIMS = Get-Credential imswest\
$credentialsPlat = Get-credential imsprod\
$vmhosts = Get-view -viewtype hostsystem
$hostlist = $selectedcluster.host


foreach ($i in $hostlist) 
	{
	$selected = get-view $i
	$vmsonhost = $selected.vm
	$clusterinfo = Get-View $selected.parent
	foreach ($vm in $vmsonhost)
		{
		$vmdetails = Get-view $vm
		$object = "" | select Cluster, Hostname, VMname, VMDescription, Managedby
		$object.cluster = $clusterinfo.name
		$object.hostname = (get-view $i).name
		$object.vmname = $vmdetails.name
        if ($vmdetails.guest.hostname | where {$_ -like "*.ims.lcl"})
            {
            write-host "Plat"
            $adstats = .\getadstatsfromname.ps1 $vmdetails.name $credentialsPlat
            }
            else
                {
		        $adstats = .\getadstatsfromname.ps1 $vmdetails.name $credentialsIMS
                }
        
		$object.VMDescription = $adstats.description
		$object.Managedby =  $adstats.managedby
		$object
		$array += $object
		}    
	}
    $array | export-csv c:\temp\$cluster-VMlist.csv
