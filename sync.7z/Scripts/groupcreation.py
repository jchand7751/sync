import os, sys, time
import requests, json
from requests.auth import HTTPBasicAuth

headers = {'Content-type': 'application/json'}

if TENANT == "cloud-techservices":
  print "Region setup: tenant is cloud-techservices"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-technologyserv_l'
  ADMINPASSW = '79A795B51117AF01'
  GROUPID = '6'

if TENANT == "cloud-fotech":
  print "Region setup: tenant is cloud-fotech"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-frontofficetec_m'
  ADMINPASSW = '5DB9F20074DD8A59'
  GROUPID = '7'

if TENANT == "cloud-tlc":
  print "Region setup: tenant is cloud-tlc"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-tradelegalcomp_C'
  ADMINPASSW = '4AB0340F5966EFF9'
  GROUPID = '8'

if TENANT == "cloud-cftech":
  print "Region setup: tenant is cloud-cftech"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-clientfacingte_H'
  ADMINPASSW = '1E06FFCF291DDB18'
  GROUPID = '9'

if TENANT == "cloud-pimcocommon":
  print "Region setup: tenant is cloud-pimcocommon"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-pimcocommon_G'
  ADMINPASSW = '031BC9BC59451B35'
  GROUPID = '10'

if TENANT == "cloud-analytics":
  print "Region setup: tenant is cloud-analytics"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-analytics_F'
  ADMINPASSW = 'A15088C9A3E2BF2F'
  GROUPID = '11'

if TENANT == "cloud-business":
  print "Region setup: tenant is cloud-business"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-businessfuncti_J'
  ADMINPASSW = 'E3F3753E5D12BAB9'
  GROUPID = '12'

if TENANT == "cloud-pmapps":
  print "Region setup: tenant is cloud-pmapps"
  #Use tenant admin to get the user's key
  ADMIN = 'cloud-pmapplications_K'
  ADMINPASSW = '799183C045731A09'
  GROUPID = '13'
  TENANTID = '15'

NewUserGroup={
    "description": "", 
    "name": "envadmingroup",
    "users": [
    {
        "id": "46"
    },
    {
        "id": "83"
    }
    ], 
    "roles": [
    {
        "id": "135"
    }
    ], 
    "tenantId": "%s" % (TENANTID)
}

#Stupid json conversion
json_data = json.dumps(NewUserGroup)

#Save the data to a json format
#json_data = json.loads(jsonstring)

#json_data = json.dumps(jsondata)


r = requests.post('https://10.155.6.21/v1/tenants/%s/groups' % (TENANTID), data=json_data, headers=headers, verify=False, auth=(ADMIN, ADMINPASSW))


TENANTDATA={
"tenants": [
{
	"name": "cloud-pmapps",
	"ADMIN": "cloud-pmapplications_K",
	"ADMINPASSW": "799183C045731A09",
	"GROUPID": "13",
	"TENANTID": "15",
	"ROLESID": "135"
},
{
	"name": "cloud-business",
	"ADMIN": "cloud-businessfuncti_J",
	"ADMINPASSW": "E3F3753E5D12BAB9",
	"TENANTID": "14",
	"ROLESID": "128"
},
{
	"name": "cloud-techservices",
	"ADMIN": "cloud-technologyserv_l",
	"ADMINPASSW": "79A795B51117AF01",
	"TENANTID": "6",
	"ROLESID": "72"
},
{
	"name": "cloud-fotech",
	"ADMIN": "cloud-frontofficetec_m",
	"ADMINPASSW": "5DB9F20074DD8A59",
	"TENANTID": "7",
	"ROLESID": "79"
},
{
	"name": "cloud-tlc",
	"ADMIN": "cloud-tradelegalcomp_C",
	"ADMINPASSW": "4AB0340F5966EFF9",
	"TENANTID": "9",
	"ROLESID": "93"
},
{
	"name": "cloud-cftech",
	"ADMIN": "cloud-clientfacingte_H",
	"ADMINPASSW": "1E06FFCF291DDB18",
	"TENANTID":"13",
	"ROLESID": "121"
},
{
	"name": "cloud-pimcocommon",
	"ADMIN": "cloud-pimcocommon_G",
	"ADMINPASSW": "031BC9BC59451B35",
	"TENANTID": "12",
	"ROLESID": "114"
},
{
	"name": "cloud-analytics",
	"ADMIN": "cloud-analytics_F",
	"ADMINPASSW": "A15088C9A3E2BF2F",
	"TENANTID": "10",
	"ROLESID": "100"
}
]
}

for tenant in TENANTDATA['tenants']:
    tenant['name']
    NewUserGroup={
    "description": "", 
    "name": "envadmingroup",
    "users": [
    ], 
    "roles": [
    {
        "id": "%s" % (tenant['ROLESID'])
    }
    ], 
    "tenantId": "%s" % (tenant['TENANTID'])
    }
    json_data = json.dumps(NewUserGroup)
    r = requests.post('https://10.155.6.21/v1/tenants/%s/groups' % (tenant['TENANTID']), data=json_data, headers=headers, verify=False, auth=(tenant['ADMIN'], tenant['ADMINPASSW']))
    r.text
