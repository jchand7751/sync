﻿#Create new user in a totally unsecure method
$hostsystem = hostname

function CreateSvc_Vagrant
{

$machine = [ADSI]"WinNT://$hostsystem"
$User = $machine.Create("User", "svc_vagrant")
$User.setpassword("Insecure1!")
$User.SetInfo()
$User.description = "vagrant service account"
$User.SetInfo()

#Add to local admin
([ADSI]"WinNT://$hostsystem/Administrators,group").Add("WinNT://$hostsystem/svc_vagrant")
}

function SetupService
{
    If (Test-Path "C:\vagrant\supportfiles\nssm")
    {
        try
        {
            #Check for the service
            Get-Service VagrantSvc -ErrorAction stop
        }
        catch
        {
            #Service not installed
            cd C:\vagrant\supportfiles\nssm\win64
            .\nssm.exe install VagrantSvc %SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe -executionpolicy bypass -file c:\vagrant\vms\mq\vagrantup.ps1
            .\nssm.exe set VagrantSvc ImagePath C:\vagrant\supportfiles\nssm\win64\nssm.exe
            .\nssm.exe set VagrantSvc DisplayName VagrantSvc
            .\nssm.exe set VagrantSvc Description "Vagrant VM Service"
            .\nssm.exe set VagrantSvc ObjectName .\svc_vagrant Insecure1!
        }
    }
    else
    {
        Write-Warning "NSSM not found on PC"

    }

}

New-Item -ItemType file C:\temp\vagrantlog.txt
Add-Content "Running user creation Script" -Path C:\temp\vagrantlog.txt

if ([ADSI]::Exists("WinNT://$hostsystem/svc_vagrant"))
{
Add-Content "User exists" -Path C:\temp\vagrantlog.txt
}
else
{
    Add-Content "Creating user" -Path C:\temp\vagrantlog.txt
    CreateSvc_Vagrant
}

SetupService