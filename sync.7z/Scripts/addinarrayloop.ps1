﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/23/2015 9:24 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$array = @()
foreach ($i in $a)
{
	$b = import-csv $i.fullname; foreach ($addin in $b)
	{
		$object = "" | select user, PC, title, fullname, type, enabled
		$object.title = $addin.title
		$object.fullname = $addin.fullname
		$object.type = $addin.type
		$object.enabled = $addin.enabled
		$object.user = (($i.name).split("-")[1]) -replace (".csv")
		$count = ($i.name).split("-").count - 1
		$object.PC = ([string]((($i.name).split("-")[2..$count]) -replace (".csv"))).replace(" ", "-")
		$array += $object
	}
}