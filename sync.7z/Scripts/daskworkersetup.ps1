﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/13/2017 2:56 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Base variables and environment information
$logfile = "c:\temp\DaskWorkerSetup.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$server = hostname
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
$reposource = "http://10.155.5.63:8080/"
$whoami = whoami

#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

#endregion

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

function EnableLogOnAsService
{
	param ($name)
	#Grant rights to logon as a service
	$Identity = $name
	$privilege = "SeServiceLogonRight"
	$CarbonDllPath = "c:\pimcloud\cliqr-scripts\windows\utils\Carbon.dll"
	Add-Log -Type Information -Message "Enabling local logon for $name"
	[Reflection.Assembly]::LoadFile($CarbonDllPath)
	[Carbon.Lsa]::GrantPrivileges($Identity, $privilege)
	Add-Log -Type Information -Message "Enabled local logon for $name"
	
}

function GiveAdminRights
{
	param ($local_name)
	#Give service account admin rights?
	try
	{
		Add-Log -Type Information -Message "Giving admin rights to: $local_name"
		([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$local_name") | Out-Null
		Add-Log -Type Information -Message "Gave admin rights to: $local_name"
	}
	catch
	{
		#Add-Content -Path $logfile "$(executiontime) - Failed to remove svc_adaccess to local admins group"
		#agentSendLogMessage "$(executiontime) - Failed to remove svc_adaccess to local admins group"
	}
	
}

function StartService
{
	param ($service_name, $user, $pass)
	
	Add-Log -Type Information -Message "Starting $service_name as $user"
	$Service = gwmi win32_service | where { $_.name -eq "$service_name" }
	$Service.Change($Null, $Null, $Null, $Null, $Null, $Null, "$user", $pass, $Null, $Null, $Null)
	$Service.StartService()
	Add-Log -Type Information -Message "Started $service_name"
}

function RegisterService
{
	param ($service_name, $executable, $logpath, $arguments)
	
	Add-Log -Type Information -Message "Registering service ${service_name}: ${executable}"
	#."C:\Program Files\osmosix\bin\nssm.exe" install "$service_name" %SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe -executionpolicy bypass -file "$executable"
	."C:\temp\nssm.exe" install "$service_name" $executable
	if ($logpath)
	{
		."c:\temp\nssm.exe" set "$service_name" AppStdout $logpath
		."C:\temp\nssm.exe" set "$service_name" AppStderr $logpath
	}
	if ($arguments)
	{
		."c:\temp\nssm.exe" set "$service_name" AppParameters $arguments
	}
	Add-Log -Type Information -Message "$service_name registered"
	cmd /c sc sdset "$service_name" "D:(A;; CCLCSWRPWPDTLOCRRC;;; SY)(A;; CCDCLCSWRPWPDTLOCRSDRCWDWO;;; BA)(A;; CCLCSWLOCRRC;;; IU)(A;; CCLCSWLOCRRC;;; SU)(A;; CCDCLCSWRPWPDTLOCRSDRCWDWO;;; RD)S:(AU; FA; CCDCLCSWRPWPDTLOCRSDRCWDWO;;; WD)"
}

function AdjustPassword
{
	param ($pass)
	$a = $pass -replace "\\\$", "$"
	return $a
}

function StopService
{
	param ($service_name)
	
	Add-Log -Type Information -Message "Starting $service_name as $user"
	$Service = gwmi win32_service | where { $_.name -eq "$service_name" }
	if ($Service -ne $null)
	{
		$Service.StopService()
	}
	Add-Log -Type Information -Message "Stop $service_name"
}

function SetupSybaseOdbc
{
	try
	{
		Get-OdbcDsn -Name "Sybase" -ErrorAction Stop
	}
	catch
	{
		Add-OdbcDsn -Name "Sybase" -DsnType "System" -DriverName "Adaptive Server Enterprise" -Platform "64-bit" -SetPropertyValue @("Server=trdbserver", "Port=5010")
	}
}

function ensure_tr_tas
{
	try
	{
		$tr_tas_ip = [System.Net.Dns]::GetHostAddresses("tr_tas")[0].IPAddressToString
	}
	catch
	{
		$tr_tas_ip = [System.Net.Dns]::GetHostAddresses("tr_tas.pimco.com")[0].IPAddressToString
		Add-Content  C:\Windows\System32\drivers\etc\hosts "`n$tr_tas_ip        tr_tas`n"
	}
}

function DaskEnvSetup
{
	
	if (Test-Path l:\logs\app\dask)
	{ }
	else
	{
		mkdir l:\logs\app\dask -Force
	}
	
	$env:PATH = $env:pithonbase + "\" + $env:pithonver + "\pithon;" + $env:PATH
	[Environment]::SetEnvironmentVariable('PATH', $env:PATH, 'Machine')
}

function CopyUpdateScript
{
	try
	{
		Add-Log -Type Information -Message "Copying Dask upgrade script to c:\temp"
		Copy-Item ($env:pithonbase + "\" + $env:pithonver + "\pithon\Scripts\UpgradeDaskService.ps1") c:\temp -Force
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to copy update script"
	}
}



Add-Log -Type Information -Message "Starting Dask worker setup"

if ((Get-Service -Name Dask*) -eq $null)
{
	if ($env:upgrade -eq "True")
	{
		Add-Log -Type Information -Message "Upgrade flag detected, using passed variables"
	}
	else
	{
		LoadCliqrEnvVariables
		Invoke-Expression $env:cliqrPythondaskworkerPreStartAction
		Invoke-Expression $env:cliqrPythondaskworkerPostStartAction
	}
	
	#Service account setup
	Import-Module cyberarkmoduletest
	#fix cyberark
	function GetCreds
	{
		Add-Log -Type 'Information' -Message "Starting credential loop"
		try
		{
			Connect-CyberArk -credentialfileuser "svc_iisadmin" -credentialfile "C:\pimcloud\cliqr-scripts\windows\utils\data\iisadmin.dat" -credentialkey "C:\pimcloud\cliqr-scripts\windows\utils\data\iisadmin.k"
		}
		catch
		{
			Add-Log -Type 'Warning' -Message "Failed to get authentication token"
		}
		if ($env:CliqrDepEnvName -eq "prod" -or $env:CliqrDepEnvName -eq "preprod")
		{
			if ($env:prod_svc_acct)
			{
				$script:service_account_fqdn = $env:prod_svc_acct
			}
		}
		else
		{
			if ($env:svc_acct)
			{
				$script:service_account_fqdn = $env:svc_acct
			}
		}
		
		$script:service_account = ($script:service_account_fqdn -split '\\')[-1]
		try
		{
			$accountid = (Get-CyberArkAccount -Accountname $script:service_account_fqdn -Safe "PIMCO_TechInfra").id
		}
		catch
		{
			Add-Log -Type 'Warning' -Message "Failed to query account from cyberark"
		}
		
		if ($accountid)
		{
			try
			{
				$script:service_password = Get-CyberArkCredential -Accountid $accountid
			}
			catch
			{
				Add-Log -Type 'Warning' -Message "Failed to pull credentials for $accountid from cyberark"
			}
		}
		else
		{
			Add-Log -Type 'Warning' -Message "Failed to find an account ID for the specified service account: $script:service_account_fqdn"
		}
	}
	
	#Get creds loop
	$credloop = 0
	do { sleep 5; GetCreds; $credloop++;  $credloop}
	until ($script:service_password -notlike $Null -or $credloop -ge 10)
	
	#prevent account lockout
	if ($script:service_password -like $null)
	{
		$script:service_account = $null
		$script:service_account_fqdn = $null
	}
	
	#Add users to remote desktop
	try
	{
		if ("$env:serviceadmingroup" -ne "")
		{
			([ADSI]"WinNT://localhost/Remote Desktop Users,group").Add("WinNT://pimco.imswest.sscims.com/$env:serviceadmingroup") | Out-Null
		}
	}
	catch
	{
		Add-Log -Type Error -Message "Failed to add $env:serviceadmingroup to remote desktop users group"
	}
	
	EnableLogOnAsService -name $script:service_account_fqdn
	GiveAdminRights -local_name $script:service_account
	
	$dask_scheduler = (ls env: | where { $_.name -like "*pythondaskscheduler*HOSTNAME*" }).value + ":8786"
	Add-Log -Type Information -Message "Configuring Dask Startup"
	DaskEnvSetup
	for ($x = 1; $x -le $env:workerinstances; $x++)
	{
		Add-Log -Type Information -Message "Configuring Dask Worker $x"
		#". $pithonFolder\Scripts\dask-worker.exe --nthreads 1 $dask_scheduler >c:\temp\dask_worker$x.out 2>&1" | Out-File $file -Append -Encoding Default
		RegisterService -service_name "DaskWorker_$x" -executable ($env:pithonbase + "\" + $env:pithonver + "\pithon\Scripts\dask-worker.exe") -logpath "l:\logs\app\dask\daskworker_$x.log" -arguments ("--nthreads 1" + " " + $dask_scheduler)
		StartService -service_name "DaskWorker_$x" -user $script:service_account_fqdn -pass $script:service_password
		Add-Log -Type Information -Message "Dask Worker $x Started"
	}
	CopyUpdateScript
	agentSendLogMessage "Worker setup complete"
	Add-Log -Type Information -Message "Dask Worker setup complete"
}
#endregion
