﻿Param ($servername)

#([adsi]"IIS://$servername/w3svc").children
try
{
	Test-Connection -Count 1 -Quiet $servername -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "$servername is offline"
	exit
}

try
{
	Test-Path \\$($machine.name)\c$ -ea 'Stop' | Out-Null
}
catch
{
	Write-Warning "No access to server $($machine.name)"
	exit
}

#IDs we can use
try
{
	$siteIDs = ((([adsi]"IIS://$servername/w3svc").children).path | foreach { ($_ -split "/")[4] })[3..999]
}
catch
{
	Write-Warning "$servername is missing IIS 6 management console, or IIS metabase and IIS 6 configuration compatibility"
	exit	
}


#$appdetails = ([adsi]"IIS://ina001p082/w3svc/6")
$array = @()
foreach ($id in $siteIDs)
{
    $appdetails = ([adsi]"IIS://$servername/w3svc/$id")
    $object = "" | select Server, Name, ParentSiteID, ParentSiteName, SiteID, LogDirectory, Path, Authentication, Bindings, AppPoolName, AppPool32bitEnabled, AppPoolCredential, AppPoolVersion, Type, Webconfig, IISPath

    $object.server = $servername
    $object.name = [string]$appdetails.servercomment
    $object.siteid = $appdetails.Name
    $bindings = foreach ($_ in (([adsi]"IIS://$servername/w3svc/$($object.siteid)").serverbindings))
{
    $temp = [string]$_ -split ":"
    for ($x = 0; $x -lt $temp.count ; $x++) 
    {
        if ($temp[$x] -like "") 
        {
            $temp[$x] = "*"
        } 
    } 
    $temp = ([string]$temp -replace " ","|") + ","
    $temp
    #$x
    #$temp.count
    #if ($x -ne ($temp.count + 1)) {$temp + ","} else {$temp}
    }
    #([string]$bindings).trimend(",")
    $bindings = (([string]$bindings).trimend(",")).replace(" ","")
    #$object.bindings = [string]$appdetails.serverbindings
    $object.bindings = $bindings
    $object.authentication = [string]$appdetails.NTAuthenticationProviders
    $object.logdirectory = [string]$appdetails.logfiledirectory + "\" + "W3SVC" + [string]$appdetails.name
    $object.path = ($appdetails.children).path[0]
    $object.appPoolname = [string](($appdetails.children | where {$_.path -eq $object.path}).AppPoolId)
    $apppoolspecs = ([adsi]"IIS://$servername/w3svc/APPPools/$($object.apppoolname)")
    $object.apppoolcredential = [string]$apppoolspecs.WAMUserName
    $object.appPoolversion = [string]$apppoolspecs.managedruntimeversion
    #shutdown timeout? 32bit?
    $object.AppPool32bitenabled = [string]$apppoolspecs.enable32bitapponwin64
    $object.type = "Root Site"
	$object.iispath = $object.name
    #Web.config
	try
	{
		$webconfig = ((((get-content "\\$servername\(($object.path).replace(":","`$"))\Web.config" -ea stop) -as [XML]).configuration)).appsettings.add
	}
	catch
	{
	}
	if ($webconfig)
	{
		$webconfigarray = @()
		foreach ($pair in $webconfig)
		{
			$stringpair = $pair.key + " : " + $pair.value + ","
			$webconfigarray += $stringpair
		}
		$webconfigarray = ([string]$webconfigarray).trimend(",")
		$object.webconfig = $webconfigarray
	}
	#$object
    $array += $object
    #$appdetails.children
    $sitechildren = ($appdetails.children | where {$_.path -eq $object.path}).children
    
    foreach ($application in $sitechildren)
    {
        $childobject = "" | Select Server, Name, ParentSiteID, ParentSiteName, SiteID, LogDirectory, Path, Authentication, Bindings, AppPoolName, AppPool32bitEnabled, AppPoolCredential, AppPoolVersion, Type, webconfig, IISPath
        
        $childobject.server = $servername
        $childobject.name = $application.name
        $childobject.ParentSiteID = $object.siteID
        $childobject.parentsitename = $object.name
        $childobject.logdirectory = $object.logdirectory
        $childobject.path = [string]$application.path
        $childobject.authentication = [string]$application.NTauthenticationproviders
        $childobject.apppoolname = [string]$application.apppoolid
        $apppoolspecs = ([adsi]"IIS://$servername/w3svc/APPPools/$($childobject.apppoolname)")
        $childobject.apppoolcredential = [string]$apppoolspecs.WAMUserName
        $childobject.appPoolversion = [string]$apppoolspecs.managedruntimeversion
        #shutdown timeout? 32bit?
        $childobject.AppPool32bitenabled = [string]$apppoolspecs.enable32bitapponwin64
		$childobject.type = "App"
		$childobject.iispath = $childobject.parentsitename + "/" + $childobject.name

        $webconfigpath = ($($childobject.path).replace(":","`$"))
		$stringwebconfigpath = "\\$servername\$webconfigpath"
		try
		{
			$webconfig = ((((get-content $stringwebconfigpath\Web.config -ea stop) -as [XML]).configuration)).appsettings.add
		}
		catch
		{
		}
		
		$webconfigarray = @()
		if ($webconfig)
		{
			foreach ($pair in $webconfig)
			{
				$stringpair = $pair.key + "|" + $pair.value + ","
				$webconfigarray += $stringpair
			}
			$webconfigarray = ((([string]$webconfigarray).Replace(" ", "")).trimend(",")).replace("|", "  |  ")
			$childobject.webconfig = $webconfigarray
		}
		#$childobject
        $array += $childobject
    }
}
$array