﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/12/2015 5:17 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$array = @()

$a = get-qaduser -includedproperties co, extensionattribute5 -sizelimit 0 | select lastname, firstname, samaccountname, title, department, city, email, phonenumber, l, co, manager, extensionattribute5, accountisdisabled
foreach ($i in ($a | where { $_.extensionattribute5 -eq "u" -and $_.accountisdisabled -eq $false }))
{
	$object = "" | select LoginID, LastName, FirstName, Title, Department, Manager, Office, Location, Country, Email, Phonenumber, UserType, AccountisDisabled
	$object.LastName = $i.lastname
	$object.FirstName = $i.firstname
	$object.LoginID = $i.samaccountname
	$object.Title = $i.title
	$object.Department = $i.department
	$object.Office = $i.city
	$object.Email = $i.email
	$object.Phonenumber = $i.phonenumber
	$object.location = $i.l
	$object.country = $i.co
	$object.accountisdisabled = $i.accountisdisabled
	$object.usertype = $i.extensionattribute5
	try
	{
		$TestManager = (get-qaduser ($i.manager)).name
		$object.Manager = $TestManager
	}
	Catch
	{
		$object.Manager = "Manager not found"
	}
	$array += $object
	$object
}
$array | export-csv c:\temp\larrylist.csv