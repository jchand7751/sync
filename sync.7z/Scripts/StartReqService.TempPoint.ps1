﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/4/2016 3:46 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$Username = ((whoami) -split "pimco\\")[1]
$searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(sAMAccountName=$Username))"
$searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com'
$user = $searcher.FindOne().GetDirectoryEntry()
$uevcheck = if ($user.memberof | where { $_ -like "CN=UEV_Users*" })
$appsensecheck = $user.memberof | where { $_ -like "*Appsense*" }

switch ($uevcheck)
{
	$true {
			if ((Get-Service -Name UevAgentService) -eq "Running")
			{
			
			}
	}
	$false { }
}
