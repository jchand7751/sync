﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/8/2016 11:27 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#Service type permissions
Add-Type  @"
   [System.FlagsAttribute]
   public enum ServiceAccessFlags : uint
   {
       QueryConfig = 1,
       ChangeConfig = 2,
       QueryStatus = 4,
       EnumerateDependents = 8,
       Start = 16,
       Stop = 32,
       PauseContinue = 64,
       Interrogate = 128,
       UserDefinedControl = 256,
       Delete = 65536,
       ReadControl = 131072,
       WriteDac = 262144,
       WriteOwner = 524288,
       Synchronize = 1048576,
       AccessSystemSecurity = 16777216,
       GenericAll = 268435456,
       GenericExecute = 536870912,
       GenericWrite = 1073741824,
       GenericRead = 2147483648
   }
"@

#get SDDL fir the service
$sddl = sc.exe \\$computer sdshow "AppSense Client Communications Agent"
#Translate SDDL
$rawsec = New-Object System.Security.AccessControl.RawSecurityDescriptor (($sddl | where { $_ }))

#Get the permissions for Domain users
$domainuserAcl = $rawsec.DiscretionaryAcl | where { $_.securityidentifier -eq "S-1-5-21-2241961287-1671099396-3952850847-513" }

#Convert access mask to real permissions
#[ServiceAccessFlags]983551
[ServiceAccessFlags] $domainuserAcl.accessmask