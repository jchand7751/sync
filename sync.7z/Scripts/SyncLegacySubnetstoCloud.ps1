﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	5/3/2017 11:48 AM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$credential = Get-Credential
$pimcolegacysubnets = Get-ADReplicationSubnet -Server vms001p6 -Credential $credential -Filter *
$pimcolegacysites = Get-ADReplicationSite -Server vms001p6 -Credential $credential -Filter *

foreach ($site in $pimcolegacysites)
{
	Write-Host "Creating $($site.name)"
	New-ADReplicationSite -Name $site.name
}

foreach ($subnet in $pimcolegacysubnets)
{
	$sitename = ($subnet.site -split ",")[0] -replace "CN="
	Write-Host "Creating $($subnet.name) and applying it to $sitename"
	New-ADReplicationSubnet -Name $subnet.name -Site $sitename
}


