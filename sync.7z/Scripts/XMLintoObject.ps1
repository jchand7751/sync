﻿[xml]$XML = get-content C:\temp\Test.xml

$ApplicationArray = @()
foreach ($Application in @($XML.Applications.childnodes.name)) 
{
    $PSObject = New-Object PSObject
    foreach ($Property in $XML.Applications.$Application.AppDetails.childnodes.name) 
    {
        $PSObject | Add-Member NoteProperty $Property $XML.Applications.$Application.AppDetails.$Property
    }
        $PSObject
        $ApplicationArray += $PSObject
}