﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   8/15/2013 2:38 PM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================



Write-Host "Press any key to continue ..."

$x = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")