﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/28/2015 1:24 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   	CliqrInjectSetup.ps1  	
	===========================================================================
	.DESCRIPTION
		Cliqr Environment Variable Setup Script.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer
)
#endregion

#region Base variables and environment information
$logfile = "c:\temp\CliqrBackgroundInit.txt"
$OSinitlogfile = "c:\temp\OSinit.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")

$server = hostname
$key = 203, 117, 112, 91, 119, 165, 146, 173, 140, 253, 20, 134, 174, 241, 213, 16
$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString -Key $key)
$credential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
$cliqrvars = Get-Content C:\temp\userenv.ps1
$clientrb = "C:\chef\client.rb"
$cliqrvariableslocation = "C:\temp\userenv.ps1"
$cliqrvariableslocationbackup = "C:\temp\userenv.ps1_bkp"
$reposource = "http://10.155.5.63:8080/"
$whoami = whoami
$datacenter = switch ($server[4])
{
	"3" { "irvine" }
	"h" { "newjersey" }
}
$deploymentenvironment = switch ($server[6])
{
	"s" { "sandbox" }
	"d" { "dev" }
	"b" { "beta" }
	"r" { "preprod" }
	"p" { "prod" }
}
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module BitsTransfer -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

function GrantAccessRights
{
	#Give user admin rights to sandbox
	#Need to run this as something else...won't have rights to query AD
	<#
	if ($env:cliqrdepEnvname -eq "sandbox")
	{
        Invoke-Command localhost {
	        $usersemail = ($env:launchUserName -split("_r"))[0] + "@pimco.com"
	        $searcher = [ADSISearcher]"(&(objectClass=User)(objectCategory=person)(mail=$usersemail))"
	        $searcher.SearchRoot = 'LDAP://pimco.imswest.sscims.com'
	        $user = $searcher.FindOne().GetDirectoryEntry()
	        $userlogin = $user.samaccountname
	        Add-Content -Path $logfile "$(executiontime) - Adding $userlogin to local admins group"
	        try
	        {
	            ([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://Pimco/$userlogin") | Out-Null
	        }
	        catch
	        {
	            Add-Content -Path $logfile "$(executiontime) - Failed to add $userlogin to local admins group"
	        }
        } -Credential $Credential -Authentication 'Credssp' -ea Stop
	}
	#>
	if ($env:cliqrdepEnvname -eq "sandbox")
	{
		Add-Log -Type Information -Message "Adding pimco\$($env:userExternalId) to local admins group"
		agentSendLogMessage "$(executiontime) - Adding pimco\$($env:userExternalId) to local admins group"
		try
		{
			([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$($env:userExternalId)") | Out-Null
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to add $userlogin to local admins group"
			agentSendLogMessage "$(executiontime) - Failed to add $userlogin to local admins group"
		}
	}
	
}

function LoadCliqrEnvVariables
{
	Add-Log -Type Information -Message "Checking for User Environment file"
	agentSendLogMessage "$(executiontime) - Checking for User Environment file"
	$counter = 0
	do
	{
		$checkfor = Test-Path $cliqrvariableslocationbackup
		sleep 5
		$counter++
	}
	until
	(
	$checkfor -eq $true -or $counter -ge 300
	)
	
	if ($counter -ge 300)
	{
		Add-Log -Type Information -Message "Didn't find User Environment file"
		agentSendLogMessage "$(executiontime) - Didn't find User Environment file"
		#Stop-Service JettyService -Force -ErrorAction 'Stop'
		#Stop-Service CliQrStartupService -Force -ErrorAction 'Stop'
	}
	
	#sleep 10
	
	if ($checkfor)
	{
		#Load the Cliqr Env Variables
		.$cliqrvariableslocation
	}
}

function SendOSLogstoCliqr
{
	Add-Log -Type Information -Message "Sending OS log data to Cliqr"
	agentSendLogMessage "OS logs:"
	foreach ($line in (Get-Content $OSinitlogfile))
	{
		agentSendLogMessage $line
	}
}

function CleanupTasks
{
	Add-Log -Type Information -Message "Cleaning up scheduled tasks/jobs"
	Unregister-ScheduledTask "Cliqr Inject Setup" -Confirm:$false
	Get-ScheduledJob -Name "NewServerSetupResume" | Unregister-ScheduledJob
}

function ChefRunlist
{
	if ($env:runlist)
	{
		Add-Log -Type Information -Message "Adding additional Chef runlist commands: $($env:runlist)"
		agentSendLogMessage "$(executiontime) - Adding additional Chef runlist commands: $($env:runlist)"
		chef-client -r "role[dc-$datacenter],role[base],$($env:runlist)"
	}
	else
	{
		Add-Log -Type Information -Message "Running Chef with default recipes"
		agentSendLogMessage "$(executiontime) - Running Chef with default recipes"
		chef-client -r "role[dc-$datacenter],role[base]"
	}
}

#Load Cliqr functions
. "c:\Program Files\osmosix\service\utils\agent_util.ps1"

#endregion

#region Main
Add-Log -Type Information -Message "Starting inject script"
agentSendLogMessage "$(executiontime) - Starting inject script"
SendOSLogstoCliqr
LoadCliqrEnvVariables
#GrantAccessRights
CleanupTasks
#ChefRunlist
#PackageSetup
#c:\temp\PackageSetup.ps1
agentSendLogMessage "$(executiontime) - Inject script complete"
Add-Log -Type Information -Message "Inject script complete"
#endregion