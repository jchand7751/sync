﻿
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$Computername
)
Add-PSSnapin VMware.VimAutomation.Core

#endregion

#region Base variables and environment information
$VerbosePreference = "continue"
$logfile = "c:\temp\Logs\VMCleanup-$Computername.log"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins

#endregion

#region Create variables and arrays
$key = 203, 117, 112, 91, 119, 165, 146, 173, 140, 253, 20, 134, 174, 241, 213, 16
$password = Get-Content c:\scripts\s_cleaner
$password = $password | ConvertTo-SecureString -Key $key
$credential = New-Object System.Management.Automation.PSCredential "core\s_cleaner", $password

#endregion

#region Script functions

#endregion

#region Main

Add-Log -Type 'Information' -Message "Starting VM Cleanup"

invoke-command localhost {
	#Variables
	$computername = ($args.trimend(" "))
	$computernamefqdn = ($args.trimend(" ")) + ".core.pimcocloud.net"
	$VerbosePreference = "continue"
	
	$logfile = "c:\temp\Logs\VMCleanup-$Computername.log"
	
	function executiontime
	{
		get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
	}
	
	function Add-Log
	{
		param (
			[ValidateSet('Information', 'Warning', 'Error')]
			$Type,
			$Message,
			$EventId,
			$EventSource,
			[switch]$Throw
		)
		Write-Verbose "$(executiontime) - $type : $message"
		Add-Content -Path $logfile "$(executiontime) - $type : $message"
		if ($EventId -ne $null -and $EventSource -ne $null)
		{
			Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
		}
		switch ($throw)
		{
			$true { throw "$type : $message" }
			$false { }
			default { }
		}
	}
	
	#Chef cleanup
	try
	{
		Add-Log -Type 'Information' -Message "Removing $computernamefqdn from Chef"
		$ChefServer = knife node show $computernamefqdn -c C:\chef\admjchandler\knife.rb
		if ($ChefServer)
		{
			$Chefdelete = knife node delete $computernamefqdn --yes -c C:\chef\admjchandler\knife.rb
			if ($Chefdelete -ne "Deleted node[$computernamefqdn]")
			{
				Add-Log -Type 'Error' -Message "Node delete was not successful in Chef" -Throw
			}
		}
		else
		{
			Add-Log -Type 'Error' -Message "Could not find node in Chef" -Throw
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Error removing computer $computernamefqdn from Chef"
	}
	
	#Centrify cleanup
	try
	{
		$VerbosePreference = "Silentlycontinue"
		Import-Module Centrify.DirectControl.PowerShell -ea 'Stop' | Out-Null
		$VerbosePreference = "continue"
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Error loading Centrify module" -Throw
	}
	
	if ($Computername[7] -eq "l")
	{
		try
		{
			Add-Log -Type 'Information' -Message "Removing $computernamefqdn from Centrify"
			$CentrifyServer = Get-CdmManagedComputer -Name $computernamefqdn -ea Stop
			if (($CentrifyServer).count -ge 2)
			{
				Add-Log -Type 'Error' -Message "More than one computer was found in Centrify" -Throw
			}
			elseif (($CentrifyServer).count -eq 0)
			{
				Add-Log -Type 'Error' -Message "Computer not found in Centrify" -Throw
			}
			else
			{
				$CentrifyServer | Remove-CdmManagedComputer -ea Stop
			}
		}
		catch
		{
			Add-Log -Type 'Error' -Message "Error removing computer $computernamefqdn from Centrify"
		}
	}
	else
	{
		Add-Log -Type 'Information' -Message "Bypassing Centrify removal for $computernamefqdn"
	}
	
	#AD cleanup
	try
	{
		Add-PSSnapin quest.activeroles.admanagement | Out-Null
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Error loading Centrify module" -Throw
	}
	
	try
	{
		Add-Log -Type 'Information' -Message "Removing $computername from Active Directory"
		Connect-qadservice core.pimcocloud.net | Out-Null
		$ADServer = Get-QADComputer -Name $computername -ea 'Stop'
		if (($ADServer).count -ge 2)
		{
			Add-Log -Type 'Error' -Message "More than one computer was found in Active Directory" -Throw
		}
		elseif (($ADServer).count -eq 0)
		{
			Add-Log -Type 'Error' -Message "Computer not found in Active Directory" -Throw
		}
		else
		{
			$ADServer | Remove-QADObject -force -confirm:$false -ea 'Stop'
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Error removing computer $computername from Active Directory"
	}
	
	try
	{
		Add-Log -Type 'Information' -Message "Removing $computername from VMware"
		Connect-VIServer  | Out-Null
		$ADServer = Get-QADComputer -Name $computername -ea 'Stop'
		if (($ADServer).count -ge 2)
		{
			Add-Log -Type 'Error' -Message "More than one computer was found in Active Directory" -Throw
		}
		elseif (($ADServer).count -eq 0)
		{
			Add-Log -Type 'Error' -Message "Computer not found in Active Directory" -Throw
		}
		else
		{
			$ADServer | Remove-QADObject -force -confirm:$false -ea 'Stop'
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Error removing computer $computername from Active Directory"
	}
} -auth credssp -credential $credential -Argumentlist $computername

Add-Log -Type 'Information' -Message "VM Cleanup complete"
exit 0
#endregion