﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   7/29/2013 10:34 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================

Add-PSSnapin VMware.VimAutomation.Core
$hostinfo

<#cant query from windows
UAC
LastLogon?
OSname
OSversion
SP
Applications
Manufacturer
Model
SerialNumber
BackupPolicy
Delegation
SPN
LocalAdmins
CPU - $i.hardware.cpuinfo.numcpupackages
memory
#>
Connect-VIServer ina000pv
$a = Get-View -viewtype hostsystem
foreach ($i in $a)
	{
	$customvar = "" | select Name, Environment, CreationDate, Domain, OU, Loc, Role, Pingable, NSlookup, IP, MAC, Site, UAC, LastLogon, Managedby, SMTPADDR, OSname, OSversion, SP, Applications, Manufacturer, Model, SerialNumber, BackupPolicy, Delegation, SPN, LocalAdmins
	$customvar.name = $i.name
	$customvar.Manufacturer = $i.hardware.systeminfo.vendor
	$customvar.Model = $i.hardware.systeminfo.model
	$customvar.OSname = $i.config.product.name
	$customvar.OSversion = $i.config.product.version
	$customvar.serialnumber = $i.hardware.systeminfo.otheridentifyinginfo[1].identifiervalue
	$array += $customvar
	}