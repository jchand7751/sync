﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/5/2017 4:14 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

<#Save as 8859-1 encoding

{
	"username": "jchandle",
	"password": "*****"
}
#>

$a = curl.exe -H "Accept: application/json" -H "Content-Type:application/json" https://exv035tw-cpma1/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -d "@jsonpw"
$Authcode = ($a | convertfrom-json).CyberArkLogonResult


#List Safes
curl.exe -H "Accept: application/json" -H "Authorization: $Authcode" https://exv035tw-cpma1/PasswordVault/WebServices/PIMServices.svc/Safes -k
$result = (curl.exe -H "Accept: application/json" -H "Authorization: $Authcode" https://exv035tw-cpma1/PasswordVault/WebServices/PIMServices.svc/Safes -k) | ConvertFrom-Json


#Get creds
Curl.exe -H "Accept:application/json" -H "Authorization: $Authcode" https://exv035tw-cpma1/PasswordVault/WebServices/PIMServices.svc/Accounts/svc_adfs_np/Credentials -k


$credential = Get-Credential
$Execute = "`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`""
$expression = "curl.exe -H `"Accept: application/json`" -H `"Content-Type:application`/json`" https://exv035tw-cpma1/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -d --% `"`{`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`"`}`""
Invoke-Expression $expression


#### DEV ####

function Connect-CyberArk
{
	param ($environment)
	try
	{
		#$request = curl.exe -H "Accept: application/json" -H "Content-Type:application/json" https://exv035tw-cpma1/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -d "@jsonpw" -s
		$credential = Get-Credential
		$expression = "curl.exe -H `"Accept: application/json`" -H `"Content-Type:application`/json`" https://exv035tw-cpma1/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -s -d --% `"`{`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`"`}`""
		$Request = Invoke-Expression $expression
	}
	catch
	{
		Write-Warning "Caught Exception"
	}
	$Global:Authcode = ($Request | convertfrom-json).CyberArkLogonResult
}

function Lookup-CyberArkAccount
{
	param ($Accountname, $safe)
	$request = Curl.exe -H "Accept:application/json" -H "Authorization: $Authcode" https://exv035tw-cpma1/PasswordVault/WebServices/PIMServices.svc/Accounts?keywords=$accountname`&safe=PIMCO_TechInfra -k -s
	$result = ($Request | convertfrom-json).accounts.properties
	$object = "" | select ID, Safe, Folder, Name, UserName, PolicyID, LogonDomain, Address, DeviceType
	$object.ID = ($request | ConvertFrom-Json).accounts.accountid
	$object.Safe = $result[0].value
	$object.Folder = $result[1].value
	$object.Name = $result[2].value
	$object.UserName = $result[3].value
	$object.PolicyID = $result[4].value
	$object.LogonDomain = $result[5].value
	$object.Address = $result[6].value
	$object.DeviceType = $result[7].value
	$object
}

function Get-CyberArkCredential
{
	param ($Accountid)
	
	$request = Curl.exe -H "Accept:application/json" -H "Authorization: $Global:Authcode" https://exv035tw-cpma1/PasswordVault/WebServices/PIMServices.svc/Accounts/$accountid/Credentials -k -s
	#$result = ($Request | convertfrom-json).CyberArkLogonResult
	$result = $request
	$result
}


#### PROD ####
function Connect-CyberArk
{
	param ($environment)
	try
	{
		#$request = curl.exe -H "Accept: application/json" -H "Content-Type:application/json" https://exv035tw-cpma1/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -d "@jsonpw" -s
		$credential = Get-Credential
		$expression = "curl.exe -H `"Accept: application/json`" -H `"Content-Type:application`/json`" https://10.155.60.21/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon -X POST -k -s -d --% `"`{`\`"username`\`":`\`"$($credential.UserName)`\`", `\`"password`\`":`\`"$($credential.GetNetworkCredential().Password)`\`"`}`""
		$Request = Invoke-Expression $expression
	}
	catch
	{
		Write-Warning "Caught Exception"
	}
	$Global:Authcode = ($Request | convertfrom-json).CyberArkLogonResult
}

function Lookup-CyberArkAccount
{
	param ($Accountname, $safe)
	$request = Curl.exe -H "Accept:application/json" -H "Authorization: $Authcode" https://10.155.60.21/PasswordVault/WebServices/PIMServices.svc/Accounts?keywords=$accountname`&safe=PIMCO_TechInfra -k -s
	$result = ($Request | convertfrom-json).accounts.properties
	$object = "" | select ID, Safe, Folder, Name, UserName, PolicyID, LogonDomain, Address, DeviceType
	$object.ID = ($request | ConvertFrom-Json).accounts.accountid
	$object.Safe = $result[0].value
	$object.Folder = $result[1].value
	$object.Name = $result[2].value
	$object.UserName = $result[3].value
	$object.PolicyID = $result[4].value
	$object.LogonDomain = $result[5].value
	$object.Address = $result[6].value
	$object.DeviceType = $result[7].value
	$object
}

function Get-CyberArkCredential
{
	param ($Accountid)
	
	$request = Curl.exe -H "Accept:application/json" -H "Authorization: $Authcode" https://10.155.60.21/PasswordVault/WebServices/PIMServices.svc/Accounts/$accountid/Credentials -k -s
	#$result = ($Request | convertfrom-json).CyberArkLogonResult
	$result = $request
	$result
}



