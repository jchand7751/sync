﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/11/2015 10:35 AM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:	ExcelAddinInventory.ps1     	
	===========================================================================
	.DESCRIPTION
		Excel Addin inventory login script.
#>
#Variables and Environment setup
$logfile = "C:\temp\ExcelAddinLog.txt"
$whoami = ((whoami) -split ("\\"))[1]
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

Add-Content -Path $logfile "$(executiontime) - Starting script"

try
{
	$excel = new-object -comobject Excel.Application -ea 'Stop'
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - Error: Could not create Excel sessions via com object"
	exit
}

$array = @()

if (Test-Path c:\temp\exceladdins-$whoami.csv)
{
	try
	{
		Remove-Item c:\temp\exceladdins-$whoami.csv -ea 'Stop'
		$array += $excel.addins | foreach { $_ } | select Title, FullName, @{ Name = "Type"; Expression = { "Excel" } }, @{ Name = "Enabled"; Expression = { $_."Installed" } }
		$array += $excel.comaddins | foreach { $_ } | select @{ Name = "Title"; Expression = { $_."Description" } }, @{ Name = "Type"; Expression = { "COM" } }, @{ Name = "Enabled"; Expression = { $_."Connect" } }
		$array | export-csv c:\temp\exceladdins-$whoami.csv -NoTypeInformation -ea 'Stop'
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Error: Could not remove or create export file"
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel)
		exit
	}
}
else
{
	try
	{
		$array += $excel.addins | foreach { $_ } | select Title, FullName, @{ Name = "Type"; Expression = { "Excel" } }, @{ Name = "Enabled"; Expression = { $_."Installed" } }
		$array += $excel.comaddins | foreach { $_ } | select @{ Name = "Title"; Expression = { $_."Description" } }, @{ Name = "Type"; Expression = { "COM" } }, @{ Name = "Enabled"; Expression = { $_."Connect" } }
		$array | export-csv c:\temp\exceladdins-$whoami.csv -NoTypeInformation -ea 'Stop'
	}
	catch
	{
		Add-Content -Path $logfile "$(executiontime) - Error: Could not create export file"
		[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel)
		exit
	}
}

[System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel)
#| export-csv c:\temp\exceladdins-$whoami.csv -NoTypeInformation -ea 'Stop'

Add-Content -Path $logfile "$(executiontime) - Script finished"