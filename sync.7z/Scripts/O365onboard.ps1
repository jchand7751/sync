﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/16/2017 2:12 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
<#
CRM + Yammer user
O365-E3-Yammer
O365-E3-ProPlus
O365-E3-Sharepoint Online
O365-CRM Online
VPN-O365-CRM

Yammer user
O365-E3-Yammer
O365-E3-ProPlus
VPN-Email-ADFS

ProPlus User (No CRM, No Yammer)
O365-E3-ProPlus
VPN-Email-ADFS

CRM only
O365-E3-ProPLus
O365-E3-Sharepoint Online
O365-CRM Online
VPN-O365-CRM
#>

#Add-PSSnapin Quest.ActiveRoles.ADManagement
$users = Import-Csv c:\tmp\crmonboard\users1.csv
foreach ($i in $users)
{
	if ($i."CRM + Yammer user" -eq "Y")
	{
		$usertype = "CRM + Yammer User"
	}
	
	if ($i."CRM Only" -eq "Y")
	{
		$usertype = "CRM Only"
	}
	
	if ($i."Yammer User Only" -eq "Y")
	{
		$usertype = "Yammer User Only"
	}
	
	$user = Get-QADUser -SamAccountName $i.samaccountname
	
	switch ($usertype)
	{
		"CRM + Yammer User" {
			Write-Host "$($i.samaccountname) is a CRM + Yammer User"
			$user | Add-qadmemberof -Group "O365-E3-Yammer" | Out-Null
			$user | Add-qadmemberof -Group "O365-E3-ProPlus" | Out-Null
			$user | Add-qadmemberof -Group "O365-E3-Sharepoint Online" | Out-Null
			$user | Add-qadmemberof -Group "O365-CRM Online" | Out-Null
			$user | Add-qadmemberof -Group "VPN-O365-CRM" | Out-Null
		}
		"Yammer user" {
			Write-Host "$($i.samaccountname) is a Yammer User"
			$user | Add-qadmemberof -Group "O365-E3-Yammer" | Out-Null
			$user | Add-qadmemberof -Group "O365-E3-ProPlus" | Out-Null
			$user | Add-qadmemberof -Group "VPN-Email-ADFS" | Out-Null
		}
		"ProPlus User" {
			Write-Host "$($i.samaccountname) is a ProPlus User"
			$user | Add-qadmemberof -Group "O365-E3-ProPlus" | Out-Null
			$user | Add-qadmemberof -Group "VPN-Email-ADFS" | Out-Null
		}
		"CRM only" {
			Write-Host "$($i.samaccountname) is a CRM Only user"
			$user | Add-qadmemberof -Group "O365-E3-ProPlus" | Out-Null
			$user | Add-qadmemberof -Group "O365-E3-Sharepoint Online" | Out-Null
			$user | Add-qadmemberof -Group "O365-CRM Online" | Out-Null
			$user | Add-qadmemberof -Group "VPN-O365-CRM" | Out-Null
		}
		"ProPlusProPlus User" {
			Write-Host "$($i.samaccountname) is a ProPlus User"
			$user | Add-qadmemberof -Group "O365-ProPlus-ProPlus" | Out-Null
			$user | Add-qadmemberof -Group "VPN-Email-ADFS" | Out-Null
		}
	}
	
	if ($i."O365-CRM-Dev" -eq "Y")
	{
		Write-Host "Adding $($i.samaccountname) to CRM Online Dev"
		$user | Add-qadmemberof -Group "O365-CRM-Dev" | Out-Null
	}
	if ($i."O365-CRM-Alpha" -eq "Y")
	{
		Write-Host "Adding $($i.samaccountname) to CRM Online Alpha"
		$user | Add-qadmemberof -Group "O365-CRM-Alpha" | Out-Null
	}
	if ($i."O365-CRM-Beta" -eq "Y")
	{
		Write-Host "Adding $($i.samaccountname) to CRM Online Beta"
		$user | Add-qadmemberof -Group "O365-CRM-Beta" | Out-Null
	}
	if ($i."O365-CRM-Prod" -eq "Y")
	{
		Write-Host "Adding $($i.samaccountname) to CRM Online Prod"
		$user | Add-qadmemberof -Group "O365-CRM-Prod" | Out-Null
	}
}