﻿#========================================================================
# Created with: SAPIEN Technologies, Inc., PowerShell Studio 2012 v3.1.20
# Created on:   8/21/2013 10:34 AM
# Created by:   z548410
# Organization: 
# Filename:     
#========================================================================
Add-PSSnapin VMware.VimAutomation.Core
Connect-VIServer ina000pv
Connect-VIServer ina0z0pv
Connect-VIServer vma0b0v51vc
$b = Get-View -viewtype virtualmachine
$array = @()
$a = Get-Content c:\Temp\IISServers.txt
foreach ($i in $a)
	{
	$object = "" | select Name, Datastore, VMSize, Capacity, FreeSpace
	$object.name = $i
	$vmview = $b | where {$_.name -like $i} 
	$disks = $null
	$d = $null
	$datastore = $null
	$disks = Get-HardDisk -VM $vmview.name
	foreach ($i in $disks)
		{
		$d = $d + $i.capacityGB
		}
	$object.VMsize = $d
	$datastore = get-view ($vmview.datastore)
	$object.datastore = $datastore.name
	$object.freespace = ($datastore.info).freespace /1024 /1024 /1024
	$object.capacity = ($datastore.summary).capacity /1024 /1024 /1024
	$object
	$array += $object
	}
$array | Export-Csv C:\Temp\SharepointVMDetails.csv