﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/2/2015 1:55 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$a = connect-viserver csv035ma3
$snmphost = get-VMHostSnmp  -Server $a
Set-VMHostSNMP $snmphost -Enabled:$true -ReadOnlyCommunity 'Tk2ThCld'
