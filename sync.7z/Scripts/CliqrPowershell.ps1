﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/30/2015 4:02 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$user = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"

function Get-CliqrJobs
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $false, Position = 0)]
		[string]$Status
	)
	$jobarray = @()
	$jobs = invoke-command { curl.exe -k -X GET -H "Accept: application/json" -u $user "https://$url/v1/jobs" 2>&1 } -ea 'Stop'
	try
	{
		$jobs = $jobs[-1] | ConvertFrom-Json
	}
	catch
	{
		throw "Failed to get Cliqr jobs"	
	}
	$jobs = $jobs.jobs
	$properties = ($jobs | gm | where { $_.membertype -eq "NoteProperty" }).name
	foreach ($job in $jobs)
	{
		$object = "" | select $properties
		foreach ($property in $properties)
		{
			$object.$property = $job.$property
		}
		$jobarray += $object
	}
	if ($Status)
	{
		$jobarray | where { $_.status -eq $Status }
	}
	else
	{
		$jobarray	
	}
}