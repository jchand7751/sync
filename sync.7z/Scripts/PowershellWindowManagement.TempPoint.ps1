﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	1/19/2017 5:48 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

function MinimizeWindow
{
	param ($MainWindowTitle)
	$window = @(Get-Process -Name "powershell" | where { $_.MainWindowTitle -eq $MainWindowTitle })[0].MainWindowHandle
	[Win32.NativeMethods]::ShowWindowAsync($window, 2)
}

function MaximizeWindow
{
	param ($MainWindowTitle)
	$window = @(Get-Process -Name "powershell" | where { $_.MainWindowTitle -eq $MainWindowTitle })[0].MainWindowHandle
	[Win32.NativeMethods]::ShowWindowAsync($window, 4)
}