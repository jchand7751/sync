﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/20/2017 3:35 PM
	 Created by:   	 
	 Organization: 	 
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Add-PSSnapin VMware.VimAutomation.Core
foreach ($i in $vms)
{
	get-vm -Name $i | Shutdown-VMGuest -Confirm:$false
}

foreach ($i in $vms)
{
	get-vm -Name $i | get-harddisk | Set-HardDisk -Persistence Persistent -Confirm:$false
}


foreach ($i in $vms)
{
	get-vm -Name $i | New-Snapshot -Name boebetasnap-delete6-27
}

foreach ($i in $vms)
{
	get-vm -Name $i | Start-VM
}