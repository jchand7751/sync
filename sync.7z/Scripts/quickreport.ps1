﻿Add-PSSnapin Quest.ActiveRoles.ADManagement
Connect-QADService vms001p4
Remove-Item \\nasshare\share\test\allpimco.csv -force
Rename-Item \\nasshare\share\test\allpimco.txt -NewName allpimco.csv -Force
$a = import-csv \\nasshare\share\test\allpimco.csv
$array = @()
foreach ($i in $a) 
{
    $object = "" | select Full_Name, Login_Name, EmailAddress, Title, Department, Office, Location, Country, Desk, Manager, Mailbox_size, Assistant, StartDate, ItemCount, TotalBytes, Desknumber, Mobilenumber
    $testforuser = get-qaduser -DisplayName $i.displayname -includedproperties msExchAssistantName, co | select Displayname, samaccountname, title, department, city, msExchAssistantName, creationdate, email, l, co, manager, office, physicalDeliveryOfficeName, PhoneNumber, Mobilephone
    if ($testforuser)
    {
    	$object.Full_Name = $testforuser.displayname
        $object.Login_Name = $testforuser.samaccountname
        $object.Title = $testforuser.title
        $object.Department = $testforuser.department
        $object.Office = $testforuser.city
        $object.Mailbox_size = $i.TotalItemSize
		$object.Desk = $testforuser.physicalDeliveryOfficeName
		$object.desknumber = $testforuser.phonenumber
		$object.mobilenumber = $testforuser.mobilephone
        $object.Assistant = $testforuser.msExchAssistantName
        $object.StartDate = ($testforuser.creationdate).toshortdatestring()
        $object.ItemCount = $i.itemcount
        $object.Totalbytes = (($i.totalitemsize).split("(")[1]).replace("bytes)","")
        $object.EmailAddress = $testforuser.email
        $object.Location = $testforuser.L
		$object.Country = $testforuser.co

       try
       {
            $TestManager = (get-qaduser ($testforuser.manager)).name
            $object.Manager = $TestManager
       }
       Catch
       {
        $object.Manager = "Manager not found"
       }
       #$object
       $array += $object
    }
    else
    {
        $object.Full_Name = $i.displayname
        $object.Login_Name = "Not found"
        $object.EmailAddress = "Not found"
        $object.Title = "Not found"
        $object.Department = "Not found"
        $object.Manager = "Not found"
        $object.desk = "Not found"
        $object.itemcount = $i.itemcount
        $object.Mailbox_size = $i.totalitemsize
        $object.Totalbytes = (($i.totalitemsize).split("(")[1]).replace("bytes)","")
        $array += $object
    }


}
$array | export-csv c:\temp\cleanreport1.csv