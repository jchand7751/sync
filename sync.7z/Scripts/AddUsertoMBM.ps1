﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	7/23/2015 1:08 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
$logfile = "C:\temp\AddUsertoMBMLog.txt"
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}
$mmusers = Import-Csv c:\temp\policy1.csv
foreach ($user in $mmusers[1468..1469])
{
	try
	{
		set-mailbox $($user.alias) -ManagedFolderMailboxPolicy "custommanagedfolder" -ea stop -whatif
	}
	catch
	{
		Write-Warning "Could not add $($user.alias) to custommanagedfolder policy!"
		Add-Content -Path $logfile "$(executiontime) - Could not add $($user.alias) to custommanagedfolder policy!"
	}
}