﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	4/19/2016 6:27 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Cliqr API Application profile provisioning
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	[string]$JSONPath
)
#endregion

#region Base variables and environment information
$logfile = "c:\scripts\logging\JenkinsBuild.log"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

#CreateLogfile
CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-Module Centrify.DirectControl.PowerShell -ea 'Stop' | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays
$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"
$infobloxuser = ""
$infobloxurl = ""
#endregion

#region Script functions
function Stop-CliqrJob
{
	param ($jobid)
	try
	{
		$command = curl.exe -k -X PUT -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid`?action=stop" -s | ConvertFrom-Json
		if ($command.code -eq 400 -or $command.errors -or $command.msg -ne "Stopping the app")
		{
			throw "Exception"
		}
	}
	catch
	{
		throw "Failed to stop Cliqr job $jobid"
		$Error[0]
		$Error[1]
	}
	Write-Output "Job $jobid is stopping"
}

function Delete-CliqrJob
{
	param ($jobid)
	try
	{
		$command = curl.exe -k -X DELETE -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid" -s | ConvertFrom-Json
		if ($command.code -eq 400 -or $command.errors)
		{
			throw "Exception"
		}
	}
	catch
	{
		throw "Deleting job $jobid has failed"
	}
	Write-Output "Job $jobid is deleting"
}

function Get-CliqrJob
{
	param ($jobid)
	try
	{
		$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$jobid" -s | ConvertFrom-Json
		if ($jobstatus.code -eq 400 -or $jobstatus.errors)
		{
			throw "Exception"
			$Error[0]
			$Error[1]
		}
	}
	catch
	{
		$jobstatus = "JobError"
	}
	Write-Output $jobstatus.status
}

function Get-InfobloxDNSRecord
{
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $True, Position = 0)]
		$HostName
	)
	#Connection variables
	$infobloxcreds = "admjchandler:Ker988qa"
	$url = "pimcloudinfblx/wapi/v1.0/record:host"
	
	try
	{
		$command = [string](curl.exe -k -u $infobloxcreds -X GET https://$url -d name=$HostName -s) | ConvertFrom-Json
		if ($command.code -eq 400)
		{
			throw "Exception"
		}
	}
	catch
	{
		throw "Exception: Something happened"
		$Error[0]
		$Error[1]
	}
	Write-Output $command
}
#endregion

#region Main
try
{
	Write-Host "Creating Job"
	$result = curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/jobs" -d "@$JSONPath" -s | ConvertFrom-Json
	if ($result.code -eq 400 -or $result.errors -or $result.code -eq 500 -or $result.status -eq 400)
	{
		throw "Exception"
	}
	sleep 10
}
catch
{
	throw "Result is not correct"
	$Error[0]
	$Error[1]
}

#Job details
$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$($result.id)" -s | ConvertFrom-Json
Write-Host ""
Write-Host "Deployment Details"
Write-Host ""
Write-Host "Name:  $($jobstatus.name)"
Write-Host "App Name:  $($jobstatus.appname)"
Write-Host "App Version:  $($jobstatus.appversion)"
Write-Host "Job ID:  $($jobstatus.id)"
Write-Host "Job URL:  https://10.155.5.112/#job/runs/$($jobstatus.id)/0/1/web"
Write-Host "Start Time:  $($jobstatus.starttime)"
Write-Host "Environment: $(($jobstatus.parameters.envparams | where {$_.name -eq "cliqrdepenvname"}).value)"
Write-Host ""
do
{
	try
	{
		$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$($result.id)" -s | ConvertFrom-Json
		if ($jobstatus.code -eq 400 -or $jobstatus.errors)
		{
			throw "Exception"
		}
		sleep 60
		Write-Host $jobstatus.status
	}
	catch
	{
		$jobstatus = "JobError"
		$Error[0]
		$Error[1]
	}
}
until
($jobstatus.status -eq "JobError" -or $jobstatus.status -eq "JobRunning" -or $jobstatus.status -eq "JobCanceling")

#Stop the job and wait for it to finish
switch ($jobstatus.status)
{
	"JobError" {
		Delete-CliqrJob -Jobid $result.id
		write-host "Job has failed";
		Write-Host ""
		Write-Host "Deployment Details"
		Write-Host ""
		Write-Host "Name:  $($jobstatus.name)"
		Write-Host "App Name:  $($jobstatus.appname)"
		Write-Host "App Version:  $($jobstatus.appversion)"
		Write-Host "Job ID:  $($jobstatus.id)"
		Write-Host "Job URL:  https://10.155.5.112/#job/runs/$($jobstatus.id)/0/1/web"
		Write-Host "Start Time:  $($jobstatus.starttime)"
		Write-Host "Completion Time:  $(get-date -UFormat '%Y-%m-%d %H:%M:%S')"
		Write-Host "Environment: $(($jobstatus.parameters.envparams | where { $_.name -eq "cliqrdepenvname" }).value)"
		Write-Host "VMs: $($jobstatus.jobs.virtualmachines.id)"
		Write-Host "VM IPs: $($jobstatus.jobs.virtualmachines.privateip)"
		Write-Host ""
		$script:appprofilehostnames = $jobstatus.jobs.virtualmachines.id
		exit 1
	}
	"JobCanceling" {
		Delete-CliqrJob -Jobid $result.id
		write-host "Job has failed";
		Write-Host ""
		Write-Host "Deployment Details"
		Write-Host ""
		Write-Host "Name:  $($jobstatus.name)"
		Write-Host "App Name:  $($jobstatus.appname)"
		Write-Host "App Version:  $($jobstatus.appversion)"
		Write-Host "Job ID:  $($jobstatus.id)"
		Write-Host "Job URL:  https://10.155.5.112/#job/runs/$($jobstatus.id)/0/1/web"
		Write-Host "Start Time:  $($jobstatus.starttime)"
		Write-Host "Completion Time:  $(get-date -UFormat '%Y-%m-%d %H:%M:%S')"
		Write-Host "Environment: $(($jobstatus.parameters.envparams | where { $_.name -eq "cliqrdepenvname" }).value)"
		Write-Host "VMs: $($jobstatus.jobs.virtualmachines.id)"
		Write-Host "VM IPs: $($jobstatus.jobs.virtualmachines.privateip)"
		Write-Host ""
		$script:appprofilehostnames = $jobstatus.jobs.virtualmachines.id
	}
	"JobRunning" {
		write-host "Job completed successfully";
		Write-Host ""
		Write-Host "Deployment Details"
		Write-Host ""
		Write-Host "Name:  $($jobstatus.name)"
		Write-Host "App Name:  $($jobstatus.appname)"
		Write-Host "App Version:  $($jobstatus.appversion)"
		Write-Host "Job ID:  $($jobstatus.id)"
		Write-Host "Job URL:  https://10.155.5.112/#job/runs/$($jobstatus.id)/0/1/web"
		Write-Host "Start Time:  $($jobstatus.starttime)"
		Write-Host "Completion Time:  $(get-date -UFormat '%Y-%m-%d %H:%M:%S')"
		Write-Host "Environment: $(($jobstatus.parameters.envparams | where { $_.name -eq "cliqrdepenvname" }).value)"
		Write-Host "VMs: $($jobstatus.jobs.virtualmachines.id)"
		Write-Host "VM IPs: $($jobstatus.jobs.virtualmachines.privateip)"
		Write-Host ""
		#Get variables from the job
		#$jobstatus = curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/jobs/$($result.id)" -s | ConvertFrom-Json
		$script:appprofilehostnames = $jobstatus.jobs.virtualmachines.id
		#$script:appprofilehostnames
		Stop-CliqrJob $result.id; do { $checkres = Get-CliqrJob $result.id; sleep 60 } until ($checkres -eq "JobFinished") 
	}
}

$errorthrow = @()

#Verify Infoblox cleanup
foreach ($hostname in $script:appprofilehostnames)
{
	if ((Get-InfobloxDNSRecord -HostName ($hostname + ".core.pimcocloud.net")))
	{
		#throw "Infobox deprovision failed, node $hostname still exists in DNS"
		$errorthrow += "Infobox deprovision failed, node $hostname still exists in DNS"
	}
	else
	{
		Write-Host "Infoblox node cleanup for $hostname was successful."
	}
}

#Verify Chef cleanup
foreach ($hostname in $script:appprofilehostnames)
{
	$fqdn = ($hostname + ".core.pimcocloud.net")
	$chefnodecheck = [string](knife search node fqdn:$fqdn -c C:\chef\client.rb -F json) | ConvertFrom-Json
	if ($chefnodecheck.results -ne 0)
	{
		#throw "Chef deprovision failed, node $hostname still exists in Chef"
		$errorthrow += "Chef deprovision failed, node $hostname still exists in Chef"
	}
	else
	{
		Write-Host "Chef node cleanup for $hostname was successful."
	}
}

#Verify AD Cleanup
foreach ($hostname in $script:appprofilehostnames)
{
	$searcher = [ADSISearcher]"(&(objectClass=Computer)(Name=$hostname))"
	$searcher.searchroot = "LDAP://core.pimcocloud.net"
	if (($searcher.findone()))
	{
		#throw "Active Directory deprovision failed, node $hostname still exists in core.pimcocloud.net"
		$errorthrow += "Active Directory deprovision failed, node $hostname still exists in core.pimcocloud.net"
	}
	else
	{
		Write-Host "Active Directory node cleanup for $hostname was successful."
	}
}

#Verify Centrify cleanup
foreach ($hostname in $script:appprofilehostnames)
{
	if ($hostname[7] -eq "l")
	{
		if (Get-CdmManagedComputer -Name ($hostname + ".core.pimcocloud.net"))
		{
			#throw "Centrify deprovision failed, node $hostname still exists in Centrify"
			$errorthrow += "Centrify deprovision failed, node $hostname still exists in Centrify"
		}
		else
		{
			Write-Host "Centrify node cleanup for $hostname was successful."
		}
	}
}

if ($errorthrow -notlike "")
{
	throw [string]$errorthrow	
}
#endregion

