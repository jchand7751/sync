﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/7/2016 12:06 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Get-Cluster -Name csv035mgmtc001 | Get-VM | foreach ($_) { if (($_ | Get-Snapshot) -notlike $null) { $_.name } }