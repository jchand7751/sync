﻿$whoami = ((whoami) -split "\\")[1]
$timestamp = (Get-Date -UFormat %Y-%m-%d-%H%M)
$LogPath = "C:\temp\Exdcleanup-$whoami.txt"

if  ((Test-Path $LogPath) -eq $true)
{
    Add-Content -Path $LogPath "$timestamp - Script started" | Out-Null
}
else
{
	New-Item -Path $LogPath -ItemType File | Out-Null
	Add-Content -Path $LogPath "$timestamp - Script started" | Out-Null
}

$exdfiles = ls C:\Windows\Temp\*.exd -Recurse
if ($exdfiles)
{
    foreach ($file in $exdfiles)
    {
        try
        {
            $file | Remove-item -force -ea stop
        }
        catch
        {
            Add-Content -Path $LogPath "$timestamp - Failed to remove $($file.name)" | Out-Null
        }
    }
}
Add-Content -Path $LogPath "$timestamp - Done" | Out-Null