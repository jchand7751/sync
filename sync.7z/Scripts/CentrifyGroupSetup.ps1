﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/7/2015 1:44 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	CentrifyGroupSetup.ps1
	===========================================================================
	.DESCRIPTION
		Import legacy group NIS data into Core Centrify.
#>
#Load Modules and Snapins
try
{
	Import-module activedirectory -ea 'Stop'
	Import-module centrify.directcontrol.powershell -ea 'Stop'
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - ERROR: Could not load necessary modules"
	throw "Could not load necessary Powershell modules"
	Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Error' -EventId 16 -Message "CentrifyGroupSetup.ps1 - Could not load necessary Powershell modules"
}

#Create variables and arrays
$logfile = "E:\logs\NISGroupImportlog.txt"
$nisarray = @()
$nisdatafile = "c:\temp\nis.groups"
$zonename = "pimcloud"

#Functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force
	}
}

#Main
CreateLogFile
Add-Content -Path $logfile "$(executiontime) - Starting Script"
Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Information' -EventId 3 -Message "CentrifyGroupSetup.ps1 - Script started"
try
{
	$zone = Get-CdmZone -Name $zonename -domain core.pimcocloud.net
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - ERROR: Could not load zone $zonename"
	Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Error' -EventId 17 -Message "CentrifyGroupSetup.ps1 - Could not load zone $zonename"
	throw "Could not load zone $zonename"
}

if ((Test-Path "e:\logs\curlerrNisGroups.txt") -eq $true)
{
	Remove-Item "e:\logs\curlerrNisGroups.txt" -Force
}
e:\scripts\curl.exe http://pimcloudrpms.core.pimcocloud.net/nis-legacy/nis.groups -o c:\temp\nis.groups -R -Ss -f --stderr e:\logs\curlerrNisGroups.txt
$curloutput = Get-Content "e:\logs\curlerrNisGroups.txt"
if ($curloutput -notlike "")
{
	Add-Content -Path $logfile "$(executiontime) - ERROR: Could not download nis file"
	Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Error' -EventId 18 -Message "CentrifyGroupSetup.ps1 - Could not download nis file"
	throw "Could not download nis file"
}

try
{
	$nisdata = Get-Content $nisdatafile
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - ERROR: Could not find NIS data"
	Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Error' -EventId 19 -Message "CentrifyGroupSetup.ps1 - Could not find NIS data file"
	throw "Could not find NIS data"
}

try
{
	$currentcentrifygroups = Get-CdmGroupProfile -Zone $zone
}
catch
{
	Add-Content -Path $logfile "$(executiontime) - ERROR: Could not get existing Centrify groups"
	Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Error' -EventId 20 -Message "CentrifyGroupSetup.ps1 - Could not get existing Centrify groups"
	throw "Could not get existing Centrify groups"
}

$currenttime = Get-Date
if (($currenttime - ((get-item C:\temp\nis.groups).lastwritetime)).totalhours -ge 4)
{
	Add-Content -Path $logfile "$(executiontime) - Warning: Nis file is out of date"
	Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Warning' -EventId 9 -Message "CentrifyGroupSetup.ps1 - Nis file is out of date"
}

foreach ($item in $nisdata)
{
	$item = $item -split ":"
	$object = "" | select GroupName, GID, Members
	$object.GroupName = $item[0]
	$object.GID = $item[1]
	$object.Members = $item[2]
	#$object
	$nisarray += $object
}

foreach ($group in $nisarray)
#foreach ($group in ($nisarray | where { $_.groupname -eq "workpuma" -or $_.groupname -eq "cfapps"}))
{
	Write-Host "Checking $($group.groupname)"
	#Find the group in the nis array
	$selectedgroup = $currentcentrifygroups | where { $_.name -eq $group.groupname }
	
	#If the group is already provisioned
	if ($selectedgroup)
	{
		<#
		#Compare the attributes
		$script:userattributemismatch = $false
		$attributes = "User", "Uid", "PrimaryGroupID", "HomeDirectory", "Gecos", "Shell"
		for ($x = 0; $x -lt $attributes.count; $x++)
		{
			Write-Host "Comparing $(($selecteduser).($attributes[$x])) -ne $(($user).($attributes[$x]))"
			if ([string]($selecteduser.($attributes[$x])) -ne ([string]$user.($attributes[$x])))
			{
				Write-Host "$($user.Name) does not have matching $($attributes[$x]) attribute"
				$x = 7
				$script:userattributemismatch = $true
			}
		}
		if ($script:userattributemismatch -eq $true)
		{
			try
			{
				Write-Host "Removing user $($user.Name)"
				#Remove and re-add the user
				Get-CdmUserProfile -Zone $zone -User "$($user.logonname)@pimco.imswest.sscims.com" -ea stop | Remove-CdmUserProfile -ea stop
			}
			catch
			{
				throw "Could not remove user"
			}
			
			#Run Centrify commands
			try
			{
				Write-Host "Creating user $($user.Name)"
				New-CdmUserProfile -zone $zone -User "$($user.logonname)@pimco.imswest.sscims.com" -Login $user.logonname -Uid $user.UID -PrimaryGroup $user.PrimaryGroupID –HomeDir $user.HomeDirectory –Gecos $user.Gecos –Shell $user.Shell -ea stop
			}
			catch
			{
				throw "Could not add user"
			}
		}
		#>
	}
	else
	{
		#Run AD Commands
		try
		{
			Add-Content -Path $logfile "$(executiontime) - Adding new AD group: New-ADGroup -Name $($group.groupname) -SamAccountName $($group.groupname) -GroupCategory Security -GroupScope DomainLocal -DisplayName $($group.groupname) -Path OU=centrify, OU=sec_groups, OU=itops, DC=core, DC=pimcocloud, DC=net -Description Centrify created AD group for $($group.groupname) -Server $($zone.preferredServer) -ea Stop"
			New-ADGroup -Name "$($group.groupname)" -SamAccountName "$($group.groupname)" -GroupCategory Security -GroupScope DomainLocal -DisplayName "$($group.groupname)" -Path "OU=centrify,OU=sec_groups,OU=itops,DC=core,DC=pimcocloud,DC=net" -Description "Centrify created AD group for $($group.groupname)" -Server $($zone.preferredServer) -ea Stop | Out-Null
		}
		catch
		{
			Add-Content -Path $logfile "$(executiontime) - Could not add AD group: $($group.GroupName)"
			#throw "Could not add group AD group: $($group.GroupName)"
			$newgrouperrors = $true
		}
		
		#Sleep a few for the group..
		sleep 1
		
		#Run Centrify commands
		try
		{
			Write-Host "Creating group $($group.GroupName)"
			Add-Content -Path $logfile "$(executiontime) - Adding new Centrify group: New-CdmGroupProfile -zone $zone -name $($group.groupname) -gid $($group.gid) -Group cn=$($group.groupname),OU=centrify,OU=sec_groups,OU=itops,DC=core,DC=pimcocloud,DC=net -ea Stop"
			New-CdmGroupProfile -zone $zone -name $($group.groupname) -gid $($group.gid) -Group "cn=$($group.groupname),OU=centrify,OU=sec_groups,OU=itops,DC=core,DC=pimcocloud,DC=net" -ea Stop | Out-Null
		}
		catch
		{
			Add-Content -Path $logfile "$(executiontime) - Could not add Centrify group: $($group.GroupName)"
			#throw "Could not add Centrify group: $($group.GroupName)"
			$newgrouperrors = $true
		}
	}
}
if ($newgrouperrors -eq $true)
{
	Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Warning' -EventId 8 -Message "CentrifyGroupSetup.ps1 - Errors found during provisioning, check log for details"
}
Write-EventLog -LogName Application -Source Pimcloud -EntryType 'Information' -EventId 4 -Message "CentrifyGroupSetup.ps1 - Script run complete"
Add-Content -Path $logfile "$(executiontime) - Run Complete"