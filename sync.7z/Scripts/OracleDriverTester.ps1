﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	12/16/2015 2:07 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>
param ($Environment)
Add-PSSnapin Quest.ActiveRoles.ADManagement
$scriptfiles = "\\nasshare\share\test\32bittest.bat", "\\nasshare\share\test\64bittest.bat"
$resultfiles = "c$\temp\32bitoracleresults.txt", "c$\temp\64bitoracleresults.txt"
$resultarray = @()

#$servers = Get-QADComputer -OSName "Windows Server 2008*" -SizeLimit 0
$servers = @()
#$servers += Get-QADComputer ina001b019
#$servers += Get-QADComputer ina001b012
#$servers += Get-QADComputer vma001d030
#$servers += Get-QADComputer ina001b013
#$servers += Get-QADComputer INE001P11

switch ($Environment)
{
	"dev-beta" {
		$servers += Get-QADComputer INA001D* -SizeLimit 0
		$servers += Get-QADComputer VMA001D* -SizeLimit 0
		$servers += Get-QADComputer INH001D* -SizeLimit 0
		$servers += Get-QADComputer VMH001D* -SizeLimit 0
		$servers += Get-QADComputer VMA001B* -SizeLimit 0
		$servers += Get-QADComputer INA001B* -SizeLimit 0
		$servers += Get-QADComputer INH001B* -SizeLimit 0
		$servers += Get-QADComputer VMH001B* -SizeLimit 0
	}
	"prod" {
		$servers += Get-QADComputer INA001P* -SizeLimit 0
		$servers += Get-QADComputer VMA001P* -SizeLimit 0
		$servers += Get-QADComputer INH001P* -SizeLimit 0
		$servers += Get-QADComputer VMH001P* -SizeLimit 0
	}
	"test" {
		$servers += Get-QADComputer VMA001D003 -SizeLimit 0
	}
}
#$servers += Get-QADComputer VMH001d7
#$servers += Get-QADComputer VMA001d016
#$servers += Get-QADComputer VMA001d020
foreach ($server in $servers)
{
	$object = "" | select Servername, Status, OracleDriverTest32bit, OracleDriverTest64bit, KRB5Present
	$object.Servername = $server.name
	if ((Test-Connection -ComputerName $server.name -Count 1 -Quiet) -eq $true)
	{
		$object.Status = "Online"
		
		<#try
		{
			Test-Path \\$($server.name)\c$ -ea 'Stop'
		}
		catch
		{
			$object.Status = "No access to server"
			$resultarray += $object
			continue
		}
		#>
		
		#Make sure we have access
		if ((Test-Path \\$($server.name)\c$ -ea 'SilentlyContinue') -eq $true)
		{
		}
		else
		{
			$object.Status = "No access to server"
			$resultarray += $object
			continue
		}
		
		#check for krb5
		if ((Test-Path \\$($server.name)\c$\windows\krb5.ini) -eq $false)
		{
			$object.KRB5Present = $false
		}
		else
		{
			$object.KRB5Present = $true
		}
		
		#make sure the tester is there
		if ((Test-Path \\$($server.name)\c$\OracleDriver_tester) -eq $false)
		{
			try
			{
				Copy-Item \\nasshare\share\PimcoIIS_InstallPackage\Oracle_install\OracleDriver_tester \\$($server.name)\c$ -ea 'Stop' -Force -Recurse
			}
			catch
			{
				$object.Status = "Failed to copy Oracle driver tester"
				$resultarray += $object
				break
			}
		}
		
		#copy files
		foreach ($file in $scriptfiles)
		{
			try
			{
				Copy-Item $file \\$($server.name)\c$\temp -ea 'Stop' -Force
			}	
			catch
			{
				$object.Status = "Failed to copy required files"
				$resultarray += $object
				break
			}
		}
		#clean up current run results
		foreach ($resultfile in $resultfiles)
		{
			if ((Test-Path \\$($server.name)\$resultfile) -eq $true)
			{
				try
				{
					Remove-Item \\$($server.name)\$resultfile -ea 'Stop'
				}
				catch
				{
					$object.Status = "Failed to remove previous result files"
					$resultarray += $object
					break
				}
			}
		}
		#run
		\\nasshare\share\PimcoIIS_InstallPackage\Tools\PSTool\PsExec.exe -s \\$($server.name) c:\temp\32bittest.bat -accepteula
		\\nasshare\share\PimcoIIS_InstallPackage\Tools\PSTool\PsExec.exe -s \\$($server.name) c:\temp\64bittest.bat -accepteula
		sleep 1
		
		#gather the results
		foreach ($resultfile in $resultfiles)
		{
			if ((Test-Path \\$($server.name)\$resultfile) -eq $true)
			{
				try
				{
					$result = Get-Content \\$($server.name)\$resultfile -ea 'Stop'
				}
				catch
				{
					$object.Status = "Failed to get results from this run"
					Add-Content $Error[0] -Path c:\temp\failed.txt
					$resultarray += $object
					break
				}
				
				if (!$result)
				{
					$object.OracleDriverTest64bit = "Run failure"
					$object.OracleDriverTest32bit = "Run failure"
				}
				elseif (($result[1].contains("Successfully")) -eq $true)
				{
					if (($result[0].contains("64bit")) -eq $true)
					{
						$object.OracleDriverTest64bit = "Success"
					}
					if (($result[0].contains("32bit")) -eq $true)
					{
						$object.OracleDriverTest32bit = "Success"
					}
				}
				else
				{
					if (($result[0].contains("64bit")) -eq $true)
					{
						$object.OracleDriverTest64bit = "Failed"
					}
					if (($result[0].contains("32bit")) -eq $true)
					{
						$object.OracleDriverTest32bit = "Failed"
					}
				}
			}
			else
			{
				$object.Status = "Failed to get results from this run"
				Add-Content $Error[0] -Path c:\temp\failed.txt
				#$resultarray += $object
				break
			}
		}
		#$object
		$resultarray += $object
	}
	else
	{
		$object.Status = "Offline"
		$resultarray += $object
		continue
	}
}
$resultarray
$resultarray | Export-Csv c:\temp\OracleDriverTesterReport.csv -Force
$body = [string]($resultarray | ConvertTo-Html)
#Send-MailMessage -To "Technology-ServicesWeb@pimco.com" -From OracleDriverReport@PimcoNoReply.com -SmtpServer mailhost -BodyAsHtml -Body $body -Subject "Oracle Driver Tester Results"
Send-MailMessage -To "james.chandler@pimco.com" -From OracleDriverReport@PimcoNoReply.com -SmtpServer mailhost -BodyAsHtml -Body $body -Subject "Oracle Driver Tester Results"