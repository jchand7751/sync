﻿#$Computers = “vmh001b016","vmh001b017","vma001p087","vmh001p053"

$CSV = "C:\temp\vappdata.csv"
    $hosts = @()
    $a = get-content $CSV
    $serverarray = $null
    $serverarray = @()

    $a = $a -replace(";",",")
    #$blah = '"name","serverame","blank1","blank2","protocol","port","path" ' + $a

    #Turns the list into an array of objects
    foreach ($i in $a) 
    {
        $serverobject = "" | select ConnectionName, ServerName, Path, Department, Environment, Protocol
        $b = ($i -split ",") -replace '"'
        $serverobject.ConnectionName = $b[0]
        $serverobject.servername = $b[1]
        $serverobject.Path = $b[6]
        $serverobject.Department = $b[6].split("\\")[0]
        $serverobject.Environment = $b[6].split("\\")[1]
        $serverobject.Protocol = $b[4]
        #$object
        if ($serverobject.protocol -eq "RDP")
        {
            $hosts += $serverobject
        }
    }

$RunspaceCollection = @()
$RunspacePool = [RunspaceFactory]::CreateRunspacePool(1,40)
$RunspacePool.Open()

$scriptblock = {param ($computer) ; write-verbose "starting script" ; \\nasshare\share\PimcoIIS_InstallPackage\Powershell\OneOffScript\FindEvents\findevents.ps1 $computer}

<#$scriptblock = {
Param(
        $Computer
        )
         
        Try{
            Get-WinEvent -ComputerName $Computer -MaxEvents 10 -ErrorAction Stop
        }
        Catch{
            write-warning "caught this"
            Write-Warning $_
        }      
     }
#>

Foreach($Computer in $hosts.servername)
{
    
    #Create a PowerShell object to run add the script and argument.
    $Powershell = [PowerShell]::Create().AddScript($ScriptBlock).AddArgument($Computer)
    #Specify runspace to use
    $Powershell.RunspacePool = $RunspacePool
    
    #Create Runspace collection
    [Collections.Arraylist]$RunspaceCollection += New-Object -TypeName PSObject -Property @{
    Runspace = $PowerShell.BeginInvoke()
    PowerShell = $PowerShell  
    } 
}

$RunspaceTotal = $RunspaceCollection.count
$CompletionCount = 0
While($RunspaceCollection)
{
    Foreach($Runspace in $RunspaceCollection.ToArray())
    {
        If($Runspace.Runspace.IsCompleted)
        {
            #write-host "Run space finished"
            if ($Runspace.Powershell.HadErrors -eq $true)
            {
                $runspace.powershell.streams.error
            }
            $Runspace.PowerShell.EndInvoke($Runspace.Runspace)
            $Runspace.PowerShell.Dispose()
            #$runspace.powershell
            $RunspaceCollection.Remove($Runspace)
            $CompletionCount++
            Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
            Write-host "Total count: $RunspaceTotal"
            write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
        }
        else
        {
            sleep 5
            write-host "Run space not done"
            Write-host "Percent complete: $($Completioncount/$RunspaceTotal * 100)%"
            Write-host "Total count: $RunspaceTotal"
            write-host "Remaining count: $($RunspaceTotal - $Completioncount)"
        }
    }
}