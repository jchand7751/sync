﻿Param($EmailAddress, $Folder)

function AddPolicyToFolder
{
    Param ($EmailAddress, $FolderName)

    Write-host "Attemping to add policy on $foldername for mailbox: $EmailAddress"
    
    #Change the user to Impersonate (if we use a service account)
    $service.ImpersonatedUserId = new-object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress,$EmailAddress);

    #Search for the folder to add the property on
    $oFolderView = new-object Microsoft.Exchange.WebServices.Data.FolderView(1)
    $oSearchFilter = new-object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.FolderSchema]::DisplayName,$FolderName)

    #Search for folder in message root
    $oFindFolderResults = $service.FindFolders([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::MsgFolderRoot,$oSearchFilter,$oFolderView)

    if ($oFindFolderResults.TotalCount -eq 0)
    {
         Write-Warning "Folder was not found in mailbox for $EmailAddress, exiting..."
         exit
    }
    else
    {
        Write-host "Folder found in mailbox, adding policy"

        #PR_POLICY_TAG 0x3019
        $PolicyTag = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x3019,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Binary);

        #PR_RETENTION_FLAGS 0x301D    
        $RetentionFlags = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x301D,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer);
        
        #PR_RETENTION_PERIOD 0x301A
        $RetentionPeriod = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x301A,[Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer);

        #Bind to the folder found
        $oFolder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$oFindFolderResults.Folders[0].Id)
       
        #Same as the value in the PR_RETENTION_FLAGS property
        #$oFolder.SetExtendedProperty($RetentionFlags, 137)
        $oFolder.SetExtendedProperty($RetentionFlags, 129)

        #Same as the value in the PR_RETENTION_PERIOD property
        #$oFolder.SetExtendedProperty($RetentionPeriod, 1095)
        $oFolder.SetExtendedProperty($RetentionPeriod, 30)

        #Set the GUID based on your policy tag
        #$PolicyTagGUID = new-Object Guid("{92186ff7-7f4d-4efa-a09b-bbdc5aee3908}");
        #$PolicyTagGUID = new-Object Guid("{7707713b-2839-46a9-8bbc-1ed12cd00686}");
        $PolicyTagGUID = new-Object Guid("{33c1d985-eb5a-4f63-bf90-b25a3b86b970}");

        $oFolder.SetExtendedProperty($PolicyTag, $PolicyTagGUID.ToByteArray())

        try
        {
            $oFolder.Update()
            Write-host "Retention policy added to $FolderName"
        }
        catch
        {
            Write-Warning "Retention policy add failed"
        }
    }    

    #Disable the impersonationID
    #$service.ImpersonatedUserId = $null
}

#Import the module
try
{
    Import-Module -Name "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll"
}
catch
{
    Write-Warning "Module not installed, exiting"
}

$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP2)

#Get credentials
$Cred = Get-Credential

#Set the credentials
$service.Credentials = new-object Microsoft.Exchange.WebServices.Data.WebCredentials($($cred.getnetworkcredential().username),$($cred.getnetworkcredential().password),$($cred.getnetworkcredential().domain))

#Change the URL to point to your cas server
$service.Url= new-object Uri("https://owa-lb.pimco.imswest.sscims.com/EWS/Exchange.asmx")

AddPolicyToFolder $EmailAddress $Folder 