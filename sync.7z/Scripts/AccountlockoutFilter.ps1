﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	6/25/2015 7:03 PM
	 Created by:   	jchandle
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

get-qaduser -ldapfilter '(lockouttime>=1)' -IncludedProperties lockouttime | select name, lockouttime, accountislockedout