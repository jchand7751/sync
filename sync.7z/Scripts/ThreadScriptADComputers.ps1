Param($file)

function Export-CSV2 { 
[CmdletBinding(DefaultParameterSetName='Delimiter', 
  SupportsShouldProcess=$true, ConfirmImpact='Medium')] 
param( 
[Parameter(Mandatory=$true, ValueFromPipeline=$true, 
           ValueFromPipelineByPropertyName=$true)] 
[System.Management.Automation.PSObject] 
${InputObject}, 

[Parameter(Mandatory=$true, Position=0)] 
[Alias('PSPath')] 
[System.String] 
${Path}, 

#region -Append (added by Dmitry Sotnikov) 
[Switch] 
${Append}, 
#endregion 

[Switch] 
${Force}, 

[Switch] 
${NoClobber}, 

[ValidateSet('Unicode','UTF7','UTF8','ASCII','UTF32', 
                  'BigEndianUnicode','Default','OEM')] 
[System.String] 
${Encoding}, 

[Parameter(ParameterSetName='Delimiter', Position=1)] 
[ValidateNotNull()] 
[System.Char] 
${Delimiter}, 

[Parameter(ParameterSetName='UseCulture')] 
[Switch] 
${UseCulture}, 

[Alias('NTI')] 
[Switch] 
${NoTypeInformation}) 

begin 
{ 
# This variable will tell us whether we actually need to append 
# to existing file 
$AppendMode = $false 

try { 
  $outBuffer = $null 
  if ($PSBoundParameters.TryGetValue('OutBuffer', [ref]$outBuffer)) 
  { 
      $PSBoundParameters['OutBuffer'] = 1 
  } 
  $wrappedCmd = $ExecutionContext.InvokeCommand.GetCommand('Export-Csv', 
    [System.Management.Automation.CommandTypes]::Cmdlet) 

#String variable to become the target command line 
$scriptCmdPipeline = '' 

# Add new parameter handling 
#region Dmitry: Process and remove the Append parameter if it is present 
if ($Append) { 

  $PSBoundParameters.Remove('Append') | Out-Null 

  if ($Path) { 
   if (Test-Path $Path) { 
    # Need to construct new command line 
    $AppendMode = $true 

    if ($Encoding.Length -eq 0) { 
     # ASCII is default encoding for Export-CSV 
     $Encoding = 'ASCII' 
    } 

    # For Append we use ConvertTo-CSV instead of Export 
    $scriptCmdPipeline += 'ConvertTo-Csv -NoTypeInformation ' 

    # Inherit other CSV convertion parameters 
    if ( $UseCulture ) { 
     $scriptCmdPipeline += ' -UseCulture ' 
    } 
    if ( $Delimiter ) { 
     $scriptCmdPipeline += " -Delimiter '$Delimiter' " 
    } 

    # Skip the first line (the one with the property names) 
    $scriptCmdPipeline += ' | Foreach-Object {$start=$true}' 
    $scriptCmdPipeline += '{if ($start) {$start=$false} else {$_}} ' 

    # Add file output 
    $scriptCmdPipeline += " | Out-File -FilePath '$Path'" 
    $scriptCmdPipeline += " -Encoding '$Encoding' -Append " 

    if ($Force) { 
     $scriptCmdPipeline += ' -Force' 
    } 

    if ($NoClobber) { 
     $scriptCmdPipeline += ' -NoClobber' 
    } 
   } 
  } 
} 

$scriptCmd = {& $wrappedCmd @PSBoundParameters } 

if ( $AppendMode ) { 
  # redefine command line 
  $scriptCmd = $ExecutionContext.InvokeCommand.NewScriptBlock( 
      $scriptCmdPipeline 
    ) 
} else { 
  # execute Export-CSV as we got it because 
  # either -Append is missing or file does not exist 
  $scriptCmd = $ExecutionContext.InvokeCommand.NewScriptBlock( 
      [string]$scriptCmd 
    ) 
} 

# standard pipeline initialization 
$steppablePipeline = $scriptCmd.GetSteppablePipeline( 
        $myInvocation.CommandOrigin) 
$steppablePipeline.Begin($PSCmdlet) 

} catch { 
   throw 
} 

} 

process 
{ 
  try { 
      $steppablePipeline.Process($_) 
  } catch { 
      throw 
  } 
} 

end 
{ 
  try { 
      $steppablePipeline.End() 
  } catch { 
      throw 
  } 
} 
<# 

.ForwardHelpTargetName Export-Csv 
.ForwardHelpCategory Cmdlet 

#> 

} 

Function Threadscript 
{
if (Get-PSSnapin -Name VMware.VimAutomation.Core)
	{}
	else
		{Add-PSSnapin VMware.VimAutomation.Core}
if (Test-Path C:\scripts\ScriptResult-$file.csv)
	{Remove-Item  C:\scripts\ScriptResult-$file.csv -Force}
if (Test-Path C:\scripts\LogFile.txt)
	{Remove-Item C:\scripts\logfile.txt -Force}
$script:errorlog = @()
$hosts = $null 


#$domains = "sscims.com", "enterprise.sscims.com", "development.enterprise.sscims.com", "beta.enterprise.sscims.com", "imswest.sscims.com", "pimco.imswest.sscims.com", "ims.lcl", "imsprod.ims.lcl", "imsalpha.ims.lcl", "imsbeta.ims.lcl"
#$domains = "sscims.com"
$domains = "pimco.imswest.sscims.com"

$mastercomputerlist = @()

#$credentialIMS = Get-Credential "imswest\z548410"
#$credentialPlat = Get-Credential "imsprod\z548410"
foreach ($i in $domains)
    {
    switch ($i) {
	"sscims.com" {
	connect-qadservice -service 'ins000pa.sscims.com:389' -credential $credentialIMS | out-null
	}
	"imswest.sscims.com" {
	connect-qadservice -service 'ins000p001.imswest.sscims.com:389' -credential $credentialIMS | out-null
	}
	"pimco.imswest.sscims.com" {
	connect-qadservice -service 'vms001p4.pimco.imswest.sscims.com:389' | Out-Null
	#-credential $credentialIMS | out-null
	}
	"enterprise.sscims.com" {
	connect-qadservice -service 'vms000e0.enterprise.sscims.com:389' -credential $credentialIMS | out-null
	}
	"development.enterprise.sscims.com" {
	connect-qadservice -service 'vms000d0.development.enterprise.sscims.com:389' -credential $credentialIMS | out-null
	}
	"beta.enterprise.sscims.com" {
	connect-qadservice -service 'vms000b0.beta.enterprise.sscims.com:389' -credential $credentialIMS | out-null
	}
	"ims.lcl" {
	connect-qadservice -service 'vms002pa.ims.lcl:389' -credential $credentialplat | out-null
	}
	"imsprod.ims.lcl" {
	connect-qadservice -service 'vms002p0.imsprod.ims.lcl:389' -credential $credentialplat | out-null
	}
	"imsalpha.ims.lcl" {
	connect-qadservice -service 'vms002d0.imsalpha.ims.lcl:389' -credential $credentialplat | out-null
	}
	"imsbeta.ims.lcl" {
	connect-qadservice -service 'vms002b0.imsbeta.ims.lcl:389' -credential $credentialplat | out-null
	}
	default {}
    }       
		
    #$mastercomputerlist += Get-qadcomputer -OSname "Windows Serv*" -sizelimit 0
    #$mastercomputerlist += Get-qadcomputer -OSname "Windows 2000 serv*" -sizelimit 0
    $mastercomputerlist += Get-QADComputer -sizelimit 0 -OSname "Windows 7*" | select name
    }

cls
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
Write-Host ""
$hosts = $mastercomputerlist | where {$_.name -notlike $null}
$script:jobtimer = @()
foreach($i in $hosts) 
    {
    $jobname = $i.name	
    $b = $hosts.count 
	$stringvm = [string]$i.moref
        While ($(Get-Job -state running).count -ge "8")
        { 
        $trJobs = ([array]$(Get-Job -state running)).count; 
        $ttJobs = ([array]$(Get-Job)).count; 
        $tcJobs = ([array]$(Get-Job -state Completed)).count; 
        $tnfjobs = ($b - $ttjobs) 
        Write-Progress -Activity "Threading selected script" -Status "Max threads open, waiting for threads to close" -CurrentOperation "$tnfjobs threads left - $($(Get-Job -state running).count) threads open" -PercentComplete ($($(Get-Job -state Completed).count) / $hosts.count * 100) 
        } 
############# JOB TO BE RUN HERE ############# 		
    Start-job -filepath  C:\scripts\browsernonense.ps1 -Argumentlist $jobname -Name $jobname | out-null 
    $object = "" | select Jobname, Timer
	$timeout = new-timespan -seconds 3
	$sw = [diagnostics.stopwatch]::StartNew()
	#$jobtimer[$jobname] = $sw
	#	$jobtimer[0].value
	$object.jobname = $jobname
	$object.timer = $sw
	$script:jobtimer += $object
	}   
        While ($(Get-Job -State Running).count -gt 0 -or ($(Get-Job -State 'Running') -ne $null)
		) 
        { 
        $rJobs = ([array]$(Get-Job -state running)).count; 
        $tJobs = ([array]$(Get-Job)).count; 
        Write-Progress -Activity "Getting results" -Status "Waiting for script to finish" -CurrentOperation "$rJobs left out of $tJobs" -PercentComplete ($(Get-Job -State Completed).count / $(Get-Job).count * 100) 
        #If ($(New-TimeSpan $Complete $(Get-Date)).totalseconds -ge $MaxWaitAtEnd){"Killing all jobs still running . . .";Get-Job -State Running | Remove-Job -Force} 
       $timeout = new-timespan -seconds 300
		$script:listjobs = @()
		$runningjobs = Get-Job -State 'Running'
		foreach ($runjobs in $runningjobs)
			{
			$script:listjobs += $script:jobtimer | where {$_.jobname -eq $runjobs.name}
			}
			foreach ($i in $script:listjobs)
				{
				#Write-Host "Checking timer on $($i.jobname)"
				#Write-Host "Runtime: $($i.timer.elapsed.totalseconds)"
				if ($i.timer.elapsed -gt $timeout)
					{
					$checkjob = Get-Job $i.jobname 
					if ($checkjob.jobstateinfo -notlike "Completed")
						{
						#$i.timer.elapsed.totalseconds
						Write-Host "Timeout exceeded ending job: $($checkjob.name)"
						#$checkjob.jobstateinfo
						$checkjob | Remove-Job -Force
						$script:errorlog += "$($i.jobname) did not complete before the specified timeout"
						}
					}
				}
		Start-sleep 3 
        } 
            ForEach($Job in Get-Job) 
            {
			Write-Host "Writing results for $($job.name)"
		    Write-Host ""
            $testforcsv = test-path C:\scripts\ScriptResult-$file.csv 
############# RESULT FIELDS ############# 
			$jobdata = Receive-Job $job | select *
			$jobdata
                if ($testforcsv -eq $false) 
                    {$jobdata | Export-csv  C:\scripts\ScriptResult-$file.csv 
                    } 
                    else 
                        { 
                        $jobdata | select * | Export-csv2  C:\scripts\ScriptResult-$file.csv -append 
                        } 
            write-host "" 
            } 
$results = $null 
Get-Job | Remove-Job -Force 
#$results = Read-host "Would you like to view results now? (Y/N)" 
    Switch($results) 
    { 
    "Y" {import-csv  C:\scripts\ScriptResult-$file.csv | out-gridview} 
    "N" {$null} 
    } 
}

ThreadScript
$date = (get-date).toshortdatestring() -replace "/","-"
$script:errorlog | out-file C:\scripts\logfile.txt

