﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	3/14/2016 6:27 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		Cliqr self-provisioning.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $true, Position = 0)]
	$jsonticket
)
#endregion

#region Base variables and environment information
$logfile = "E:\scripts\CliqrSelfProvisioning\cliqrselfprovisioning.log"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Add-PSSnapin Quest.ActiveRoles.ADManagement -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#Jira credential
$password = Get-Content c:\secure\secure.p | ConvertTo-SecureString
$credential = New-Object System.Management.Automation.PSCredential pimco\s_jiraauto, $password
$password = $credential.getnetworkcredential().password
$account = "s_jiraauto"
$creds = $account + ":" + $password

#Cliqr credential
$cliqruser = "cliqradmin:13B2BAAF5C2EB62C"
$url = "10.155.5.112"

#s_pimcldpr
$pw = Get-Content c:\secure\secure1.p | ConvertTo-SecureString
$groupaddcredential = New-Object System.Management.Automation.PSCredential pimco\s_pimcldpr, $pw

#Issue ID
$issueid = $jsonticket.issue.key

#Selected clouds
$selectedclouds = $jsonticket.issue.fields.customfield_13700.value
$selectedenvironments = $jsonticket.issue.fields.customfield_13700.value

#User email
$useremail = $jsonticket.issue.fields.reporter.emailaddress

$cloudarray = @()
switch ($selectedclouds)
{
	"Sandbox" { $selectedclouds = $cloudarray += 1 }
	"Dev" { $selectedclouds = $cloudarray += 2 }
	"Beta" { $selectedclouds = $cloudarray += 3 }
	"Pre-prod" { $selectedclouds = $cloudarray += 4 }
	"prod" { $selectedclouds = $cloudarray += 5 }
}

#Requestor
$requestor = $jsonticket.issue.fields.reporter.name

#Selected department
$script:selecteddept = $jsonticket.issue.fields.customfield_12808.value

#Department Mapping
switch ($script:selecteddept)
{
	"Analytics" { $script:selecteddept = "analytics" }
	"Business Dept/User" { "" }
	"HR" { "" }
	"IMS" { $script:selecteddept = "ims" }
	"Tech: Client Facing, Management, Strategic" { $script:selecteddept = "cftech" }
	"Tech: Core / Technical Architecture" { $script:selecteddept = "coresvc" }
	"Tech: Data Architecture" { $script:selecteddept = "coresvc" }
	"Tech: Front Office Tech" { $script:selecteddept = "fotech" }
	"Tech: Infra" { $script:selecteddept = "infra" }
	"Tech: PM Apps" { $script:selecteddept = "pmapps" }
	"Tech: Security" { $script:selecteddept = "security" }
	"Tech: Services or Operations" { $script:selecteddept = "techsvc" }
	"Tech: Trade Legal Compliance" { $script:selecteddept = "tlc" }
    "Tech: DBA" { $script:selecteddept = "dba" }
}

#endregion

#region Script functions

#endregion

#region Main
Add-Log -Type 'Information' -Message "Starting Script"
try
{
	Connect-QADService Pimco.imswest.sscims.com -ea 'Stop' | Out-Null
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Could not connect to domain" -Throw
}

try
{
	$user = Get-QADUser -SamAccountName $requestor -ea 'Stop'
	if ($user)
	{ }
	else
	{
		throw "Could not find the specified user $requestor"
	}
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Could not find the specified user $requestor" -Throw
}

#User Department Mapping
<#
switch ($user.department)
{
	"Analytics" { $userdept = "analytics" }
	"Business Dept/User" { "" }
	"HR" { "" }
	"IMS" { $userdept = "infra" }
	"TECH-CF & Strategic Proj" { $userdept = "cftech" }
	"TECH-Management" { $userdept = "coresvc" }
	"Tech: Data Architecture" { "" }
	"TECH-Front Office" { $userdept = "fotech" }
	"TECH-Infrastructure" { $userdept = "infra" }
	"TECH-PM Applications" { $userdept = "pmapps" }
	"Tech: Security" { $userdept = "security" }
	"TECH-Technical Services" { $userdept = "techsvc" }
	"Tech: Trade Legal Compliance" { $userdept = "tlc" }
}
#>
#Taking this out so we have on behalf of requests
$userdept = $script:selecteddept

try
{
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" } -ea 'Stop'
	$cliqrusers = ($cliqrusers | ConvertFrom-Json -ea 'Stop').users
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Cliqr user query failed" -Throw
}

#Check for an existing Cliqr user
if (!($cliqrusers | where { $_.externalid -eq $requestor }))
{
	#User wasn't found in the Cliqr user lookup, create a new account
	#Stage new User with Activation profile (using AD variables)
	Add-Log -Type 'Information' -Message "Creating a new user Cliqr user for $requestor"
	Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/" -d "{ `"`"firstName`"`": `"`"$($user.firstname)`"`", `"`"lastName`"`": `"`"$($user.lastname)`"`", `"`"password`"`": `"`"===redacted===`"`", `"`"emailAddr`"`": `"`"$($user.email)`"`", `"`"companyName`"`": `"`"$($user.department)`"`", `"`"phoneNumber`"`": `"`"`"`", `"`"externalId`"`": `"`"$($user.samaccountname)`"`", `"`"tenantId`"`": 1, `"`"activationProfileId`"`": 8 } " } -ea 'Stop'
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0" } -ea 'Stop'
	$cliqrusers = ($cliqrusers | ConvertFrom-Json -ea 'Stop').users
	$selectedcliqruser = ($cliqrusers | where { $_.externalid -eq $requestor })
	#clouds no longer needed
	<#
	foreach ($cloud in $selectedclouds)
	{
		Add-Log -Type 'Information' -Message "Adding $requestor to cloud $cloud - cliqr ID is $($selectedcliqruser.id)"
		Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/$($selectedcliqruser.id)" -d "{ `"`"action`"`": `"`"MANAGE_CLOUDS`"`", `"`"manageCloudsData`"`": { `"`"activateRegions`"`": [ { `"`"regionId`"`": `"`"$cloud`"`" } ], `"`"storageSize`"`": 0 } } " } -ea 'Stop'
	}
	#>
}
else
{
	$selectedcliqruser = ($cliqrusers | where { $_.externalid -eq $requestor })
	#Add user to selected clouds - no longer needed
	<#
	foreach ($cloud in $selectedclouds)
	{
		Add-Log -Type 'Information' -Message "Cliqr user found for $requestor"
		Add-Log -Type 'Information' -Message "Adding $requestor to cloud $cloud"
		Invoke-Command { curl.exe -k -X POST -H "Accept: application/json" -H "Content-Type: application/json" -u $cliqruser "https://$url/v1/users/$($selectedcliqruser.id)" -d "{ `"`"action`"`": `"`"MANAGE_CLOUDS`"`", `"`"manageCloudsData`"`": { `"`"activateRegions`"`": [ { `"`"regionId`"`": `"`"$cloud`"`" } ], `"`"storageSize`"`": 0 } } " } -ea 'Stop'
	}
	#>
}

#Verify
try
{
	$cliqrusers = Invoke-Command { curl.exe -k -X GET -H "Accept: application/json" -u $cliqruser "https://$url/v1/users?size=0&detail=true" } -ea 'Stop'
	$cliqrusers = ($cliqrusers | ConvertFrom-Json -ea 'Stop').users
}
catch
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Could not query Cliqr users" -Throw
}

$usersregions = ($cliqrusers | where { $_.externalid -eq $requestor }).detail.regions

#No longer need regions
<#
$checkregionarray = @()
foreach ($region in $selectedclouds)
{
	$checkregionarray += ($usersregions -contains $region)
}

if ($checkregionarray -contains $false)
{
	curl.exe -k -u  $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Error' -Message "Region add failed" -Throw
}
else
{
	Add-Log -Type 'Information' -Message "Region(s) verified"
}
#>

#Group adds
try
{
	foreach ($environment in $selectedenvironments)
	{
		$environment
		switch ($environment)
		{
			"Sandbox" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-sandbox"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-sandbox -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $script:selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$script:selecteddept-sandbox"
					$user | Add-QADMemberOf -Group pimcloud-$script:selecteddept-sandbox -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"Dev" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-dev"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-dev -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $script:selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$script:selecteddept-dev"
					$user | Add-QADMemberOf -Group pimcloud-$script:selecteddept-dev -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"Beta" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-beta"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-beta -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $script:selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$script:selecteddept-beta"
					$user | Add-QADMemberOf -Group pimcloud-$script:selecteddept-beta -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"Pre-prod" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-preprod"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-preprod -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $script:selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$script:selecteddept-preprod"
					$user | Add-QADMemberOf -Group pimcloud-$script:selecteddept-preprod -ea 'Stop' -Credential $groupaddcredential
				}
			}
			"prod" {
				if ($userdept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to pimcloud-$userdept-prod"
					$user | Add-QADMemberOf -Group pimcloud-$userdept-prod -ea 'Stop' -Credential $groupaddcredential
				}
				if ($userdept -ne $script:selecteddept)
				{
					Add-Log -Type 'Information' -Message "Adding $requestor to requested group pimcloud-$script:selecteddept-prod"
					$user | Add-QADMemberOf -Group pimcloud-$script:selecteddept-prod -ea 'Stop' -Credential $groupaddcredential
				}
			}
		}
		
	}
}
catch
{
	curl.exe -k -u $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Something happened"" }'
	curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""61"" }}'
	Add-Log -Type 'Information' -Message "Group add failed" -Throw
}

curl.exe -k -u $creds -H "Content-Type: application/json" -X POST https://jira/rest/api/2/issue/$issueid/comment -d '{""body"": ""Request completed successfully"" }'
curl.exe -k https://jira/rest/api/2/issue/$issueid/transitions -u $creds -X POST -H "Content-Type: application/json" -d '{""transition"": { ""id"": ""51"" }}'
Add-Log -Type 'Information' -Message "Sending email"

$body = "Hello $($user.firstname),
<br>
<br>
Welcome to the PIMCO Cloud!
<br>
Please review the information below to understand our service model and policies.

<br>
<br>
Cloud Documentation:
<br>
<br>
*  <a href='http://pimcoportal/newport/technology/infrastructure/Documents/Cloud/PIMCO Cloud User Reference Guidev2.doc'>User Guide</a>
<br>
*  <a href='http://pimcoportal/newport/technology/infrastructure/Documents/Cloud/PIMCO Cloud Expectations Early Access.docx'>Cloud Sandbox Expectations</a>
<br>
*  <a href='http://pimcoportal/newport/technology/infrastructure/core/Shared Documents/Cliqr/Cliqr Service Modeling Expectations.docx'>Service Managers</a>
<br>
*  <a href='http://pimcoportal/newport/technology/infrastructure/core/Shared Documents/Cliqr/How to Model Services in Cliqr.docx'>How to Build a Service</a>
<br>
*  <a href='http://docs.cliqr.com/display/CCD42/Deployment+Lifecycle+Scripts'>CliQr Lifecycle Scripts</a>
<br>
<br>
If you have any questions or need help please email: <a href='mailto:Technology-Cloud@pimco.com'>Technology-Cloud@pimco.com</a>
<br>
<br>
Thanks
"

Send-MailMessage -BodyAsHtml -To $useremail -From PimcoCloudOnboarding@pimcocloud.net -SmtpServer vme001py -Body $body -Subject "Cloud Onboarding"


Add-Log -Type 'Information' -Message "Setup for $requestor complete"
#endregion