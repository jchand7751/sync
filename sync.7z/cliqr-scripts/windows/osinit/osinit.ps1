﻿<#
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2015 v4.2.82
	 Created on:   	10/28/2015 1:24 PM
	 Created by:   	jchandle
	 Organization: 	PIMCO
	 Filename:   	OSinit.ps1  	
	===========================================================================
	.DESCRIPTION
		Cliqr Windows Init Script.
#>
#region Parameter set
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $false, Position = 0)]
	[string]$Computer
)


#endregion

#region Base variables and environment information
$logfile = "c:\temp\OSinit.txt"
$FullScriptPath = $MyInvocation.MyCommand.Definition
$CurrentScriptName = $MyInvocation.MyCommand.Name
$CurrentExecutingPath = $FullScriptPath.Replace($CurrentScriptName, "")
$server = hostname
$key = 203, 117, 112, 91, 119, 165, 146, 173, 140, 253, 20, 134, 174, 241, 213, 16
$password = (Get-Content C:\temp\cred.dat | ConvertTo-SecureString -Key $key)
$credential = New-Object System.Management.Automation.PSCredential "core\svc_adaccess", $password
$clientrb = "C:\chef\client.rb"
$reposource = "http://10.155.5.63:8080/"
$whoami = whoami
#Cliqr Authentication and URL

$url = "10.155.6.21"
$datacenter = switch ($server[4])
{
	"3" { "irvine" }
	"h" { "newjersey" }
}
$deploymentenvironment = switch ($server[6])
{
	"s" { "sandbox" }
	"d" { "dev" }
	"b" { "beta" }
	"r" { "preprod" }
	"p" { "prod" }
}
$vcenter = switch ($datacenter)
{
	"irvine" { "vma035gw080.core.pimcocloud.net" }
	"newjersey" { "vma0h5gw080.core.pimcocloud.net" }
}
$reposerver
#endregion

#region Base functions
function executiontime
{
	get-date -format "ddd MM/dd/yyyy HH:mm:ss.ff"
}

function CreateLogfile
{
	if ((Test-Path $logfile) -ne $true)
	{
		New-Item -ItemType File $logfile -Force | Out-Null
	}
}

function Add-Log
{
	param (
		[ValidateSet('Information', 'Warning', 'Error')]
		$Type,
		$Message,
		$EventId,
		$EventSource,
		[switch]$Throw
	)
	Write-Verbose "$(executiontime) - $type : $message"
	Add-Content -Path $logfile "$(executiontime) - $type : $message"
	if ($EventId -ne $null -and $EventSource -ne $null)
	{
		Write-EventLog -LogName Application -Source $eventsource -EntryType $type -EventId $eventid -Message "$CurrentScriptName - $message"
	}
	switch ($throw)
	{
		$true { throw "$type : $message" }
		$false { }
		default { }
	}
}

CreateLogfile
#endregion

#region Load modules and snapins
try
{
	Import-module ActiveDirectory -ea 'Stop' | Out-Null
	Import-module BitsTransfer -ea 'Stop' | Out-Null
	Add-PSSnapin VMware.VimAutomation.Core | Out-Null
	#Add-PSSnapin SnapinName -ea 'Stop' | Out-Null
}
catch
{
	Add-Log -Type 'Error' -Message "Could not load required modules/snap-ins" -Throw #-EventSource -EventId
}
#endregion

#region Create variables and arrays

#endregion

#region Script functions

function Expand-ZIPFile($file, $destination)
{
	$shell = new-object -com shell.application
	$zip = $shell.NameSpace($file)
	foreach ($item in $zip.items())
	{
		$shell.Namespace($destination).copyhere($item, 0x14)
	}
}

function CheckNetwork
{
	#check for the network
	Add-Content -Path $logfile "$(executiontime) - Network info:"
	#agentSendLogMessage "$(executiontime) - Network info:"
	$ipaddress = (Get-NetIPAddress -InterfaceAlias ethernet1 -AddressFamily ipv4 -ea SilentlyContinue).ipaddress
	$dns = [string]((Get-NetIPConfiguration -ea SilentlyContinue).dnsserver | where { $_.addressfamily -eq "2" }).serveraddresses
	Add-Content -Path $logfile "$(executiontime) - IP: $ipaddress"
	#agentSendLogMessage "$(executiontime) - IP: $ipaddress"
	Add-Content -Path $logfile "$(executiontime) - DNS: $dns"
	#agentSendLogMessage "$(executiontime) - DNS: $dns"
	do
	{
		sleep 5
		$ipaddress = (Get-NetIPAddress -InterfaceAlias ethernet1 -AddressFamily ipv4 -ea SilentlyContinue).ipaddress
		if ($ipaddress -notlike "10.155.*")
		{
			Add-Content -Path $logfile "$(executiontime) - Seems like we don't have an IP yet"
			#agentSendLogMessage "$(executiontime) - Seems like we don't have an IP yet"
		}
		else
		{
			Add-Content -Path $logfile "$(executiontime) - Network setup complete"
			#agentSendLogMessage "$(executiontime) - Network setup complete"
			$ippass = $true
		}
	}
	until ($ippass -eq $true)
}

function TestConnectivity
{
	if ((Test-Connection core.pimcocloud.net -count 1 -Quiet) -ne $true)
	{
		Add-Content -Path $logfile "$(executiontime) - Failed to ping domain"
		#agentSendLogMessage "$(executiontime) - Failed to ping domain"
		Add-Content -Path $logfile "$(executiontime) - $error[0]"
		#agentSendLogMessage "$(executiontime) - $error[0]"
	}
	else
	{
		Add-Content -Path $logfile "$(executiontime) - Unable to resolve core.pimcocloud.net"
		#agentSendLogMessage "$(executiontime) - Unable to resolve core.pimcocloud.net"
	}
}

function PartitionDisks
{
	Add-Log -Type 'Information' -Message "Partitioning disks"
	
	<#
	foreach ($disk in (Get-Disk))
	{
		if ($disk.OperationalStatus -eq "Offline" -or $disk.IsReadOnly -eq $true)
		{
			$disk | Set-Disk -IsOffline $false
			$disk | Set-Disk -IsReadOnly $false
		}
	}
	
	if (!((Get-Volume).DriveLetter -contains "E") -and (Get-Disk -Number 1).IsOffline -ne $true)
	{
		Add-Log -Type 'Information' -Message "Creating E disk volume"
		Get-Disk -Number 1 | New-Partition -Driveletter "E" -UseMaximumSize | Format-Volume -FileSystem NTFS -confirm:$false -Force
	}
	
	if (!((Get-Volume).DriveLetter -contains "L") -and ((Get-Disk -Number 2).IsOffline) -ne $true)
	{
		Add-Log -Type 'Information' -Message "Creating L disk volume"
		Get-Disk -Number 2 | New-Partition -Driveletter "L" -UseMaximumSize | Format-Volume -FileSystem NTFS -confirm:$false -Force
	}
	#>
	
	cmd /c echo rescan | diskpart
	$totaldisksize = (Get-PartitionSupportedSize -DiskNumber 0 -PartitionNumber 2).sizemax
	
	#Do math
	$totaldisksize = [math]::Truncate($totaldisksize / 1024 / 1024 / 1024)
	$cdisksize = 100
	$ldisksize = 10
	#$Edisksize = ($totaldisksize - $cdisksize - $ldisksize)
	
	try
	{
		#Increase C to 100GB
		Resize-Partition -DiskNumber 0 -PartitionNumber 2 -Size ($cdisksize * 1024 * 1024 * 1024) -ea stop
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to resize C disk"
	}
	
	try
	{
		#Create L disk
		Add-Log -Type 'Information' -Message "Creating L disk volume"
		New-Partition -DiskNumber 0 -Size ($ldisksize * 1024 * 1024 * 1024) -DriveLetter L -ea stop
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to create L disk volume"
	}
	
	try
	{
		#Create E disk
		Add-Log -Type 'Information' -Message "Creating E disk volume"
		#New-Partition -DiskNumber 0 -Size ($edisksize * 1024 * 1024 * 1024) -DriveLetter E -ea stop
		New-Partition -DiskNumber 0 -UseMaximumSize -DriveLetter E -ea stop
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to create E disk volume"
	}
	
	try
	{
		Format-Volume -DriveLetter E -Force -confirm:$false -ea stop
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to format E disk volume"
	}
	
	try
	{
		Format-Volume -DriveLetter L -Force -confirm:$false -ea stop
	}
	catch
	{
		Add-Log -Type 'Warning' -Message "Failed to format L disk volume"
	}
	
}

function MoveADComputer
{
	param ($computer, $environment)
	try
	{
		$ADObject = Get-ADObject -filter 'name -eq $server' -ErrorAction 'Stop' -Credential $credential
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Could not find computer in AD" -Throw
	}
	
	try
	{
		if ($ADObject)
		{
			$ADObject | Move-ADObject -TargetPath "OU=windows,OU=$deploymentenvironment,OU=$datacenter,OU=data_center,DC=core,DC=pimcocloud,DC=net" -ErrorAction 'Stop' -Credential $credential
		}
		else
		{
			Add-Log -Type 'Error' -Message "Could not find computer in AD" -Throw
		}
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to move computer object" -Throw
	}
}

function ChefSetup
{
	try
	{
		#Chef setup
		Start-BitsTransfer -Source http://10.155.5.63:8080/cheffiles.zip -destination c:\temp -ProxyUsage NoProxy -ErrorAction 'Stop'
	}
	catch
	{
		#add logging for failed
		Add-Log -Type 'Error' -Message "Failed to download Chef setup files" -Throw
	}
	
	#Download the JSON for this service
	Expand-ZIPFile -File "C:\temp\cheffiles.zip" -Destination "C:\chef"
	
	#Create client.rb
	Add-Log -Type 'Information' -Message "Configuring Chef for environment $deploymentenvironment"
	New-item -ItemType file $clientrb
	Add-Content -Path $clientrb "log_level        :info"
	Add-Content -Path $clientrb "log_location     STDOUT"
	Add-Content -Path $clientrb "chef_server_url  'https://chef.core.pimcocloud.net/organizations/pimco'"
	Add-Content -Path $clientrb "validation_client_name 'pimco-validator'"
	Add-Content -Path $clientrb "validation_key 'c:\chef\pimco-validator.pem'"
	Add-Content -Path $clientrb "client_key 'c:\chef\client.pem'"
	#Add-Content -Path $clientrb "no_proxy  'localhost, 127.*, 10.*, *.pimcocloud.net, *.core.pimcocloud.net'"
	Add-Content -Path $clientrb "environment '$($deploymentenvironment)'"
	#Add-Content -Path $clientrb "http_proxy               'http://proxynb.pimco.imswest.sscims.com:8080'"
	#Add-Content -Path $clientrb "https_proxy              'http://proxynb.pimco.imswest.sscims.com:8080'"
	
	#Run Chef client
	#Add-Log -Type 'Information' -Message "Running Chef with base role"
	#chef-client -r "role[dc-$datacenter],role[base]"
}

function CreateFolders
{
	if ((test-path e:\apps) -eq $false)
	{
		mkdir e:\apps
	}
	
	if ((test-path e:\vendor) -eq $false)
	{
		mkdir e:\vendor
	}
	
	if ((test-path e:\services) -eq $false)
	{
		mkdir e:\services
	}
	
	if ((test-path e:\inetpub) -eq $false)
	{
		mkdir e:\inetpub
	}
	
	if ((test-path c:\tmp) -eq $false)
	{
		mkdir c:\tmp
	}
}

function EnableCliqrServices
{
	Add-Log -Type 'Information' -Message "Enabling Cliqr services"
	try
	{
		Set-Service JettyService -StartupType 'Automatic' -ErrorAction 'Stop'
		Set-Service CliQrStartupService -StartupType 'Automatic' -ErrorAction 'Stop'
		#sc.exe config JettyService start=delayed-auto
		#sc.exe config CliQrStartupService start=delayed-auto
	}
	catch
	{
		Add-Log -Type 'Error' -Message "Failed to set Cliqr services to start automatically" -Throw
	}
}

function DownloadPackages
{
	$packages = ($script:cliqrvariables | where { $_.name -eq "Packages" }).value
	$packages = $ExecutionContext.InvokeCommand.Expandstring($packages)
	$script:packagearray = $packages -split " "
	if ($script:packagearray)
	{
		foreach ($pkg in $script:packagearray)
		{
			#$pkg = $ExecutionContext.InvokeCommand.Expandstring($pkg)
			try
			{
				Start-BitsTransfer -Source $pkg -destination e:\apps -ProxyUsage NoProxy -ea 'Stop'
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to download package: $pkg - $($Error[0])"
				#agentSendLogMessage "$(executiontime) - Failed to download package: $pkg"
			}
		}
	}
}

function DownloadVendor
{
	$packages = ($script:cliqrvariables | where { $_.name -eq "Vendor" }).value
	$packages = $ExecutionContext.InvokeCommand.Expandstring($packages)
	$script:vendorpackagearray = $packages -split " "
	if ($script:vendorpackagearray)
	{
		foreach ($pkg in $script:vendorpackagearray)
		{
			try
			{
				Start-BitsTransfer -Source $pkg -destination e:\vendor -ProxyUsage NoProxy -ea 'Stop'
			}
			catch
			{
				Add-Log -Type Information -Message "Failed to download vendor package: $pkg - $($Error[0])"
				#agentSendLogMessage "$(executiontime) - Failed to download vendor package: $pkg"
			}
		}
	}
}

function ConnectVmware
{
	Add-Log -Type Information -Message "Connecting to Vmware"
	try
	{
		#Connect to VMware
		Connect-VIServer $vcenter -Credential $credential -ea 'Stop'
	}
	catch
	{
		Add-Log -Type Information -Message "Failed to connect to vcenter"
	}
}

function ExpandPackages
{
	$expandedpackages = @()
	#Expand Zips
	$downloadedzip = ls e:\apps\*.zip
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:packagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\apps\$extractpath\$basename -ea 'SilentlyContinue'
			Expand-ZIPFile E:\apps\$filename -destination e:\apps\$extractpath$basename
			$expandedpackages += "e:\apps\$extractpath"
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
		}
	}
	
	#Expand 7Zips
	$downloadedzip = ls e:\apps\*.7z
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:packagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\apps\$extractpath\$basename -ea 'SilentlyContinue'
			.'C:\Program Files\7-Zip\7z.exe' x E:\apps\$filename -oe:\apps\$extractpath$basename
			$expandedpackages += "e:\apps\$extractpath"
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
		}
	}
}

function ExpandVendor
{
	$expandedvendorpackages = @()
	
	#Expand vendor Zips
	$downloadedzip = ls e:\vendor\*.zip
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:vendorpackagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\vendor\$extractpath\$basename -ea 'SilentlyContinue'
			Expand-ZIPFile E:\apps\$filename -destination e:\apps\$extractpath$basename
			$expandedpackages += "e:\vendor\$extractpath"
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand package: $basename"
		}
	}
	
	#Expand vendor 7Zips
	$downloadedzip = ls e:\vendor\*.7z
	foreach ($zip in $downloadedzip)
	{
		try
		{
			Add-Log -Type Information -Message "Expanding $($zip.basename)"
			$basename = $zip.basename
			$filename = ($zip -split "\\")[-1]
			$extractpath = (($script:vendorpackagearray | where { $_ -like "*$filename" }) -split "/artifactory/")[1] -replace $filename
			$extractpath = $extractpath -replace "/", "\"
			mkdir e:\vendor\$extractpath\$basename -ea 'SilentlyContinue'
			.'C:\Program Files\7-Zip\7z.exe' x E:\vendor\$filename -oe:\vendor\$extractpath$basename
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to expand vendor package: $basename - $($Error[0])"
			#agentSendLogMessage "$(executiontime) - Failed to expand vendor package: $basename"
		}
	}
}

function GetEnvVariables
{
	Add-Log -Type Information -Message "Getting Cliqr variables"
	try
	{
		#Get Notes
		$script:vmwarevariables = ((get-view -ViewType virtualmachine -Filter @{ Name = $server } -ErrorAction 'Stop').config.annotation) -split "\n"
	}
	catch
	{
		Add-Log -Type Information -Message "Failed to pull vmware notes - $($Error[0])"
	}
	#parent job ID
	#$jobid = ($vmwarevariables | where { $_ -like "eNV_JOB_ID=*" }) -replace "eNV_JOB_ID="
	#$deploymentname = ($vmwarevariables | where { $_ -like "Name=*" }) -replace "Name="
	#$jobid = (c:\temp\curl.exe -k -X GET -H "Accept: application/json" -u $script:cliqruser "https://$url/v2/jobs?search=`\[deploymentEntity.name,eq,$deploymentname`\]" -s | convertfrom-json).jobs.id
	#(c:\temp\curl.exe -k -X GET -H "Accept: application/json" -u $script:cliqruser "https://$url/v1/virtualMachines?startDate=1495393867211&endDate=1497985867212&listType=MANAGED_VMS&size=50&includeFilters=true&sort=runTime-&status=Running%2CStarting%2CStopped%2CError%2CStopping" -s | convertfrom-json).details.virtualmachinedetails
	#(c:\temp\curl.exe -k -X GET -H "Accept: application/json" -u $script:cliqruser "https://$url/v1/virtualMachines?Type=MANAGED_VMS&size=50&includeFilters=true&sort=runTime-&status=Running%2CStarting%2CStopped%2CError%2CStopping" -s | convertfrom-json).details.virtualmachinedetails
	<#
	try
	{
		Add-Log -Type Information -Message "Checking all jobs for a VM with $server"
		function FindJob
		{
			#get all jobs
			$jobs = (c:\temp\curl.exe -k -X GET -H "Accept: application/json" -u $script:cliqruser "https://$url/v2/jobs?showAllJobs" -s | ConvertFrom-Json -ErrorAction 'Stop').jobs
			foreach ($job in $jobs)
			{
				write-host "processing $($job.id)"
				#get details of the top level job
				$topjobdetails = c:\temp\curl.exe -k -X GET -H "Accept: application/json" -u $script:cliqruser "https://$url/v2/jobs/$($job.id)" -s | ConvertFrom-Json -ErrorAction 'Stop'
				
				if ($topjobdetails.childjobs -notlike "")
				{
					foreach ($childjob in $topjobdetails.childjobs)
					{
						write-host "processing childjob $($childjob.id)"
						#Find the child job we want
						$childjobdetails = c:\temp\curl.exe -k -X GET -H "Accept: application/json" -u $script:cliqruser "https://$url/v2/jobs/$($childjob.id)?includeNodeDetails=true" -s | ConvertFrom-Json -ErrorAction 'Stop'
						if (($childjobdetails.virtualMachines.hostname -contains $server) -eq $true)
						{
							$script:cliqrvariables = $childjobdetails.parameters.appparams
						}
					}
				}
			}
		}
		$counter = 0
		do { FindJob; if ($script:cliqrvariables -eq $null) { Add-Log -Type Information -Message "Didn't find a matching VM name $server - counter is at $counter"; sleep 6; $counter++ } }
		until ($script:cliqrvariables -ne $null -or $counter -ge 40)
		#find the right job ensure why this happens right now, sometimes you get the parentjob sometimes you get the node job?
		#if ($job.jobs)
		#{
		#	$job = $job.jobs | where { $_.virtualmachines.hostname -eq $server }
		#}
	}
	catch
	{
		Add-Log -Type Information -Message "Failed to query job info from Cliqr API - $($Error[0])"
	}
	#$script:cliqrvariables = $job.parameters.appparams
	#$script:cliqrvariables
	#>
}

function GetVMDepartmentFolder
{
	Add-Log -Type Information -Message "Looking up deployment department name"
	$departmentname = (get-view (get-view (get-view -ViewType virtualmachine -Filter @{ Name = $server }).parent).parent).name
	
	$script:cliqruser = switch ($departmentname)
	{
		"fotech" { "cloud-frontofficetec_m:5DB9F20074DD8A59" }
		"techservices" { "cloud-technologyserv_l:79A795B51117AF01" }
		"pimcocommon" { "cloud-pimcocommon_G:031BC9BC59451B35" }
		"analytics" { "cloud-analytics_F:A15088C9A3E2BF2F" }
		"pmapps" { "cloud-pmapplications_K:799183C045731A09" }
		"cftech" { "cloud-clientfacingte_H:1E06FFCF291DDB18" }
		"business" { "cloud-businessfuncti_J:E3F3753E5D12BAB9" }
		"tlc" { "cloud-tradelegalcomp_C:4AB0340F5966EFF9" }
	}
	Add-Log -Type Information -Message "using $script:cliqruser to query cloudcenter"
}

function ChefRunlist
{
	$runlist = ($script:cliqrvariables | where { $_.name -eq "runlist" }).value
	if ($runlist)
	{
		Add-Log -Type Information -Message "Adding additional Chef runlist commands: $runlist"
		#agentSendLogMessage "$(executiontime) - Adding additional Chef runlist commands: $($env:runlist)"
		chef-client -r "role[dc-$datacenter],role[base],$runlist"
	}
	else
	{
		Add-Log -Type Information -Message "Running Chef with default recipes"
		#agentSendLogMessage "$(executiontime) - Running Chef with default recipes"
		chef-client -r "role[dc-$datacenter],role[base]"
	}
}

function GrantAccessRights
{
	#Give user admin rights to sandbox and RDP to dev/beta
	#$userid = ($script:cliqrvariables | where { $_.name -eq "launchUserId" }).value
	#$userid = ($script:cliqrvariables | where { $_.name -eq "l" }).value
	try
	{
		Add-Log -Type Information -Message "Getting user external ID from vmware variables"
		#$Userexternalid = (c:\temp\curl.exe -k -X GET -H "Accept: application/json" -u $script:cliqruser "https://$url/v1/users/$userid" -s | ConvertFrom-Json -ErrorAction 'Stop').externalId
		$Userexternalid = ($script:vmwarevariables | where { $_ -like "User_external_ID=*" }) -replace "User_External_ID="
	}
	catch
	{
		Add-Log -Type Information -Message "Failed to lookup $userid"
	}
	
	if ($deploymentenvironment -eq "sandbox")
	{
		Add-Log -Type Information -Message "Adding pimco\$userExternalId) to local admins group"
		#agentSendLogMessage "$(executiontime) - Adding pimco\$($env:userExternalId) to local admins group"
		try
		{
			([ADSI]"WinNT://localhost/Administrators,group").Add("WinNT://pimco.imswest.sscims.com/$($userExternalId)") | Out-Null
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to add $userExternalId to local admins group"
			#agentSendLogMessage "$(executiontime) - Failed to add $userlogin to local admins group"
		}
	}
	if ($deploymentenvironment -eq "dev" -or $deploymentenvironment -eq "beta")
	{
		Add-Log -Type Information -Message "Adding pimco\$($userExternalId) to remote desktop users group"
		#agentSendLogMessage "$(executiontime) - Adding pimco\$($env:userExternalId) to remote desktop users group"
		try
		{
			([ADSI]"WinNT://localhost/Remote Desktop Users,group").Add("WinNT://pimco.imswest.sscims.com/$($userExternalId)") | Out-Null
		}
		catch
		{
			Add-Log -Type Information -Message "Failed to add $userExternalId to remote desktop users group"
			#agentSendLogMessage "$(executiontime) - Failed to add $userlogin to remote desktop users group"
		}
	}
	
}

function SetupGit
{
	mkdir C:\Users\Administrator\.ssh
	$File = New-Item -Type File -Name "known_hosts" -Path "C:\Users\Administrator\.ssh"
	$File | Set-Content -Value "[pimcocm.pimco.imswest.sscims.com]:29418,[144.77.120.103]:29418 ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAxgxagfLOjW26DNwnOXIY3M73/bHJhf4N/DoBAhmeT0ocV+ionQ4P7moaGyKXCcd3gAOd8sPOf2ZfOOrQOcBl998FznmHNzd3wqw6bTb+ahdl//BqzuNYw1XFYV5dmxHGy77uY9YtjaeBYRcuX/fCYIBR0UebZRMNGNSXL68RF6usbRNC7tRUmYP/63QQshTTry5g9owRQEbzxzniJgGPvitqy/iGLntk98+lDrYLdumXFOX1zFwWOySwQvfqXIS3Kr32ufVCSDFjq41l0yvo+bLeTjB9N8BgA4CPzHUieZBV9t2YEAKRCNYRWUjXmJuNax29AW8thaQUWy3DPT3t1Q=="
	$File = New-Item -Type File -Name "id_rsa.pub" -Path "C:\Users\Administrator\.ssh"
	$File | Set-Content -Value "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDV2sQeHoqi1pIO64Mb0W2smptcvJQbuzn962il1pkRnrHtiQAlFOlbxmxf3Qee/xDMhOYXS/Hbln16o8d50BxzXdhtf6BcYyZhtj+O4y11fq5tNNUlfIvJxCbNlqQASRSVymIKB+8SDhAGHsAIPuG/JRurt1nV8oOhMFUQZOMwVKUDIRDh1Gi18NscFKiTvRvpdykeC5mmcXXw/oC/ZnVDMVKsffk8CTqTIdVDWgiHOBmGZOVONmpS8KnRWjAETVEJ/MCJoDFbItLY+8px9rWY8gl/koI5si8PYsyIMI/+g9WU3yt+POxOIDUtZlNj7VoE3e3Ram/U57ylAK1HHc7t CLV035SW-68A325+Administrator@clv035sw-68a325"
	$File = New-Item -Type File -Name "id_rsa" -Path "C:\Users\Administrator\.ssh"
	$File | Set-Content -value "-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA1drEHh6KotaSDuuDG9FtrJqbXLyUG7s5/etopdaZEZ6x7YkA
JRTpW8ZsX90Hnv8QzITmF0vx25Z9eqPHedAcc13YbX+gXGMmYbY/juMtdX6ubTTV
JXyLycQmzZakAEkUlcpiCgfvEg4QBh7ACD7hvyUbq7dZ1fKDoTBVEGTjMFSlAyEQ
4dRotfDbHBSok70b6XcpHguZpnF18P6Av2Z1QzFSrH35PAk6kyHVQ1oIhzgZhmTl
TjZqUvCp0VowBE1RCfzAiaAxWyLS2PvKcfa1mPIJf5KCObIvD2LMiDCP/oPVlN8r
fjzsTiA1LWZTY+1aBN3t0Wpv1Oe8pQCtRx3O7QIDAQABAoIBAGVOezVhdn9pckuL
GdLlxTTNEOg/lVIFwZUeHbbiECUerl8+VUk7vMhzGQfYpzGU1xproqxKl8pUYiDk
0SxNgAzO2iYVHZxmg9oqAbXovLI6TtsA+jAF7hqox1EBGbPg6tWCyCrEU2aULtcX
XhUJ5Nst8wvHkdEeT2jego1/nXhY4kmyAdSqaeV7GOo9tSZBcblbJmwYI7kGRMHI
tFsmkw27enrf8qcX8lkhvdozHZBe1w82VzHBC4nSbvbtHphjvXVRCKXSwYB1YeqG
h5GEcW3qHdA//hgOVAMRVCurro+WUTRDP4KDKVllJU7D8PgRzutjEJejx9Ry3vyv
QqsQlukCgYEA/vwkqijDUtyTVjhrH7moFqGtwGETO3T9b5yRvnsqNcQtsOdxURMe
BMQYNFYBIwag9T2rntKfHmb1YUgMba5DenxeKfX4XeQ7/kOgOrerAGkPzAFeRx5B
STQaxgdw0+bO6ycEUEyfi+xp41OAh6figwswQfCKqORxo2WuRPf6/8sCgYEA1rS0
5bg5QR/Cj2qbvHAmu5sHiPgWkNAemYiswwa/LHIdAsVPTbYEN1Vk98GWP1Yrp2A2
egS3l9Nkiwk2XIVIxYI0BPcBmH8sVvNjsOiWdOZNPYXfzqhb1mRyqaFSOmy6/qBq
Izs5Tma0f/Zq/BJNxW9QQ0hSvqzSwN9J+BSppScCgYBdrimSUrOgZ+XB0ayZ1U4K
MpBxk7jLKWpLbUymnP2fD1pyGjYpwUpQGfOClu6H/dF5CJVbHqrTMqSIfz4BtfqY
r8SwyevcIxRfkFz39a7f0bm6C+6lVlpKGNiVVPqA/9WZ05XkIqKjd9JXcMBSFr5D
wwKR11w6POP7Uko6kJkpDQKBgEBlInxjrIhjxi7NgrgZywQpkzD5d4snYIYb//Te
aSgjcaALHaXpGYqfChFk9nM4nQ8uRCiEkavvsxAgSzWkpBbY3lE+5DOgsOPDS/sb
R0T4beIt7NpGlITQy7Mkt0zen5cO9cZrVNy24RwgBCZmNv0oTaJgZrDZlLxUPBMz
302xAoGBANJVbMaVBUdQn+9On128kosJd+klMRlUJSinC2qpdP+JgJUBaeXa67fA
ikctXpdx6DhS6BKvBpKYVGYmKkXHN25Stb0ufGToMZXhlQwrm6AGJ44/p3wI/2FZ
MFzLGxf2TneB1BukpCE+HavlPMyj0LjqAvn96QNi/J7K1ke3mQVO
-----END RSA PRIVATE KEY-----"
	$File = New-Item -Type File -Name ".gitconfig" -Path "C:\Users\Administrator\"
	$File | Set-Content -Value "[user]
  name = svc_iisadmin
  email = Technology-Cloud@pimco.com
[http]
  sslVerify = false"
}

function GetCliqrUtils
{
	git clone ssh://svc_iisadmin@pimcocm.pimco.imswest.sscims.com:29418/cliqr-scripts c:\pimcloud\cliqr-scripts
	if ($lastexitcode -ne 0)
	{
		Add-Log -Type Information -Message "Failed to git clone from cliqr-scripts"
		agentSendLogMessage "$(executiontime) - Failed to git clone from cliqr-scripts"
	}
}

function StopandDisableIIS
{
	iisreset /stop
	Set-Service IISADMIN -StartupType Disabled
	Set-Service W3SVC -StartupType Disabled
}

function SetupCylance
{
	C:\pimcloud\cliqr-scripts\windows\utils\psexec.exe -s /accepteula powershell.exe -command "New-ItemProperty -Path HKLM:\SOFTWARE\Cylance\Desktop\ -PropertyType String -Name InstallToken -Value GZVFiH3P7avGTWrKL1xCww1B"
}

workflow WorkflowStep
{
	Restart-Computer -Force
	$logfile = "c:\temp\OSinit.txt"
	Add-Content -Path $logfile "$(Get-Date -Format "ddd MM/dd/yyyy HH:mm:ss.ff") - Information : Resuming from reboot"
	Add-Content -Path $logfile "$(Get-Date -Format "ddd MM/dd/yyyy HH:mm:ss.ff") - Information : OSinit script complete"
}

#endregion

#region Main
Add-Log -Type 'Information' -Message "OSinit script started"
PartitionDisks
CreateFolders
ChefSetup
MoveADComputer
ConnectVmware
GetVMDepartmentFolder
GetEnvVariables
#DownloadPackages
#DownloadVendor
#ExpandPackages
#ExpandVendor
#SetupGit
#GetCliqrUtils
EnableCliqrServices
GrantAccessRights
SetupCylance
ChefRunlist
StopandDisableIIS
Add-Log -Type 'Information' -Message "Rebooting..."
WorkflowStep

#endregion