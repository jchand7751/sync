default['svc_accounts'] = %w(svc_lxadmin svc_pmunix svc_centrify)
