provides :svcAccount

actions :create, :delete_homedir
default_action :create

attribute :name, kind_of: String, required: true, name_attribute: true
attribute :ssh_keys, kind_of: [Hash, NilClass], required: false
attribute :keytabs, kind_of: [Hash, NilClass], required: false
