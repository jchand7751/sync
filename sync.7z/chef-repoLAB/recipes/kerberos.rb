namespace = node['namespace']
directory node[namespace]['kerberos']['keytabdir']
