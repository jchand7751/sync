
file 'berkshelf-complete.sh' do
  path '/etc/bash_completion.d/berkshelf-complete.sh'
  owner 'root'
  group 'root'
  mode '0644'
end
