template '/root/prep_vm_cleanup.sh' do
  user 'root'
  group 'root'
  mode '0700'
end

template '/root/deprovision.sh' do
  user 'root'
  group 'root'
  mode '0700'
end
