#### PROXY
# define bash & csh proxy ENV settings based from pimco-environments-*
#  attributes

# puts node.default.flatten

namespace = node['namespace']

template '/etc/profile.d/proxy.sh' do
  #  local true
  owner 'root'
  group 'root'
  mode '0644'
  variables(
    http_proxy: node[namespace]['proxy']['http'],
    https_proxy: node[namespace]['proxy']['https'],
    ftp_proxy: node[namespace]['proxy']['ftp'],
    no_proxy: node[namespace]['proxy']['no_proxy']
  )
end

template '/etc/profile.d/proxy.csh' do
  #  local true
  owner 'root'
  group 'root'
  mode '0644'
  variables(
    http_proxy: node[namespace]['proxy']['http'],
    https_proxy: node[namespace]['proxy']['https'],
    ftp_proxy: node[namespace]['proxy']['ftp'],
    no_proxy: node[namespace]['proxy']['no_proxy']
  )
end
