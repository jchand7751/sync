# Define /etc/ssh/sshd_config

package 'openssh-server'

template '/etc/ssh/sshd_config'

service 'sshd'
