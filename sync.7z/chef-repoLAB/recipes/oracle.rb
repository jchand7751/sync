namespace = node['namespace']

directory '/base/vendor/oracle' do
  owner node[namespace]['base']['vendor']['owner'] || 'nobody'
  group node[namespace]['base']['vendor']['group'] || 'nobody'
end

### EWventually need to put oracle client in some sort of fast sync recipe?
### CURRENTLY: baked in as it's ~1G big
