namespace = node['namespace']

template '/etc/wgetrc' do
  owner 'root'
  group 'root'
  mode '0644'
  variables(
    http_proxy: node[namespace]['proxy']['http'],
    https_proxy: node[namespace]['proxy']['https'],
    ftp_proxy: node[namespace]['proxy']['ftp'],
    no_proxy: node[namespace]['proxy']['no_proxy']
  )
end
