### CREATE /base{apps,logs,data} AND POPULATE /base/vendor WITH STANDARD GIT REPOS & SOFTWARE
include_recipe 'pimco-linux-std::svc_accounts'

namespace = node['namespace']
svc_acct = node[namespace]['base']['vendor']['owner']
svc_grp = node[namespace]['base']['vendor']['group']

### BASE DIRECTORIES SETUP
directory '/base'
%w(/base/data /base/logs /base/apps /base/apps/web /base/apps/bin /base/vendor ).each do |d|
  directory d do
    owner svc_acct || 'nobody'
    group svc_grp || 'nobody'
    mode '0775'
  end
end

### SET UP SSH_WRAPPER FOR FUTURE GIT DEPLOYMENTS INTO /base/vendor
%w( /base/vendor/usr /base/vendor/usr/bin  ).each do |d|
  directory d do
    owner svc_acct || 'nobody'
    group svc_grp || 'nobody'
    mode '0755'
  end
end

### CREATE /base/apps/bin/{apps,webapps} LIFECYCLE SCRIPTS
%w(/base/apps/bin/apps /base/apps/bin/webapps).each do |f|
  template f do
    owner svc_acct || 'nobody'
    group svc_grp || 'nobody'
    mode '0755'
  end
end

### CRON: CLEAN UP LOGS DIR
cron '/base/logs cleanup' do
  minute '0'
  hour '1'
  weekday '*'
  command 'find /base/logs -type f -mtime +30 -exec rm -f {} \\;'
  only_if { File.exist?('/base/logs') }
end

### DROP OFF THE README - YES IN ALL 4 LOCATIONS
%w[ /base/apps/README /base/data/README /base/logs/README /base/vendor/README ].each do |f|
  template f do
    user 'svc_lxadmin'
    group 'svc_lxadmin'
    mode '0444'
  end
end
