#
# Cookbook Name:: pimco-linux-misc
# Recipe:: default
#
# Copyright 2015, PIMCO
#
# All rights reserved - Do Not Redistribute

include_recipe 'pimco-linux-std::install_packages'
include_recipe 'pimco-linux-std::kerberos'
include_recipe 'pimco-linux-std::svc_accounts'

### BASE + VENDOR_REPOS SHOULD BE CALLED FROM CLIQR-NODE ROLE,
### NOT DEFAULT FOR ALL MGMT HOSTS
# include_recipe 'pimco-linux-std::base'
# include_recipe 'pimco-linux-std::vendor_repos'
###

include_recipe 'pimco-linux-std::proxy'
include_recipe 'pimco-linux-std::wget'
include_recipe 'pimco-linux-std::aliases'
# DEBUGGING  vmware-tools don't include for all yet
include_recipe 'pimco-linux-std::vmware-tools'
include_recipe 'pimco-linux-std::vm_cleanup_scripts'
