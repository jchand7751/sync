### GIT REPOS (INTERNAL & EXTERNAL) PUT IN VENDOR AREA
# default['pimco-environments-cloud'][:base][:vendor][:repos] = {
### LOOP AND CREATE ALL REPOS AS RESOURCES, BUT REMOVE IF DISABLED

namespace = node['namespace']
svc_acct = node[namespace]['base']['vendor']['owner']
svc_grp  = node[namespace]['base']['vendor']['group']

include_recipe 'pimco-linux-std::base'
include_recipe 'pimco-linux-std::svc_accounts'

template '/base/vendor/usr/bin/ssh_wrapper' do
  owner svc_acct || 'nobody'
  group svc_grp || 'nobody'
  mode '0755'
end

namespace = node['namespace']
node[namespace]['base']['vendor']['repos'].each_pair do |name, repo|
  ### CHECK IF REPO ALREADY EXISTS
  ### IF NOT CLONE IT AS "account"
  ### IF EXISTS BUT DISABLED, THEN REMOVE IT
  if repo['enabled'] == true
    git name do
      destination '/base/vendor/' + name
      repository repo['source']
      user repo['account'] # 'svc_lxadmin'   #repo[:account]
      ssh_wrapper '/base/vendor/usr/bin/ssh_wrapper'
    end
  else
    execute "rm -rf /base/vendor/#{repo}" do
      only_if { ::File.directory?("/base/vendor/#{repo}") }
    end
  end
end

### ADD /etc/profile.d/base_env.sh TO ADD VENDOR BIN PATHS TO $PATH
template '/etc/profile.d/base_env.sh' do
  #  local true
  owner 'root'
  group 'root'
  mode '0644'
end
template '/etc/profile.d/base_env.csh' do
  #  local true
  owner 'root'
  group 'root'
  mode '0644'
end

### SOFTWARE:  INSTALL CUSTOM RPMS & TARBALLS
# default['pimco-environments-cloud'][:base][:vendor][:rpms]     = {}
# node[namespace][:base][:vendor][:rpms].each_pair do |name, repo|

# default['pimco-environments-cloud'][:base][:vendor][:tarballs] = {}
# node[namespace][:base][:vendor][:tarballs].each_pair do |name, repo|
