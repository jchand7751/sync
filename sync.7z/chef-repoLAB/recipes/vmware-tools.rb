# INSTALL & START VMWARE TOOLS IF WE ARE VMWARE

begin
  unless node['vmware'].nil? && node['virtualization']['system']['vmware'].nil?
    package 'vmware-tools-foundation'
    package 'vmware-tools-esx-nox'

    #    template '/etc/init.d/vmware-tools' do
    #      mode '0755'
    #      owner 'root'
    #      group 'root'
    #    end

    #    service 'vmware-tools' do
    #      action [:disable, :stop]
    #    end

    # TESTINGT SIMPLER VMWARE TOOLS SERVICE SETUP
    template '/etc/init.d/vmtoolsd' do
      mode '0755'
      owner 'root'
      group 'root'
    end

    service 'vmtoolsd' do
      action [:enable, :start]
    end

  end
rescue Chef::Exceptions::FileNotFound => e
  Chef::Log.debug(e)
end
