# pimco-role-base::install_packages
#
# Installs packages listed in pimco-environments-cloud cookbook attributes
# == ATTRIBUTE driven package installs
#
# Pin ALL base package names & versions in pimco-environments-cloud/attributes/default.rb

# puts("Now inside pimco-role-base::install_packages - My environment is: " + node.chef_environment)

#  EXAMPLE OHAI
#  "platform": "centos",
#  "platform_version": "6.6",
#  "platform_family": "rhel",

env       = node.chef_environment || 'sandbox'
# platform  = node['platform']
pf        = node['platform_family']
pfver     = node['platform_version'].to_i.floor.to_s
namespace = node['namespace']

# puts env
# puts pf
# puts pfver

### FIRST CLEAN SOME CACHE
# execute 'yum clean rpmdb packages metadata' do
#  action :nothing
# end.run_action(:run)

node[namespace][env][pf][pfver]['rpms'].each do |p, h|
  if h['enabled']
    yum_package p do
      version h['version']
      allow_downgrade true
      #      action :nothing
      #    end.run_action(:install)
    end
  else
    yum_package p do
      action :remove
    end
  end
end
