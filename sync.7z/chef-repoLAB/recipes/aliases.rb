#### PROXY
# define bash & csh aliases based from pimco-environments-* attributes

# puts node.default.flatten

namespace = node['namespace']

template '/etc/profile.d/aliases.sh'
template '/etc/profile.d/aliases.csh'
