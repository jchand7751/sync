### ENSURE CLIQR VARS ARE SOURCED INTO USER'S SHELL
template '/etc/profile.d/cliqr-vars.sh'
