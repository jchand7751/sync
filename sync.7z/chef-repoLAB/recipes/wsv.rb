#
# Cookbook Name:: pimco-linux-misc
# Recipe:: default
#
# Copyright 2015, PIMCO
#
# All rights reserved - Do Not Redistribute

include_recipe 'pimco-linux-std::install_packages'
include_recipe 'pimco-linux-std::kerberos'
include_recipe 'pimco-linux-std::svc_accounts'
include_recipe 'pimco-linux-std::base'
include_recipe 'pimco-linux-std::vendor_repos'
include_recipe 'pimco-linux-std::proxy'
include_recipe 'pimco-linux-std::aliases'
include_recipe 'pimco-linux-std::vmware-tools'
include_recipe 'pimco-linux-std::vm_cleanup_scripts'
