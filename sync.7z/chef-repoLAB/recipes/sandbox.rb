namespace = node['namespace']
svc_acct = node[namespace]['base']['vendor']['owner']
svc_grp = node[namespace]['base']['vendor']['group']

### READ CLIQR VARS INTO OUR ENVIRONMENT

begin
  File.readlines('/usr/local/osmosix/etc/userenv').each do |line|
    values = line.split[1].split('=')
    ENV[values[0]] = values[1].gsub!(/^\"|\"?$/, '')
  end
rescue StandardError => e
  puts e
end

### ADD SANDBOX DIR IF WE ARE IN SANDBOX
### ADD 777 PERMS IF WE ARE IN SANDBOX ONLY
if node.environment == 'sandbox'
  %w( /base/vendor/sandbox /base/data/sandbox /base/logs/sandbox /base/apps/sandbox ).each do |d|
    directory d do
      owner ENV['userExternalId'] || svc_acct || 'nobody'
      group svc_grp || 'nobody'
      mode '0775'
    end
  end
else
  %w( /base/vendor/sandbox /base/logs/sandbox /base/apps/sandbox ).each do |d|
    directory d do
      recursive true
      action :delete
    end
  end
end
