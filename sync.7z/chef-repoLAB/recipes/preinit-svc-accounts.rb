#
# PREINITIALIZING SERVICE ACCOUNTS - DUE TO SOME SOFTWARE INSTALLERS' FAILURE
#  TO HANDLE LDAP (AD) ACCOUNTS EXISTENCE.  THEY DEMAND USING LOCAL ACCOUNTS W/O
#  EXCEPTION
#

namespace = node['namespace']

### PREINITIALIZE svc_lxadmin SO UID/GID EXSIT BEFORE ADJOIN
# group node[namespace]['base']['vendor']['group'] do
#   gid node[namespace]['base']['vendor']['uid']
#   ignore_failure true
# end.run_action(:create)

ohai 'reload_group' do
  action :nothing
  plugin 'group'
end

ohai 'reload_passwd' do
  action :nothing
  plugin 'passwd'
end

user = node[namespace]['base']['vendor']['owner']
gid = node[namespace]['base']['vendor']['uid']

### ADD A LOCAL GROUP NAMED AFTER /base/vendor OWNER SO ANACONDA WON'T BLOW UP
### NOTE: CHEF CAN'T TELL IF AD GROUP IS CREATED LOCALLY OR NOT, AND FAILS
###  TO GROUPADD LOCALLY IF EXISTS IN AD
bash "lgroupadd #{user}" do
  code "lgroupadd -g #{gid} #{user}"
  not_if "grep #{user} /etc/group"
  ignore_failure true
  notifies :reload, 'ohai[reload_group]', :immediately
end.run_action(:run)

user node[namespace]['base']['vendor']['owner'] do
  uid node[namespace]['base']['vendor']['uid']
  gid node[namespace]['base']['vendor']['group']
  manage_home false
  ignore_failure true
  action :create
  notifies :reload, 'ohai[reload_passwd]', :immediately
end.run_action(:create)
