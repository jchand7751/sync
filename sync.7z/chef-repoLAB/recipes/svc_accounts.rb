### FROM DATABAG, CREATES LOCAL ACCOUNT'S HOMEDIR AND SSH KEYS FOR CHEF COOKBOOKS, GIT REPOS, ...
### DATA BAG:  accounts
###   https://blog.conjur.net/lets-talk-encrypted-data-bags
namespace = node['namespace']

### PUT THE KEY LOCALLAY
include_recipe 'pimco-data-bags::accounts'

### DATA BAG: SVC ACCOUNTS
### GET CREDS TO DO STUFF
secret = Chef::EncryptedDataBagItem.load_secret("#{node[namespace]['data_bag']['secretpath']}/accounts.key")

begin
  node['svc_accounts'].each do |account|
    # FLUSH CACHE IF CENTRIFY CAN'T FIND THE ACCOUNT
    # LAME BUT HAPPENS SOMETIMES IF ACCOUNTS ARE MOVED IN OR OUT OF ROLES...
    execute "adflush  #{account}" do
      command 'adflush'
      not_if { "adquery user #{account}" }
    end

    #  Chef::Resource::svcAccount do
    a = Chef::EncryptedDataBagItem.load('accounts', account, secret)
    h = a.to_hash
    svcAccount account do
      name account
      ssh_keys h['ssh_keys'] || {}
      keytabs h['keytabs'] || {}
    end
  end

rescue Chef::Exceptions::FileNotFound => e
  Chef::Log.debug(e)
end
