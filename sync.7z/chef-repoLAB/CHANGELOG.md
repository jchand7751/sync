pimco-linux-std CHANGELOG
==========================

This file is used to list changes made in each version of the pimco-linux-std cookbook.

0.1.54
-----
- mvander - fixed adflush typo

0.1.53
-----
- mvander - updated proxy scripts to add HTTP_PROXY & HTTPS_PROXY

0.1.49
-----
- mvander - PLACEHOLDER -testing different init script for vmware tools (vmtoolsd)

0.1.48
-----
- mvander - ensured prep_vm_cleanup.sh.erb populates the backup krb5.conf

0.1.47
-----
- mvander - added ssh_wrapper and debugging vmware-tools issue

0.1.46
-----
- mvander - updated sshd_config w/ header and updated prep_vm_cleanup.sh.erb to save eth0

0.1.45
-----
- mvander - updated /etc/init.d/vmware-tools and prep_vm_cleanup.sh.erb to remove pidfile properly

0.1.44
-----
- mvander - updated /etc/init.d/vmware-tools to remove pidfile properly

0.1.43
-----
- mvander - prep_vm_cleanup.sh now cleans up vmware pid it's tools always leave behind

0.1.42
-----
- mvander - updated /etc/wgetrc for no_proxy and syntax fix

0.1.41
-----
- mvander - reorganized ssh_wrapper and updated /etc/init.d/vmware-tools

0.1.40
-----
- mvander - updated default.rb

0.1.39
-----
- mvander - added /etc/wgetrc

0.1.38
-----
- mvander - added trap for cliqr-vars.sh.erb so we can exit cleanly if var names are borked

0.1.37
-----
- mvander - added additional check if we are in vmware

0.1.36
-----
- mvander - added wsv.rb for future segmentation of WSV standard from MGMT nodes

0.1.35
-----
- mvander - added wsv.rb for future segmentation of WSV standard from MGMT nodes

0.1.34
-----
- mvander - (workaround) ensured cliqr-vars.sh exits 0 so cliqr build won't fail if App Name has special characters

0.1.33
-----
- mvander - updated deprovision.sh.erb

0.1.32
-----
- mvander - reorganized templates and added ohai_reload resource, added sshd.rb

0.1.31
-----
- mvander - added cliqr-vars.csh.erb and removed superfluous oracle.sh

0.1.30
-----
- mvander - added base_env.csh

0.1.29
-----
- mvander - added more cleanup into prep_vm_cleanup.sh.erb (tns_admin, chef-client, pimunix)

0.1.28
-----
- mvander - yum makecach added to prep_vm_cleanup.sh

0.1.27
-----
- mvander - renamed alias ps -> pstop

0.1.26
-----
- mvander - wrapped sandbox.rb stuff in begin catch block

0.1.25
-----
- mvander - added vm_clean_scripts recipe to regulate vm prep & deprovision for testing anything, anywhere

0.1.24
-----
- mvander - added vmware-tools.rb to ensure it's installed and running

0.1.23
-----
- mvander - added preinit-svc-accounts.rb to seed uid/gid for anaconda installer

0.1.22
-----
- mvander - made 777 dirs for sandbox in /base for now till we can whitelist software & process for mgmt

0.1.21
-----
- mvander - updated /base/apps/bin/apps & webapps to ignore meaningless dirs

0.1.20
-----
- mvander - added /base/vendor/sandbox for devs

0.1.19
-----
- mvander - added kerberos keytabs to accounts databag and enabled provider to create from databag

0.1.18
-----
- mvander - moved tns_admin to new cookbook pimco-oracle-client

0.1.17
-----
- mvander - testing package installation in converge phase and not compile phase...

0.1.16
-----
- mvander - fixed linting

0.1.11
-----
- mvander - added /etc/profile.d/base_vendor.sh to add to PATH

0.1.10
-----
- mvander - added standard environment variables for ORACLE_HOME ORACLE_LIB JAVA_HOME PYTHON_HOME LD_LIBRARY_PATH MACHTYPE_ARCH BIT

0.1.9
-----
- mvander - added /base/apps/bin/{apps,webapps} scripts to manage apps on cliqr deployments

0.1.8
-----
- mvander - added crontab to clean up /base/logs (keep 30 days worth)

0.1.7
-----
- mvander - svc_accounts now provisioned through LWRP svcAccount from 'accounts' databag

0.1.4
-----
- mvander - updated aliases files and added /base/{apps,vendor,data,logs}, added accounts data bag, added git repos for /base/vendor/...

0.1.1
-----
- mvander - added 

0.1.0
-----
- mvander - Initial release of pimco-linux-std

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
